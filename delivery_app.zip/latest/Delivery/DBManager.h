//
//  DBManager.h
//  SQlite_demo
//
//  Created by Barani Elangovan on 10/03/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "singleton.h"

@interface DBManager : NSObject
{
    NSString *databasePath;
    singleton *manage;
}

@property(strong,nonatomic)NSMutableDictionary *arrLocal;
@property(strong,nonatomic)NSMutableArray *arr_LocalValues;

+(DBManager*)getSharedInstance;
-(BOOL)createDB;
-(BOOL) saveData:(NSString*)Logid StoreID:(NSString*)StoreID;
-(NSString *) saveBarCodeData:(NSString*)Logid isPOS:(NSString*)isPOS StoreID:(NSString*)StoreID;
-(BOOL) saveDataDelivery:(NSString*)Logid;
    //-(BOOL) saveData:(NSString*)Logid;

-(BOOL) saveDataSig:(NSString*)Name Relation:(NSString*)Relation
          Signature:(NSString*)Signature XmlTrans:(NSString*)XmlTrans IsPOS:(NSString*)IsPOS StoreID:(NSString*)StoreID UserName:(NSString*)UserName Password:(NSString*)Password CounsellingType:(NSString*)CounsellingType POSID:(NSString*)POSID RxID:(NSString*)RxID DeliveryComments:(NSString*)DeliveryComments DeletedRxList:(NSString*)DeletedRxList;


-(BOOL) deleteRxIDList:(NSString*)StoreID LogID:(NSString*)LogID RxID:(NSString*)RxID;

-(NSMutableArray*)retrive_values:(NSString*)SDate EDate:(NSString*)EDate StoreID:(NSString*)StoreID;
-(NSMutableArray*)retrive_LocalValues:(NSString*)StoreID;


-(NSMutableArray*)retrive_DeliveredValues;
-(NSMutableArray*) findProductDetail_byLogid:(NSString*)Logid;
-(NSMutableArray*) findSignature;


-(BOOL)deleteLocalPastValue;


-(BOOL)deleteSig:(NSString*)Logid StoreID:(NSString*)StoreID;
-(BOOL)deleteLog:(NSString*)Logid;
-(BOOL)deleteLocalArray:(NSString*)Logid StoreID:(NSString*)StoreID;


-(BOOL) saveDataRxNum:(NSString*)Logid StoreID:(NSString*)StoreID;
-(BOOL) saveDataLogNum:(NSString*)Logid StoreID:(NSString*)StoreID;
-(BOOL) saveDataPOSNum:(NSString*)Logid StoreID:(NSString*)StoreID;

-(BOOL)deleteLocalRxList:(NSString*)Logid;


-(BOOL)deleteLog;


-(BOOL)addColumn;
-(BOOL)checkColumnName;


-(BOOL)addColumnSigStoreID;
-(BOOL)checkColumnNameSigStoreID;
-(BOOL)addColumnSigUserName;
-(BOOL)checkColumnSigUserName;
-(BOOL)addColumnSigPassword;
-(BOOL)checkColumnSigPassword;

@end
