//
//  singleton.m
//  Delivery
//
//  Created by Barani Elangovan on 2/20/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "singleton.h"

@implementation singleton

@synthesize str_LoginName,activityTypes,str_url,arr_storeInfoList,str_dateLabText,str_DriverName,arr_OnlineArray,str_InternetFlag,arr_LocatSelectedRx,arr_searchVal,str_StartDatee,str_EndDatee,str_DateLabel,GPSallow,str_iTunesAppID,str_iTunesVersion,str_CurrentVresion,str_updatee,str_LoginPassword,arr_OnlineDeliveredArray,str_startdate_bulk,str_enddate_bulk,str_DelPatientID,str_DelPatientPhone,arr_ArChargeID,str_deletedRxList;
+(id)share
{
    static singleton *free=nil;
    if (free==nil)
    {
        free =[[self alloc]init];
    }
    return free;
}

- (id)init
{
    self = [super init];
    if (!self)
        return nil;
    
    arr_storeInfoList=[[NSDictionary alloc]init];
    arr_OnlineArray=[[NSMutableArray alloc]init];
    arr_LocatSelectedRx=[[NSMutableArray alloc]init];
    arr_searchVal=[[NSMutableArray alloc]init];
    arr_OnlineDeliveredArray=[[NSMutableArray alloc]init];
    
    arr_ArChargeID=[[NSMutableArray alloc]init];
    
    return self;
}

@end
