//
//  CustomAnnotation.h
//  RXfill
//
//  Created by Barani Elangovan on 1/1/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface CustomAnnotation : MKPlacemark
{
    CLLocationCoordinate2D coordinate1;
    NSString *title;
    NSString *subtitle;
    NSString *phone;
    
}

//@property (strong,nonatomic) NSString *title;

@property (strong, nonatomic) NSString *title;
@property (strong, nonatomic) NSString *subtitle;
@property (strong, nonatomic) NSString *phone;
@property (nonatomic) NSUInteger index;

//@property (strong, nonatomic) NSString *customAnnotationTitle;

@property (nonatomic,assign) CLLocationCoordinate2D coordinate1;



@end
