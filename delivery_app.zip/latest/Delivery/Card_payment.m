    //
    //  Card_payment.m
    //  RXfill
    //
    //  Created by Suresh Elumalai on 1/9/16.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "Card_payment.h"

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;


@interface Card_payment ()

{
    NSString *previousTextFieldContent;
    UITextRange *previousSelection;
    DGActivityIndicatorView *activityIndicatorView;
    
    NSArray *activityTypes;
    NSString *internet_flag;
    NSString *yearstring;
    NSString *monthString;
    
    NSInteger week;
    
    
    NSString *str_PaymentType;
    
}


@end

@implementation Card_payment

@synthesize scroll_View,view_Scroll,text_CardNumber,lab_CardLine,lab_CashLine,lab_CheckLine,lab_Card,lab_Cash,lab_Check,arr_DelRxListAmount,arr_DelRxListNumber,arr_DelRxID,lab_RxCount,lab_RxAmount,btn_skip, view_offline_alert, imag_card_cvv, img_card_number, img_card_expdate, txt_card_exp, txt_cvv,txt_zip,lab_RefNumber,txt_RefNumber,lab_CardNumber,arr_PatientID,arr_HipaaSigID,arr_HipaaSig,arr_BalanceAmount;

@synthesize str_patpay,str_internet,str_logid,btn_back, txt_card_name,str_rxcount,str_cardNumber,str_expDate,str_ccCode,str_patZip,arr_RxARItemID;

@synthesize  view_Comments,lab_Comments,text_Comments,view_CommentBase,view_CardPayment,view_CashPayment,text_CashAmount,lab_CommentsOthers, view_CommentsOthers,text_CommentsOthers,view_OtherPayment,btn_OthersOK,btn_OthersCancel;

@synthesize str_PatientName,str_IsPOS,str_POSID,str_PatientAddress, str_street,str_city,str_state,arr_Del_Qty,str_patient_email, labl_ARamoumt, str_ARzip,str_ARstate,str_ARcity,str_ARbalance,str_ARbill,str_ARphone,str_ARacc,str_ARar,str_ARaddress, labl_ARtotalAmount,labl_ARCurrentAmount,labl_ARaddress1,labl_ARaddress2,labl_ARaccountname,lab_RxPaidAmount,labl_ARPaidAmount,scroll_ARview,str_RxSearch;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    str_PaymentType=@"Card";
    
    manage=[singleton share];
    
    if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
    {
        text_CashAmount.enabled=YES;
    }
    else
    {
        text_CashAmount.enabled=YES;

    }
    
    [self restrictRotation:NO];
    
    lab_CardLine.hidden=NO;
    lab_CashLine.hidden=YES;
    lab_CheckLine.hidden=YES;

    view_OtherPayment.hidden=YES;
    
    
    // Card Payment
    lab_RefNumber.hidden=YES;
    txt_RefNumber.hidden=YES;
    lab_CardNumber.hidden=NO;
    text_CardNumber.hidden=NO;
    
    
    lab_Card.font=[UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    lab_Cash.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    lab_Check.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    
    lab_Card.textColor=[UIColor whiteColor];
    lab_Cash.textColor=[UIColor groupTableViewBackgroundColor];
    lab_Check.textColor=[UIColor groupTableViewBackgroundColor];
    
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self
                                           action:@selector(hideKeyBoard)];
    
    [self.view addGestureRecognizer:tapGesture];
    tapGesture.enabled = YES;
    
    
    view_Comments. layer.cornerRadius =2;
    view_Comments. layer.masksToBounds =YES;
    view_Comments.layer.borderColor=([UIColor lightGrayColor]).CGColor;
    view_Comments.layer.borderWidth=1;
    
    view_CommentsOthers. layer.cornerRadius =2;
    view_CommentsOthers. layer.masksToBounds =YES;
    view_CommentsOthers.layer.borderColor=([UIColor lightGrayColor]).CGColor;
    view_CommentsOthers.layer.borderWidth=1;
    
    
    btn_OthersCancel. layer.cornerRadius =2;
    btn_OthersCancel. layer.masksToBounds =YES;
        // btn_OthersCancel.layer.borderColor=([UIColor lightGrayColor]).CGColor;
        // btn_OthersCancel.layer.borderWidth=1;
    
    btn_OthersOK. layer.cornerRadius =2;
    btn_OthersOK. layer.masksToBounds =YES;
        // btn_OthersOK.layer.borderColor=([UIColor lightGrayColor]).CGColor;
        // btn_OthersOK.layer.borderWidth=1;
    
    img_card_number.image =[UIImage imageNamed:@"cnumber.png"];
    img_card_expdate.image =[UIImage imageNamed:@"calendarnew.png"];
    imag_card_cvv.image =[UIImage imageNamed:@"cvvnew.png"];
    
    
    activityTypes = @[@(DGActivityIndicatorAnimationTypeBallClipRotate)]; activityTypes = @[@(DGActivityIndicatorAnimationTypeBallClipRotate)];
    
    view_offline_alert.hidden = YES;
    
    NSInteger rCount=arr_DelRxListNumber.count;

    float arbalance=0.0;
    arbalance=[str_ARbalance floatValue];
    
    labl_ARamoumt.text=[NSString stringWithFormat:@"$%.2f",arbalance];
    lab_RxCount.text=[@"Item Count: " stringByAppendingString:[NSString stringWithFormat:@"%ld",(long)rCount]];
    
    manage.arr_LocatSelectedRx=arr_DelRxListNumber;
    
    float f_Amount=0.0;
    float f_BalanceAmount=0.0;
    float f_PaidAmount=0.0;

    
    for (int i=0; i<arr_DelRxListAmount.count; i++)
    {
        f_Amount=f_Amount+[arr_DelRxListAmount[i]floatValue];
       // NSLog(@"%f", [arr_BalanceAmount[i]floatValue]);

        f_BalanceAmount=f_BalanceAmount+[arr_BalanceAmount[i]floatValue];

    }
    
    f_PaidAmount=f_Amount-f_BalanceAmount;
    
    lab_RxAmount.text=[@"$" stringByAppendingString:[NSString stringWithFormat:@"%.2f",f_Amount]];
    lab_RxPaidAmount.text=[@"Already Paid : $" stringByAppendingString:[NSString stringWithFormat:@"%.2f",f_PaidAmount]];
    text_CashAmount.text=[NSString stringWithFormat:@"%.2f",f_BalanceAmount];
    
    /*
    if (str_patpay.intValue ==0) {
        btn_skip.hidden= NO;
    }
    else if (str_patpay.intValue!=0)
    {
        
        btn_skip.hidden=YES;
    }
    */
    
    float arcurrentBalance=0.0;
    
    
    
    labl_ARtotalAmount.text=lab_RxAmount.text;
    labl_ARPaidAmount.text=[@"$" stringByAppendingString:[NSString stringWithFormat:@"%.2f",f_PaidAmount]];
    float aramount=0.0;
    aramount=[str_ARbalance floatValue];
    arcurrentBalance=f_BalanceAmount+aramount;
    
    
    labl_ARaddress1.text=str_ARaddress;
    labl_ARaddress2.text=[NSString stringWithFormat:@"%@, %@ - %@",str_city,str_ARstate,str_ARzip];
    labl_ARCurrentAmount.text=[NSString stringWithFormat:@"$%.2f",arcurrentBalance];
    labl_ARaccountname.text=str_ARacc;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yy"];
    yearstring = [formatter stringFromDate:[NSDate date]];
    
    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    [formatter1 setDateFormat:@"MM"];
    monthString = [formatter1 stringFromDate:[NSDate date]];
    
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
    
 //   NSInteger day = [components day];
    week = [components month];
   // NSInteger year = [components year];
    
  //  NSString *string = [NSString stringWithFormat:@"%ld",(long)week];
    
    
        //view_success.hidden = YES;
    
    [txt_card_exp addTarget:self
                     action:@selector(dateTextFieldDidChange:)
           forControlEvents:UIControlEventEditingChanged];
    
    
    NSLog(@"%@",manage.arr_OnlineArray);
    
    /*
    NSString *pat_cardNo = manage.arr_OnlineArray[0][@"PatientCreditCardNo"];
    NSString *pat_expdate = manage.arr_OnlineArray[0][@"PatientCCExpMMYY"];
    NSString *pat_cccode = manage.arr_OnlineArray[0][@"PatientCCCode"];
    NSString *pat_zip = manage.arr_OnlineArray[0][@"Patientzip"];
    */
    //pat_expdate=@"04/07/2018";
    //pat_cardNo=@"1111222244446666";
    
    
    //pat_expdate=@"XXXXX";
    
    //NSLog(@"%@",pat_expdate);
    
    
    
    NSString *pat_cardNo = str_cardNumber;
    NSString *pat_expdate = str_expDate;
    NSString *pat_cccode = str_ccCode;
    NSString *pat_zip = str_patZip;

    
    
    
    //pat_cccode=@"1116";
    
    if ([pat_cardNo isEqualToString:@""] || pat_cardNo == NULL) {
        
    }
    else
    {
        NSLog(@"%@",text_CardNumber.text);
        NSString *str_padding=@"";
        NSRange subStringRange = NSMakeRange(0,[pat_cardNo length]-4);
        str_padding =[str_padding stringByPaddingToLength:subStringRange.length+3 withString:@"X" startingAtIndex:0];
        
        
        pat_cardNo = [pat_cardNo stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_cardNo substringToIndex:subStringRange.length]] withString:str_padding];
        NSLog(@"%@",pat_cardNo);
        NSString *trimmedString=[pat_cardNo substringFromIndex:MAX((int)[pat_cardNo length]-4, 0)];
        
        
        pat_cardNo=[@"XXXX XXXX XXXX " stringByAppendingString:trimmedString];
        text_CardNumber.text=pat_cardNo;


    }
    
    if ([pat_expdate isEqualToString:@""] || pat_expdate == NULL) {
        
        
    }
    else
    {
        NSString *str_padding1=@"";
        NSRange subStringRange1 = NSMakeRange(0,[pat_expdate length]);
        str_padding1 =[str_padding1 stringByPaddingToLength:subStringRange1.length withString:@"X" startingAtIndex:0];
        
        pat_expdate = [pat_expdate stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_expdate substringToIndex:subStringRange1.length]] withString:str_padding1];
        

        txt_card_exp.text=pat_expdate;
    }
    
    if ([pat_cccode isEqualToString:@""] || pat_cccode == NULL) {
        
    }
    else
    {
        
        NSString *str_padding2=@"";
        NSRange subStringRange2 = NSMakeRange(0,[pat_cccode length]);
        str_padding2 =[str_padding2 stringByPaddingToLength:subStringRange2.length withString:@"X" startingAtIndex:0];
        
        pat_cccode = [pat_cccode stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_cccode substringToIndex:subStringRange2.length]] withString:str_padding2];
        NSLog(@"%@",pat_cccode);
        

        txt_cvv.text=pat_cccode;
    }
    if ([pat_zip isEqualToString:@""] || pat_zip == NULL) {
        
    }
    else
    {
        
        NSString *str_padding3=@"";
        NSRange subStringRange3 = NSMakeRange(0,[pat_zip length]);
        str_padding3 =[str_padding3 stringByPaddingToLength:subStringRange3.length withString:@"X" startingAtIndex:0];
        
        pat_zip = [pat_zip stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_zip substringToIndex:subStringRange3.length]] withString:str_padding3];
        NSLog(@"%@",pat_zip);
        
        
        txt_zip.text=pat_zip;
    }
    

    
    NSLog(@"%@",manage.arr_storeInfoList);

    
    
    btn_skip.layer.cornerRadius=2;
    
    if (str_ARar.intValue>0) {
        btn_skip.hidden=NO;
    }
    else
    {
        btn_skip.hidden=YES;
    }
    

        // Do any additional setup after loading the view.
}

#pragma mark - Button Payment Types

-(IBAction)btn_Card:(id)sender
{
    
    str_PaymentType=@"Card";
    
    lab_Card.font=[UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    lab_Cash.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    lab_Check.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];

    lab_Card.textColor=[UIColor whiteColor];
    lab_Cash.textColor=[UIColor groupTableViewBackgroundColor];
    lab_Check.textColor=[UIColor groupTableViewBackgroundColor];
    
    lab_CardLine.hidden=NO;
    lab_CashLine.hidden=YES;
    lab_CheckLine.hidden=YES;

    view_CardPayment.hidden=NO;
    
        // Card Payment
    lab_RefNumber.hidden=YES;
    txt_RefNumber.hidden=YES;
    lab_CardNumber.hidden=NO;
    text_CardNumber.hidden=NO;
    
    [UIView animateWithDuration:.25
                     animations:^{
                         
                         [view_CommentBase setFrame:CGRectMake(0, 320, view_CommentBase.frame.size.width, view_CommentBase.frame.size.height)];
                     }
     ];
    
    scroll_View.scrollsToTop=YES;
    scroll_View.scrollEnabled=YES;
    scroll_View.contentSize=CGSizeMake(view_Scroll.frame.size.width, view_Scroll.frame.size.height);

    
}
-(IBAction)btn_Cash:(id)sender
{

    str_PaymentType=@"Cash";
    
    lab_Card.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    lab_Cash.font=[UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    lab_Check.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    
    lab_Card.textColor=[UIColor groupTableViewBackgroundColor];
    lab_Cash.textColor=[UIColor whiteColor];
    lab_Check.textColor=[UIColor groupTableViewBackgroundColor];
    
    lab_CardLine.hidden=YES;
    lab_CashLine.hidden=NO;
    lab_CheckLine.hidden=YES;

        // Card Payment
    lab_RefNumber.hidden=YES;
    txt_RefNumber.hidden=YES;
    lab_CardNumber.hidden=YES;
    text_CardNumber.hidden=YES;
    [UIView animateWithDuration:.25
                     animations:^{
                         
                         [view_CommentBase setFrame:CGRectMake(0, 88, view_CommentBase.frame.size.width, view_CommentBase.frame.size.height)];
                     }
     ];
    
    scroll_View.scrollsToTop=YES;
    scroll_View.scrollEnabled=YES;
    scroll_View.contentSize=CGSizeMake(view_Scroll.frame.size.width, 220);
    
}

-(IBAction)btn_Check:(id)sender
{
    
    str_PaymentType=@"Check";
    
    lab_Card.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    lab_Cash.font=[UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    lab_Check.font=[UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    
    lab_Card.textColor=[UIColor groupTableViewBackgroundColor];
    lab_Cash.textColor=[UIColor groupTableViewBackgroundColor];
    lab_Check.textColor=[UIColor whiteColor];

    
    lab_CardLine.hidden=YES;
    lab_CashLine.hidden=YES;
    lab_CheckLine.hidden=NO;
    
        // Card Payment
    lab_RefNumber.hidden=NO;
    txt_RefNumber.hidden=NO;
    lab_CardNumber.hidden=YES;
    text_CardNumber.hidden=YES;
    
    [UIView animateWithDuration:.25
                     animations:^{
                         
                         [view_CommentBase setFrame:CGRectMake(0, 165, view_CommentBase.frame.size.width, view_CommentBase.frame.size.height)];
                     }
     ];
    
    scroll_View.scrollsToTop=YES;
    scroll_View.scrollEnabled=YES;
    scroll_View.contentSize=CGSizeMake(view_Scroll.frame.size.width, 297);
    
}

#pragma mark - Restrict Rotation

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
       [self restrictRotation:NO];

}

-(void)viewDidAppear:(BOOL)animated
{

    [super viewDidAppear:animated];

    //[self restrictRotation:NO];

    if ([str_internet isEqualToString:@"no"]) {
        btn_back.hidden = NO;
        view_offline_alert.hidden = YES;
    }
    
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
            UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
                //  NSLog(@"iphone");
            if(orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationMaskPortrait)
            {

            }
        else
        {
                NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationMaskPortrait];
                [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }
        
        /*
    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
    */
    }
    [self restrictRotation:NO];

    scroll_View.scrollEnabled=YES;
    scroll_View.contentSize=CGSizeMake(view_Scroll.frame.size.width, view_Scroll.frame.size.height);
    
    scroll_ARview.scrollEnabled=YES;
    scroll_ARview.contentSize=CGSizeMake(view_OtherPayment.frame.size.width, 530);
}

-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}


#pragma mark - TextView

- (void)textViewDidEndEditing:(UITextView *)theTextView
{
    if (![text_Comments hasText])
    {
        lab_Comments.hidden = NO;
    }
    if (![text_CommentsOthers hasText]) {
        lab_CommentsOthers.hidden=NO;
    }
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
    
    
    
}

- (void) textViewDidChange:(UITextView *)textView
{
    if(![text_Comments hasText]) {
        lab_Comments.hidden = NO;
    }
    else if([text_Comments hasText]){
        lab_Comments.hidden = YES;
    }
    
    if(![text_CommentsOthers hasText]) {
        lab_CommentsOthers.hidden = NO;
    }
    else if([text_CommentsOthers hasText]){
        lab_CommentsOthers.hidden = YES;
    }
}
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    CGRect textFieldRect =
    [self.view.window convertRect:textView.bounds fromView:textView];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}

-(void)hideKeyBoard
{

    [text_CommentsOthers endEditing:YES];
    
    [text_Comments endEditing:YES];
    [text_CashAmount endEditing:YES];
    [text_CardNumber endEditing:YES];
    [txt_cvv endEditing:YES];
    [txt_card_exp endEditing:YES];
    [txt_zip endEditing:YES];
    [txt_RefNumber endEditing:YES];

}

#pragma mark - Back Button

-(IBAction)back_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Button Payments

-(IBAction)btn_pay:(id)sender
{
    if ([str_PaymentType isEqualToString:@"Card"])
    {
        
        if ([manage.str_InternetFlag isEqualToString:@"Yes"])
        {
            if(text_CashAmount.text.length ==0 || text_CashAmount.text.floatValue <0 || [text_CashAmount.text isEqualToString:@"."])
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                [text_CashAmount becomeFirstResponder];

                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter total amount." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter total amount."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
            
            else if(text_CardNumber.text.length <19 )
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                
                img_card_number.image =[UIImage imageNamed:@"cnumber1.png"];
                [text_CardNumber becomeFirstResponder];

                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid card number" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid card number"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
            else if (txt_card_exp.text.length<5)
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                
                img_card_expdate.image =[UIImage imageNamed:@"calendarnew1.png"];
                
                [txt_card_exp becomeFirstResponder];

                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid expiry date" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid expiry date"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
//
                
                
                
            }
            else if (txt_cvv.text.length<3)
            {
                
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                
                [txt_cvv becomeFirstResponder];

                imag_card_cvv.image =[UIImage imageNamed:@"cvvnew1.png"];
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid CVV number" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid CVV number"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
            else
            {
                [text_CommentsOthers endEditing:YES];
                
                [text_Comments endEditing:YES];
                [text_CashAmount endEditing:YES];
                [text_CardNumber endEditing:YES];
                [txt_cvv endEditing:YES];
                [txt_card_exp endEditing:YES];
                [txt_zip endEditing:YES];
                [txt_RefNumber endEditing:YES];

                Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
                signature.str_PatientName=str_PatientName;
                signature.str_IsPOS=str_IsPOS;
                signature.str_POSID=str_POSID;
                signature.str_PatientAddresss=str_PatientAddress;
                signature.str_PaymentType=@"Card";
                signature.arr_RxNumberr=arr_DelRxListNumber;
                signature.arr_RxPrice=arr_DelRxListAmount;
                signature.arr_RxID=arr_DelRxID;
                
                signature.arr_PatientID=arr_PatientID;
                signature.arr_HipaaSigID=arr_HipaaSigID;
                signature.arr_HipaaSig=arr_HipaaSig;
                signature.arr_BalanceAmount=arr_BalanceAmount;
                signature.str_RxSearch=str_RxSearch;
                signature.arr_RxARItemID=arr_RxARItemID;

                
                signature.str_PayType=@"2";
                
                signature.str_TotalTender=text_CashAmount.text;
                
                signature.str_CCNumber=text_CardNumber.text;
                signature.str_ExpDate=txt_card_exp.text;
                signature.str_CVV=txt_cvv.text;
                signature.str_ZipCode=txt_zip.text;
                signature.str_Comments=text_Comments.text;
                
                signature.str_CCNumber1=str_cardNumber;
                signature.str_ExpDate1=str_expDate;
                signature.str_CVV1=str_ccCode;
                signature.str_ZipCode1=str_patZip;
                
                signature.str_street=str_street;
                signature.str_state=str_state;
                signature.str_city=str_city;
                signature.arr_del_Qty=arr_Del_Qty;
                
                signature.str_RefNumber=@"";

                
                signature.str_pat_email=str_patient_email;
                

                
                [self.navigationController pushViewController:signature animated:NO];
            }
        }
        else
        {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"You are in offline. Cash and AR Payment will be acceptable in offline" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"You are in offline. Cash and AR Payment will be acceptable in offline"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//            [alert show];
            
        }
    }
    else if ([str_PaymentType isEqualToString:@"Cash"])
    {
        
        NSLog(@"%f",text_CashAmount.text.floatValue);
        
            if(text_CashAmount.text.length ==0  || text_CashAmount.text.floatValue <0 || [text_CashAmount.text isEqualToString:@"."])
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                [text_CashAmount becomeFirstResponder];

                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter total amount." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
//
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter total amount."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
        
            else
            {
                
                [text_CommentsOthers endEditing:YES];
                
                [text_Comments endEditing:YES];
                [text_CashAmount endEditing:YES];
                [text_CardNumber endEditing:YES];
                [txt_cvv endEditing:YES];
                [txt_card_exp endEditing:YES];
                [txt_zip endEditing:YES];
                [txt_RefNumber endEditing:YES];

                
                Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
                signature.str_PatientName=str_PatientName;
                signature.str_IsPOS=str_IsPOS;
                signature.str_POSID=str_POSID;
                signature.str_PatientAddresss=str_PatientAddress;
                signature.str_PaymentType=@"Cash";

                signature.arr_RxNumberr=arr_DelRxListNumber;
                signature.arr_RxPrice=arr_DelRxListAmount;
                signature.arr_RxID=arr_DelRxID;
                
                signature.arr_PatientID=arr_PatientID;
                signature.arr_HipaaSigID=arr_HipaaSigID;
                signature.arr_HipaaSig=arr_HipaaSig;
                signature.arr_BalanceAmount=arr_BalanceAmount;
                signature.arr_RxARItemID=arr_RxARItemID;

                signature.str_PayType=@"0";
                
                signature.str_TotalTender=text_CashAmount.text;
                signature.str_Comments=text_Comments.text;
                signature.str_RxSearch=str_RxSearch;

                
                signature.str_CCNumber=@"";
                signature.str_ExpDate=@"";
                signature.str_CVV=@"";
                signature.str_ZipCode=@"";
                
                signature.str_ZipCode1=str_patZip;

                
                signature.str_street=str_street;
                signature.str_state=str_state;
                signature.str_city=str_city;
                signature.arr_del_Qty=arr_Del_Qty;
                signature.str_pat_email=str_patient_email;
                signature.str_RefNumber=@"";

                
                [self.navigationController pushViewController:signature animated:NO];
            }
        }
    else
    {
        if(text_CashAmount.text.length ==0  || text_CashAmount.text.floatValue <0 ||[text_CashAmount.text isEqualToString:@"."])
        {
            [activityIndicatorView stopAnimating];
            activityIndicatorView.hidden=YES;
            [text_CashAmount becomeFirstResponder];

            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter total amount." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter total amount."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//            [alert show];
            
            
        }
        else  if(txt_RefNumber.text.length ==0 )
        {
            [activityIndicatorView stopAnimating];
            activityIndicatorView.hidden=YES;
            [txt_RefNumber becomeFirstResponder];

            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter check reference number." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter check reference number."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//            [alert show];
            
            
        }
        else
        {
            
            [text_CommentsOthers endEditing:YES];
            
            [text_Comments endEditing:YES];
            [text_CashAmount endEditing:YES];
            [text_CardNumber endEditing:YES];
            [txt_cvv endEditing:YES];
            [txt_card_exp endEditing:YES];
            [txt_zip endEditing:YES];
            [txt_RefNumber endEditing:YES];

            
            Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
            signature.str_PatientName=str_PatientName;
            signature.str_IsPOS=str_IsPOS;
            signature.str_POSID=str_POSID;
            signature.str_PatientAddresss=str_PatientAddress;
            signature.str_PaymentType=@"Check";
            
            signature.arr_RxNumberr=arr_DelRxListNumber;
            signature.arr_RxPrice=arr_DelRxListAmount;
            signature.arr_RxID=arr_DelRxID;
            
            signature.arr_PatientID=arr_PatientID;
            signature.arr_HipaaSigID=arr_HipaaSigID;
            signature.arr_HipaaSig=arr_HipaaSig;
            signature.arr_BalanceAmount=arr_BalanceAmount;
            signature.arr_RxARItemID=arr_RxARItemID;

            signature.str_PayType=@"1";
            
            signature.str_TotalTender=text_CashAmount.text;
            signature.str_Comments=text_Comments.text;
            signature.str_RxSearch=str_RxSearch;

            
            signature.str_CCNumber=@"";
            signature.str_ExpDate=@"";
            signature.str_CVV=@"";
            signature.str_ZipCode=@"";
            
            signature.str_ZipCode1=str_patZip;
            
            
            signature.str_street=str_street;
            signature.str_state=str_state;
            signature.str_city=str_city;
            signature.arr_del_Qty=arr_Del_Qty;
            signature.str_pat_email=str_patient_email;
            signature.str_RefNumber=txt_RefNumber.text;
            
            
            [self.navigationController pushViewController:signature animated:NO];
        }
    }
}


-(IBAction)btn_Others:(id)sender
{
    view_OtherPayment.hidden=NO;
    
}



-(IBAction)btn_OthersOK:(id)sender
{
    
    float f_Amount=0.0;
    for (int i=0; i<arr_BalanceAmount.count; i++)
    {
        f_Amount=f_Amount+[arr_BalanceAmount[i]floatValue];
    }

    [text_CommentsOthers endEditing:YES];
    
    [text_Comments endEditing:YES];
    [text_CashAmount endEditing:YES];
    [text_CardNumber endEditing:YES];
    [txt_cvv endEditing:YES];
    [txt_card_exp endEditing:YES];
    [txt_zip endEditing:YES];
    [txt_RefNumber endEditing:YES];

    Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
    signature.str_PatientName=str_PatientName;
    signature.str_IsPOS=str_IsPOS;
    signature.str_POSID=str_POSID;
    signature.str_PatientAddresss=str_PatientAddress;
    
    signature.arr_RxNumberr=arr_DelRxListNumber;
    signature.arr_RxPrice=arr_DelRxListAmount;
    signature.arr_RxID=arr_DelRxID;

    signature.arr_PatientID=arr_PatientID;
    signature.arr_HipaaSigID=arr_HipaaSigID;
    signature.arr_HipaaSig=arr_HipaaSig;
    signature.arr_BalanceAmount=arr_BalanceAmount;
    signature.arr_RxARItemID=arr_RxARItemID;

    signature.str_PayType=@"3";
    signature.str_PaymentType=@"AR";
    signature.str_Comments=text_CommentsOthers.text;
    signature.str_RxSearch=str_RxSearch;

    
    signature.str_TotalTender=[NSString stringWithFormat:@"%.2f",f_Amount];
    
    signature.str_CCNumber=@"";
    signature.str_ExpDate=@"";
    signature.str_CVV=@"";
    signature.str_ZipCode=@"";
    signature.str_ZipCode1=str_patZip;
    signature.str_RefNumber=@"";
    
    signature.str_street=str_street;
    signature.str_state=str_state;
    signature.str_city=str_city;
    signature.arr_del_Qty=arr_Del_Qty;
    signature.str_pat_email=str_patient_email;
    
  
    
    [self.navigationController pushViewController:signature animated:NO];
    
}
-(IBAction)btn_OthersCancel:(id)sender
{
    view_OtherPayment.hidden=YES;
}


#pragma mark - Textfield

- (void) dateTextFieldDidChange: (UITextField *)theTextField {
    
    NSString *string = theTextField.text;
        // NSLog(@"%d", theTextField.text.intValue);
    
    
    
    if (string.length == 2  &&  theTextField.text.intValue<=12) {
        
        theTextField.text = [string stringByAppendingString:@"/"];
        
            //  NSLog(@"%d",[theTextField.text substringToIndex:2].intValue);
        
    }
    else if(string.length==2 && theTextField.text.intValue>12)
    {
        
            // theTextField.text = [theTextField.text stringByAppendingString:@"0"];
        NSMutableString *mu = [NSMutableString stringWithString:string];
        [mu insertString:@"0" atIndex:0];
        [mu insertString:@"/" atIndex:2];
        theTextField.text = mu;
            // NSLog(@"Please enter");
            //  txt_card_exp.text= @"";
    }
    
    
    else if (string.length==5 && [theTextField.text substringFromIndex:[theTextField.text length] -2].intValue<yearstring.intValue)
        
    {
        NSString *mu = [theTextField.text substringToIndex:[theTextField.text length]-5];
        theTextField.text = mu;
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid Date" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid Date"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//        [alert show];
        
    }
    
    else if (string.length==5 && [theTextField.text substringFromIndex:[theTextField.text length] -2].intValue==yearstring.intValue &&  string.length==5 && [theTextField.text substringToIndex:2].intValue<monthString.intValue)
        
    {
        NSString *mu = [theTextField.text substringToIndex:[theTextField.text length]-5];
        theTextField.text = mu;
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid Date" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid Date"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//        [alert show];
        
    }
    
    
    else if (string.length > 5) {
        
        theTextField.text = [string substringToIndex:5];
        
    }
    else if(string.length==5)
    {
        
            // NSLog(@"%@",[theTextField.text substringToIndex:2]);
        
        
      //  CGFloat borderWidth = 1.0f;
        
        
            //view_expdate.layer.borderColor = [UIColor lightGrayColor].CGColor;
            //view_expdate.layer.borderWidth = borderWidth;
            //view_expdate.layer.cornerRadius = 3;
        img_card_expdate.image =[UIImage imageNamed:@"calendarnew.png"];
        
    }
    
    
    
}





-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField ==text_CashAmount) {
        
        NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789."]invertedSet];
            // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
        
        if ([string isEqualToString:filtered]) {
            if(string.length!=0){
                if ([string isEqualToString:@"."]) {
                    if ([text_CashAmount.text containsString:@"."]) {
                        return NO;
                    }
                    else
                    {
                        return YES;
                    }
                }
                else
                {
                    return YES;

                }
                
            }
            else
            {
                return YES;
            }
        }

        return [string isEqualToString:filtered];
        
    }
    else if (textField==text_CardNumber) {
        
        
        __block NSString *text = [text_CardNumber text];
        
        NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789X\b"];
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) {
            return NO;
        }
        
        text = [text stringByReplacingCharactersInRange:range withString:string];
        text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        NSString *newString = @"";
        while (text.length > 0) {
            NSString *subString = [text substringToIndex:MIN(text.length, 4)];
            newString = [newString stringByAppendingString:subString];
            if (subString.length == 4) {
                newString = [newString stringByAppendingString:@" "];
            }
            text = [text substringFromIndex:MIN(text.length, 4)];
        }
        
        newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
        
        
       // CGFloat borderWidth = 1.0f;
        
        
        if(text_CardNumber.text.length==18)
        {
                //view_cardnumber.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_cardnumber.layer.borderWidth = borderWidth;
                //view_cardnumber.layer.cornerRadius = 3;
            img_card_number.image =[UIImage imageNamed:@"cnumber.png"];
            
        }
        if (newString.length >= 20) {
            return NO;
        }
        
        [textField setText:newString];
        
        return NO;
    }
    
    else if (textField==txt_cvv)
    {
        
        NSString *string1 = txt_cvv.text;
        if(string1.length<=2)
        {
            
            NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789X"]invertedSet];
                // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
            
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
            
            return [string isEqualToString:filtered];
            
        }
        else if([string isEqualToString:@""])
        {
            return YES;
        }
        else if (txt_cvv.text.length==3)
        {
            //CGFloat borderWidth = 1.0f;
            
                //view_cvv.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_cvv.layer.borderWidth = borderWidth;
                //view_cvv.layer.cornerRadius = 3;
            
            
            imag_card_cvv.image =[UIImage imageNamed:@"cvvnew.png"];
            
        }
        else
        {
            return NO;
        }
    }
    else if (textField==txt_zip)
    {
        
        NSString *string1 = txt_zip.text;
        if(string1.length<=8)
        {
            
            NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789X"]invertedSet];
                // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
            
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
            
            
            return [string isEqualToString:filtered];
            
            
        }
        else if([string isEqualToString:@""])
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if (textField==txt_RefNumber)
    {
  
            NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
                // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
            
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
            
            
            return [string isEqualToString:filtered];
            
        
    }
    /*
     else if (textField ==txt)
     {
     CGFloat borderWidth = 1.0f;
     
     
     view_zip.layer.borderColor = [UIColor lightGrayColor].CGColor;
     view_zip.layer.borderWidth = borderWidth;
     view_zip.layer.cornerRadius = 3;
     
     NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
     // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
     
     NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
     
     
     return [string isEqualToString:filtered];
     
     
     }
     
     
     */
    
    else if (textField==txt_card_exp) {
        
        

         NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789X"]invertedSet];
         // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
         
         NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
         
         
         
         
         
        

        
        NSString *resultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        BOOL isPressedBackspaceAfterSingleSpaceSymbol = [string isEqualToString:@""] && resultString.intValue<=12 && range.location == 2 && range.length == 1;
        if (isPressedBackspaceAfterSingleSpaceSymbol) {
            
            
                //  NSString *mu = [theTextField.text substringToIndex:[theTextField.text length]-2];
                //  your actions for deleteBackward actions
            txt_card_exp.text= @"";
            NSLog(@"delete");
            
        }
             return [string isEqualToString:filtered];
        /*
         else if([string isEqualToString:@""])
         {
         return YES;
         }
         
         
         */
    }
    
    
    /*
     
     else if ([string isEqualToString:@""] && textField.text.length == 0) {
     
     NSString *dateString = textField.text;
     
     [dateString stringByReplacingOccurrencesOfString:@"/" withString:@""];
     
     }
     
     
     */
    
    return YES;
    
    
}





-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==text_CashAmount)
    {
        [text_CashAmount resignFirstResponder];
    }
    else if (textField==text_CardNumber)
    {
        [text_CardNumber becomeFirstResponder];
    }
    else if (textField==txt_card_exp)
    {
        
        [txt_card_exp becomeFirstResponder];
    }
    else if (textField==txt_cvv)
    {
        [txt_zip becomeFirstResponder];
    }
    else if (textField==txt_zip)
    {
        [txt_zip resignFirstResponder];
    }
    
    return YES;
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
