//
//  MSSCalendarCollectionReusableView.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MSSCalendarCollectionReusableView : UICollectionReusableView

@property (nonatomic,strong)UILabel *headerLabel;

@end
