    //
    //  DeviceAuthentication.m
    //  Delivery
    //
    //  Created by Barani Elangovan on 6/6/17.
    //  Copyright © 2017 Suresh Elumalai. All rights reserved.
    //

#import "DeviceAuthentication.h"
#import "DGActivityIndicatorView.h"


static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;




@interface DeviceAuthentication ()

{
    DGActivityIndicatorView *activityIndicatorView;
    
}

@end

@implementation DeviceAuthentication

@synthesize view_Code,btn_Cancel,btn_Confirm,text_Code,view_back,view_back1;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    view_back1.hidden=YES;
    self.view_activity.hidden=YES;
    
    
        [self restrictRotation:NO];
    
    view_Code.layer.borderColor = [UIColor grayColor].CGColor;
    view_Code.layer.borderWidth = 1;
    view_Code.layer.cornerRadius = 3;
    view_Code.layer.masksToBounds=YES;
    
    btn_Confirm.layer.cornerRadius = 3;
    btn_Confirm.layer.masksToBounds=YES;
    
    btn_Cancel.layer.cornerRadius = 3;
    btn_Cancel.layer.masksToBounds=YES;
    
    view_back.layer.cornerRadius = 5;
    view_back.layer.masksToBounds=YES;
    
    manage=[singleton share];
    
    NSMutableArray *arr_valAuth=[[NSMutableArray alloc]init];
    
    [arr_valAuth removeAllObjects];
    [arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
    [arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
    [arr_valAuth addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
    [arr_valAuth addObject:manage.arr_storeInfoList[@"PharmacyName"]];
 //   [arr_valAuth addObject:manage.arr_storeInfoList[@"PharmacyEmail"]];
    [arr_valAuth addObject:@""];
    [arr_valAuth addObject:manage.arr_storeInfoList[@"UserFirstName"]];
    [arr_valAuth addObject:manage.arr_storeInfoList[@"DeliveryAppAccessLevel"]];
    [arr_valAuth addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] name]]];
    [arr_valAuth addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] model]]];

    
    NSArray *propertyAuth =[NSArray arrayWithObjects:@"StoreID",@"UserID",@"DeviceID",@"StoreName",@"StoreEmail",@"UserName",@"UserLevel",@"DeviceName",@"DeviceModel",nil];
    
    
    NSDictionary *propertiesAuth = [NSDictionary dictionaryWithObjects:arr_valAuth forKeys:propertyAuth];
    
    NSMutableDictionary *newUserObjectAuth = [NSMutableDictionary dictionary];
    
    [newUserObjectAuth setObject:propertiesAuth forKey:@"ObjAuthenticDevice"];
    
    NSLog(@"%@",newUserObjectAuth);
    
    NSData *jsonDataAuth = [NSJSONSerialization dataWithJSONObject:newUserObjectAuth options:kNilOptions error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:jsonDataAuth encoding:NSUTF8StringEncoding];
    NSString *str_service3=[NSString stringWithFormat:@"IOSInsertAuthenticDevice"];
    str_service3=[manage.str_url stringByAppendingString:str_service3];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3]];
    [request setHTTPMethod:@"POST"];
    [request setValue:jsonString forHTTPHeaderField:@"json"];
    [request setHTTPBody:jsonDataAuth];
        // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSError *error = nil;
    NSURLResponse *theResponse = [[NSURLResponse alloc]init];
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
    if(data)
    {
        NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        
        NSDictionary *tranID2=jsonArray3[@"IOSInsertAuthenticDeviceResult"];
        NSString *transaction_id3=tranID2[@"TransactionID"];
        
            //        Activated'
            //        'Not-Activated'
            //        'Store-Mismatch'
            //        'New-Insert-NotActivated'
        
        
        if ([transaction_id3 isEqualToString:@"New-Insert-NotActivated"])
        {
            view_back1.hidden=NO;
        }
        
        else if ([transaction_id3 isEqualToString:@"Not-Activated"])
        {
            view_back1.hidden=NO;
            
        }
       
        else if ([transaction_id3 isEqualToString:@"Store-Mismatch"])
        {
            view_back1.hidden=YES;
            
            ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
            [self.navigationController pushViewController:home animated:NO];
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"This device is already registered with another store" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
        else
        {
            
            NSMutableArray *arr_valLog=[[NSMutableArray alloc]init];
            
            [arr_valLog removeAllObjects];
            [arr_valLog addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
            [arr_valLog addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
            [arr_valLog addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
            
                /*   NSString *removeName = [[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] name]]
                                                               stringByReplacingOccurrencesOfString:@"/" withString:@""];*/
            [arr_valLog addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] model]]];
            [arr_valLog addObject:@"0"];

            NSArray *propertyLog =[NSArray arrayWithObjects:@"StoreID",@"UserID",@"DeviceID",@"DeviceName",@"UpdateLogin",nil];
            
            
            NSDictionary *propertiesLog = [NSDictionary dictionaryWithObjects:arr_valLog forKeys:propertyLog];
            
            NSMutableDictionary *newUserObjectLog = [NSMutableDictionary dictionary];
            
            [newUserObjectLog setObject:propertiesLog forKey:@"ObjDeviceLogin"];
            
            NSLog(@"%@",newUserObjectLog);
            
            NSData *jsonDataLog = [NSJSONSerialization dataWithJSONObject:newUserObjectLog options:kNilOptions error:nil];
            NSString *jsonStringLog = [[NSString alloc] initWithData:jsonDataLog encoding:NSUTF8StringEncoding];
            NSString *str_serviceLog=[NSString stringWithFormat:@"InsertDeviceLoginInfo"];
            str_serviceLog=[manage.str_url stringByAppendingString:str_serviceLog];
            NSMutableURLRequest *requestLog = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_serviceLog]];
            [requestLog setHTTPMethod:@"POST"];
            [requestLog setValue:jsonStringLog forHTTPHeaderField:@"json"];
            [requestLog setHTTPBody:jsonDataLog];
                // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            [requestLog setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
            
            NSError *errorLog = nil;
            NSURLResponse *theResponseLog = [[NSURLResponse alloc]init];
            NSData *dataLog = [NSURLConnection sendSynchronousRequest:requestLog returningResponse:&theResponseLog error:&errorLog];
            if(dataLog)
            {
                NSDictionary *jsonArrayLog =[NSJSONSerialization JSONObjectWithData:dataLog options:NSJSONReadingMutableContainers error:&errorLog];
                
                NSDictionary *tranIDLog=jsonArrayLog[@"InsertDeviceLoginInfoResult"];
                NSString *transaction_idLog=tranIDLog[@"TransID"];
                
                if ([transaction_idLog isEqualToString:@"LoggedIn"])
                {
                    OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
                    ln.str_DelivSearchDate=@"Login";
                    [self.navigationController pushViewController:ln animated:NO];
                }
                else
                {
                    view_back.hidden=YES;
                    
                    NSString *str_Alert=[NSString stringWithFormat:@"You have already login in %@ device. Please confirm login in this device.",transaction_idLog];
                    
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:str_Alert
                                                                   delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Confirm", nil];
                    alert.tag=10;
                    [alert show];
                    
                  
                }
                
                
            }
            
        }
    }
          // Do any additional setup after loading the view.
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==10)
    {
        if (buttonIndex==0)
        {
            ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
            [self.navigationController pushViewController:home animated:NO];
            
        }
        else
        {
            
            
            NSMutableArray *arr_valLog=[[NSMutableArray alloc]init];
            
            [arr_valLog removeAllObjects];
            [arr_valLog addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
            [arr_valLog addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
            [arr_valLog addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
            NSString* Identifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString]; // IOS 6+
            NSLog(@"output is : %@", Identifier);
            [arr_valLog addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] name]]];
            
            [arr_valLog addObject:@"1"];

            
                //  public int StoreID { get; set; }
                //  [DataMember]
                //  public int UserID { get; set; }
                //  [DataMember]
                //  public string DeviceID { get; set; }
            
            
            
            NSArray *propertyLog =[NSArray arrayWithObjects:@"StoreID",@"UserID",@"DeviceID",@"DeviceName",@"UpdateLogin",nil];
            
            
            NSDictionary *propertiesLog = [NSDictionary dictionaryWithObjects:arr_valLog forKeys:propertyLog];
            
            NSMutableDictionary *newUserObjectLog = [NSMutableDictionary dictionary];
            
            [newUserObjectLog setObject:propertiesLog forKey:@"ObjDeviceLogin"];
            
            NSLog(@"%@",newUserObjectLog);
            
            NSData *jsonDataLog = [NSJSONSerialization dataWithJSONObject:newUserObjectLog options:kNilOptions error:nil];
            NSString *jsonStringLog = [[NSString alloc] initWithData:jsonDataLog encoding:NSUTF8StringEncoding];
            NSString *str_serviceLog=[NSString stringWithFormat:@"InsertDeviceLoginInfo"];
            str_serviceLog=[manage.str_url stringByAppendingString:str_serviceLog];
            NSMutableURLRequest *requestLog = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_serviceLog]];
            [requestLog setHTTPMethod:@"POST"];
            [requestLog setValue:jsonStringLog forHTTPHeaderField:@"json"];
            [requestLog setHTTPBody:jsonDataLog];
                // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            [requestLog setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
            
            NSError *errorLog = nil;
            NSURLResponse *theResponseLog = [[NSURLResponse alloc]init];
            NSData *dataLog = [NSURLConnection sendSynchronousRequest:requestLog returningResponse:&theResponseLog error:&errorLog];
            if(dataLog)
            {
                NSDictionary *jsonArrayLog =[NSJSONSerialization JSONObjectWithData:dataLog options:NSJSONReadingMutableContainers error:&errorLog];
                
                NSDictionary *tranIDLog=jsonArrayLog[@"InsertDeviceLoginInfoResult"];
                NSString *transaction_idLog=tranIDLog[@"TransID"];
                
                if ([transaction_idLog isEqualToString:@"LoggedIn"])
                {
                    OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
                    ln.str_DelivSearchDate=@"Login";
                    [self.navigationController pushViewController:ln animated:NO];
                    
                }
            }
                // ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
                // [self.navigationController pushViewController:home animated:YES];
            
        }
    }
    
}

-(IBAction)btn_info:(id)sender
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Information" message:@"Please contact our customer support center for getting authentication code." preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

-(IBAction)btn_Cancel:(id)sender
{
    ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
    [self.navigationController pushViewController:home animated:NO];
}

-(IBAction)btn_Confirm:(id)sender
{
    
    NSString *strCode=text_Code.text;
    _view_activity.hidden=NO;
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
                //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
        
        NSMutableArray *arr_valAuth=[[NSMutableArray alloc]init];
        
        [arr_valAuth removeAllObjects];
        [arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
            //[arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
        [arr_valAuth addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
        [arr_valAuth addObject:strCode];
        [arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
        [arr_valAuth addObject:manage.arr_storeInfoList[@"PharmacyName"]];
        //   [arr_valAuth addObject:manage.arr_storeInfoList[@"PharmacyEmail"]];
        [arr_valAuth addObject:@""];
        [arr_valAuth addObject:manage.arr_storeInfoList[@"UserFirstName"]];
        [arr_valAuth addObject:manage.arr_storeInfoList[@"DeliveryAppAccessLevel"]];
        [arr_valAuth addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] name]]];
        [arr_valAuth addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] model]]];
        
        
        
        
        NSArray *propertyAuth =[NSArray arrayWithObjects:@"StoreID",@"DeviceID",@"AuthCode",@"UserID",@"StoreName",@"StoreEmail",@"UserName",@"UserLevel",@"DeviceName",@"DeviceModel",nil];
        
        
        NSDictionary *propertiesAuth = [NSDictionary dictionaryWithObjects:arr_valAuth forKeys:propertyAuth];
        
        NSMutableDictionary *newUserObjectAuth = [NSMutableDictionary dictionary];
        
        [newUserObjectAuth setObject:propertiesAuth forKey:@"ObjUpdateDevice"];
        
        NSLog(@"%@",newUserObjectAuth);
        
        NSData *jsonDataAuth = [NSJSONSerialization dataWithJSONObject:newUserObjectAuth options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonDataAuth encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"IOSUpdateAuthenticDevice"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3]];
        [request setHTTPMethod:@"POST"];
        [request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonDataAuth];
            // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            NSDictionary *tranID2=jsonArray3[@"IOSUpdateAuthenticDeviceResult"];
            NSString *transaction_id3=[NSString stringWithFormat:@"%d",[tranID2[@"TransactionID"]intValue]];
            
            if ([transaction_id3 isEqualToString:@"1"])
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    NSMutableArray *arr_valLog=[[NSMutableArray alloc]init];
                    
                    [arr_valLog removeAllObjects];
                    [arr_valLog addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
                    [arr_valLog addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
                    [arr_valLog addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
                    
                    [arr_valLog addObject:[NSString stringWithFormat:@"%@",[[UIDevice currentDevice] name]]];
                    
       
                    
                    NSArray *propertyLog =[NSArray arrayWithObjects:@"StoreID",@"UserID",@"DeviceID",@"DeviceName",nil];
                    
                    
                    NSDictionary *propertiesLog = [NSDictionary dictionaryWithObjects:arr_valLog forKeys:propertyLog];
                    
                    NSMutableDictionary *newUserObjectLog = [NSMutableDictionary dictionary];
                    
                    [newUserObjectLog setObject:propertiesLog forKey:@"ObjDeviceLogin"];
                    
                    NSLog(@"%@",newUserObjectLog);
                    
                    NSData *jsonDataLog = [NSJSONSerialization dataWithJSONObject:newUserObjectLog options:kNilOptions error:nil];
                    NSString *jsonStringLog = [[NSString alloc] initWithData:jsonDataLog encoding:NSUTF8StringEncoding];
                    NSString *str_serviceLog=[NSString stringWithFormat:@"InsertDeviceLoginInfo"];
                    str_serviceLog=[manage.str_url stringByAppendingString:str_serviceLog];
                    NSMutableURLRequest *requestLog = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_serviceLog]];
                    [requestLog setHTTPMethod:@"POST"];
                    [requestLog setValue:jsonStringLog forHTTPHeaderField:@"json"];
                    [requestLog setHTTPBody:jsonDataLog];
                        // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                    [requestLog setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                    
                    NSError *errorLog = nil;
                    NSURLResponse *theResponseLog = [[NSURLResponse alloc]init];
                    NSData *dataLog = [NSURLConnection sendSynchronousRequest:requestLog returningResponse:&theResponseLog error:&errorLog];
                    if(dataLog)
                    {
                        NSDictionary *jsonArrayLog =[NSJSONSerialization JSONObjectWithData:dataLog options:NSJSONReadingMutableContainers error:&errorLog];
                        NSDictionary *tranIDLog=jsonArrayLog[@"InsertDeviceLoginInfoResult"];
                        NSString *transaction_idLog=tranIDLog[@"TransID"];
                        
                        if ([transaction_idLog isEqualToString:@"LoggedIn"])
                        {
                            
                            self.view_activity.hidden=YES;
                            [activityIndicatorView stopAnimating];
                            OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
                            ln.str_DelivSearchDate=@"Login";
                            [self.navigationController pushViewController:ln animated:NO];
                            
                        }
                        else
                        {
                            _view_activity.hidden=YES;

                            view_back1.hidden=YES;
                            
                            NSString *str_Alert=[NSString stringWithFormat:@"You have already login in %@ device. Please confirm login in this device.",transaction_idLog];
                            
                            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:str_Alert
                                                                           delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Confirm", nil];
                            alert.tag=10;
                            [alert show];
                            
                        }
                        
                    }
                    
                    
                
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Information" message:@"Please contact our customer support center for getting authentication code." preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                });
            }
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                self.view_activity.hidden=YES;
                [activityIndicatorView stopAnimating];
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
            });
        }
    });
}


-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}



#pragma mark - Textfield

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self view] endEditing:YES];
}



-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
