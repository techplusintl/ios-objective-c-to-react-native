//
//  DeliveryOrderSearchCell.h
//  Delivery
//
//  Created by Barani Elangovan on 5/10/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeliveryOrderSearchCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lab_Address;
@property(strong,nonatomic)IBOutlet UILabel *lab_TItems;
@property(strong,nonatomic)IBOutlet UILabel *lab_tCost;
@property(strong,nonatomic)IBOutlet UILabel *lab_DItems;
@property(strong,nonatomic)IBOutlet UILabel *lab_dCost;
@property(strong,nonatomic)IBOutlet UILabel *lab_Discription;

@end
