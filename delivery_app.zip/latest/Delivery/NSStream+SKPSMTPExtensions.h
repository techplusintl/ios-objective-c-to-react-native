//
//  NSStream+SKPSMTPExtensions.h
//
///  Created by Barani Elangovan on Tue Mar 18 2017.
//  Copyright (c) 2017 digitalRx. All rights reserved.
//

#import <CFNetwork/CFNetwork.h>
#import <Foundation/NSStream.h>

@interface NSStream (SKPSMTPExtensions)

+ (void)getStreamsToHostNamed:(NSString *)hostName port:(NSInteger)port inputStream:(NSInputStream **)inputStream outputStream:(NSOutputStream **)outputStream;

@end
