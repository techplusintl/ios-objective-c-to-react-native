//
//  ArSearchVc.h
//  Delivery
//
//  Created by Ghanshyam on 11/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "singleton.h"
#import "CommanMethods.h"

NS_ASSUME_NONNULL_BEGIN

@interface ArSearchVc : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    singleton *manage;
}

@property (weak, nonatomic) IBOutlet UITextField *txtSearch;
@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property(strong,nonatomic)IBOutlet UIView *view_activity;
@property (weak, nonatomic) IBOutlet UIView *viewNoDataFound;


- (IBAction)btnFind_Click:(id)sender;

- (IBAction)btnBack_Click:(id)sender;

- (IBAction)btnPay_Click:(id)sender;


@end

NS_ASSUME_NONNULL_END
