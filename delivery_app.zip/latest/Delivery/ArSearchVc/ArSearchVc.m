//
//  ArSearchVc.m
//  Delivery
//
//  Created by Ghanshyam on 11/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import "ArSearchVc.h"
#import "AccSearchCell.h"
#import "ArPaymentVc.h"
#import "DGActivityIndicatorView.h"
#import "AppDelegate.h"

@interface ArSearchVc ()
{
    NSString *str_storeID;
    NSMutableArray *arr_custList;
    NSMutableArray *arrSelected;
    DGActivityIndicatorView *activityIndicatorView;
}
@end

@implementation ArSearchVc

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setUI];
}

//MARK:- CUSTOM METHODS

-(void)setUI{
    
    arr_custList=[[NSMutableArray alloc] init];
    arrSelected=[[NSMutableArray alloc] init];
    str_storeID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];
    [self.tblView registerNib:[UINib nibWithNibName:@"AccSearchCell" bundle:nil] forCellReuseIdentifier:@"AccSearchCell"];
    self.tblView.delegate = self;
    self.tblView.dataSource = self;
    self.view_activity.hidden = true;
    
}

//MARK:- CAll API
-(void)ARCustomerList
{
    self.view_activity.hidden=NO;
    [arr_custList removeAllObjects];
    
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
              NSLog(@"%@",manage.activityTypes);
            //[[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:DGActivityIndicatorAnimationTypeBallClipRotate tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4) - 100, width/2, height/2);
            
            // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
        // NSString *myurlString = @"http://192.168.1.58:8085/Delivery.svc/DeliveryLogByUserID/100010/15/2-23-2017/2-23-2017";
        // str_StartDate=@"04-19-2017";
        // str_EndDate=@"04-19-2017";
        
        // NSString *str_DriverName1=@"";
        
        NSString *str_urrl=[NSString stringWithFormat:@"GetARAcctByName/%@/%s",self.txtSearch.text,"1"];
        
        // NSString *str_urrl=[NSString stringWithFormat:@"DeliveryDetailByID/%@/%@/%@/%@/CURRENT",manage.arr_storeInfoList[@"StoreID"],str_StartDate,str_EndDate,str_DriverName1];
        
        NSString *myurlString = [@"http://www.dbsuatserver.com/DigitalRxDeliveryIOS/Delivery.svc/" stringByAppendingString:str_urrl];
        
        
        // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
            //NSLog(@"%@",jsonArray);
            
            NSMutableArray *arr_Content = jsonArray[@"GetARAcctByNameResult"];

            NSLog(@"%@",arr_Content);
            [arr_custList removeAllObjects];
            //  arr_LogIDList= jsonArray[@"DeliveryLogByUserIDResult"];
            
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [_tblView reloadData];
                    [activityIndicatorView stopAnimating];
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    NSLog(@"%@", arr_Content);
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        [itemshowdetails setValue:temp[@"Acct_Descr"] forKey:@"Acct_Descr"];
                        [itemshowdetails setValue:temp[@"Acct_Name"] forKey:@"Acct_Name"];
                        [itemshowdetails setValue:temp[@"ArID"] forKey:@"ArID"];
                        [arr_custList addObject:itemshowdetails];
                    }
                    
                    NSLog(@"%lu", (unsigned long)arr_custList.count);
                    
                    
                    [_tblView reloadData];
                    
                  //  [table_driverlist reloadData];
                    
                    self.view_activity.hidden=YES;
                    
                    
                });
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [activityIndicatorView stopAnimating];
                //view_Current_NoData.hidden=NO;
                
                
                self.view_activity.hidden=YES;
                self.viewNoDataFound.hidden= NO;
                [_tblView reloadData];
                
            });
        }
    });
}

//MARK:- IBACTION METHODS

- (IBAction)btnFind_Click:(id)sender {
    [self ARCustomerList];
}

- (IBAction)btnBack_Click:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)btnPay_Click:(id)sender {
    
    if (arrSelected.count == 0)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Please Select Atleast One Customer" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }else{
        ArPaymentVc *ln = [[ArPaymentVc alloc]initWithNibName:@"ArPaymentVc" bundle:nil];
        [self.navigationController pushViewController:ln animated:true];
    }
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (arr_custList.count == 0)
    {
        self.view_activity.hidden=YES;
        self.viewNoDataFound.hidden= NO;
        return 0;
    }
    self.view_activity.hidden=YES;
    self.viewNoDataFound.hidden= YES;
    return arr_custList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *MyIdentifier = @"AccSearchCell";
    
    AccSearchCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    cell.lblAmount.hidden = YES;
    cell.lblName.text = [NSString stringWithFormat:@"%@",arr_custList[indexPath.row][@"Acct_Name"]];
    cell.lblAddress.text = [NSString stringWithFormat:@"%@",arr_custList[indexPath.row][@"Acct_Descr"]];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        return cell;
    }

    - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
        ArPaymentVc *ln = [[ArPaymentVc alloc]initWithNibName:@"ArPaymentVc" bundle:nil];
        ln.arrArSearch = arr_custList[indexPath.row];
        [self.navigationController pushViewController:ln animated:true];
    }

    - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
        return 150;
    }

    - (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
        return 150;
    }

    @end
