//
//  AccSearchCell.h
//  Delivery
//
//  Created by Ghanshyam on 13/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AccSearchCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblAmount;
@property (weak, nonatomic) IBOutlet UILabel *lblAddress;
@property (weak, nonatomic) IBOutlet UIView *viewMain;


@end

NS_ASSUME_NONNULL_END
