//
//  AccSearchCell.m
//  Delivery
//
//  Created by Ghanshyam on 13/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import "AccSearchCell.h"

@implementation AccSearchCell



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.viewMain.layer.masksToBounds = NO;
    self.viewMain.layer.cornerRadius = 8.f;
    self.viewMain.layer.shadowOffset = CGSizeMake(.0f,2.5f);
    self.viewMain.layer.shadowRadius = 1.5f;
    self.viewMain.layer.shadowOpacity = .9f;
    self.viewMain.layer.shadowColor = [UIColor colorWithRed:176.f/255.f green:199.f/255.f blue:226.f/255.f alpha:1.f].CGColor;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
