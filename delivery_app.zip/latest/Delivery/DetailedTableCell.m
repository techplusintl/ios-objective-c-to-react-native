//
//  DetailedTableCell.m
//  Delivery
//
//  Created by Barani Elangovan on 5/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "DetailedTableCell.h"

@implementation DetailedTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
