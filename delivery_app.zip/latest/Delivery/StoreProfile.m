//
//  StoreProfile.m
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "StoreProfile.h"

@interface StoreProfile ()

{
    NSString *str_Time;
    Mapannotation *newAnnotation;
    
    NSString *address;
}

@end

@implementation StoreProfile
@synthesize view_Mail,view_Phone,view_Fax,lab_Time,lab_Contry,lab_Street,lab_CityState,lab_ContactName,lab_PharmacyName,lab_PharmacyName1,view_WorkingHours,view_Address,scroll_view,lab_fax,lab_mail,lab_phone,mapView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage=[singleton share];
    
    
    view_WorkingHours.hidden=YES;
    str_Time=@"No";
    
    
    
        // lab_ContactName.text=manage.arr_storeInfoList[@"PharmacyContactName"];
    
    lab_phone.text=manage.arr_storeInfoList[@"PharmacyPhone"];
    lab_mail.text=manage.arr_storeInfoList[@"PharmacyEmail"];
    lab_fax.text=manage.arr_storeInfoList[@"PharmacyFax"];
    
    lab_PharmacyName1.text=manage.arr_storeInfoList[@"PharmacyName"];
    lab_PharmacyName.text=manage.arr_storeInfoList[@"PharmacyName"];
    lab_Street.text=manage.arr_storeInfoList[@"PharmacyStreet"];
    
    NSString *str_Add=[manage.arr_storeInfoList[@"PharmacyCity"] stringByAppendingString:@", "];
    str_Add=[str_Add stringByAppendingString:manage.arr_storeInfoList[@"PharmacyState"]];
    str_Add=[str_Add stringByAppendingString:@" - "];
    str_Add=[str_Add stringByAppendingString:manage.arr_storeInfoList[@"PharmacyZip"]];
    lab_CityState.text=str_Add;
    
    
    // lab_PharmacyName.text=manage.arr_storeInfoList[0][@"PharmacyName"];
    // lab_PharmacyName.text=manage.arr_storeInfoList[0][@"PharmacyName"];
    
    
    view_Mail. layer.cornerRadius =25;
    view_Mail. layer.masksToBounds =YES;
    view_Mail.layer.borderColor=([UIColor whiteColor]).CGColor;
    view_Mail.layer.borderWidth=1;
    
    view_Phone. layer.cornerRadius =25;
    view_Phone. layer.masksToBounds =YES;
    view_Phone.layer.borderColor=([UIColor whiteColor]).CGColor;
    view_Phone.layer.borderWidth=1;
    
    view_Fax. layer.cornerRadius =25;
    view_Fax. layer.masksToBounds =YES;
    view_Fax.layer.borderColor=([UIColor whiteColor]).CGColor;
    view_Fax.layer.borderWidth=1;
    
    
    
    mapView.mapType = MKMapTypeStandard;
    
    address=[lab_Street.text stringByAppendingString:[NSString stringWithFormat:@", %@",manage.arr_storeInfoList[@"PharmacyCity"]]];
    address=[address stringByAppendingString:[NSString stringWithFormat:@", %@",manage.arr_storeInfoList[@"PharmacyState"]]];
    address=[address stringByAppendingString:[NSString stringWithFormat:@" - %@",manage.arr_storeInfoList[@"PharmacyZip"]]];
    
    
  //  NSString *address = [NSString stringWithFormat:@"100 Pacifica Suite 470,Irvine,California,United States"];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder geocodeAddressString:str_Add completionHandler:^(NSArray *placemarks, NSError *error)
     {
         if(!error)
         {
             CLPlacemark *placemark = [placemarks objectAtIndex:0];
             // // NSLog(@"%f",placemark.location.coordinate.latitude);
             // NSLog(@"%f",placemark.location.coordinate.longitude);
             // NSLog(@"%@",[NSString stringWithFormat:@"%@",[placemark description]]);
             
             CLLocationCoordinate2D location;
             
             location.longitude =placemark.location.coordinate.longitude;
             location.latitude =placemark.location.coordinate.latitude;
             // Add the annotation to our map view
             newAnnotation = [[Mapannotation alloc]
                              initWithTitle:lab_PharmacyName.text andCoordinate:location];
             [mapView addAnnotation:newAnnotation];
             
         }
         else
         {
             // NSLog(@"There was a forward geocoding error\n%@",[error localizedDescription]);
         }
     }
     ];
    
    
    /* [UIView animateWithDuration:.0
     animations:^{
     
     [view_Address setFrame:CGRectMake(view_AddCardView.frame.origin.x,(self.table_Rx_list.frame.size.height+table_Rx_list.frame.origin.y), view_AddCardView.frame.size.width, view_AddCardView.frame.size.height)];
     }
     ];
     */
    
    [UIView animateWithDuration:.0
                     animations:^{
                         
                         [view_Address setFrame:CGRectMake(view_Address.frame.origin.x,118, view_Address.frame.size.width, view_Address.frame.size.height)];
                     }
     ];
    
    
   
    
    
    // Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL)animated
{
    scroll_view.scrollEnabled=YES;
    scroll_view.contentSize=CGSizeMake(self.view.frame.size.width,586);
}



- (void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    MKAnnotationView *annotationView = [views objectAtIndex:0];
    id <MKAnnotation> mp = [annotationView annotation];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance
    ([mp coordinate], 500, 500);
    [mv setRegion:region animated:YES];
    [mv selectAnnotation:mp animated:YES];
    
    
}

-(IBAction)btn_Back:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}

-(IBAction)btn_WorkingHours:(id)sender
{
    
    
    if ([str_Time isEqualToString:@"No"])
    {
        
        str_Time=@"Yes";
        view_WorkingHours.hidden=NO;
        
        
        [UIView animateWithDuration:.0
                         animations:^{
                             
                             [view_Address setFrame:CGRectMake(view_Address.frame.origin.x,263, view_Address.frame.size.width, view_Address.frame.size.height)];
                         }
         ];
        
        scroll_view.scrollEnabled=YES;
        scroll_view.contentSize=CGSizeMake(self.view.frame.size.width,435);
        
        
        
    }
    else
    {
        
        str_Time=@"No";
        
        view_WorkingHours.hidden=YES;
        
        [UIView animateWithDuration:.0
                         animations:^{
                             
                             [view_Address setFrame:CGRectMake(view_Address.frame.origin.x,118, view_Address.frame.size.width, view_Address.frame.size.height)];
                         }
         ];
        
        scroll_view.scrollEnabled=YES;
        scroll_view.contentSize=CGSizeMake(self.view.frame.size.width,300);
    }
    
}

-(IBAction)call_phone:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:manage.arr_storeInfoList[@"PharmacyPhone"]
                                                   delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Call", nil];
    alert.tag=999;
    [alert show];
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==999)
    {
        if (buttonIndex==0) {
        }
        else
        {
            if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
            {
                NSString *number=manage.arr_storeInfoList[@"PharmacyPhone"];
                NSString *phoneNumber = [@"tel://" stringByAppendingString:number];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
                
            } else {
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Your device doesn't support this feature." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *notPermitted=[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Your device doesn't support this feature." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//                [notPermitted show];
                
            }
        }
    }
}
-(IBAction)btn_Mail:(id)sender
{
    NSString *emailTitle = @"";
    // Email Content
    NSString *messageBody = @"";
    // To address
    NSMutableArray *toRecipents=[[NSMutableArray alloc]init];
    
    [toRecipents addObject:manage.arr_storeInfoList[@"PharmacyEmail"]];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    [mc setSubject:emailTitle];
    [mc setMessageBody:messageBody isHTML:NO];
    [mc setToRecipients:toRecipents];
    
    // Present mail view controller on screen
    [self presentViewController:mc animated:YES completion:nil];
    
}

-(IBAction)btn_Fax:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Fax Number" message:manage.arr_storeInfoList[@"PharmacyFax"]
                                                   delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
    alert.tag=1000;
    [alert show];
    
}
-(IBAction)btn_PharmacyDirection:(id)sender
{
    
    
    
    /*
     
     AccessLevel = Admin;
     AccessLevelID = 4;
     MerchantAccount = "";
     MerchantPassword = "";
     PharmacyCity = Irvine;
     PharmacyEmail = "support@rxcity.com";
     PharmacyFax = "(714) 844-4606";
     PharmacyName = "DBS-TEST-SERVER11";
     PharmacyPhone = "(949) 298-6600";
     PharmacyState = CA;
     PharmacyStreet = "100 Pacifica, Suite 470";
     PharmacyZip = 92618;
     StoreID = 100999;
     UserFirstName = Owner;
     UserID = 461;
     UserLastName = Pharmacy;
     
     
     */

    
    
    DeliveryLocation *ln = [[DeliveryLocation alloc]initWithNibName:@"DeliveryLocation" bundle:nil];
    ln.str_Address=address;
    ln.str_Street=manage.arr_storeInfoList[@"PharmacyStreet"];
    ln.str_State=[NSString stringWithFormat:@"%@, %@ - %@",manage.arr_storeInfoList[@"PharmacyCity"],manage.arr_storeInfoList[@"PharmacyState"],manage.arr_storeInfoList[@"PharmacyZip"]];
    
    ln.str_PatientName=manage.arr_storeInfoList[@"PharmacyName"];
    
    
    [self.navigationController pushViewController:ln animated:NO];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
