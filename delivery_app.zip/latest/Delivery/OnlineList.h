//
//  OnlineList.h
//  Delivery
//
//  Created by Barani Elangovan on 5/3/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CommanMethods.h"
#import "NSString+test.h"

#import "OnlineListCell.h"
#import "OnlineListCellTest.h"
#import "DriverListCell.h"
#import "singleton.h"
#import "DetailedScreen.h"
#import "DeliveredDetailedScreen.h"
#import "AppDelegate.h"
#import "HomeScreen.h"
#import "DeliveryOrderScreen.h"
#import "ScanReadyforDeliver.h"


#import "BarCodeScaner.h"


#import "RouteMap.h"

#import <CoreLocation/CoreLocation.h>

#import "ViewController.h"
#import "DBManager.h"
#import "Reachability.h"
#import "OnlineCheck.h"
#import "OnlineList.h"



#import "StoreProfile.h"
#import "PatientProfile.h"

#import "DriverTtackPath.h"

@interface OnlineList : UIViewController<CLLocationManagerDelegate, UIAlertViewDelegate,UITextFieldDelegate>
{
    singleton *manage;
    
    BOOL isSearching;
    BOOL isSearching_delivered;
}

@property(strong,nonatomic)NSString *str_PaymentLogID;

@property(strong,nonatomic)NSString *str_DelivSearchDate;

@property (nonatomic,strong) CLLocationManager *locationManager;


@property(strong,nonatomic)IBOutlet UIView *view_activity;


@property(strong,nonatomic)IBOutlet UIView *view_Current;
@property(strong,nonatomic)IBOutlet UIView *view_Delivered;

@property(strong,nonatomic)IBOutlet UIView *view_Current_Line;
@property(strong,nonatomic)IBOutlet UIView *view_Delivered_Line;

@property(strong,nonatomic)IBOutlet UIView *view_Current_NoData;
@property(strong,nonatomic)IBOutlet UIView *view_Delivered_NoData;

@property(strong,nonatomic)IBOutlet UITableView *table_Current;
@property(strong,nonatomic)IBOutlet UITableView *table_Delivered;

@property(strong,nonatomic)IBOutlet UILabel *lab_Date;
@property(strong,nonatomic)IBOutlet UILabel *lab_Date1;
@property(strong,nonatomic)IBOutlet UIView *view_Date_Small;
@property(strong,nonatomic)IBOutlet UIView *view_Date_Large;



@property(strong,nonatomic)IBOutlet UIView *viewMain;
@property(strong,nonatomic)IBOutlet UIView *sidepage;
@property(strong,nonatomic)IBOutlet UIScrollView *scroll_SidePage;
@property(strong,nonatomic)IBOutlet UILabel *lab_DriverName;
@property (weak, nonatomic) IBOutlet UIView *viewArPayment;


@property(strong,nonatomic)IBOutlet UIImageView *image_Search;
@property(strong,nonatomic)IBOutlet UIButton *btn_Search;

@property(strong,nonatomic)IBOutlet UIButton *btn_MapListt;

@property(strong,nonatomic)IBOutlet UIImageView *image_Scan;
@property(strong,nonatomic)IBOutlet UIButton *btn_Scan;
@property(strong,nonatomic)IBOutlet UIView *view_BarCode;
@property(strong,nonatomic)IBOutlet UIView *view_BarCode1;
@property(strong,nonatomic)IBOutlet UIView *view_BarCode2;


@property(strong,nonatomic)IBOutlet UIView *view_current_background;
@property(strong,nonatomic)IBOutlet UIView *view_delivered_background;

@property(strong,nonatomic)IBOutlet UIButton *btn_current;
@property(strong,nonatomic)IBOutlet UIButton *btn_delivered;

@property(strong,nonatomic)IBOutlet UIView *view_scrl_inside;

@property(strong,nonatomic)IBOutlet UISearchBar *searchbar_current;
@property(strong,nonatomic)IBOutlet UISearchBar *searchbar_delivered;
@property (strong, nonatomic) IBOutlet UISearchDisplayController *searchBarController;

@property(strong,nonatomic) IBOutlet UIImageView *img_download;
@property(strong,nonatomic) IBOutlet UIButton *btn_bulk_download;

@property(strong,nonatomic) IBOutlet UIView *view_scanLogID;
@property(strong,nonatomic) IBOutlet UIView *view_scanSide;

@property(strong,nonatomic) IBOutlet UIView *view_driverlist;
@property(strong,nonatomic) IBOutlet UITableView *table_driverlist;
@property (weak, nonatomic) IBOutlet UIView *viewSettings;

- (IBAction)btnSettings_Click:(id)sender;

@end
