//
//  HomeScreen.h
//  Delivery
//
//  Created by Barani Elangovan on 5/3/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ViewController.h"
#import "OnlineList.h"
#import "singleton.h"
#import "LocationFind.h"
@interface HomeScreen : UIViewController
{
    singleton *manage;
}


@property(strong,nonatomic)IBOutlet UIView *view_Online;
@property(strong,nonatomic)IBOutlet UIView *view_Offline;
@property(strong,nonatomic)IBOutlet UIView *view_Download;
@property(strong,nonatomic)IBOutlet UIView *view_Upload;

@property(strong ,nonatomic)IBOutlet UILabel *lab_Online_icon_color;
@property(strong ,nonatomic)IBOutlet UILabel *lab_Offline_icon_color;
@property(strong ,nonatomic)IBOutlet UILabel *lab_Download_icon_color;
@property(strong ,nonatomic)IBOutlet UILabel *lab_Upload_icon_color;

@property(strong,nonatomic)IBOutlet UIView *view1;
@property(strong,nonatomic)IBOutlet UIView *sidepage;
@property(strong,nonatomic)IBOutlet UIScrollView *scroll_SidePage;


@property(strong,nonatomic)IBOutlet UILabel *lab_DriverName;
@property(strong,nonatomic)IBOutlet UILabel *lab_PharmacyName;


@end
