//
//  GPSTrack.m
//  Delivery
//
//  Created by Barani Elangovan on 4/27/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "GPSTrack.h"

@interface GPSTrack ()

{
    NSString *str_StoreID;
    NSString *str_UserID;

}
@end

@implementation GPSTrack

@synthesize mapVieww;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage=[singleton share];
    
    str_StoreID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];
    str_UserID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]];

    [NSTimer scheduledTimerWithTimeInterval:60
                                     target:self selector:@selector(GPSTrackk:) userInfo:nil repeats:YES];
    [self GPSTrack];

    
    // Do any additional setup after loading the view.
}
- (void) GPSTrackk:(NSTimer *)timer
{
    NSMutableArray *arr_location=[[NSMutableArray alloc]init];
    
    [arr_location removeAllObjects];
    NSString *str_urrl=[NSString stringWithFormat:@"GetGPSMobileTracking/%@/%@",str_StoreID,str_UserID];
    
    NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
    
    
        // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    NSError *err;
    NSURLResponse *response;
    
    NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        //   NSLog(@"%@",responsedata);
    
    
    if (responsedata)
    {
        
        /*  CreatedDate = "4-27-2017";
         Latitude = "37.337574";
         Longitude = "-122.04126";
         Status = 1;
         StoreID = 100010;
         UserID = 15;*/
        
        
        NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
        NSLog(@"%@",jsonArray);
        NSArray *arr_vall=jsonArray[@"GetGPSMobileTrackingResult"];
        
        
        
        for (NSDictionary *temp in arr_vall)
        {
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            [itemshowdetails setValue:temp[@"CreatedDate"] forKey:@"CreatedDate"];
            [itemshowdetails setValue:temp[@"Latitude"] forKey:@"Latitude"];
            [itemshowdetails setValue:temp[@"Longitude"] forKey:@"Longitude"];
            [itemshowdetails setValue:temp[@"Status"] forKey:@"Status"];
            [itemshowdetails setValue:temp[@"StoreID"] forKey:@"StoreID"];
            [itemshowdetails setValue:temp[@"UserID"] forKey:@"UserID"];
            
            [arr_location addObject:itemshowdetails];
        }
        
        [self.mapVieww removeAnnotations:mapVieww.annotations];
        
        
        CLLocation *newLocation = [[CLLocation alloc] initWithLatitude:[arr_location[0][@"Latitude"]doubleValue] longitude:[arr_location[0][@"Longitude"]doubleValue]];
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        annotation.coordinate = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
            //annotation.title = arr_mutAddress[m];
        [self.mapVieww addAnnotation:annotation];

        MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(newLocation.coordinate, 800, 800);
        [self.mapVieww setRegion:[self.mapVieww regionThatFits:region] animated:YES];
    }
    
}


-(void)GPSTrack
{
    NSMutableArray *arr_location=[[NSMutableArray alloc]init];
    
    [arr_location removeAllObjects];
    NSString *str_urrl=[NSString stringWithFormat:@"GetGPSMobileTracking/%@/%@",str_StoreID,str_UserID];
    
    NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
    
    
        // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    NSError *err;
    NSURLResponse *response;
    
    NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        //   NSLog(@"%@",responsedata);
    
    
    if (responsedata)
    {
        
        /*  CreatedDate = "4-27-2017";
         Latitude = "37.337574";
         Longitude = "-122.04126";
         Status = 1;
         StoreID = 100010;
         UserID = 15;*/
        
        
        NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
        NSLog(@"%@",jsonArray);
        NSArray *arr_vall=jsonArray[@"GetGPSMobileTrackingResult"];
        
        
        
        for (NSDictionary *temp in arr_vall)
        {
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            [itemshowdetails setValue:temp[@"CreatedDate"] forKey:@"CreatedDate"];
            [itemshowdetails setValue:temp[@"Latitude"] forKey:@"Latitude"];
            [itemshowdetails setValue:temp[@"Longitude"] forKey:@"Longitude"];
            [itemshowdetails setValue:temp[@"Status"] forKey:@"Status"];
            [itemshowdetails setValue:temp[@"StoreID"] forKey:@"StoreID"];
            [itemshowdetails setValue:temp[@"UserID"] forKey:@"UserID"];
            
            [arr_location addObject:itemshowdetails];
        }
        
        
        [self.mapVieww removeAnnotations:mapVieww.annotations];
        
        
        CLLocation *newLocation = [[CLLocation alloc] initWithLatitude:[arr_location[0][@"Latitude"]doubleValue] longitude:[arr_location[0][@"Longitude"]doubleValue]];
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        annotation.coordinate = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
            //annotation.title = arr_mutAddress[m];
        [self.mapVieww addAnnotation:annotation];
        
        
        MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(newLocation.coordinate, 800, 800);
        [self.mapVieww setRegion:[self.mapVieww regionThatFits:region] animated:YES];

        
    }
    
}


-(IBAction)btn_Back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
