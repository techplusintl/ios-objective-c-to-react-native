//
//  DeliveryOrderSearchDownloadCell.h
//  Delivery
//
//  Created by Barani Elangovan on 5/18/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeliveryOrderSearchDownloadCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UIButton *btn_Download;

@end
