//
//  CustomMessage.h
//  Delivery
//
//  Created by Barani Elangovan on 10/23/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomMessage : UIViewController

@property(strong,nonatomic)NSString *str_Title;
@property(strong,nonatomic)IBOutlet UILabel *lab_Title;

@end
