//
//  BarCodeScaner.h
//  Delivery
//
//  Created by Barani Elangovan on 5/25/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "singleton.h"
#import "MTBBarcodeScanner.h"
#import "DBManager.h"

@interface BarCodeScaner : UIViewController
{
    singleton *manage;
}
@property(strong,nonatomic)NSString *str_Type;

@property(strong,nonatomic)IBOutlet UIView *view_activity;


@property (nonatomic, weak) IBOutlet UIView *previewView;

@property (nonatomic, strong) MTBBarcodeScanner *scanner;
@property (nonatomic, strong) NSMutableArray *uniqueCodes;
@property(strong,nonatomic)NSString *name_copy;
@property (nonatomic, assign) BOOL captureIsFrozen;
@property (nonatomic, weak) IBOutlet UIBarButtonItem *toggleTorchButton;
@property (nonatomic, weak) IBOutlet UIButton *toggleScanningButton;

@property(strong,nonatomic)IBOutlet UIButton *btn_Scann;

@property(strong,nonatomic)IBOutlet UILabel *lab_Code;

@property(strong,nonatomic)IBOutlet UIImageView *image_Flash;

@end
