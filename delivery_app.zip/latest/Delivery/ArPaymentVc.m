//
//  ArPaymentVc.m
//  Delivery
//
//  Created by Ghanshyam on 11/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import "ArPaymentVc.h"
#import "UITextView+Placeholder.h"
#import "SignVc.h"
#import "AppDelegate.h"
#import "DGActivityIndicatorView.h"
#import "singleton.h"

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;

@interface ArPaymentVc ()
{
    NSString *previousTextFieldContent;
    UITextRange *previousSelection;
    DGActivityIndicatorView *activityIndicatorView;
    
    NSArray *activityTypes;
    NSString *internet_flag;
    NSString *yearstring;
    NSString *monthString;
    
    NSInteger week;
    
    
    NSString *str_PaymentType;
}
@end

@implementation ArPaymentVc

@synthesize str_PatientName,str_IsPOS,str_POSID,str_PatientAddress, str_street,str_city,str_state,arr_Del_Qty,str_patient_email, str_ARzip,str_ARstate,str_ARcity,str_ARbalance,str_ARbill,str_ARphone,str_ARacc,str_ARar,str_ARaddress,str_RxSearch,str_patpay,str_internet,str_logid,str_rxcount,str_cardNumber,str_expDate,str_ccCode,str_patZip,arr_RxARItemID;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setUI];
}

-(void)setUI
{
    str_PaymentType=@"Card";
    
    manage=[singleton share];

    
    _viewCash.hidden = true;
    _viewCheck.hidden = true;
    _viewCredit.hidden = false;
    _viewSeperateCash.hidden = true;
    _viewSeperateCheck.hidden = true;
    _viewSeperateCredit.hidden = false;
    
    self.txtCreditTotal.delegate = self;
    self.txtCheckTotal.delegate = self;
    self.txtCashTotal.delegate = self;
    self.txtCreditCardNumber.delegate = self;
    self.txtExpiryDate.delegate = self;
    self.txtCVV.delegate = self;
    self.txtZipCode.delegate = self;
    self.txtRefNumber.delegate = self;    
    
    [self.txtCashComments.layer setCornerRadius:3.0];
    [self.txtCashComments.layer setBorderColor:UIColor.blackColor.CGColor];
    [self.txtCashComments.layer setBorderWidth:1.0];
 
    [self.txtCreditComments.layer setCornerRadius:3.0];
    [self.txtCreditComments.layer setBorderColor:UIColor.blackColor.CGColor];
    [self.txtCreditComments.layer setBorderWidth:1.0];
    
    [self.txtCheckComments.layer setCornerRadius:3.0];
    [self.txtCheckComments.layer setBorderColor:UIColor.blackColor.CGColor];
    [self.txtCheckComments.layer setBorderWidth:1.0];
    
    self.txtCheckComments.placeholder = @"Comments";
    self.txtCreditComments.placeholder = @"Comments";
    self.txtCheckComments.placeholder = @"Comments";
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yy"];
    yearstring = [formatter stringFromDate:[NSDate date]];
    
    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    [formatter1 setDateFormat:@"MM"];
    monthString = [formatter1 stringFromDate:[NSDate date]];
    
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
    week = [components month];
    
    NSString *pat_cardNo = str_cardNumber;
    NSString *pat_expdate = str_expDate;
    NSString *pat_cccode = str_ccCode;
    NSString *pat_zip = str_patZip;

    
    
    
    //pat_cccode=@"1116";
    
    if ([pat_cardNo isEqualToString:@""] || pat_cardNo == NULL) {
        
    }
    else
    {
        NSLog(@"%@",_txtCreditCardNumber.text);
        NSString *str_padding=@"";
        NSRange subStringRange = NSMakeRange(0,[pat_cardNo length]-4);
        str_padding =[str_padding stringByPaddingToLength:subStringRange.length+3 withString:@"X" startingAtIndex:0];
        
        
        pat_cardNo = [pat_cardNo stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_cardNo substringToIndex:subStringRange.length]] withString:str_padding];
        NSLog(@"%@",pat_cardNo);
        NSString *trimmedString=[pat_cardNo substringFromIndex:MAX((int)[pat_cardNo length]-4, 0)];
        
        
        pat_cardNo=[@"XXXX XXXX XXXX " stringByAppendingString:trimmedString];
        _txtCreditCardNumber.text=pat_cardNo;


    }
    
    if ([pat_expdate isEqualToString:@""] || pat_expdate == NULL) {
        
        
    }
    else
    {
        NSString *str_padding1=@"";
        NSRange subStringRange1 = NSMakeRange(0,[pat_expdate length]);
        str_padding1 =[str_padding1 stringByPaddingToLength:subStringRange1.length withString:@"X" startingAtIndex:0];
        
        pat_expdate = [pat_expdate stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_expdate substringToIndex:subStringRange1.length]] withString:str_padding1];
        

        _txtExpiryDate.text=pat_expdate;
    }
    
    if ([pat_cccode isEqualToString:@""] || pat_cccode == NULL) {
        
    }
    else
    {
        
        NSString *str_padding2=@"";
        NSRange subStringRange2 = NSMakeRange(0,[pat_cccode length]);
        str_padding2 =[str_padding2 stringByPaddingToLength:subStringRange2.length withString:@"X" startingAtIndex:0];
        
        pat_cccode = [pat_cccode stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_cccode substringToIndex:subStringRange2.length]] withString:str_padding2];
        NSLog(@"%@",pat_cccode);
        

        _txtCVV.text=pat_cccode;
    }
    if ([pat_zip isEqualToString:@""] || pat_zip == NULL) {
        
    }
    else
    {
        
        NSString *str_padding3=@"";
        NSRange subStringRange3 = NSMakeRange(0,[pat_zip length]);
        str_padding3 =[str_padding3 stringByPaddingToLength:subStringRange3.length withString:@"X" startingAtIndex:0];
        
        pat_zip = [pat_zip stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@",[pat_zip substringToIndex:subStringRange3.length]] withString:str_padding3];
        NSLog(@"%@",pat_zip);
        
        
        _txtZipCode.text=pat_zip;
    }
    

    
    NSLog(@"%@",manage.arr_storeInfoList);
    
    [self.txtExpiryDate addTarget:self
              action:@selector(dateTextFieldDidChange:)
    forControlEvents:UIControlEventEditingChanged];
}

-(void)viewDidAppear:(BOOL)animated
{

    [super viewDidAppear:animated];

    //[self restrictRotation:NO];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
            UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
                //  NSLog(@"iphone");
            if(orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationMaskPortrait)
            {

            }
        else
        {
                NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationMaskPortrait];
                [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }
        
        /*
    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
    */
    }
}

#pragma mark - Textfield Delegate

- (void) dateTextFieldDidChange: (UITextField *)theTextField {
    
    NSString *string = theTextField.text;
        // NSLog(@"%d", theTextField.text.intValue);
    
    
    
    if (string.length == 2  &&  theTextField.text.intValue<=12) {
        
        theTextField.text = [string stringByAppendingString:@"/"];
        
            //  NSLog(@"%d",[theTextField.text substringToIndex:2].intValue);
        
    }
    else if(string.length==2 && theTextField.text.intValue>12)
    {
        
            // theTextField.text = [theTextField.text stringByAppendingString:@"0"];
        NSMutableString *mu = [NSMutableString stringWithString:string];
        [mu insertString:@"0" atIndex:0];
        [mu insertString:@"/" atIndex:2];
        theTextField.text = mu;
            // NSLog(@"Please enter");
            //  txt_card_exp.text= @"";
    }
    
    
    else if (string.length==5 && [theTextField.text substringFromIndex:[theTextField.text length] -2].intValue<yearstring.intValue)
        
    {
        NSString *mu = [theTextField.text substringToIndex:[theTextField.text length]-5];
        theTextField.text = mu;
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid Date" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid Date"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//        [alert show];
        
    }
    
    else if (string.length==5 && [theTextField.text substringFromIndex:[theTextField.text length] -2].intValue==yearstring.intValue &&  string.length==5 && [theTextField.text substringToIndex:2].intValue<monthString.intValue)
        
    {
        NSString *mu = [theTextField.text substringToIndex:[theTextField.text length]-5];
        theTextField.text = mu;
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid Date" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid Date"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//        [alert show];
        
    }
    
    
    else if (string.length > 5) {
        
        theTextField.text = [string substringToIndex:5];
        
    }
    else if(string.length==5)
    {
        
            // NSLog(@"%@",[theTextField.text substringToIndex:2]);
        
        
      //  CGFloat borderWidth = 1.0f;
        
        
            //view_expdate.layer.borderColor = [UIColor lightGrayColor].CGColor;
            //view_expdate.layer.borderWidth = borderWidth;
            //view_expdate.layer.cornerRadius = 3;
        //img_card_expdate.image =[UIImage imageNamed:@"calendarnew.png"];
        
    }
    
    
    
}





-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField ==_txtCashTotal || textField ==self.txtCreditTotal || textField ==self.txtCheckTotal) {
        
        NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789."]invertedSet];
            // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
        
        if ([string isEqualToString:filtered]) {
            if(string.length!=0){
                if ([string isEqualToString:@"."]) {
                    if ([_txtCashTotal.text containsString:@"."] || [_txtCreditTotal.text containsString:@"."] || [_txtCheckTotal.text containsString:@"."]) {
                        return NO;
                    }
                    else
                    {
                        return YES;
                    }
                }
                else
                {
                    return YES;

                }
                
            }
            else
            {
                return YES;
            }
        }

        return [string isEqualToString:filtered];
        
    }
    else if (textField==_txtCreditCardNumber) {
        
        
        __block NSString *text = [_txtCreditCardNumber text];
        
        NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789X\b"];
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) {
            return NO;
        }
        
        text = [text stringByReplacingCharactersInRange:range withString:string];
        text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        NSString *newString = @"";
        while (text.length > 0) {
            NSString *subString = [text substringToIndex:MIN(text.length, 4)];
            newString = [newString stringByAppendingString:subString];
            if (subString.length == 4) {
                newString = [newString stringByAppendingString:@" "];
            }
            text = [text substringFromIndex:MIN(text.length, 4)];
        }
        
        newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
        
        
       // CGFloat borderWidth = 1.0f;
        
        
        if(_txtCreditCardNumber.text.length==18)
        {
                //view_cardnumber.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_cardnumber.layer.borderWidth = borderWidth;
                //view_cardnumber.layer.cornerRadius = 3;
            //img_card_number.image =[UIImage imageNamed:@"cnumber.png"];
            
        }
        if (newString.length >= 20) {
            return NO;
        }
        
        [textField setText:newString];
        
        return NO;
    }
    
    else if (textField==_txtCVV)
    {
        
        NSString *string1 = _txtCVV.text;
        if(string1.length<=2)
        {
            
            NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789X"]invertedSet];
                // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
            
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
            
            return [string isEqualToString:filtered];
            
        }
        else if([string isEqualToString:@""])
        {
            return YES;
        }
        else if (_txtCVV.text.length==3)
        {
            //CGFloat borderWidth = 1.0f;
            
                //view_cvv.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_cvv.layer.borderWidth = borderWidth;
                //view_cvv.layer.cornerRadius = 3;
            
            
            //imag_card_cvv.image =[UIImage imageNamed:@"cvvnew.png"];
            
        }
        else
        {
            return NO;
        }
    }
    else if (textField==_txtZipCode)
    {
        
        NSString *string1 = _txtZipCode.text;
        if(string1.length<=8)
        {
            
            NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789X"]invertedSet];
                // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
            
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
            
            
            return [string isEqualToString:filtered];
            
            
        }
        else if([string isEqualToString:@""])
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if (textField==_txtRefNumber)
    {
  
            NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
                // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
            
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
            
            
            return [string isEqualToString:filtered];
            
        
    }
    /*
     else if (textField ==txt)
     {
     CGFloat borderWidth = 1.0f;
     
     
     view_zip.layer.borderColor = [UIColor lightGrayColor].CGColor;
     view_zip.layer.borderWidth = borderWidth;
     view_zip.layer.cornerRadius = 3;
     
     NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
     // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
     
     NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
     
     
     return [string isEqualToString:filtered];
     
     
     }
     
     
     */
    
    else if (textField==_txtExpiryDate) {
        
        

         NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789X"]invertedSet];
         // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
         
         NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
         
         
         
         
         
        

        
        NSString *resultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        BOOL isPressedBackspaceAfterSingleSpaceSymbol = [string isEqualToString:@""] && resultString.intValue<=12 && range.location == 2 && range.length == 1;
        if (isPressedBackspaceAfterSingleSpaceSymbol) {
            
            
                //  NSString *mu = [theTextField.text substringToIndex:[theTextField.text length]-2];
                //  your actions for deleteBackward actions
            _txtExpiryDate.text= @"";
            NSLog(@"delete");
            
        }
             return [string isEqualToString:filtered];
        /*
         else if([string isEqualToString:@""])
         {
         return YES;
         }
         
         
         */
    }
    
    
    /*
     
     else if ([string isEqualToString:@""] && textField.text.length == 0) {
     
     NSString *dateString = textField.text;
     
     [dateString stringByReplacingOccurrencesOfString:@"/" withString:@""];
     
     }
     
     
     */
    
    return YES;
    
    
}





-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==_txtCreditTotal)
    {
        [_txtCashTotal resignFirstResponder];
    }
    else if (textField==_txtCreditCardNumber)
    {
        [_txtCreditCardNumber becomeFirstResponder];
    }
    else if (textField==_txtExpiryDate)
    {
        
        [_txtExpiryDate becomeFirstResponder];
    }
    else if (textField==_txtCVV)
    {
        [_txtCVV becomeFirstResponder];
    }
    else if (textField==_txtZipCode)
    {
        [_txtZipCode resignFirstResponder];
    }
    else if (textField==_txtCashTotal)
    {
        [_txtCashTotal resignFirstResponder];
    }else if (textField==_txtCheckTotal)
    {
        [_txtCheckTotal resignFirstResponder];
    }else if (textField==_txtRefNumber)
    {
        [_txtRefNumber resignFirstResponder];
    }
    return YES;
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}

//MARK:- IBACTION METHODS
- (IBAction)btnBack_Click:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)btnCreditCard_Click:(id)sender {
    str_PaymentType=@"Card";
    _viewCash.hidden = true;
    _viewCheck.hidden = true;
    _viewCredit.hidden = false;
    _viewSeperateCash.hidden = true;
    _viewSeperateCheck.hidden = true;
    _viewSeperateCredit.hidden = false;
}

- (IBAction)btnCash_Click:(id)sender {
     str_PaymentType=@"Cash";
    _viewCash.hidden = false;
    _viewCheck.hidden = true;
    _viewCredit.hidden = true;
    _viewSeperateCash.hidden = false;
    _viewSeperateCheck.hidden = true;
    _viewSeperateCredit.hidden = true;
}

- (IBAction)btnCheck_Click:(id)sender {
    str_PaymentType=@"Check";
    _viewCash.hidden = true;
    _viewCheck.hidden = false;
    _viewCredit.hidden = true;
    _viewSeperateCash.hidden = true;
    _viewSeperateCheck.hidden = false;
    _viewSeperateCredit.hidden = true;
    
//    SignVc *ln = [[SignVc alloc]initWithNibName:@"SignVc" bundle:nil];
//    [self.navigationController pushViewController:ln animated:true];
}

- (IBAction)btnVerify_Click:(id)sender {
    if ([str_PaymentType isEqualToString:@"Card"])
    {
        
        if ([manage.str_InternetFlag isEqualToString:@"Yes"])
        {
            if(_txtCreditTotal.text.length ==0 || _txtCreditTotal.text.floatValue <0 || [_txtCreditTotal.text isEqualToString:@"."])
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                [_txtCreditTotal becomeFirstResponder];

                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter total amount." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter total amount."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
            
            else if(_txtCreditCardNumber.text.length <19 )
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                
               // img_card_number.image =[UIImage imageNamed:@"cnumber1.png"];
                [_txtCreditCardNumber becomeFirstResponder];

                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid card number" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid card number"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
            else if (_txtExpiryDate.text.length<5)
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                
                //img_card_expdate.image =[UIImage imageNamed:@"calendarnew1.png"];
                
                [_txtExpiryDate becomeFirstResponder];

                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid expiry date" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid expiry date"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
//
                
                
                
            }
            else if (_txtCVV.text.length<3)
            {
                
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                
                [_txtCVV becomeFirstResponder];

                //imag_card_cvv.image =[UIImage imageNamed:@"cvvnew1.png"];
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid CVV number" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please provide valid CVV number"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
            else
            {
                
                [_txtCreditComments endEditing:YES];
                [_txtCreditComments endEditing:YES];
                [_txtCreditCardNumber endEditing:YES];
                [_txtCVV endEditing:YES];
                [_txtExpiryDate endEditing:YES];
                [_txtZipCode endEditing:YES];
                [_txtRefNumber endEditing:YES];

                Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
                signature.str_PatientName=str_PatientName;
                signature.str_IsPOS=str_IsPOS;
                signature.str_POSID=str_POSID;
                signature.str_PatientAddresss=str_PatientAddress;
                signature.str_PaymentType=@"Card";
                signature.arr_RxNumberr=_arr_DelRxListNumber;
                signature.arr_RxPrice=_arr_DelRxListAmount;
                signature.arr_RxID=_arr_DelRxID;
                
                signature.arr_PatientID=_arr_PatientID;
                signature.arr_HipaaSigID=_arr_HipaaSigID;
                signature.arr_HipaaSig=_arr_HipaaSig;
                signature.arr_BalanceAmount=_arr_BalanceAmount;
                signature.str_RxSearch=str_RxSearch;
                signature.arr_RxARItemID=arr_RxARItemID;

                
                signature.str_PayType=@"2";
                
                signature.str_TotalTender=_txtCreditTotal.text;
                
                signature.str_CCNumber=_txtCreditCardNumber.text;
                signature.str_ExpDate=_txtExpiryDate.text;
                signature.str_CVV=_txtCVV.text;
                signature.str_ZipCode=_txtZipCode.text;
                signature.str_Comments=_txtCreditComments.text;
                
                signature.str_CCNumber1=str_cardNumber;
                signature.str_ExpDate1=str_expDate;
                signature.str_CVV1=str_ccCode;
                signature.str_ZipCode1=str_patZip;
                
                signature.str_street=str_street;
                signature.str_state=str_state;
                signature.str_city=str_city;
                signature.arr_del_Qty=arr_Del_Qty;
                
                signature.str_RefNumber=@"";

                
                signature.str_pat_email=str_patient_email;
                

                
                [self.navigationController pushViewController:signature animated:NO];
            }
        }
        else
        {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"You are in offline. Cash and AR Payment will be acceptable in offline" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"You are in offline. Cash and AR Payment will be acceptable in offline"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//            [alert show];
            
        }
    }
    else if ([str_PaymentType isEqualToString:@"Cash"])
    {
        
        NSLog(@"%f",_txtCashTotal.text.floatValue);
        
            if(_txtCashTotal.text.length ==0  || _txtCashTotal.text.floatValue <0 || [_txtCashTotal.text isEqualToString:@"."])
            {
                [activityIndicatorView stopAnimating];
                activityIndicatorView.hidden=YES;
                [_txtCashTotal becomeFirstResponder];

                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter total amount." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
//
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter total amount."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//                [alert show];
                
                
            }
        
            else
            {
                
                [_txtCashComments endEditing:YES];
                [_txtCreditTotal endEditing:YES];
                [_txtCreditCardNumber endEditing:YES];
                [_txtCVV endEditing:YES];
                [_txtExpiryDate endEditing:YES];
                [_txtZipCode endEditing:YES];
                [_txtRefNumber endEditing:YES];

                
                Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
                signature.str_PatientName=str_PatientName;
                signature.str_IsPOS=str_IsPOS;
                signature.str_POSID=str_POSID;
                signature.str_PatientAddresss=str_PatientAddress;
                signature.str_PaymentType=@"Cash";

                signature.arr_RxNumberr=_arr_DelRxListNumber;
                signature.arr_RxPrice=_arr_DelRxListAmount;
                signature.arr_RxID=_arr_DelRxID;
                
                signature.arr_PatientID=_arr_PatientID;
                signature.arr_HipaaSigID=_arr_HipaaSigID;
                signature.arr_HipaaSig=_arr_HipaaSig;
                signature.arr_BalanceAmount=_arr_BalanceAmount;
                signature.arr_RxARItemID=arr_RxARItemID;

                signature.str_PayType=@"0";
                
                signature.str_TotalTender=_txtCashTotal.text;
                signature.str_Comments=_txtCashComments.text;
                signature.str_RxSearch=str_RxSearch;

                
                signature.str_CCNumber=@"";
                signature.str_ExpDate=@"";
                signature.str_CVV=@"";
                signature.str_ZipCode=@"";
                
                signature.str_ZipCode1=str_patZip;

                
                signature.str_street=str_street;
                signature.str_state=str_state;
                signature.str_city=str_city;
                signature.arr_del_Qty=arr_Del_Qty;
                signature.str_pat_email=str_patient_email;
                signature.str_RefNumber=@"";

                
                [self.navigationController pushViewController:signature animated:NO];
            }
        }
    else
    {
        if(_txtCheckTotal.text.length ==0  || _txtCheckTotal.text.floatValue <0 ||[_txtCheckTotal.text isEqualToString:@"."])
        {
            [activityIndicatorView stopAnimating];
            activityIndicatorView.hidden=YES;
            [_txtCheckTotal becomeFirstResponder];

            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter total amount." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter total amount."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//            [alert show];
            
            
        }
        else  if(_txtRefNumber.text.length ==0 )
        {
            [activityIndicatorView stopAnimating];
            activityIndicatorView.hidden=YES;
            [_txtRefNumber becomeFirstResponder];

            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please enter check reference number." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter check reference number."  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//            [alert show];
            
            
        }
        else
        {
            [_txtCreditComments endEditing:YES];
            [_txtCashComments endEditing:YES];
            [_txtCreditTotal endEditing:YES];
            [_txtCreditCardNumber endEditing:YES];
            [_txtCVV endEditing:YES];
            [_txtExpiryDate endEditing:YES];
            [_txtZipCode endEditing:YES];
            [_txtRefNumber endEditing:YES];

            
            Signature_screen *signature = [[Signature_screen alloc]  initWithNibName:@"Signature_screen" bundle:nil];
            signature.str_PatientName=str_PatientName;
            signature.str_IsPOS=str_IsPOS;
            signature.str_POSID=str_POSID;
            signature.str_PatientAddresss=str_PatientAddress;
            signature.str_PaymentType=@"Check";
            
            signature.arr_RxNumberr=_arr_DelRxListNumber;
            signature.arr_RxPrice=_arr_DelRxListAmount;
            signature.arr_RxID=_arr_DelRxID;
            
            signature.arr_PatientID=_arr_PatientID;
            signature.arr_HipaaSigID=_arr_HipaaSigID;
            signature.arr_HipaaSig=_arr_HipaaSig;
            signature.arr_BalanceAmount=_arr_BalanceAmount;
            signature.arr_RxARItemID=arr_RxARItemID;

            signature.str_PayType=@"1";
            
            signature.str_TotalTender=_txtCreditTotal.text;
            signature.str_Comments=_txtCreditComments.text;
            signature.str_RxSearch=str_RxSearch;

            
            signature.str_CCNumber=@"";
            signature.str_ExpDate=@"";
            signature.str_CVV=@"";
            signature.str_ZipCode=@"";
            
            signature.str_ZipCode1=str_patZip;
            
            
            signature.str_street=str_street;
            signature.str_state=str_state;
            signature.str_city=str_city;
            signature.arr_del_Qty=arr_Del_Qty;
            signature.str_pat_email=str_patient_email;
            signature.str_RefNumber=_txtRefNumber.text;
            
            
            [self.navigationController pushViewController:signature animated:NO];
        }
    }
}
@end
