//
//  PJRSignatureView.h
//  SignExample
//
//  Created by Barani Elangovan on 21/11/14.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "singleton.h"

@interface PJRSignatureView : UIView
{
    UILabel *lblSignature;
    CAShapeLayer *shapeLayer;
    singleton *manage;
}

- (UIImage *)getSignatureImage;
- (void)clearSignature;



@end

// Copyright belongs to original author
// http://code4app.net (en) http://code4app.com (cn)
// From the most professional code share website: Code4App.net 
