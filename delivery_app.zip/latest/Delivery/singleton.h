//
//  singleton.h
//  Delivery
//
//  Created by Barani Elangovan on 2/20/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface singleton : NSObject

    //////////////       PatientID       ////////////

@property(strong,nonatomic)NSMutableArray *arr_ArChargeID;


@property(strong,nonatomic)NSString *str_DelPatientID;
@property(strong,nonatomic)NSString *str_DelPatientPhone;


@property(strong,nonatomic)NSString *str_StartDatee;
@property(strong,nonatomic)NSString *str_EndDatee;

@property(strong,nonatomic)NSString *str_DateLabel;


@property(strong,nonatomic)NSString *str_LoginName;
@property(strong,nonatomic)NSString *str_LoginPassword;


@property(strong,nonatomic)NSArray *activityTypes;
@property(strong,nonatomic)NSString *str_url;

@property(strong,nonatomic)NSString *str_dateLabText;

@property(strong,nonatomic)NSDictionary *arr_storeInfoList;

@property(strong,nonatomic)NSString *str_DriverName;

@property(strong,nonatomic)NSMutableArray *arr_OnlineArray;

@property(strong,nonatomic)NSMutableArray *arr_OnlineDeliveredArray;


@property(strong,nonatomic)NSString *str_InternetFlag;

@property(strong,nonatomic)NSMutableArray *arr_LocatSelectedRx;

@property(strong,nonatomic)NSMutableArray *arr_searchVal;


@property(strong,nonatomic)NSString *GPSallow;

@property(strong,nonatomic)NSString *str_iTunesVersion;
@property(strong,nonatomic)NSString *str_CurrentVresion;
@property(strong,nonatomic)NSString *str_iTunesAppID;

@property(strong,nonatomic)NSString *str_updatee;

@property(strong,nonatomic)NSString *str_startdate_bulk;
@property(strong,nonatomic)NSString *str_enddate_bulk;

@property(strong,nonatomic)NSString *str_deletedRxList;

+(id)share;
- (id)init;
@end
