    //
    //  DeliveryOrderScreen.m
    //  Delivery
    //
    //  Created by Barani Elangovan on 2/20/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "DeliveryOrderScreen.h"
#import "DGActivityIndicatorView.h"

@interface DeliveryOrderScreen ()
{
    NSDateFormatter *Formate_DateMonthYear_Service;
    NSDateFormatter *Formate_DateMonthYear;
    
    DGActivityIndicatorView *activityIndicatorView;
    NSString *str_StoreID;
    NSMutableArray *arr_DeliveryList;
    NSString *str_StartDate;
    NSString *str_EndDate;
    NSString *str_check;
    
    NSMutableArray *arr_RxNumber;
    NSMutableArray *arr_RxCost;
    
    
    NSMutableArray *arr_SelectedRxNumber;
    NSMutableArray *arr_SelectedRxAmount;
    
    
    NSMutableArray *arr_Number;
    NSMutableArray *arr_Date;
    NSMutableArray *arr_Qty;
    NSMutableArray *arr_Cost;
    NSMutableArray *arr_RxID;
    
    NSMutableArray *arr_DrugName;
    NSMutableArray *arr_HipaaSigID;
    NSMutableArray *arr_PatientID;
    NSMutableArray *arr_HipaaSig;
    NSMutableArray *arr_BalanceAmount;
    NSMutableArray *arr_RxARItemID;
    NSMutableArray *arr_ShippingDetailID;

    
    NSString *str_Address;
    NSString *str_Description;
    NSString *str_TCount;
    NSString *str_TCost;
    NSString *str_DCount;
    NSString *str_DCost;
    
    
    NSString *str_Typeee;
    NSString *str_LogIDD;
    NSString *str_isPOS;
    
    
    NSString *str_cnumber;
    NSString *str_expdate;
    NSString *str_cccode;
    NSString *str_Zip;
    NSString *str_Street;
    NSString *str_City;
    NSString *str_State;
    NSString *str_email;
    
    
    
    
}
@end

@implementation DeliveryOrderScreen

@synthesize table_RxList,lab_storeNmae,arr_RxList,str_DeliveryNumber,btn_Search,lab_RxNumLine,lab_DelNumLine,text_RxNumber,lab_TextHint,view_activity,lab_date,lab_POSNumLine,lab_Phone,lab_PName,lab_Address,text_RxNumber1,view_Search,view_Search1,btn_Clear,btn_Search1,str_RxSearch;

- (void)viewDidLoad {
    [super viewDidLoad];
    manage=[singleton share];
    [manage.arr_ArChargeID removeAllObjects];
    
    
    view_Search1.hidden=YES;
    view_Search.hidden=NO;

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        [self restrictRotation:NO];
        
    }
    else
        
    {
        
        [self restrictRotation:NO];
        
    }
    
    arr_Qty=[[NSMutableArray alloc]init];
    arr_Date=[[NSMutableArray alloc]init];
    arr_Number=[[NSMutableArray alloc]init];
    arr_Cost=[[NSMutableArray alloc]init];
    arr_RxID=[[NSMutableArray alloc]init];
    
    arr_PatientID=[[NSMutableArray alloc]init];
    arr_DrugName=[[NSMutableArray alloc]init];
    arr_HipaaSigID=[[NSMutableArray alloc]init];
    arr_HipaaSig=[[NSMutableArray alloc]init];
    arr_BalanceAmount=[[NSMutableArray alloc]init];
    arr_RxARItemID=[[NSMutableArray alloc]init];
        //  NSLog(@"%@",arr_RxList);
    
    arr_DeliveryList=[[NSMutableArray alloc]init];
    arr_RxNumber=[[NSMutableArray alloc]init];
    arr_RxCost=[[NSMutableArray alloc]init];
    arr_SelectedRxNumber=[[NSMutableArray alloc]init];
    arr_SelectedRxAmount=[[NSMutableArray alloc]init];
    arr_ShippingDetailID=[[NSMutableArray alloc]init];

    Formate_DateMonthYear=[[NSDateFormatter alloc]init];
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    [Formate_DateMonthYear setDateFormat:@"MM/dd/yyyy"];
    NSString *strDateService = [Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
    NSString *strDate = [Formate_DateMonthYear stringFromDate:[NSDate date]];
    lab_date.text=strDate;
    
    
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self
                                           action:@selector(hideKeyBoard)];
    
    [self.view addGestureRecognizer:tapGesture];
    tapGesture.enabled = YES;
    
    
        // NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
        // [offsetComponents setDay:-31];
        // NSDate *date = [Formate_DateMonthYear_Service dateFromString:dateEnd];
        // NSDate *date_Start = [gregorian dateByAddingComponents:offsetComponents toDate:date  options:0];
        // NSString *date_end = [Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
    
    str_StartDate=strDateService;
    str_EndDate=strDateService;
    
    
    
    lab_storeNmae.text=  manage.arr_storeInfoList[@"PharmacyName"];
    str_StoreID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];
    
    
    /*
     PatPay = 0;
     PatientCity = LINCOLN;
     PatientName = "ASENCIO,MICHELLE";
     PatientState = NE;
     PatientStreet = "323 W TREEHAVEN DR";
     Patientphone = "(402) 304-63";
     QtyShipped = 15;
     RxNumber = 569250;
     ShipLogID = 170058;
     */
    
    
    str_Typeee=@"RX";
    str_RxSearch=@"1";
    lab_TextHint.text=@"By Item #";
    btn_Search. layer.cornerRadius =3;
    btn_Search. layer.masksToBounds =YES;
    
    btn_Search1. layer.cornerRadius =3;
    btn_Search1. layer.masksToBounds =YES;
    btn_Clear. layer.cornerRadius =3;
    btn_Clear. layer.masksToBounds =YES;
    
    lab_DelNumLine.hidden=YES;
    lab_POSNumLine.hidden=YES;
    
    view_activity.hidden=YES;
    
    
        //lab_storeNmae.text=[@"D# " stringByAppendingString:str_DeliveryNumber];
    
        // Do any additional setup after loading the view.
}

#pragma mark - Keyboard hide

-(void)hideKeyBoard
{
    [[self view] endEditing:YES];
    [text_RxNumber endEditing:YES];
    [text_RxNumber1 endEditing:YES];
}

#pragma mark - Rx Number Search

-(void)RxNumberSearch
{
    if (arr_DeliveryList.count>0) {
        
        [arr_Qty removeAllObjects];
        [arr_Date removeAllObjects];
        [arr_Number removeAllObjects];
        [arr_Cost removeAllObjects];
        [arr_RxID removeAllObjects];
        
        [arr_PatientID removeAllObjects];
        [arr_HipaaSigID removeAllObjects];
        [arr_HipaaSig removeAllObjects];
        [arr_DrugName removeAllObjects];
        [arr_BalanceAmount removeAllObjects];
        [arr_RxARItemID removeAllObjects];

        [manage.arr_ArChargeID removeAllObjects];
        [arr_ShippingDetailID removeAllObjects];
        manage.str_deletedRxList = @"";

    }
    else
    {
        [arr_DeliveryList removeAllObjects];
        
        [arr_Qty removeAllObjects];
        [arr_Date removeAllObjects];
        [arr_Number removeAllObjects];
        [arr_Cost removeAllObjects];
        [arr_RxID removeAllObjects];
        
        [arr_PatientID removeAllObjects];
        [arr_HipaaSigID removeAllObjects];
        [arr_HipaaSig removeAllObjects];
        [arr_DrugName removeAllObjects];
        [arr_BalanceAmount removeAllObjects];
        [arr_RxARItemID removeAllObjects];
        [arr_ShippingDetailID removeAllObjects];
        manage.str_deletedRxList = @"";

        [manage.arr_ArChargeID removeAllObjects];
        
        
    }
    
    [[self view] endEditing:YES];
    
    
    
    self.view_activity.hidden=NO;
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
                //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width ;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
        NSString *str_urrl=[NSString stringWithFormat:@"RxbyNumber/%@/%@",str_StoreID,str_LogIDD];
            // NSString *str_urrl=[NSString stringWithFormat:@"GetLogIn/%@/%@/%@",text_StoreNumber.text,text_UserId.text,text_Password.text];
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"RxbyNumberResult"];
            NSLog(@"%@", arr_Content);
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                   // [table_RxList reloadData];
                    
                    if (arr_DeliveryList.count>0)
                    {
                        [text_RxNumber1 becomeFirstResponder];
                        //text_RxNumber1.text=@"";

                    }
                    else
                    {
                        [text_RxNumber becomeFirstResponder];
                      //  text_RxNumber.text=@"";

                    }

                    if (arr_DeliveryList.count>0) {
                        
                        str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
                        str_Description=@"";
                        str_TCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                        str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                        
                        str_isPOS=@"0";
                        
                        float f_Cost=0.0;
                        
                        for (int i=0; i<arr_DeliveryList.count; i++)
                        {
                            [arr_Number addObject:arr_DeliveryList[i][@"RxNumber"]];
                            [arr_Qty addObject:arr_DeliveryList[i][@"Qty"]];
                            [arr_Cost addObject:arr_DeliveryList[i][@"PatPay"]];
                            [arr_Date addObject:arr_DeliveryList[i][@"RxDate"]];
                            [manage.arr_ArChargeID addObject:arr_DeliveryList[i][@"ArChargeID"]];
                            [arr_RxID addObject:[NSString stringWithFormat:@"%d",[arr_DeliveryList[i][@"RxID"]intValue]]];

                            
                            [arr_DrugName addObject:arr_DeliveryList[i][@"DrugName"]];
                            [arr_HipaaSigID addObject:arr_DeliveryList[i][@"HipaaSigID"]];
                            [arr_PatientID addObject:arr_DeliveryList[i][@"PatientID"]];
                            [arr_HipaaSig addObject:arr_DeliveryList[i][@"HipaaSig"]];
                            [arr_BalanceAmount addObject:arr_DeliveryList[i][@"BalanceAmt"]];
                            [arr_RxARItemID addObject:arr_DeliveryList[i][@"RxARItemID"]];

                            
                            
                            
                            f_Cost=f_Cost+[arr_DeliveryList[i][@"PatPay"]floatValue];
                            
                        }
                        str_TCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                        str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                        

                    }
                    [table_RxList reloadData];

                    
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Item # is not found!" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        
                        /*
                         
                         City = LINCOLN;
                         DrugName = "ACARBOSE 100 MG TABLET";
                         Mobile = "";
                         PatPay = 0;
                         PatientName = "BABCOCK,IVA";
                         Phone = "(000) 875-2991";
                         RxDate = "09-05-2017 22:33:49";
                         RxID = 7346416;
                         RxNumber = 569910;
                         State = NE;
                         Street1 = "1111 SO 70TH STREET APT#224";
                         Street2 = "";
                         Zip = 68528;
                         
                         */
                        
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                        [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails setValue:temp[@"Mobile"] forKey:@"Mobile"];
                        [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails setValue:temp[@"PatPay"] forKey:@"PatPay"];
                        [itemshowdetails setValue:temp[@"Phone"] forKey:@"Phone"];
                        [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                        [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                        [itemshowdetails setValue:temp[@"Street1"] forKey:@"Street1"];
                        [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails setValue:temp[@"AcctName"] forKey:@"AcctName"];
                        [itemshowdetails setValue:temp[@"BillAdd"] forKey:@"BillAdd"];
                        [itemshowdetails setValue:temp[@"ARState"] forKey:@"ARState"];
                        [itemshowdetails setValue:temp[@"ARCity"] forKey:@"ARCity"];
                        [itemshowdetails setValue:temp[@"ARPhone1"] forKey:@"ARPhone1"];
                        [itemshowdetails setValue:temp[@"ARZip"] forKey:@"ARZip"];
                        [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails setValue:temp[@"Ar"] forKey:@"ArChargeID"];
                            //  [itemshowdetails setValue:temp[@"IsDelivered"] forKey:@"IsDelivered"];
                            // [itemshowdetails setValue:@"" forKey:@"ArChargeID"];
                        [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
                        BOOL b_Valid=NO;
                        
                        for (int k=0; k<arr_DeliveryList.count; k++)
                        {
                            if ([[NSString stringWithFormat:@"%d",[temp[@"RxID"]intValue]] isEqualToString:[NSString stringWithFormat:@"%d",[arr_DeliveryList[k][@"RxID"]intValue]] ])
                            {
                                b_Valid=YES;
                                k=arr_DeliveryList.count;
                            }
                        }
                        if (b_Valid==NO)
                        {
                            [arr_DeliveryList addObject:itemshowdetails];
                        }
                    }
                    
                    if (arr_DeliveryList.count>0)
                    {
                        view_Search.hidden=YES;
                        view_Search1.hidden=NO;

                    }
                    else
                    {
                        view_Search1.hidden=NO;
                        view_Search.hidden=YES;
                    }
                    manage.arr_searchVal=arr_DeliveryList;
                    
                    str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
                    str_Description=@"";
                    str_TCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                    str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                    
                    str_isPOS=@"0";
                    
                    float f_Cost=0.0;
                    
                    for (int i=0; i<arr_DeliveryList.count; i++)
                    {
                        [arr_Number addObject:arr_DeliveryList[i][@"RxNumber"]];
                        [arr_Qty addObject:arr_DeliveryList[i][@"Qty"]];
                        [arr_Cost addObject:arr_DeliveryList[i][@"PatPay"]];
                        [arr_Date addObject:arr_DeliveryList[i][@"RxDate"]];
                        [manage.arr_ArChargeID addObject:arr_DeliveryList[i][@"ArChargeID"]];
                        [arr_RxID addObject:[NSString stringWithFormat:@"%d",[arr_DeliveryList[i][@"RxID"]intValue]]];
                        
                        
                        [arr_DrugName addObject:arr_DeliveryList[i][@"DrugName"]];
                        [arr_HipaaSigID addObject:arr_DeliveryList[i][@"HipaaSigID"]];
                        [arr_PatientID addObject:arr_DeliveryList[i][@"PatientID"]];
                        [arr_HipaaSig addObject:arr_DeliveryList[i][@"HipaaSig"]];
                        [arr_BalanceAmount addObject:arr_DeliveryList[i][@"BalanceAmt"]];
                        [arr_RxARItemID addObject:arr_DeliveryList[i][@"RxARItemID"]];

                        
                        
                        f_Cost=f_Cost+[arr_DeliveryList[i][@"PatPay"]floatValue];
                        
                    }
                    str_TCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                    str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                    
                    
                    
                    [table_RxList reloadData];
                    
                    self.view_activity.hidden=YES;
                    
                });
                
                
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [activityIndicatorView stopAnimating];
                
                self.view_activity.hidden=YES;
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
                
                
                
            });
        }
    });
    
    
}
/*
 
 {
 
 [arr_DeliveryList removeAllObjects];
 
 [arr_Qty removeAllObjects];
 [arr_Date removeAllObjects];
 [arr_Number removeAllObjects];
 [arr_Cost removeAllObjects];
 [arr_RxID removeAllObjects];
 
 [[self view] endEditing:YES];
 
 if (text_RxNumber.text.length ==0)
 {
 [text_RxNumber becomeFirstResponder];
 
 UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Item # is empty!" preferredStyle:UIAlertControllerStyleAlert];
 
 UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
 [alertController addAction:ok];
 
 [self presentViewController:alertController animated:YES completion:nil];
 }
 
 else
 {
 
 self.view_activity.hidden=NO;
 
 [activityIndicatorView removeFromSuperview];
 dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
 dispatch_async(dispatch_get_main_queue(), ^{
 
 //  NSLog(@"%@",manage.activityTypes);
 
 activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
 
 CGFloat width = self.view.bounds.size.width ;
 CGFloat height = self.view.bounds.size.height;
 
 activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
 // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
 [self.view_activity addSubview:activityIndicatorView];
 [activityIndicatorView startAnimating];
 });
 
 NSString *str_urrl=[NSString stringWithFormat:@"RxbyNumber/%@/%@",str_StoreID,text_RxNumber.text];
 // NSString *str_urrl=[NSString stringWithFormat:@"GetLogIn/%@/%@/%@",text_StoreNumber.text,text_UserId.text,text_Password.text];
 
 NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
 
 
 NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
 
 [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
 NSError *err;
 NSURLResponse *response;
 
 NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
 //   NSLog(@"%@",responsedata);
 
 
 if (responsedata)
 {
 
 NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
 //NSLog(@"%@",jsonArray);
 
 NSArray *arr_Content = jsonArray[@"RxbyNumberResult"];
 
 if (arr_Content.count==0)
 {
 dispatch_async(dispatch_get_main_queue(), ^{
 self.view_activity.hidden=YES;
 [activityIndicatorView stopAnimating];
 
 [table_RxList reloadData];
 
 
 [text_RxNumber becomeFirstResponder];
 UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Item # is not found!" preferredStyle:UIAlertControllerStyleAlert];
 
 UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
 [alertController addAction:ok];
 
 [self presentViewController:alertController animated:YES completion:nil];
 
 });
 }
 else
 {
 [arr_DeliveryList removeAllObjects];
 dispatch_async(dispatch_get_main_queue(), ^{
 
 self.view_activity.hidden=YES;
 [activityIndicatorView stopAnimating];
 
 for (NSDictionary *temp in arr_Content)
 {
 
 NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
 [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
 [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
 [itemshowdetails setValue:temp[@"Mobile"] forKey:@"Mobile"];
 [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
 [itemshowdetails setValue:temp[@"PatPay"] forKey:@"PatPay"];
 [itemshowdetails setValue:temp[@"Phone"] forKey:@"Phone"];
 [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
 [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
 [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
 [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
 [itemshowdetails setValue:temp[@"Street1"] forKey:@"Street1"];
 [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
 [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
 
 [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
 [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
 [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
 [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
 
 
 [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
 [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
 [itemshowdetails setValue:temp[@"AcctName"] forKey:@"AcctName"];
 [itemshowdetails setValue:temp[@"BillAdd"] forKey:@"BillAdd"];
 [itemshowdetails setValue:temp[@"ARState"] forKey:@"ARState"];
 [itemshowdetails setValue:temp[@"ARCity"] forKey:@"ARCity"];
 [itemshowdetails setValue:temp[@"ARPhone1"] forKey:@"ARPhone1"];
 [itemshowdetails setValue:temp[@"ARZip"] forKey:@"ARZip"];
 [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
 
 [itemshowdetails setValue:temp[@"Ar"] forKey:@"ArChargeID"];
 //  [itemshowdetails setValue:temp[@"IsDelivered"] forKey:@"IsDelivered"];
 
 // [itemshowdetails setValue:@"" forKey:@"ArChargeID"];
 
 [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
 [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
 [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
 
 [arr_DeliveryList addObject:itemshowdetails];
 }
 
 manage.arr_searchVal=arr_DeliveryList;
 
 str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
 str_Description=@"";
 str_TCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
 str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
 
 str_isPOS=@"0";
 
 float f_Cost=0.0;
 
 for (int i=0; i<arr_DeliveryList.count; i++)
 {
 [arr_Number addObject:arr_DeliveryList[i][@"RxNumber"]];
 [arr_Qty addObject:arr_DeliveryList[i][@"Qty"]];
 [arr_Cost addObject:arr_DeliveryList[i][@"PatPay"]];
 [arr_Date addObject:arr_DeliveryList[i][@"RxDate"]];
 [manage.arr_ArChargeID addObject:arr_DeliveryList[i][@"ArChargeID"]];
 [arr_RxID addObject:[NSString stringWithFormat:@"%d",[arr_DeliveryList[i][@"RxID"]intValue]]];
 
 f_Cost=f_Cost+[arr_DeliveryList[i][@"PatPay"]floatValue];
 
 }
 str_TCost=[NSString stringWithFormat:@"%.2f",f_Cost];
 str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
 
 
 
 [table_RxList reloadData];
 
 self.view_activity.hidden=YES;
 
 });
 
 
 }
 }
 
 else
 {
 dispatch_async(dispatch_get_main_queue(), ^{
 [activityIndicatorView stopAnimating];
 
 self.view_activity.hidden=YES;
 
 UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
 
 UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
 [alertController addAction:ok];
 
 [self presentViewController:alertController animated:YES completion:nil];
 
 
 
 
 });
 }
 });
 }
 
 
 }
 
 */
#pragma mark - Delivery ID Search

-(void)DeliveryIdSearch
{
    [arr_DeliveryList removeAllObjects];
    [arr_Qty removeAllObjects];
    [arr_Date removeAllObjects];
    [arr_Number removeAllObjects];
    [arr_Cost removeAllObjects];
    [arr_RxID removeAllObjects];
    [manage.arr_ArChargeID removeAllObjects];
    [arr_PatientID removeAllObjects];
    [arr_HipaaSigID removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_DrugName removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_RxARItemID removeAllObjects];
    [arr_ShippingDetailID removeAllObjects];
    manage.str_deletedRxList = @"";
    
    [[self view] endEditing:YES];
    
    if (text_RxNumber.text.length ==0)
    {
        [text_RxNumber becomeFirstResponder];
        
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Delivery ID is empty!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    else
    {
        self.view_activity.hidden=NO;
        
        [activityIndicatorView removeFromSuperview];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
                    //  NSLog(@"%@",manage.activityTypes);
                
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                    // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            });
            
            NSString *str_urrl=[NSString stringWithFormat:@"RxbyLogID/%@/%@",str_StoreID,text_RxNumber.text];
            
            NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
            
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            NSError *err;
            NSURLResponse *response;
            
            NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
                //   NSLog(@"%@",responsedata);
            
            
            if (responsedata)
            {
                
                NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                    //NSLog(@"%@",jsonArray);
                
                NSArray *arr_Content = jsonArray[@"RxbyLogIDResult"];
                
                if (arr_Content.count==0)
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        [table_RxList reloadData];
                       // text_RxNumber.text=@"";

                        
                        [text_RxNumber becomeFirstResponder];
                        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Delivery ID is not found!" preferredStyle:UIAlertControllerStyleAlert];
                        
                        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                        [alertController addAction:ok];
                        
                        [self presentViewController:alertController animated:YES completion:nil];
                        
                        
                    });
                }
                else
                {
                    [arr_DeliveryList removeAllObjects];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        for (NSDictionary *temp in arr_Content)
                        {
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            
                            /*
                             
                             City = "LA QUINTA";
                             DrugName = "ARIPIPRAZOLE 2 MG TABLET";
                             Mobile = "(528) 546-8944";
                             Notes = "";
                             PatPay = "2004.71";
                             PatientName = "MACBETH,ROSS";
                             Phone = "(760) 775-92";
                             PickupDate = "5/25/2017 12:00:20 AM";
                             QtyShipped = 50;
                             RxDate = "5/24/2017 9:51:48 PM";
                             RxID = 7806707;
                             RxNumber = 600658;
                             State = CA;
                             Street1 = "79-800 CALIFORNIA 111 #110, LA QUIN";
                             Street2 = "";
                             Zip = 92253;
                             
                             
                             */
                            
                            
                            [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                            [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:temp[@"Mobile"] forKey:@"Mobile"];
                            [itemshowdetails setValue:temp[@"Notes"] forKey:@"Notes"];
                            [itemshowdetails setValue:temp[@"PatPay"] forKey:@"PatPay"];
                            [itemshowdetails setValue:temp[@"Phone"] forKey:@"Phone"];
                            [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                            [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                            [itemshowdetails setValue:temp[@"Street1"] forKey:@"Street1"];
                            [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                            [itemshowdetails setValue:temp[@"QtyShipped"] forKey:@"QtyShipped"];
                            
                            [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
                            
                            [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                            
                            [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:temp[@"AcctName"] forKey:@"AcctName"];
                            [itemshowdetails setValue:temp[@"BillAdd"] forKey:@"BillAdd"];
                            [itemshowdetails setValue:temp[@"ARState"] forKey:@"ARState"];
                            [itemshowdetails setValue:temp[@"ARCity"] forKey:@"ARCity"];
                            [itemshowdetails setValue:temp[@"ARPhone1"] forKey:@"ARPhone1"];
                            [itemshowdetails setValue:temp[@"ARZip"] forKey:@"ARZip"];
                                // [itemshowdetails setValue:@"" forKey:@"ArChargeID"];
                            
                            [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                            
                            [itemshowdetails setValue:temp[@"Ar"] forKey:@"ArChargeID"];
                            [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                                // [itemshowdetails setValue:temp[@"IsDelivered"] forKey:@"IsDelivered"];
                            
                            
                            [arr_DeliveryList addObject:itemshowdetails];
                        }
                        
                        manage.arr_searchVal=arr_DeliveryList;
                        
                        str_isPOS=@"0";
                        
                        str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
                        str_Description=@"";
                        str_TCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                        str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                        
                        float f_Cost=0.0;
                        
                        for (int i=0; i<arr_DeliveryList.count; i++)
                        {
                            [arr_Number addObject:arr_DeliveryList[i][@"RxNumber"]];
                            [arr_Qty addObject:arr_DeliveryList[i][@"QtyShipped"]];
                            [arr_Cost addObject:arr_DeliveryList[i][@"PatPay"]];
                            [arr_Date addObject:arr_DeliveryList[i][@"RxDate"]];
                            [arr_RxID addObject:[NSString stringWithFormat:@"%d",[arr_DeliveryList[i][@"RxID"]intValue]]];
                            [manage.arr_ArChargeID addObject:arr_DeliveryList[i][@"ArChargeID"]];
                            [arr_DrugName addObject:arr_DeliveryList[i][@"DrugName"]];
                            [arr_HipaaSigID addObject:arr_DeliveryList[i][@"HipaaSigID"]];
                            [arr_PatientID addObject:arr_DeliveryList[i][@"PatientID"]];
                            [arr_HipaaSig addObject:arr_DeliveryList[i][@"HipaaSig"]];
                            [arr_BalanceAmount addObject:arr_DeliveryList[i][@"BalanceAmt"]];
                            [arr_RxARItemID addObject:arr_DeliveryList[i][@"RxARItemID"]];
                            [arr_ShippingDetailID addObject:arr_DeliveryList[i][@"ShippingDetailID"]];


                            f_Cost=f_Cost+[arr_DeliveryList[i][@"PatPay"]floatValue];
                            
                        }
                        str_TCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                        str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                        
                        
                        [table_RxList reloadData];
                        
                        self.view_activity.hidden=YES;
                        
                    });
                    
                    
                }
            }
            
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [activityIndicatorView stopAnimating];
                    
                    self.view_activity.hidden=YES;
                    
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                    
                    
                    
                });
            }
        });
    }
    
    
}

#pragma mark - POS ID Search

-(void)POSidSearch
{
    
    [arr_DeliveryList removeAllObjects];
    [arr_Qty removeAllObjects];
    [arr_Date removeAllObjects];
    [arr_Number removeAllObjects];
    [arr_Cost removeAllObjects];
    [arr_RxID removeAllObjects];
    [manage.arr_ArChargeID removeAllObjects];
    [arr_PatientID removeAllObjects];
    [arr_HipaaSigID removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_DrugName removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_RxARItemID removeAllObjects];
    [arr_ShippingDetailID removeAllObjects];
    manage.str_deletedRxList = @"";
    
    [[self view] endEditing:YES];
    
    if (text_RxNumber.text.length ==0)
    {
        [text_RxNumber becomeFirstResponder];
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"POS ID is empty!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    else
    {
        
        self.view_activity.hidden=NO;
        
        [activityIndicatorView removeFromSuperview];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
                    //  NSLog(@"%@",manage.activityTypes);
                
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                    // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            });
            
            NSString *str_urrl=[NSString stringWithFormat:@"POSQueueByID/%@/%@",str_StoreID,text_RxNumber.text];
                // NSString *str_urrl=[NSString stringWithFormat:@"GetLogIn/%@/%@/%@",text_StoreNumber.text,text_UserId.text,text_Password.text];
            
            NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
            
            
                // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
            
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            NSError *err;
            NSURLResponse *response;
            
            NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
                //   NSLog(@"%@",responsedata);
            
            
            if (responsedata)
            {
                
                NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                    //NSLog(@"%@",jsonArray);
                
                NSArray *arr_Content = jsonArray[@"POSQueueByIDResult"];
                
                
                
                if (arr_Content.count==0)
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        [table_RxList reloadData];
                        
                        [text_RxNumber becomeFirstResponder];
                        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"POS ID is not found!" preferredStyle:UIAlertControllerStyleAlert];
                        
                        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                        [alertController addAction:ok];
                        
                        [self presentViewController:alertController animated:YES completion:nil];
                        
                        
                    });
                }
                else
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        for (NSDictionary *temp in arr_Content)
                        {
                            
                            
                            /*
                             
                             CCAuth = 0;
                             CCTranID = 0;
                             CCardNumber = "";
                             CardIssuer = 0;
                             Cash = 0;
                             City = BETHANY;
                             CommID = "";
                             Cost = 0;
                             Discount = 0;
                             ItemID = 7346401;
                             ItemName = "Rx#569903: DOCUSATE SODIUM-SENNA TA";
                             ItemUPC = "#569903";
                             Mobile = "(888) 888-8888";
                             PatientID = 431138;
                             Phone = "(777) 777-7777";
                             PosID = 600823;
                             Price = "8.32";
                             Qty = 1;
                             ReceiptNo = "170508150030        ";
                             RefNum = "               ";
                             ServerID = 0;
                             State = NE;
                             StationID = 1;
                             StoreID = 100010;
                             Street1 = "45/4 MAIN STREET";
                             Street2 = "";
                             Tax = 0;
                             Taxable = 0;
                             TotalCharge = "8.32";
                             TotalPrice = "8.32";
                             TotalTender = 0;
                             TranDate = "08-05-2017 02:30:30";
                             UserID = "rxuser                   ";
                             Zip = 68505;
                             ccard = 0;
                             checks = 0;
                             
                             
                             */
                            
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:temp[@"Price"] forKey:@"Price"];
                            [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                            [itemshowdetails setValue:temp[@"ItemID"] forKey:@"RxID"];
                            [itemshowdetails setValue:temp[@"ItemName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:temp[@"ItemUPC"] forKey:@"ItemUPC"];
                            [itemshowdetails setValue:temp[@"Mobile"] forKey:@"Mobile"];
                            [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:temp[@"Phone"] forKey:@"Phone"];
                            [itemshowdetails setValue:temp[@"PosID"] forKey:@"PosID"];
                            [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                            [itemshowdetails setValue:temp[@"ReceiptNo"] forKey:@"ReceiptNo"];
                            [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                            [itemshowdetails setValue:temp[@"Street1"] forKey:@"Street1"];
                            [itemshowdetails setValue:temp[@"TotalPrice"] forKey:@"TotalPrice"];
                            [itemshowdetails setValue:temp[@"TranDate"] forKey:@"TranDate"];
                            [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                            [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                            
                            [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:temp[@"AcctName"] forKey:@"AcctName"];
                            [itemshowdetails setValue:temp[@"BillAdd"] forKey:@"BillAdd"];
                            [itemshowdetails setValue:temp[@"ARState"] forKey:@"ARState"];
                            [itemshowdetails setValue:temp[@"ARCity"] forKey:@"ARCity"];
                            [itemshowdetails setValue:temp[@"ARPhone1"] forKey:@"ARPhone1"];
                            [itemshowdetails setValue:temp[@"ARZip"] forKey:@"ARZip"];
                            
                                //  [itemshowdetails setValue:@"" forKey:@"ArChargeID"];
                            
                            [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                                //   [itemshowdetails setValue:temp[@"IsDelivered"] forKey:@"IsDelivered"];
                            
                            [itemshowdetails setValue:temp[@"Ar"] forKey:@"ArChargeID"];
                            [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];

                            
                            [arr_DeliveryList addObject:itemshowdetails];
                        }
                        
                        manage.arr_searchVal=arr_DeliveryList;
                        
                        str_isPOS=@"1";
                        
                        
                        str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
                        str_Description=@"";
                        str_TCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                        str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                        
                        float f_Cost=0.0;
                        
                        for (int i=0; i<arr_DeliveryList.count; i++)
                        {
                            [arr_Number addObject:arr_DeliveryList[i][@"ItemUPC"]];
                            [arr_Qty addObject:arr_DeliveryList[i][@"Qty"]];
                            [arr_Cost addObject:arr_DeliveryList[i][@"Price"]];
                            [arr_Date addObject:arr_DeliveryList[i][@"TranDate"]];
                            [arr_RxID addObject:[NSString stringWithFormat:@"%d",[arr_DeliveryList[i][@"RxID"]intValue]]];
                            [manage.arr_ArChargeID addObject:arr_DeliveryList[i][@"ArChargeID"]];
                            [arr_DrugName addObject:arr_DeliveryList[i][@"DrugName"]];
                            [arr_HipaaSigID addObject:arr_DeliveryList[i][@"HipaaSigID"]];
                            [arr_PatientID addObject:arr_DeliveryList[i][@"PatientID"]];
                            [arr_HipaaSig addObject:arr_DeliveryList[i][@"HipaaSig"]];
                            [arr_BalanceAmount addObject:arr_DeliveryList[i][@"BalanceAmt"]];
                            [arr_RxARItemID addObject:arr_DeliveryList[i][@"RxARItemID"]];

                            f_Cost=f_Cost+[arr_DeliveryList[i][@"Price"]floatValue];
                            
                        }
                        str_TCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                        str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                        
                        
                        [table_RxList reloadData];
                        
                        self.view_activity.hidden=YES;
                        
                    });
                    
                    
                }
            }
            
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [activityIndicatorView stopAnimating];
                    
                    self.view_activity.hidden=YES;
                    
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                    
                    
                    
                });
            }
        });
    }
    
    
}

#pragma mark - Button Search

-(IBAction)btn_search:(id)sender
{
    str_DeliveryNumber=@"";
    [[self view] endEditing:YES];
    
    if (text_RxNumber.text.length ==0)
    {
        [text_RxNumber becomeFirstResponder];
        
        if ([lab_TextHint.text isEqualToString:@"By Item #"])
        {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Item # is empty!" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
        else if ([lab_TextHint.text isEqualToString:@"By POS ID"])
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"POS ID is empty!" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
        else
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Delivery ID is empty!" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }
    
    else
    {
        str_LogIDD=text_RxNumber.text;

        if ([lab_TextHint.text isEqualToString:@"By Item #"])
        {
            text_RxNumber1.text=text_RxNumber.text;

            [self RxNumberSearch];
        }
        else if ([lab_TextHint.text isEqualToString:@"By POS ID"])
        {
            [self POSidSearch];
            
        }
        else
        {
            [self DeliveryIdSearch];
        }
        
        
    }
    
    
}
-(IBAction)btn_Search1:(id)sender
{
    str_DeliveryNumber=@"";
    [[self view] endEditing:YES];
    
    if (text_RxNumber1.text.length ==0)
    {
        [text_RxNumber1 becomeFirstResponder];
        
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Item # is empty!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
    else
    {
        str_LogIDD=text_RxNumber1.text;
        
        [self RxNumberSearch];
        
    }
    
    
}
-(IBAction)btn_Cllear:(id)sender
{
    str_Typeee=@"RX";
    str_RxSearch=@"1";

    view_Search1.hidden=YES;
    view_Search.hidden=NO;

    text_RxNumber.text=@"";
    text_RxNumber1.text=@"";
    
    lab_TextHint.text=@"By Item #";
    lab_POSNumLine.hidden=YES;
    
    lab_DelNumLine.hidden=YES;
    lab_RxNumLine.hidden=NO;
    
    [arr_DeliveryList removeAllObjects];
    
    [arr_Qty removeAllObjects];
    [arr_Date removeAllObjects];
    [arr_Number removeAllObjects];
    [arr_Cost removeAllObjects];
    [arr_RxID removeAllObjects];
    [manage.arr_ArChargeID removeAllObjects];
    [arr_PatientID removeAllObjects];
    [arr_HipaaSigID removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_DrugName removeAllObjects];
    [arr_BalanceAmount removeAllObjects];
    [arr_RxARItemID removeAllObjects];

    [table_RxList reloadData];
    
    
}
-(IBAction)btn_RxSearch:(id)sender
{
    str_Typeee=@"RX";
    str_RxSearch=@"1";

    view_Search1.hidden=YES;
    view_Search.hidden=NO;
    text_RxNumber.text=@"";
    text_RxNumber1.text=@"";

    lab_TextHint.text=@"By Item #";
    lab_POSNumLine.hidden=YES;
    
    lab_DelNumLine.hidden=YES;
    lab_RxNumLine.hidden=NO;
    
    [arr_DeliveryList removeAllObjects];
    
    [arr_Qty removeAllObjects];
    [arr_Date removeAllObjects];
    [arr_Number removeAllObjects];
    [arr_Cost removeAllObjects];
    [arr_RxID removeAllObjects];
    [manage.arr_ArChargeID removeAllObjects];
    [arr_PatientID removeAllObjects];
    [arr_HipaaSigID removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_DrugName removeAllObjects];
    [arr_BalanceAmount removeAllObjects];
    [arr_RxARItemID removeAllObjects];

    [table_RxList reloadData];
    
    
}
-(IBAction)btn_DelIdSearch:(id)sender
{
    str_Typeee=@"Log";
    str_RxSearch=@"0";

    view_Search1.hidden=YES;
    view_Search.hidden=NO;
    text_RxNumber.text=@"";
    text_RxNumber1.text=@"";

    lab_TextHint.text=@"By Delivery ID";
    lab_DelNumLine.hidden=NO;
    lab_POSNumLine.hidden=YES;
    
    lab_RxNumLine.hidden=YES;
    
    [arr_DeliveryList removeAllObjects];
    
    [arr_Qty removeAllObjects];
    [arr_Date removeAllObjects];
    [arr_Number removeAllObjects];
    [arr_Cost removeAllObjects];
    [arr_RxID removeAllObjects];
    [manage.arr_ArChargeID removeAllObjects];
    [arr_PatientID removeAllObjects];
    [arr_HipaaSigID removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_DrugName removeAllObjects];
    [arr_BalanceAmount removeAllObjects];
    [arr_RxARItemID removeAllObjects];

    [table_RxList reloadData];
    
    
}
-(IBAction)btn_POSIdSearch:(id)sender
{
    str_Typeee=@"POS";
    str_RxSearch=@"0";

    view_Search1.hidden=YES;
    view_Search.hidden=NO;
    text_RxNumber.text=@"";
    text_RxNumber1.text=@"";

    lab_TextHint.text=@"By POS ID";
    lab_DelNumLine.hidden=YES;
    lab_POSNumLine.hidden=NO;
    
    lab_RxNumLine.hidden=YES;
    
    [arr_DeliveryList removeAllObjects];
    
    [arr_Qty removeAllObjects];
    [arr_Date removeAllObjects];
    [arr_Number removeAllObjects];
    [arr_Cost removeAllObjects];
    [arr_RxID removeAllObjects];
    [manage.arr_ArChargeID removeAllObjects];
    [arr_PatientID removeAllObjects];
    [arr_HipaaSigID removeAllObjects];
    [arr_HipaaSig removeAllObjects];
    [arr_DrugName removeAllObjects];
    [arr_BalanceAmount removeAllObjects];
    [arr_RxARItemID removeAllObjects];

    [table_RxList reloadData];
    
    
}

#pragma mark - Restrict Rotation

-(void)viewDidAppear:(BOOL)animated
{
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
            //  NSLog(@"iphone");
        if(orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationMaskPortrait)
        {
            
        }
        else
        {
            NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationMaskPortrait];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }
        
    }
    else
    {
        
        
    }
}

-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}

#pragma mark - Mapview

-(IBAction)btn_DeliveryMap:(id)sender
{
    if (arr_DeliveryList.count==0)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Address not found." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else
    {
            // str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
        
        
        DeliveryLocation *ln = [[DeliveryLocation alloc]initWithNibName:@"DeliveryLocation" bundle:nil];
        ln.str_Address=str_Address;
        ln.str_Street=arr_DeliveryList[0][@"Street1"];
        ln.str_State=[NSString stringWithFormat:@"%@, %@ - %@",arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
        
            // ln.str_PatientName=arr_DeliveryList[0][@"PatientName"];
        
        ln.str_PatientName=@"CURRENT LOCATION";
        
        
        [self.navigationController pushViewController:ln animated:NO];
        
    }
    
}

#pragma mark - Button Delivery


-(IBAction)btn_Save:(id)sender
{
    if (arr_Number.count==0)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Delivery data is empty." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else
    {
        /* Card_payment *home = [[Card_payment alloc]initWithNibName:@"Card_payment" bundle:nil];
         home.arr_DelRxListNumber=arr_Number;
         home.arr_DelRxListAmount=arr_Cost;
         
         [self.navigationController pushViewController:home animated:YES];
         */
        
        Card_payment *ln = [[Card_payment alloc]initWithNibName:@"Card_payment" bundle:nil];
        ln.arr_DelRxListNumber=arr_Number;
        ln.arr_DelRxID=arr_RxID;
        ln.arr_DelRxListAmount=arr_Cost;
        ln.str_PatientAddress=str_Address;
        ln.str_PatientName=arr_DeliveryList[0][@"PatientName"];
        ln.str_IsPOS=str_isPOS;
        ln.str_POSID=str_LogIDD;
        ln.arr_Del_Qty=arr_Qty;
        
        ln.arr_PatientID=arr_PatientID;
        ln.arr_HipaaSigID=arr_HipaaSigID;
        ln.arr_HipaaSig=arr_HipaaSig;
        ln.arr_BalanceAmount=arr_BalanceAmount;
        ln.arr_RxARItemID=arr_RxARItemID;
        ln.str_RxSearch=str_RxSearch;

        
        
        manage.str_DelPatientPhone=arr_DeliveryList[0][@"Mobile"];
        
        ln.str_cardNumber=arr_DeliveryList[0][@"PatientCreditCardNo"];
        ln.str_expDate=arr_DeliveryList[0][@"PatientCCExpMMYY"];
        ln.str_ccCode=arr_DeliveryList[0][@"PatientCCCode"];
        
        ln.str_patZip=arr_DeliveryList[0][@"Zip"];
        ln.str_street=arr_DeliveryList[0][@"Street1"];
        ln.str_city=arr_DeliveryList[0][@"City"];
        ln.str_state=arr_DeliveryList[0][@"State"];
        ln.str_patient_email=arr_DeliveryList[0][@"PatientEmail"];
        
        ln.str_ARaddress=arr_DeliveryList[0][@"ARAddress"];
        ln.str_ARbalance=arr_DeliveryList[0][@"ARBalance"];
        ln.str_ARacc=arr_DeliveryList[0][@"AcctName"];
        ln.str_ARar=arr_DeliveryList[0][@"Ar"];
        ln.str_ARbill=arr_DeliveryList[0][@"BillAdd"];
        ln.str_ARcity=arr_DeliveryList[0][@"ARCity"];
        ln.str_ARstate=arr_DeliveryList[0][@"ARState"];
        ln.str_ARphone=arr_DeliveryList[0][@"ARPhone1"];
        ln.str_ARzip=arr_DeliveryList[0][@"ARZip"];
        
        
        
        
        
        [self.navigationController pushViewController:ln animated:NO];
        
        
        
        /*  Card_payment *ln = [[Card_payment alloc]initWithNibName:@"Card_payment" bundle:nil];
         ln.arr_DelRxListNumber=arr_Number;
         ln.arr_DelRxListAmount=arr_Cost;
         ln.str_PatientName=;
         ln.str_IsPOS=str_isPOS;
         ln.str_POSID=str_LogID;
         [self.navigationController pushViewController:ln animated:NO];
         */
        
    }
    
    
}

#pragma mark - Button Back

-(IBAction)btn_Back:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark - Textfield

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self view] endEditing:YES];
}



-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==text_RxNumber)
    {
        [text_RxNumber resignFirstResponder];
    }
    if (textField==text_RxNumber1)
    {
        [text_RxNumber1 resignFirstResponder];
    }
    return YES;
}




-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField ==text_RxNumber) {
        
        NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
            // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
        
        if ([string isEqualToString:filtered]) {
           // CGFloat borderWidth = 1.0f;
            
            
                //view_name.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_name.layer.borderWidth = borderWidth;
                //view_name.layer.cornerRadius = 3;
        }
        return [string isEqualToString:filtered];
        
    }
    if (textField ==text_RxNumber1) {
        
        NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
            // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
        
        if ([string isEqualToString:filtered]) {
          //  CGFloat borderWidth = 1.0f;
            
            
                //view_name.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_name.layer.borderWidth = borderWidth;
                //view_name.layer.cornerRadius = 3;
        }
        return [string isEqualToString:filtered];
        
    }
    return YES;
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    /* if (str_DeliveryNumber.length<=0)
     {
     
     }
     else
     {
     return arr_RxNumber.count;
     }*/
    if (section==0)
    {
        if (arr_DeliveryList.count<=0)
        {
            return 0;
            
        }
        else
        {
            return 1;
            
        }
        
    }
    else// if(section==1)
    {
        return arr_Number.count;
        
    }
    /*
     else
     {
     if (arr_DeliveryList.count<=0)
     {
     return 0;
     
     }
     else
     {
     return 1;
     
     }
     
     }
     
     */
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        
        return 225;
    }
    else// if (indexPath.section==1)
    {
        
        if ([manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@""] || [manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@"0"] ) {
            
            return 45;
            
            
        }
        else
        {
            NSString *str=[NSString stringWithFormat:@"%@ : %@",arr_Number[indexPath.row],arr_DrugName[indexPath.row]];
            
                // NSString *str = [arr_sale_product_name objectAtIndex:indexPath.row];
            CGSize size = [str sizeWithFont:[UIFont systemFontOfSize:14 weight:UIFontWeightMedium] constrainedToSize:CGSizeMake(165, 500) lineBreakMode:NSLineBreakByWordWrapping];
                // NSLog(@"%f",size.height);
            return size.height + 40;
        }
        
        
        
    }
    /*
     else
     {
     return 50;
     }
     
     */
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        
        return 1;
        
    }
    else
    {
        return 1;
        
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        static NSString *SimpletableIndentifier=@"DeliveryOrderSearchCell";
        DeliveryOrderSearchCell *cell = [table_RxList dequeueReusableCellWithIdentifier:SimpletableIndentifier];
        if (cell == nil) {
            cell = [[DeliveryOrderSearchCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DeliveryOrderSearchCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            UIView *bgColorView = [[UIView alloc] init];
            bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
            [cell setSelectedBackgroundView:bgColorView];
                //cell = [nib objectAtIndex:0];
        }
        
        cell.lab_Address.text=str_Address;
        cell.lab_TItems.text=str_TCount;
        cell.lab_tCost.text=str_TCost;
        cell.lab_DItems.text=str_DCount;
        cell.lab_dCost.text=str_DCost;
        cell.lab_Discription.text=str_Description;
        
            //    NSDate *datee=[Formate_DateMonthYear_Service dateFromString:arr_Date[indexPath.row]];
        
            //   cell.lab_Date.text=[NSString stringWithFormat:@"%@",[Formate_DateMonthYear stringFromDate:datee]];
        
        
        return cell;
        
    }
    else // if (indexPath.section==1)
    {
        static NSString *SimpletableIndentifier=@"DetailedTableCell";
        DetailedTableCell *cell = [table_RxList dequeueReusableCellWithIdentifier:SimpletableIndentifier];
        if (cell == nil) {
            cell = [[DetailedTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DetailedTableCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            UIView *bgColorView = [[UIView alloc] init];
            bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
            [cell setSelectedBackgroundView:bgColorView];
                //cell = [nib objectAtIndex:0];
        }
     
        NSString *str;
        if ([manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@""] || [manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@"0"] ) {
            
            str=[NSString stringWithFormat:@"%@",arr_Number[indexPath.row]];
            
            
        }
        else
        {
            str=[NSString stringWithFormat:@"%@ : %@",arr_Number[indexPath.row],arr_DrugName[indexPath.row]];
            
        }
 
        cell.lab_Number.text=str;
        cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",[arr_Cost[indexPath.row]floatValue]];
        cell.lab_Qty.text=[NSString stringWithFormat:@"%d",[arr_Qty[indexPath.row]intValue]];
        
        NSDate *datee=[Formate_DateMonthYear_Service dateFromString:arr_Date[indexPath.row]];
        NSString *str_Date=[Formate_DateMonthYear stringFromDate:datee];
        
        if (str_Date == nil)
        {
            cell.lab_Date.text=@"";
            
        }
        else
        {
            cell.lab_Date.text=str_Date;
            
        }
        
        
        return cell;
        
    }
    /*
     else
     {
     
     static NSString *SimpletableIndentifier=@"DeliveryOrderSearchDownloadCell";
     DeliveryOrderSearchDownloadCell *cell = [table_RxList dequeueReusableCellWithIdentifier:SimpletableIndentifier];
     if (cell == nil) {
     cell = [[DeliveryOrderSearchDownloadCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
     NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DeliveryOrderSearchDownloadCell" owner:self options:nil];
     cell = [nib objectAtIndex:0];
     UIView *bgColorView = [[UIView alloc] init];
     bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
     [cell setSelectedBackgroundView:bgColorView];
     //cell = [nib objectAtIndex:0];
     }
     
     [cell.btn_Download addTarget:self action:@selector(btn_Download:) forControlEvents:UIControlEventTouchUpInside];
     [cell.btn_Download setTag:indexPath.row];
     
     
     return cell;
     
     }
     */
}

-(void) btn_Download:(UIButton*)sender
{
    /* if (arr_Number.count==0)
     {
     UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Delivery data is empty." preferredStyle:UIAlertControllerStyleAlert];
     
     UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
     [alertController addAction:ok];
     
     [self presentViewController:alertController animated:YES completion:nil];
     
     
     }
     else
     {*/
    if ([str_Typeee isEqualToString:@"RX"])
    {
        NSString *str_IDDD=[NSString stringWithFormat:@"#%@",str_LogIDD];
        
        BOOL ConditionSig=[[DBManager getSharedInstance]saveDataRxNum:str_IDDD StoreID:str_StoreID];
        
        if (ConditionSig == NO) {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Data Already Exists" message:@"" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
//                                  @"Data Already Exists" message:nil
//                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//
//            [alert show];
        }
        else
        {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Download Successfully" message:@"" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
//                                  @"Download Successfully" message:nil
//                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//
//            [alert show];
//
        }
        
        
        
    }
    else if ([str_Typeee isEqualToString:@"POS"])
    {
        
        BOOL ConditionSig=[[DBManager getSharedInstance]saveDataPOSNum:str_LogIDD StoreID:str_StoreID];
        
        if (ConditionSig == NO) {
            
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Data Already Exists" message:@"" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
//                                  @"Data Already Exists" message:nil
//                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//
//            [alert show];
        }
        else
        {
                //  NSMutableArray* arr_CurrentDelivery=[[NSMutableArray alloc]init];
                //   arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values];
                //   NSLog(@"%@",arr_CurrentDelivery);
            
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Download Successfully" message:@"" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
//                                  @"Download Successfully" message:nil
//                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//
//
//            [alert show];
            
        }
    }
    else
    {
        BOOL ConditionSig=[[DBManager getSharedInstance]saveDataLogNum:str_LogIDD StoreID:str_StoreID];
        
        if (ConditionSig == NO) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                  @"Data Already Exists" message:nil
                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            
            [alert show];
        }
        else if(ConditionSig==YES)
        {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                  @"Download Successfully" message:nil
                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            
            [alert show];
            
        }
        
    }
        // }
    
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0)
    {
        return NO;
    }
    else
    {
            // if ([arr_DeliveryList[indexPath.row][@"IsDelivered"]intValue]==0) {
        return YES;
        /*
         }
         else
         {
         return NO;
         
         }
         */
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([manage.arr_storeInfoList[@"AccessToDeleteRx"] isEqualToString:@"0"] || [manage.arr_storeInfoList[@"AccessToDeleteRx"] isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                        message:@"You Don't have access to delete Rx. Please contact admin"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
        
        //  alert.tag=12;
        [alert show];
    }
    else{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [arr_Number removeObjectAtIndex:indexPath.row];
        [arr_Cost removeObjectAtIndex:indexPath.row];
        [arr_Date removeObjectAtIndex:indexPath.row];
        [arr_Qty removeObjectAtIndex:indexPath.row];
        [arr_RxID removeObjectAtIndex:indexPath.row];
        [manage.arr_ArChargeID removeObjectAtIndex:indexPath.row];
        
        [arr_DrugName removeObjectAtIndex:indexPath.row];
        [arr_PatientID removeObjectAtIndex:indexPath.row];
        [arr_HipaaSigID removeObjectAtIndex:indexPath.row];
        [arr_HipaaSig removeObjectAtIndex:indexPath.row];
        [arr_BalanceAmount removeObjectAtIndex:indexPath.row];
        [arr_RxARItemID removeObjectAtIndex:indexPath.row];

        if ([lab_TextHint.text isEqualToString:@"By Delivery ID"])
        {
            if ([manage.str_deletedRxList  isEqual: @""]) {
                manage.str_deletedRxList = arr_ShippingDetailID[indexPath.row];
            }
            else
            {
                manage.str_deletedRxList=[NSString stringWithFormat:@"%@,%@",manage.str_deletedRxList,arr_ShippingDetailID[indexPath.row]];
            }
            NSLog(@"%@", manage.str_deletedRxList);
            [arr_ShippingDetailID removeObjectAtIndex:indexPath.row];
        }

        

        
        if ([str_Typeee isEqualToString:@"RX"])
        {
            NSLog(@"%@",arr_DeliveryList);
            [arr_DeliveryList removeObjectAtIndex:indexPath.row];
            NSLog(@"%@",arr_DeliveryList);
            
            if (arr_DeliveryList.count==0)
            {
                view_Search1.hidden=YES;
                view_Search.hidden=NO;
                
            }
            else
            {
                str_Address=[NSString stringWithFormat:@"%@, %@, %@ - %@",arr_DeliveryList[0][@"Street1"],arr_DeliveryList[0][@"City"],arr_DeliveryList[0][@"State"],arr_DeliveryList[0][@"Zip"]];
                str_Description=@"";
                str_TCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_DeliveryList.count];
                
                float f_Cost=0.0;
                
                for (int i=0; i<arr_Number.count; i++)
                {
                    f_Cost=f_Cost+[arr_Cost[i]floatValue];
                    
                }
                str_TCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
                
            }
        }
        else
        {
            float f_Cost=0.0;

            for (int i=0; i<arr_Number.count; i++)
            {
                f_Cost=f_Cost+[arr_Cost[i]floatValue];
                
            }
            str_DCost=[NSString stringWithFormat:@"%.2f",f_Cost];
            str_DCount=[NSString stringWithFormat:@"%lu",(unsigned long)arr_Number.count];
        }

        [table_RxList reloadData];
        
    }
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
