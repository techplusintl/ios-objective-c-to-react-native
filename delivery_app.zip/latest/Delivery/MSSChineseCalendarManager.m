//
//  MSSChineseCalendarManager.m
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import "MSSChineseCalendarManager.h"

@interface MSSChineseCalendarManager ()
@property (nonatomic,strong)NSCalendar *chineseCalendar;
@property (nonatomic,strong)NSArray *chineseYearArray;
@property (nonatomic,strong)NSArray *chineseMonthArray;
@property (nonatomic,strong)NSArray *chineseDayArray;
@end

@implementation MSSChineseCalendarManager

- (instancetype)init
{
    self = [super init];
    if(self)
    {
        _chineseCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSChineseCalendar];
        
    }
    return self;
}

- (void)getChineseCalendarWithDate:(NSDate *)date calendarItem:(MSSCalendarModel *)calendarItem
{
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit;
    
    NSDateComponents *localeComp = [_chineseCalendar components:unitFlags fromDate:date];
//    NSString *chineseYear = [_chineseYearArray objectAtIndex:localeComp.year - 1];
    NSInteger tempDay = localeComp.day;
    if(tempDay == 0)
    {
        tempDay = 30;
    }
    NSString *chineseMonth = [_chineseMonthArray objectAtIndex:localeComp.month - 1];
    NSString *chineseDay = [_chineseDayArray objectAtIndex:tempDay - 1];
    
    calendarItem.chineseCalendar = chineseDay;
    
    if([@"" isEqualToString:chineseMonth] &&
       [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
    else if([@"" isEqualToString:chineseMonth] &&
            [@"" isEqualToString:chineseDay])
    {
        calendarItem.holiday = @"";
    }
}


- (BOOL)isQingMingholidayWithYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day
{
    if(month == 4)
    {
        NSInteger pre = year / 100;
        float c = 4.81;
        if(pre == 19)
        {
            c = 5.59;
        }
        NSInteger y = year % 100;
        NSInteger qingMingDay = (y * 0.2422 + c) - y / 4;
        if(day == qingMingDay)
        {
            return YES;
        }
    }
    return NO;
}



@end
