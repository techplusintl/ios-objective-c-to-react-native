//
//  DriverTtackPath.h
//  Delivery
//
//  Created by Barani Elangovan on 9/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#import "singleton.h"

@interface DriverTtackPath : UIViewController<MKMapViewDelegate>
{
    singleton *manage;
}
@property(strong,nonatomic)IBOutlet MKMapView *mapView;

@end
