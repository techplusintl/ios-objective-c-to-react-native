//
//  Card_payment.h
//  RXfill
//
//  Created by Suresh Elumalai on 1/9/16.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Signature_screen.h"
#import "AppDelegate.h"
#import "DGActivityIndicatorView.h"

#import "singleton.h"

@interface Card_payment : UIViewController<UITextFieldDelegate>

{
        CGFloat animatedDistance;
    singleton *manage;
}

@property(strong,nonatomic)IBOutlet UILabel *lab_Cash;
@property(strong,nonatomic)IBOutlet UILabel *lab_Card;
@property(strong,nonatomic)IBOutlet UILabel *lab_Check;

@property(strong,nonatomic)NSString *str_PatientName;
@property(strong,nonatomic)NSString *str_IsPOS;
@property(strong,nonatomic)NSString *str_POSID;
@property(strong,nonatomic)NSString *str_PatientAddress;

@property(strong,nonatomic)NSString *str_RxSearch;


@property(strong,nonatomic)NSMutableArray *arr_DelRxListNumber;
@property(strong,nonatomic)NSMutableArray *arr_DelRxListAmount;
@property(strong,nonatomic)NSMutableArray *arr_DelRxID;
@property(strong,nonatomic)NSMutableArray *arr_Del_Qty;

@property(strong,nonatomic)NSMutableArray *arr_HipaaSigID;
@property(strong,nonatomic)NSMutableArray *arr_HipaaSig;
@property(strong,nonatomic)NSMutableArray *arr_PatientID;
@property(strong,nonatomic)NSMutableArray *arr_BalanceAmount;
@property(strong,nonatomic)NSMutableArray *arr_RxARItemID;


@property(strong,nonatomic)NSString *str_patient_email;


@property(strong,nonatomic)IBOutlet UIScrollView *scroll_View;
@property(strong,nonatomic)IBOutlet UIView *view_Scroll;
@property(strong,nonatomic)IBOutlet UIScrollView *scroll_ARview;

@property(strong,nonatomic)IBOutlet UITextField *text_CardNumber;


@property(strong,nonatomic)IBOutlet UILabel *lab_CardLine;
@property(strong,nonatomic)IBOutlet UILabel *lab_CashLine;
@property(strong,nonatomic)IBOutlet UILabel *lab_CheckLine;

@property(strong,nonatomic)IBOutlet UILabel *lab_RxCount;
@property(strong,nonatomic)IBOutlet UILabel *lab_RxAmount;
@property(strong,nonatomic)IBOutlet UILabel *lab_RxPaidAmount;



@property (strong,nonatomic) NSString *str_internet;
@property (strong,nonatomic) NSString *str_logid;
@property (strong,nonatomic) NSString *str_patpay;




@property (strong,nonatomic) NSString *str_cardNumber;
@property (strong,nonatomic) NSString *str_expDate;
@property (strong,nonatomic) NSString *str_ccCode;
@property (strong,nonatomic) NSString *str_patZip;

@property (strong,nonatomic) NSString *str_street;
@property (strong,nonatomic) NSString *str_city;
@property (strong,nonatomic) NSString *str_state;


@property (strong,nonatomic) IBOutlet UIButton *btn_skip;
@property (strong,nonatomic) IBOutlet UIView *view_offline_alert;
@property (strong,nonatomic) IBOutlet UIButton *btn_back;


@property (strong,nonatomic)IBOutlet UIImageView *img_card_number;
@property (strong,nonatomic)IBOutlet UIImageView *img_card_expdate;
@property (strong,nonatomic)IBOutlet UIImageView *imag_card_cvv;

@property (strong,nonatomic)IBOutlet UITextField *txt_card_exp;
@property (strong,nonatomic)IBOutlet UITextField *txt_cvv;
@property (strong,nonatomic)IBOutlet UITextField *txt_card_name;
@property (strong,nonatomic)IBOutlet UITextField *txt_zip;

@property (strong,nonatomic)IBOutlet UITextField *txt_RefNumber;
@property (strong,nonatomic)IBOutlet UILabel *lab_RefNumber;
@property (strong,nonatomic)IBOutlet UILabel *lab_CardNumber;

@property (strong,nonatomic) NSString *str_rxcount;

@property(strong,nonatomic)IBOutlet UILabel *lab_Comments;
@property(strong,nonatomic)IBOutlet UIView *view_Comments;
@property(strong,nonatomic)IBOutlet UITextView *text_Comments;
@property(strong,nonatomic)IBOutlet UIView *view_CommentBase;

@property(strong,nonatomic)IBOutlet UIView *view_CashPayment;
@property(strong,nonatomic)IBOutlet UIView *view_CardPayment;

@property(strong,nonatomic)IBOutlet UITextField *text_CashAmount;


@property(strong,nonatomic)IBOutlet UIView *view_OtherPayment;
@property(strong,nonatomic)IBOutlet UILabel *lab_CommentsOthers;
@property(strong,nonatomic)IBOutlet UIView *view_CommentsOthers;
@property(strong,nonatomic)IBOutlet UITextView *text_CommentsOthers;
@property(strong,nonatomic)IBOutlet UIButton *btn_OthersOK;
@property(strong,nonatomic)IBOutlet UIButton *btn_OthersCancel;



@property(strong,nonatomic) NSString *str_ARaddress;
@property(strong,nonatomic) NSString *str_ARbalance;
@property(strong,nonatomic) NSString *str_ARacc;
@property(strong,nonatomic) NSString *str_ARar;
@property(strong,nonatomic) NSString *str_ARbill;
@property(strong,nonatomic) NSString *str_ARstate;
@property(strong,nonatomic) NSString *str_ARcity;
@property(strong,nonatomic) NSString *str_ARphone;
@property(strong,nonatomic) NSString *str_ARzip;


@property(strong,nonatomic)IBOutlet UILabel *labl_ARamoumt;
@property(strong,nonatomic)IBOutlet UILabel *labl_ARtotalAmount;
@property(strong,nonatomic)IBOutlet UILabel *labl_ARPaidAmount;

@property(strong,nonatomic)IBOutlet UILabel *labl_ARCurrentAmount;
@property(strong,nonatomic)IBOutlet UILabel *labl_ARaddress1;
@property(strong,nonatomic)IBOutlet UILabel *labl_ARaddress2;
@property(strong,nonatomic)IBOutlet UILabel *labl_ARaccountname;


@end
