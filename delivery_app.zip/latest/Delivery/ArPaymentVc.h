//
//  ArPaymentVc.h
//  Delivery
//
//  Created by Ghanshyam on 11/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Card_payment.h"
#import "singleton.h"
#import "AppDelegate.h"
#import "DGActivityIndicatorView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ArPaymentVc : UIViewController<UITextFieldDelegate>
{
    CGFloat animatedDistance;
    singleton *manage;
    
}

@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property (weak, nonatomic) IBOutlet UIView *viewSeperateCredit;
@property (weak, nonatomic) IBOutlet UIView *viewSeperateCash;
@property (weak, nonatomic) IBOutlet UIView *viewSeperateCheck;
@property (weak, nonatomic) IBOutlet UIView *viewCheck;
@property (weak, nonatomic) IBOutlet UIView *viewCash;
@property (weak, nonatomic) IBOutlet UIView *viewCredit;

@property (weak, nonatomic) IBOutlet UITextField *txtCheckTotal;
@property (weak, nonatomic) IBOutlet UITextField *txtRefNumber;
@property (weak, nonatomic) IBOutlet UITextView *txtCheckComments;

@property (weak, nonatomic) IBOutlet UITextField *txtCashTotal;
@property (weak, nonatomic) IBOutlet UITextView *txtCashComments;

@property (weak, nonatomic) IBOutlet UITextField *txtCreditTotal;
@property (weak, nonatomic) IBOutlet UITextField *txtCreditCardNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtExpiryDate;
@property (weak, nonatomic) IBOutlet UITextField *txtCVV;
@property (weak, nonatomic) IBOutlet UITextField *txtZipCode;
@property (weak, nonatomic) IBOutlet UITextView *txtCreditComments;
@property (weak, nonatomic) IBOutlet UILabel *lblAmount;


@property(strong,nonatomic)NSString *str_PatientName;
@property(strong,nonatomic)NSString *str_IsPOS;
@property(strong,nonatomic)NSString *str_POSID;
@property(strong,nonatomic)NSString *str_PatientAddress;

@property(strong,nonatomic)NSString *str_RxSearch;


@property(strong,nonatomic)NSMutableArray *arr_DelRxListNumber;
@property(strong,nonatomic)NSMutableArray *arr_DelRxListAmount;
@property(strong,nonatomic)NSMutableArray *arr_DelRxID;
@property(strong,nonatomic)NSMutableArray *arr_Del_Qty;

@property(strong,nonatomic)NSMutableArray *arr_HipaaSigID;
@property(strong,nonatomic)NSMutableArray *arr_HipaaSig;
@property(strong,nonatomic)NSMutableArray *arr_PatientID;
@property(strong,nonatomic)NSMutableArray *arr_BalanceAmount;
@property(strong,nonatomic)NSMutableArray *arr_RxARItemID;
@property(strong,nonatomic)NSDictionary *arrArSearch;


@property(strong,nonatomic)NSString *str_patient_email;

@property (strong,nonatomic) NSString *str_internet;
@property (strong,nonatomic) NSString *str_logid;
@property (strong,nonatomic) NSString *str_patpay;

@property (strong,nonatomic) NSString *str_cardNumber;
@property (strong,nonatomic) NSString *str_expDate;
@property (strong,nonatomic) NSString *str_ccCode;
@property (strong,nonatomic) NSString *str_patZip;

@property (strong,nonatomic) NSString *str_street;
@property (strong,nonatomic) NSString *str_city;
@property (strong,nonatomic) NSString *str_state;

@property(strong,nonatomic) NSString *str_ARaddress;
@property(strong,nonatomic) NSString *str_ARbalance;
@property(strong,nonatomic) NSString *str_ARacc;
@property(strong,nonatomic) NSString *str_ARar;
@property(strong,nonatomic) NSString *str_ARbill;
@property(strong,nonatomic) NSString *str_ARstate;
@property(strong,nonatomic) NSString *str_ARcity;
@property(strong,nonatomic) NSString *str_ARphone;
@property(strong,nonatomic) NSString *str_ARzip;
@property (strong,nonatomic) NSString *str_rxcount;

- (IBAction)btnBack_Click:(id)sender;
- (IBAction)btnCreditCard_Click:(id)sender;
- (IBAction)btnCash_Click:(id)sender;
- (IBAction)btnCheck_Click:(id)sender;

- (IBAction)btnVerify_Click:(id)sender;



@end

NS_ASSUME_NONNULL_END
