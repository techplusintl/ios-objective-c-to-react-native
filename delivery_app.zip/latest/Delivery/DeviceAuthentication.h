//
//  DeviceAuthentication.h
//  Delivery
//
//  Created by Barani Elangovan on 6/6/17.
//  Copyright © 2017 Suresh Elumalai. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "singleton.h"
#import "OnlineList.h"
#import "ViewController.h"

@interface DeviceAuthentication : UIViewController
{
    CGFloat animatedDistance;
    singleton *manage;
}

@property(strong,nonatomic)IBOutlet UIView *view_activity;

@property(strong,nonatomic)IBOutlet UIView *view_back1;


@property(strong,nonatomic)IBOutlet UIView *view_back;

@property(strong,nonatomic)IBOutlet UIView *view_Code;
@property(strong,nonatomic)IBOutlet UITextField *text_Code;
@property(strong,nonatomic)IBOutlet UIButton *btn_Cancel;
@property(strong,nonatomic)IBOutlet UIButton *btn_Confirm;


@end
