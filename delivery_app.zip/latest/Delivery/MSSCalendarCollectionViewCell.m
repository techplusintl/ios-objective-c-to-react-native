//
//  MSSCalendarCollectionViewCell.m
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import "MSSCalendarCollectionViewCell.h"
#import "MSSCalendarDefine.h"

@implementation MSSCalendarCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    {
        [self createCell];
    }
    return self;
}

- (void)createCell
{
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height)];
    [self.contentView addSubview:_imageView];
    
    _dateLabel = [[MSSCircleLabel alloc]initWithFrame:CGRectMake(0, MSS_Iphone6Scale(10), self.contentView.frame.size.width, self.frame.size.height / 2 - MSS_Iphone6Scale(10))];
    _dateLabel.textAlignment = NSTextAlignmentCenter;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
    _dateLabel.font = [UIFont systemFontOfSize:15.0f];
    }
    else
    {
        _dateLabel.font = [UIFont systemFontOfSize:20.0f];

    }
    
    [self.contentView addSubview:_dateLabel];
    
    _subLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_dateLabel.frame), self.contentView.frame.size.width, _dateLabel.frame.size.height)];
    _subLabel.textAlignment = NSTextAlignmentCenter;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
    _subLabel.font = [UIFont systemFontOfSize:15.0f];
    }
    else
    {
        _subLabel.font = [UIFont systemFontOfSize:20.0f];

    }
    [self.contentView addSubview:_subLabel];
}

- (void)setIsSelected:(BOOL)isSelected
{
    _dateLabel.isSelected = isSelected;
}

@end
