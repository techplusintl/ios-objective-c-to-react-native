//
//  ViewController.h
//  Delivery
//
//  Created by Rex on 16/02/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "singleton.h"

#import "HomeScreen.h"
#import "OnlineList.h"
#import "DeviceAuthentication.h"

#import "DBManager.h"

#import "SKPSMTPMessage.h"
#import "NSData+Base64Additions.h"
#import "CommanMethods.h"

#import "CustomMessage.h"

@interface ViewController : UIViewController<SKPSMTPMessageDelegate>
{
    CGFloat animatedDistance;
    singleton *manage;
}


@property(strong,nonatomic)IBOutlet UITextField *text_StoreNumber;
@property(strong,nonatomic)IBOutlet UITextField *text_UserId;
@property(strong,nonatomic)IBOutlet UITextField *text_Password;
@property(strong,nonatomic)IBOutlet UIButton *btn_login;
@property(strong,nonatomic)IBOutlet UIImageView *image_background;
@property (nonatomic, strong)IBOutlet UISwitch *mySwitch;
@property(strong,nonatomic)IBOutlet UIView *view_activity;



@property (strong,nonatomic)IBOutlet UIView *view_offline_alert;
@property(strong,nonatomic)IBOutlet UIView *view_offlineBackground;
@property(strong,nonatomic)IBOutlet UIView *view_fingerprint;


@property(strong,nonatomic)NSString *str_AutoLogOut;

@end

