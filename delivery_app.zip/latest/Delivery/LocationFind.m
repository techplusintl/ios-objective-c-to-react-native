//
//  LocationFind.m
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/5/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "LocationFind.h"

@interface LocationFind ()
{
    Mapannotation *newAnnotation;
    float f_UserLocation1;
    float f_UserLocation2;
    NSMutableArray *arr_direction;
    NSMutableArray *arr_distance;
    
    NSString *str_Route;
    NSString *str_FirstTime;
    NSString *str_Zoom;
    
}
@end

@implementation LocationFind

@synthesize mapView,locationManager,view_Route,image_Route,table_Route,str_IsPharmacy;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage=[singleton share];
    
    view_Route.hidden=YES;
    
    str_Route=@"Route";
    
    str_Zoom=@"Yess";
    
    arr_direction=[[NSMutableArray alloc]init];
    arr_distance=[[NSMutableArray alloc]init];
    
    
    mapView.mapType = MKMapTypeStandard;
    
    str_FirstTime=@"Yes";
    
    
    /* locationManager = [[CLLocationManager alloc] init];
     locationManager.delegate = self;
     locationManager.distanceFilter = kCLDistanceFilterNone;
     locationManager.desiredAccuracy = kCLLocationAccuracyBest;
     [locationManager startUpdatingLocation];
     
     [self.mapView setUserTrackingMode:MKUserTrackingModeFollow];*/
    
    
    self.locationManager = [[CLLocationManager alloc]init];
    self.locationManager.delegate = self;
    if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
        [self.locationManager requestAlwaysAuthorization];
    }
    
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        [self.locationManager startUpdatingLocation];
        self.mapView.showsUserLocation = YES;
        
    }
    
    if (self.locationManager == nil)
    {
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
        self.locationManager.delegate = self;
    }
    [self.locationManager startUpdatingLocation];
    
    
    [self FindDirection];
    
    // Do any additional setup after loading the view.
}

-(void)FindDirection
{
    
    NSString *address=[manage.arr_storeInfoList[@"PharmacyStreet"] stringByAppendingString:[NSString stringWithFormat:@", %@",manage.arr_storeInfoList[@"PharmacyCity"]]];
    address=[address stringByAppendingString:[NSString stringWithFormat:@", %@",manage.arr_storeInfoList[@"PharmacyState"]]];
    
    address=[address stringByAppendingString:[NSString stringWithFormat:@" - %@",manage.arr_storeInfoList[@"PharmacyZip"]]];
    
    
    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error)
     {
         if(!error)
         {
             CLPlacemark *placemark = [placemarks objectAtIndex:0];
             // NSLog(@"%f",placemark.location.coordinate.latitude);
             // NSLog(@"%f",placemark.location.coordinate.longitude);
             // NSLog(@"%@",[NSString stringWithFormat:@"%@",[placemark description]]);
             
             CLLocationCoordinate2D touchMapCoordinate;
             
             CLLocationCoordinate2D userCoordinate;
             
             userCoordinate.latitude = f_UserLocation1;
             userCoordinate.longitude = f_UserLocation2;
             
             
             touchMapCoordinate.latitude = placemark.location.coordinate.latitude;
             touchMapCoordinate.longitude = placemark.location.coordinate.longitude;
             
             
            // touchMapCoordinate.latitude = 37.327043;
             //touchMapCoordinate.longitude =-122.030690;
             
                 MKPointAnnotation *annotationPoint = [[MKPointAnnotation alloc] init];
              annotationPoint.coordinate = touchMapCoordinate;
              
              // MKCoordinateSpan span =MKCoordinateSpanMake(0.02,.02);
              // MKCoordinateRegion regionToDisplay =
              // MKCoordinateRegionMake(touchMapCoordinate, span);
              annotationPoint.title =manage.arr_storeInfoList[@"PharmacyName"];
              // annotationPoint.subtitle = @"Sub title";
              [self.mapView addAnnotation:annotationPoint];
             
             
             CLLocationCoordinate2D location;
             
             location.longitude =placemark.location.coordinate.longitude;
             location.latitude =placemark.location.coordinate.latitude;
             
             
             
             
             MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
             
             MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
             [srcMapItem setName:@""];
             
             MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(placemark.location.coordinate.latitude, placemark.location.coordinate.longitude) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
             
             
             MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
             [distMapItem setName:@""];
             
             
             MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
             [request setSource:srcMapItem];
             [request setDestination:distMapItem];
             //[request requestsAlternateRoutes];
             
             [request setTransportType:MKDirectionsTransportTypeAutomobile];
             
             MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
             
             [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                 
                 // NSLog(@"response = %@",response);
                 NSArray *arrRoutes = [response routes];
                 [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                     
                     MKRoute *route = obj;
                     
                      [mapView removeOverlays:mapView.overlays];
                     
                     MKPolyline *line = [route polyline];
                     
                     if ([str_Zoom isEqualToString:@"Yess" ])
                     {
                         [self.mapView setVisibleMapRect:[line boundingMapRect]];

                     }
                     [self.mapView addOverlay:line];
                     
                     str_Zoom=@"No";

                     
                     // NSLog(@"Rout Name : %@",route.name);
                     // NSLog(@"Total Distance (in Meters) :%f",route.distance);
                     
                     
                     ////// EDITED FROM HERE by Kosuke //////
                     NSUInteger pointCount = route.polyline.pointCount;
                     
                     // allocate a C array to hold this many points/coordinates...
                     CLLocationCoordinate2D *routeCoordinates
                     = malloc(pointCount * sizeof(CLLocationCoordinate2D));
                     
                     // get the coordinates (all of them)...
                     [route.polyline getCoordinates:routeCoordinates
                                              range:NSMakeRange(0, pointCount)];
                     
                     // make line between User location and Start point
                     CLLocationCoordinate2D coordinates1[2] = {userCoordinate, routeCoordinates[0]};
                     MKPolyline *line1 = [MKPolyline polylineWithCoordinates:coordinates1 count:2];
                     [self.mapView addOverlay:line1];
                     
                     // make line between Finish point and Destination location
                     CLLocationCoordinate2D coordinates2[2] = {routeCoordinates[pointCount - 1], touchMapCoordinate};
                     MKPolyline *line2 = [MKPolyline polylineWithCoordinates:coordinates2 count:2];
                     [self.mapView addOverlay:line2];
                     
                     //free the memory used by the C array when done with it...
                     free(routeCoordinates);
                     
                     //////////////////
                     
                     NSArray *steps = [route steps];
                     
                     // NSLog(@"Total Steps : %lu",(unsigned long)[steps count]);
                     
                     [arr_direction removeAllObjects];
                     [arr_distance removeAllObjects];
                     [steps enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                         
                         [arr_direction addObject:[obj instructions]];
                         // NSLog(@"%@",arr_direction);
                         
                         int latt=[obj distance];
                         NSString *list_la=[NSString stringWithFormat:@"%d",latt];
                         [arr_distance addObject:list_la];
                         
                         // NSLog(@"%@",arr_distance);
                     }];
                     [table_Route reloadData ];
                 }];
             }];
             
             
         }
         else
         {
             // NSLog(@"There was a forward geocoding error\n%@",[error localizedDescription]);
         }
     }
     ];
    
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    // NSLog(@"OldLocation %f %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude);
    // NSLog(@"NewLocation %f %f", newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    
    
    f_UserLocation1=newLocation.coordinate.latitude;
    f_UserLocation2=newLocation.coordinate.longitude;
    
    
    // [self.mapView.reloadInputViews];
    
    if ([str_FirstTime isEqualToString:@"Yes"])
    {
        str_FirstTime=@"No";
    }
    
    else
    {
        if ((oldLocation.coordinate.latitude == newLocation.coordinate.latitude)||(oldLocation.coordinate.longitude == newLocation.coordinate.longitude))
        {
            
        }
        else
        {
            
            [self FindDirection];
            
        }
    }
    
    
    
}
- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id)overlay {
    
    if ([overlay isKindOfClass:[MKPolyline class]]) {
        MKPolylineView* aView = [[MKPolylineView alloc]initWithPolyline:(MKPolyline*)overlay] ;
        aView.strokeColor = [UIColor colorWithRed:0.0/255.0 green:169.0/255.0 blue:252.0/255.0 alpha:1.0];
        aView.lineWidth = 8;
        return aView;
    }
    
    return nil;
}



- (void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    MKAnnotationView *annotationView = [views objectAtIndex:0];
    id <MKAnnotation> mp = [annotationView annotation];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance
    ([mp coordinate], 500, 500);
    [mv setRegion:region animated:YES];
    [mv selectAnnotation:mp animated:YES];
    
    
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr_direction.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str = [arr_direction objectAtIndex:indexPath.row];
    CGSize size = [str sizeWithFont:[UIFont fontWithName:@"HelveticaNeue-Medium" size:15] constrainedToSize:CGSizeMake(165, 500) lineBreakMode:NSLineBreakByWordWrapping];
    //NSLog(@"%f",size.height);
    return size.height+20;
    
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str_cell=@"RouteCell";
    RouteCell *cell = [table_Route dequeueReusableCellWithIdentifier:str_cell];
    if (cell == nil) {
        cell = [[RouteCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str_cell];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RouteCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        //cell = [nib objectAtIndex:0];
    }
    
    // NSInteger int_int=indexPath.row +1;
    
    cell.lab_Distance.text=[[arr_distance objectAtIndex:indexPath.row] stringByAppendingString:@" m"];
    
    cell.lab_Instruction.text=[arr_direction objectAtIndex:indexPath.row];
    
    return cell;
}

-(IBAction)btn_RouteDirection:(id)sender
{
    if ([str_Route isEqualToString:@"Route"])
    {
        str_Route=@"Map";
        image_Route.image=[UIImage imageNamed:@"Map-64.png"];
        view_Route.hidden=NO;
    }
    else
    {
        str_Route=@"Route";
        image_Route.image=[UIImage imageNamed:@"Split-48.png"];
        view_Route.hidden=YES;
    }
    
}

-(IBAction)btn_Back:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
