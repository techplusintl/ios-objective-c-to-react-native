    //
    //  DeliveredDetailedScreen.m
    //  Delivery
    //
    //  Created by Barani Elangovan on 5/4/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "DeliveredDetailedScreen.h"

@interface DeliveredDetailedScreen ()
{
    NSMutableArray *arr_Number;
    NSMutableArray *arr_Date;
    NSMutableArray *arr_Qty;
    NSMutableArray *arr_Cost;
    NSMutableArray *arr_RxID;
    NSMutableArray *arr_DrugName;
    NSMutableArray *arr_HipaaSigID;
    NSMutableArray *arr_PatientID;
    NSMutableArray *arr_HipaaSig;
    NSMutableArray *arr_BalanceAmount;
    NSMutableArray *arr_RxARItemID;
    
    /*
     
     [arr_HipaaSigID addObject:manage.arr_OnlineArray[i][@"HipaaSigID"]];
     [arr_PatientID addObject:manage.arr_OnlineArray[i][@"PatientID"]];
     [arr_HipaaSig addObject:manage.arr_OnlineArray[i][@"HipaaSig"]];
     */
    
    NSDateFormatter *Formate_DateMonthYear_Service;
    NSDateFormatter *Formate_DateMonthYear;
    
    NSDateFormatter *Formate_DateMonthYearTime;
    NSDateFormatter *Formate_DateMonthYearTime1;
    
    int i_Count;
    
    NSString *str_isPOS;
    
    
    NSString *str_Street;
    NSString *str_City;
    NSString *str_State;
    NSString *str_Zip;
    NSString *str_Description;
    NSString *str_name;
    NSString *str_DeliveryDate;
    NSString *str_PatientMail;
    
    NSString *str_email;
    NSString *str_cnumber;
    NSString *str_expdate;
    NSString *str_cccode;
    NSString *str_zipcode;
    
    
    NSString *str_ARAddress;
    NSString *str_ARAr;
    NSString *str_ARAcct;
    NSString *str_ARPhone1;
    NSString *str_ARBill;
    NSString *str_ARBalance;
    NSString *str_ARCity;
    NSString *str_ARState;
    NSString *str_ARZip;
    
    
    
    
    
}
@end

@implementation DeliveredDetailedScreen

@synthesize table_Detaill,lab_Name,lab_SCost,lab_TCost,lab_SCount,lab_TCount,lab_Address,lab_Description,lab_delivrydate,str_LogID,str_isMapView,str_addresss, labl_araccount;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage=[singleton share];
    
    [manage.arr_ArChargeID removeAllObjects];
    
    Formate_DateMonthYearTime=[[NSDateFormatter alloc]init];
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    
    [Formate_DateMonthYearTime setDateFormat:@"MM/dd/yyyy hh:mm a"];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    
    
    Formate_DateMonthYear=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear setDateFormat:@"MM/dd/yyyy"];
    
    arr_Qty=[[NSMutableArray alloc]init];
    arr_Date=[[NSMutableArray alloc]init];
    arr_Number=[[NSMutableArray alloc]init];
    arr_Cost=[[NSMutableArray alloc]init];
    arr_RxID=[[NSMutableArray alloc]init];
    arr_DrugName=[[NSMutableArray alloc]init];
    arr_PatientID=[[NSMutableArray alloc]init];
    arr_HipaaSigID=[[NSMutableArray alloc]init];
    arr_HipaaSig=[[NSMutableArray alloc]init];
    arr_BalanceAmount=[[NSMutableArray alloc]init];
    arr_RxARItemID =[[NSMutableArray alloc]init];


    NSLog(@"%@", manage.arr_OnlineDeliveredArray);
    
    float f_Cost=0.0;
    int i_count=0;
        // NSString *str_Dispacher=@"";
        //NSString *str_Date=@"";
    
        //    NSString *str_Street=@"";
        //    NSString *str_City=@"";
        //    NSString *str_State=@"";
        //    NSString *str_Zip=@"";
        //    NSString *str_Description=@"";
        //    NSString *str_name=@"";
        //    NSString *str_DeliveryDate=@"";
    
    if ([str_isMapView isEqualToString:@"Yes"]) {
        for (int i=0; i<manage.arr_OnlineDeliveredArray.count; i++)
        {
            
                //   NSLog(@"%@",str_addresss);
            
                //   NSLog(@"%@",[NSString stringWithFormat:@"%@, %@, %@ - %@",manage.arr_OnlineDeliveredArray[i][@"PatientStreet"],manage.arr_OnlineDeliveredArray[i][@"PatientCity"],manage.arr_OnlineDeliveredArray[i][@"PatientState"],manage.arr_OnlineDeliveredArray[i][@"Patientzip"]]);
            
            if ([str_addresss isEqualToString:[NSString stringWithFormat:@"%@, %@, %@ - %@",manage.arr_OnlineDeliveredArray[i][@"PatientStreet"],manage.arr_OnlineDeliveredArray[i][@"PatientCity"],manage.arr_OnlineDeliveredArray[i][@"PatientState"],manage.arr_OnlineDeliveredArray[i][@"Patientzip"]]])
            {
                
                [arr_Number addObject:manage.arr_OnlineDeliveredArray[i][@"RxNumber"]];
                [arr_Qty addObject:manage.arr_OnlineDeliveredArray[i][@"Qty"]];
                [arr_Cost addObject:manage.arr_OnlineDeliveredArray[i][@"Patpay"]];
                [arr_Date addObject:manage.arr_OnlineDeliveredArray[i][@"RxDate"]];
                
                [arr_HipaaSigID addObject:manage.arr_OnlineDeliveredArray[i][@"HipaaSigID"]];
                [arr_PatientID addObject:manage.arr_OnlineDeliveredArray[i][@"PatientID"]];
                [arr_HipaaSig addObject:manage.arr_OnlineDeliveredArray[i][@"HipaaSig"]];
                [arr_BalanceAmount addObject:manage.arr_OnlineDeliveredArray[i][@"BalanceAmt"]];
                [arr_RxARItemID addObject:manage.arr_OnlineDeliveredArray[i][@"RxARItemID"]];

                f_Cost=f_Cost+[manage.arr_OnlineDeliveredArray[i][@"Patpay"]floatValue];
                
                if(i_count==0)
                {
                    str_LogID=[NSString stringWithFormat:@"%@",manage.arr_OnlineDeliveredArray[i][@"ShipLogID"]];
                    
                    i_Count=i;
                    
                    str_name=manage.arr_OnlineDeliveredArray[i][@"PatientName"];
                    str_Description=manage.arr_OnlineDeliveredArray[i][@"ShipNotes"];
                    str_isPOS=manage.arr_OnlineDeliveredArray[i][@"IsPOS"];
                    
                    NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:manage.arr_OnlineDeliveredArray[i][@"DeliveredDate"]];
                    
                    str_DeliveryDate=[Formate_DateMonthYearTime stringFromDate:date11];
                    
                }
                i_count=i_count+1;
            }
            
        }
        
        lab_Name.text=str_name;
        lab_Description.text=str_Description;
        lab_delivrydate.text=str_DeliveryDate;
        
        lab_TCount.text=[NSString stringWithFormat:@"%d",i_count];
        lab_TCost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
        lab_SCount.text=[NSString stringWithFormat:@"%d",i_count];
        lab_SCost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
        lab_Address.text=[NSString stringWithFormat:@"%@",str_addresss];
        
        
    }
    
    else
    {
        for (int i=0; i<manage.arr_OnlineDeliveredArray.count; i++)
        {
            if ([str_LogID isEqualToString:[NSString stringWithFormat:@"%@",manage.arr_OnlineDeliveredArray[i][@"ShipLogID"]]]) {
                [arr_Number addObject:manage.arr_OnlineDeliveredArray[i][@"RxNumber"]];
                [arr_Qty addObject:manage.arr_OnlineDeliveredArray[i][@"Qty"]];
                [arr_Cost addObject:manage.arr_OnlineDeliveredArray[i][@"Patpay"]];
                [arr_Date addObject:manage.arr_OnlineDeliveredArray[i][@"RxDate"]];
                [arr_DrugName addObject:manage.arr_OnlineDeliveredArray[i][@"DrugName"]];
                [arr_HipaaSigID addObject:manage.arr_OnlineDeliveredArray[i][@"HipaaSigID"]];
                [arr_PatientID addObject:manage.arr_OnlineDeliveredArray[i][@"PatientID"]];
                [arr_HipaaSig addObject:manage.arr_OnlineDeliveredArray[i][@"HipaaSig"]];
                [manage.arr_ArChargeID addObject:manage.arr_OnlineDeliveredArray[i][@"ArChargeID"]];
                [arr_BalanceAmount addObject:manage.arr_OnlineDeliveredArray[i][@"BalanceAmt"]];
                [arr_RxARItemID addObject:manage.arr_OnlineDeliveredArray[i][@"RxARItemID"]];

                [arr_RxID addObject:[NSString stringWithFormat:@"%d",[manage.arr_OnlineDeliveredArray[i][@"RxID"]intValue]]];
                
                f_Cost=f_Cost+[manage.arr_OnlineDeliveredArray[i][@"Patpay"]floatValue];
                if(i_count==0)
                {
                    
                    i_Count=i;
                    
                    str_Street=manage.arr_OnlineDeliveredArray[i][@"PatientStreet"];
                    str_City=manage.arr_OnlineDeliveredArray[i][@"PatientCity"];
                    str_State=manage.arr_OnlineDeliveredArray[i][@"PatientState"];
                    str_Zip=manage.arr_OnlineDeliveredArray[i][@"Patientzip"];
                    str_name=manage.arr_OnlineDeliveredArray[i][@"PatientName"];
                    str_Description=manage.arr_OnlineDeliveredArray[i][@"ShipNotes"];
                    str_PatientMail=manage.arr_OnlineDeliveredArray[i][@"PatientEmail"];
                    str_isPOS=manage.arr_OnlineDeliveredArray[i][@"IsPOS"];
                    manage.str_DelPatientPhone=manage.arr_OnlineDeliveredArray[i][@"PatientMobile"];
                    NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:manage.arr_OnlineDeliveredArray[i][@"DeliveredDate"]];
                    
                    str_DeliveryDate=[Formate_DateMonthYearTime stringFromDate:date11];
                    str_ARAddress=manage.arr_OnlineDeliveredArray[i][@"PatientStreet"];
                    
                    
                    str_cnumber=manage.arr_OnlineDeliveredArray[i][@"PatientCreditCardNo"];
                    str_expdate=manage.arr_OnlineDeliveredArray[i][@"PatientCCExpMMYY"];
                    str_cccode=manage.arr_OnlineDeliveredArray[i][@"PatientCCCode"];
                    str_email=manage.arr_OnlineDeliveredArray[i][@"PatientEmail"];
                    
                    str_ARAddress=manage.arr_OnlineDeliveredArray[i][@"ARAddress"];
                    str_ARAr=manage.arr_OnlineDeliveredArray[i][@"Ar"];
                    str_ARAcct=manage.arr_OnlineDeliveredArray[i][@"Acct"];
                    str_ARPhone1=manage.arr_OnlineDeliveredArray[i][@"Phone1"];
                    str_ARBill=manage.arr_OnlineDeliveredArray[i][@"Bill"];
                    str_ARBalance=manage.arr_OnlineDeliveredArray[i][@"ARBalance"];
                    str_ARCity=manage.arr_OnlineDeliveredArray[i][@"City"];
                    str_ARState=manage.arr_OnlineDeliveredArray[i][@"State"];
                    str_ARZip=manage.arr_OnlineDeliveredArray[i][@"Zip"];
                    
                    
                    
                }
                i_count=i_count+1;
            }
            
        }
        lab_Name.text=str_name;
        
        lab_Description.text=str_Description;
        lab_delivrydate.text=str_DeliveryDate;
        
        lab_TCount.text=[NSString stringWithFormat:@"%d",i_count];
        lab_TCost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
        lab_SCount.text=[NSString stringWithFormat:@"%d",i_count];
        lab_SCost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
        lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
        
        
    }
    
    
    if ([str_ARAr isEqualToString:@""]||str_ARAr==nil) {
        
        labl_araccount.hidden=YES;
    }
    else
    {
        labl_araccount.hidden=NO;
        labl_araccount.text=[NSString stringWithFormat:@"AR Acc: %@",str_ARAcct];
    }
    
    NSLog(@"%@",str_email);
    
    
        // Do any additional setup after loading the view.
}

-(IBAction)btn_EditThisDelivery:(id)sender
{
    if ([manage.arr_storeInfoList[@"EditThisDelivery"] isEqualToString:@"0"] || [manage.arr_storeInfoList[@"EditThisDelivery"] isEqualToString:@""])
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                            message:@"You Don't have access to Edit this Delivery Please contact admin."
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil, nil];
            [alert show];
        }
  else{
    if (arr_Number.count==0)
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                              @"Alert" message:@"Delivery data is empty." delegate:nil cancelButtonTitle:
                              @"OK" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        /*
         
         ln.arr_DelRxListNumber=arr_Number;
         ln.arr_DelRxID=arr_RxID;
         ln.arr_Del_Qty=arr_Qty;
         ln.arr_DelRxListAmount=arr_Cost;
         ln.arr_Del_Qty=arr_Qty;
         ln.str_PatientName=lab_Name.text;
         ln.str_IsPOS=str_isPOS;
         ln.str_POSID=str_LogID;
         ln.str_PatientAddress=lab_Address.text;
         ln.str_cardNumber=str_cnumber;
         ln.str_expDate=str_expdate;
         ln.str_ccCode=str_cccode;
         
         ln.str_patZip=str_Zip;
         
         ln.str_street=str_Street;
         ln.str_city=str_City;
         ln.str_state=str_State;
         ln.str_patient_email=str_email;
         
         
         
         
         ln.str_ARaddress=  str_ARAddress;
         ln.str_ARar=str_ARAr;
         ln.str_ARacc=str_ARAcct;
         ln.str_ARphone=str_ARPhone1;
         ln.str_ARbill=str_ARBill;
         ln.str_ARbalance=str_ARBalance;
         ln.str_ARcity=str_ARCity;
         ln.str_ARstate=str_ARState;
         ln.str_ARzip=str_ARZip;
         
         
         */
        
        
        
        Card_payment *ln = [[Card_payment alloc]initWithNibName:@"Card_payment" bundle:nil];
        ln.arr_DelRxListNumber=arr_Number;
        ln.arr_DelRxID=arr_RxID;
        ln.arr_Del_Qty=arr_Qty;
        ln.arr_DelRxListAmount=arr_Cost;
        
        ln.arr_PatientID=arr_PatientID;
        ln.arr_HipaaSigID=arr_HipaaSigID;
        ln.arr_HipaaSig=arr_HipaaSig;
        ln.arr_BalanceAmount=arr_BalanceAmount;
        ln.arr_RxARItemID=arr_RxARItemID;

        ln.str_PatientName=lab_Name.text;
        ln.str_IsPOS=str_isPOS;
        ln.str_POSID=str_LogID;
        ln.str_PatientAddress=lab_Address.text;
        ln.str_cardNumber=str_cnumber;
        ln.str_expDate=str_expdate;
        ln.str_ccCode=str_cccode;
        
        ln.str_patZip=str_Zip;
        
        ln.str_street=str_Street;
        ln.str_city=str_City;
        ln.str_state=str_State;
        ln.str_patient_email=str_PatientMail;
        
        
        
        ln.str_ARaddress=  str_ARAddress;
        ln.str_ARar=str_ARAr;
        ln.str_ARacc=str_ARAcct;
        ln.str_ARphone=str_ARPhone1;
        ln.str_ARbill=str_ARBill;
        ln.str_ARbalance=str_ARBalance;
        ln.str_ARcity=str_ARCity;
        ln.str_ARstate=str_ARState;
        ln.str_ARzip=str_ARZip;
        
        
        
        
        
        
        [self.navigationController pushViewController:ln animated:NO];
        
    }
        }
}

#pragma mark - Button Back


-(IBAction)btn_Back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Map Button


-(IBAction)btn_DeliveryMap:(id)sender
{
    
    DeliveryLocation *ln = [[DeliveryLocation alloc]initWithNibName:@"DeliveryLocation" bundle:nil];
    ln.str_Address=lab_Address.text;
    ln.str_Street=manage.arr_OnlineDeliveredArray[i_Count][@"PatientStreet"];
    ln.str_State=[NSString stringWithFormat:@"%@, %@ - %@",manage.arr_OnlineDeliveredArray[i_Count][@"PatientCity"],manage.arr_OnlineDeliveredArray[i_Count][@"PatientState"],manage.arr_OnlineDeliveredArray[i_Count][@"Patientzip"]];
    
    ln.str_PatientName=manage.arr_OnlineDeliveredArray[i_Count][@"PatientName"];
    
    
    [self.navigationController pushViewController:ln animated:NO];
    
}

#pragma mark - TableView


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arr_Number.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return nil;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@""] || [manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@"0"] ) {
        
        return 45;
        
        
    }
    else
    {
        NSString *str=[NSString stringWithFormat:@"%@ : %@",arr_Number[indexPath.row],arr_DrugName[indexPath.row]];
        
            // NSString *str = [arr_sale_product_name objectAtIndex:indexPath.row];
        CGSize size = [str sizeWithFont:[UIFont systemFontOfSize:14 weight:UIFontWeightMedium] constrainedToSize:CGSizeMake(165, 500) lineBreakMode:NSLineBreakByWordWrapping];
            // NSLog(@"%f",size.height);
        return size.height + 40;
        
    }
    
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *SimpletableIndentifier=@"DetailedTableCell";
    DetailedTableCell *cell = [table_Detaill dequeueReusableCellWithIdentifier:SimpletableIndentifier];
    if (cell == nil) {
        cell = [[DetailedTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DetailedTableCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
            //  UIView *bgColorView = [[UIView alloc] init];
            //  bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
            // [cell setSelectedBackgroundView:bgColorView];
            //cell = [nib objectAtIndex:0];
    }
    NSString *str;
    if ([manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@""] || [manage.arr_storeInfoList[@"DeliveryAppDisplayDrugName"] isEqualToString:@"0"] ) {
        str=[NSString stringWithFormat:@"%@",arr_Number[indexPath.row]];
    }
    else
    {
        str=[NSString stringWithFormat:@"%@ : %@",arr_Number[indexPath.row],arr_DrugName[indexPath.row]];
    }
    
    cell.lab_Number.text=str;
    cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",[arr_Cost[indexPath.row]floatValue]];
    cell.lab_Qty.text=[NSString stringWithFormat:@"%d",[arr_Qty[indexPath.row]intValue]];
    
    
    
        //NSLog(@"%@",arr_Date[indexPath.row]);
    
    
    NSDate *datee=[Formate_DateMonthYear_Service dateFromString:arr_Date[indexPath.row]];
    NSString *str_Date=[Formate_DateMonthYear stringFromDate:datee];
    
    if (str_Date == nil)
    {
        cell.lab_Date.text=@"";
        
    }
    else
    {
        cell.lab_Date.text=[NSString stringWithFormat:@"%@",str_Date];
        
    }
    
    return cell;
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
