//
//  Mapannotation.h
//  
//
//  Created by Barani Elangovan on 10/6/16.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
@interface Mapannotation : NSObject
@property(strong, nonatomic) NSString *title;

@property(readwrite, nonatomic) CLLocationCoordinate2D coordinate;

//-(id) initWithTitle:(NSString *) title andCoordinate:(CLLocationCoordinate2D) coordinate2d;
-(id) initWithTitle:(NSString *) title andCoordinate:(CLLocationCoordinate2D) coordinate2d;

@end
