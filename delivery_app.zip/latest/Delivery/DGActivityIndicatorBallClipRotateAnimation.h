//
//  DGActivityIndicatorBallClipRotateAnimation.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import "DGActivityIndicatorAnimationProtocol.h"

@interface DGActivityIndicatorBallClipRotateAnimation : NSObject <DGActivityIndicatorAnimationProtocol>

@end
