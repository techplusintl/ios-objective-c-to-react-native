//
//  OnlineListCell.h
//  Delivery
//
//  Created by Barani Elangovan on 5/3/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OnlineListCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lab_ID;
@property(strong,nonatomic)IBOutlet UILabel *lab_Count;
@property(strong,nonatomic)IBOutlet UILabel *lab_Cost;
@property(strong,nonatomic)IBOutlet UILabel *lab_Address;
@property(strong,nonatomic)IBOutlet UILabel *lab_Dispacher_Date;

@property(strong,nonatomic)IBOutlet UIScrollView *scrollCell;
@property(strong,nonatomic)IBOutlet UIView *view_Scroll;
@property(strong,nonatomic)IBOutlet UIButton *btn_download;
@property(strong,nonatomic)IBOutlet UIView *view_Download;

@property(strong,nonatomic)IBOutlet UIImageView *image_Tick;

@property(strong,nonatomic)IBOutlet UIView *view_preference;
@property(strong,nonatomic)IBOutlet UILabel *labl_preference_num;
@property(strong,nonatomic)IBOutlet UILabel *labl_driver_name;
@property(strong,nonatomic)IBOutlet UIButton *btn_driverlist;
@property(strong,nonatomic)IBOutlet UIView *view_driver;


@end
