//
//  OnlineCheck.h
//  Delivery
//
//  Created by Barani Elangovan on 5/19/17.
//  Copyright © 2017 Suresh Elumalai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OnlineCheck : NSObject

@end
