    //
    //  BarCodeScaner.m
    //  Delivery
    //
    //  Created by Barani Elangovan on 5/25/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "BarCodeScaner.h"
#import "DGActivityIndicatorView.h"

@interface BarCodeScaner ()

{
    NSString *str_ScanCount;
    
    NSString *str_Scan;
    NSString *str_Flash;
    NSString *str_StoreID;
    NSMutableArray *arr_DeliveryListBar;
    
    DGActivityIndicatorView *activityIndicatorView;
    
}
@property(strong,nonatomic)NSString *str_Code;
@property(strong,nonatomic)NSString *str_Code_Copy;


@end

@implementation BarCodeScaner

@synthesize scanner,previewView,btn_Scann,lab_Code,image_Flash,str_Code,str_Code_Copy,view_activity,str_Type;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage=[singleton share];
    
    view_activity.hidden=YES;
    
    str_StoreID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];
    
    arr_DeliveryListBar=[[NSMutableArray alloc]init];
    
    str_Scan=@"No";
    str_Flash=@"No";
    
    [MTBBarcodeScanner requestCameraPermissionWithSuccess:^(BOOL success) {
        if (success) {
            
            btn_Scann.hidden=NO;
            [self startScanning];
            
        } else {
            btn_Scann.hidden=YES;
            [self displayPermissionMissingAlert];
        }
    }];
    
    
    btn_Scann. layer.cornerRadius =3;
    btn_Scann. layer.masksToBounds =YES;
    
        // Do any additional setup after loading the view.
}

#pragma mark - Back Button

-(IBAction)btn_Back:(id)sender
{
    
    self.scanner.torchMode = MTBTorchModeOff;
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark - Barcode Scanner Functions

- (MTBBarcodeScanner *)scanner {
    if (!scanner) {
        scanner = [[MTBBarcodeScanner alloc] initWithPreviewView:previewView];
    }
    return scanner;
}

#pragma mark - Scanning




- (void)startScanning {
    
    
    /* [self.scanner startScanningWithResultBlock:^(NSArray *codes) {
     
     }];
     */
    [self.scanner startScanningWithResultBlock:^(NSArray *codes) {
        self.uniqueCodes = [[NSMutableArray alloc] init];
        
        if ([str_Scan isEqualToString:@"No"])
        {
            btn_Scann.hidden=NO;
            
        }
        else
        {
            btn_Scann.hidden=YES;
            
            for (AVMetadataMachineReadableCodeObject *code in codes) {
                if (code.stringValue && [self.uniqueCodes indexOfObject:code.stringValue] == NSNotFound) {
                    [self.uniqueCodes addObject:code.stringValue];
                    
                        // NSLog(@"Found unique code: %@", code.stringValue);
                    
                    
                    str_Code= code.stringValue;
                    str_Code_Copy=code.stringValue;
                    
                }
            }
            if (![str_Code isEqualToString:@""])
            {
                if ([str_ScanCount isEqualToString:@"One"])
                {
                    str_ScanCount=@"Two";
                    btn_Scann.hidden=NO;
                    str_Code=@"";
                    str_Scan=@"No";
                    lab_Code.text=str_Code_Copy;

                    
                    if ([str_Type isEqualToString:@"Rx"]) {
                        
                        [arr_DeliveryListBar removeAllObjects];
                        view_activity.hidden=NO;
                        [activityIndicatorView removeFromSuperview];
                        
                        
                            // [self.scanner stopScanning];
                        
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                            dispatch_async(dispatch_get_main_queue(), ^{
                                
                                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                                
                                CGFloat width = self.view.bounds.size.width;
                                CGFloat height = self.view.bounds.size.height;
                                
                                activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                                
                                [self.view_activity addSubview:activityIndicatorView];
                                [activityIndicatorView startAnimating];
                                
                            });
                            
                            NSString *str_urrl=[NSString stringWithFormat:@"RxbyNumber/%@/%@",str_StoreID,str_Code_Copy];
                            
                            NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
                            
                            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
                            
                            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                            NSError *err;
                            NSURLResponse *response;
                            
                            NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
                                //   NSLog(@"%@",responsedata);
                            
                            
                            if (responsedata)
                            {
                                
                                NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                                    //NSLog(@"%@",jsonArray);
                                
                                NSArray *arr_Content = jsonArray[@"RxbyNumberResult"];
                                
                                if (arr_Content.count==0)
                                {
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        
                                        self.view_activity.hidden=YES;
                                        [activityIndicatorView stopAnimating];
                                        activityIndicatorView.hidden=YES;
                                            // [self.scanner startScanning];
                                        
                                        AudioServicesPlaySystemSound(1315);
                                        
                                        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Item # is not found!" preferredStyle:UIAlertControllerStyleAlert];
                                        
                                        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                                        [alertController addAction:ok];
                                        
                                        [self presentViewController:alertController animated:YES completion:nil];
                                        
                                        
                                    });
                                }
                                else
                                {
                                    [arr_DeliveryListBar removeAllObjects];
                                    
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        
                                        for (NSDictionary *temp in arr_Content)
                                        {
                                            
                                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                                            
                                            [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                                            [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                                            [itemshowdetails setValue:temp[@"Mobile"] forKey:@"Mobile"];
                                            [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                                            [itemshowdetails setValue:temp[@"PatPay"] forKey:@"PatPay"];
                                            [itemshowdetails setValue:temp[@"Phone"] forKey:@"Phone"];
                                            [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                                            [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                                            [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                                            [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                                            [itemshowdetails setValue:temp[@"Street1"] forKey:@"Street1"];
                                            [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                                            [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                                            
                                            [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                                            [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                                            [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                                            [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];

                                            [arr_DeliveryListBar addObject:itemshowdetails];
                                        }
                                        
                                        manage.arr_searchVal=arr_DeliveryListBar;
                                        
                                        self.view_activity.hidden=YES;
                                        [activityIndicatorView stopAnimating];
                                        activityIndicatorView.hidden=YES;
                                        
                                        
                                        NSString *str_IDDD=[NSString stringWithFormat:@"#%@",str_Code_Copy];
                                        
                                        BOOL ConditionSig=[[DBManager getSharedInstance]saveDataRxNum:str_IDDD StoreID:str_StoreID];
                                        
                                        
                                            // BOOL ConditionSig=[[DBManager getSharedInstance]saveDataLogNum:str_Code_Copy];
                                        
                                        if (ConditionSig == NO) {
                                            
                                            AudioServicesPlaySystemSound(1315);
                                                // [self.scanner startScanning];
                                            
                                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                                  @"Data Already Exists" message:nil
                                                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                                            
                                            
                                            [alert show];
                                        }
                                        else if(ConditionSig==YES)
                                        {
                                            
                                            
                                                // 1104
                                                // 1054
                                                //  1000
                                                // 1053
                                            
                                                // 1004
                                            
                                                // 1315
                                            
                                            AudioServicesPlaySystemSound(1315);
                                                // [self.scanner startScanning];
                                            
                                            AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
                                            
                                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                                  @"Download Successfully" message:nil
                                                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                                            
                                            
                                            [alert show];
                                            
                                        }
                                        
                                        
                                        
                                        
                                        
                                        
                                    });
                                    
                                    
                                }
                            }
                            
                            else
                            {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    
                                    AudioServicesPlaySystemSound(1315);
                                    self.view_activity.hidden=YES;
                                    [activityIndicatorView stopAnimating];
                                    activityIndicatorView.hidden=YES;
                                        //[self.scanner startScanning];
                                    
                                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                                    
                                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                                    [alertController addAction:ok];
                                    
                                    [self presentViewController:alertController animated:YES completion:nil];
                                    
                                    
                                    
                                });
                            }
                        });
                    }
                    
                    else if ([str_Type isEqualToString:@"POS"])
                    {
                        NSString *str_pos=@"1";
                        NSString *returnData;
                        returnData=  [[DBManager getSharedInstance]saveBarCodeData:str_Code_Copy isPOS:str_pos StoreID:str_StoreID];
                        
                        if ([returnData isEqualToString:@"No"]) {
                            AudioServicesPlaySystemSound(1315);

                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                  @"POS ID is not found!" message:nil
                                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                            [alert show];
                        }
                        else if([returnData isEqualToString:@"Yes"])
                        {
                            AudioServicesPlaySystemSound(1315);

                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                  @"Download Successfully" message:nil delegate:nil cancelButtonTitle:
                                                  @"OK" otherButtonTitles:nil];
                            [alert show];
                            
                            
                            

                        }
                        else
                        {
                            AudioServicesPlaySystemSound(1315);

                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                  @"Data Already Exists" message:nil delegate:nil cancelButtonTitle:
                                                  @"OK" otherButtonTitles:nil];
                            [alert show];
                            
                            
                        }
                        
                        
                        
                    }
                    else
                    {
                        NSString *str_pos=@"0";

                        NSString *returnData;
                        returnData=  [[DBManager getSharedInstance]saveBarCodeData:str_Code_Copy isPOS:str_pos StoreID:str_StoreID];
                        
                        if ([returnData isEqualToString:@"No"]) {
                            AudioServicesPlaySystemSound(1315);

                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                  @"Delivery ID is not found!" message:nil
                                                                          delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                            [alert show];
                        }
                        else if([returnData isEqualToString:@"Yes"])
                        {
                            AudioServicesPlaySystemSound(1315);

                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                  @"Download Successfully" message:nil delegate:nil cancelButtonTitle:
                                                  @"OK" otherButtonTitles:nil];
                            [alert show];
                            
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    
                                    activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                                    
                                    //                        CGFloat width = self.view.bounds.size.width / 5.0f;
                                    //                        CGFloat height = self.view.bounds.size.height / 5.0f;
                                    //
                                    //                        activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/2)-25,(self.view.frame.size.height/2)-80, width, height);
                                    // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
                                    
                                    CGFloat width = self.view.bounds.size.width;
                                    CGFloat height = self.view.bounds.size.height;
                                    
                                    activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                                    
                                    [self.view_activity addSubview:activityIndicatorView];
                                    [activityIndicatorView startAnimating];
                                    
                                });

                            NSMutableArray *arr_val=[[NSMutableArray alloc]init];
                            [arr_val addObject:str_StoreID];
                            [arr_val addObject:str_Code_Copy];
                            [arr_val addObject:@"1"];
                            
                            NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"IsDownloaded" ,nil];
                            
                            
                            NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
                            
                            NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
                            
                            [newUserObject2 setObject:properties forKey:@"ObjDownloadedField"];
                            
                            
                            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
                            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                            NSString *str_service3=[NSString stringWithFormat:@"UpdateIsDownloadedFieldByID"];
                            str_service3=[manage.str_url stringByAppendingString:str_service3];
                            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
                            [request setHTTPMethod:@"POST"];
                            [request setValue:jsonString forHTTPHeaderField:@"json"];
                            [request setHTTPBody:jsonData];
                            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                            
                            NSError *error = nil;
                            NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                            if(data)
                            {
                                NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                
                                NSDictionary *tranID2=jsonArray3[@"UpdateIsDownloadedFieldByIDResult"];
                                
                                NSString *str_SigID=tranID2[@"TransID"];
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    
                                    self.view_activity.hidden=YES;
                                    [activityIndicatorView stopAnimating];
                                    activityIndicatorView.hidden=YES;
                                });
                            }
                              else
                              {
                                  dispatch_async(dispatch_get_main_queue(), ^{
                                      
                                      AudioServicesPlaySystemSound(1315);
                                      self.view_activity.hidden=YES;
                                      [activityIndicatorView stopAnimating];
                                      activityIndicatorView.hidden=YES;
                                      //[self.scanner startScanning];
                                      
                                      UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                                      
                                      UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                                      [alertController addAction:ok];
                                      
                                      [self presentViewController:alertController animated:YES completion:nil];
                                      
                                      
                                      
                                  });
                              }
                                

                                
                            });
                        }
                        else
                        {
                            AudioServicesPlaySystemSound(1315);

                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                                                  @"Data Already Exists" message:nil delegate:nil cancelButtonTitle:
                                                  @"OK" otherButtonTitles:nil];
                            [alert show];
                            
                            
                        }
                        
                        
                        
                    }
                }
                else
                {
                    
                }
                
            }
        }
        
    }];
    
}

#pragma mark - Alert Actions


- (void)displayPermissionMissingAlert {
    NSString *message = nil;
    if ([MTBBarcodeScanner scanningIsProhibited]) {
        message = @"This app does not have permission to use the camera.";
    } else if (![MTBBarcodeScanner cameraIsPresent]) {
        message = @"This device does not have a camera.";
    } else {
        message = @"An unknown error occurred.";
    }
    
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    
    [self presentViewController:alertController animated:YES completion:nil];
}


- (IBAction)btn_Scann:(id)sender
{
    
    str_Scan=@"Yes";
    str_ScanCount=@"One";
    
    btn_Scann.hidden=YES;
    
    
    /*  [MTBBarcodeScanner requestCameraPermissionWithSuccess:^(BOOL success) {
     if (success) {
     
     btn_Scann.hidden=NO;
     [self startScanning];
     
     } else {
     
     btn_Scann.hidden=YES;
     [self displayPermissionMissingAlert];
     
     }
     }];*/
        //  }
    
}

- (IBAction)switchCameraTapped:(id)sender {
    [self.scanner flipCamera];
}

- (IBAction)btn_Flash:(id)sender {
    
    if ([str_Flash isEqualToString:@"No"])
    {
        str_Flash=@"Yes";
        
        image_Flash.image=[UIImage imageNamed:@"Flash Off-64.png"];
        
        self.scanner.torchMode = MTBTorchModeOn;
        
    }
    else
    {
        image_Flash.image=[UIImage imageNamed:@"Flash On-64.png"];
        
        self.scanner.torchMode = MTBTorchModeOff;
        
        str_Flash=@"No";
    }
    
   }




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
