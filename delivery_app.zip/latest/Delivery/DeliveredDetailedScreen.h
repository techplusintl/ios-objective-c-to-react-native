//
//  DeliveredDetailedScreen.h
//  Delivery
//
//  Created by Barani Elangovan on 5/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailedTableCell.h"
#import "singleton.h"

#import "DeliveryLocation.h"
#import "Card_payment.h"

@interface DeliveredDetailedScreen : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    singleton *manage;
}
@property(strong,nonatomic)NSString *str_RxSearch;

@property(strong,nonatomic)IBOutlet UITableView *table_Detaill;

@property(strong,nonatomic)NSString *str_LogID;
@property(strong,nonatomic)NSString *str_addresss;

@property(strong,nonatomic)NSString *str_isMapView;


@property(strong,nonatomic)IBOutlet UILabel *lab_Address;
@property(strong,nonatomic)IBOutlet UILabel *lab_TCount;
@property(strong,nonatomic)IBOutlet UILabel *lab_SCount;
@property(strong,nonatomic)IBOutlet UILabel *lab_TCost;
@property(strong,nonatomic)IBOutlet UILabel *lab_SCost;
@property(strong,nonatomic)IBOutlet UILabel *lab_Name;
@property(strong,nonatomic)IBOutlet UILabel *lab_Description;
@property(strong,nonatomic)IBOutlet UILabel *lab_delivrydate;

@property (strong,nonatomic) IBOutlet UILabel *labl_araccount;

@end
