//
//  MSSCalendarHeaderModel.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MSSCalendarHeaderModel : NSObject
@property (nonatomic,copy)NSString *headerText;
@property (nonatomic,strong)NSArray *calendarItemArray;
@end

typedef NS_ENUM(NSInteger, MSSCalendarType)
{
    MSSCalendarTodayType = 0,
    MSSCalendarLastType,
    MSSCalendarNextType
};

@interface MSSCalendarModel : NSObject

@property (nonatomic,assign)NSInteger year;
@property (nonatomic,assign)NSInteger month;
@property (nonatomic,assign)NSInteger day;
@property (nonatomic,copy)NSString *chineseCalendar;
@property (nonatomic,copy)NSString *holiday;
@property (nonatomic,assign)MSSCalendarType type;
@property (nonatomic,assign)NSInteger dateInterval;
@property (nonatomic,assign)NSInteger week;

@end
