//
//  DeliveryOrderSearchDownloadCell.m
//  Delivery
//
//  Created by Barani Elangovan on 5/18/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "DeliveryOrderSearchDownloadCell.h"

@implementation DeliveryOrderSearchDownloadCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
