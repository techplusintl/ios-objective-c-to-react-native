//
//  CommanMethods.m
//  Inventory
//
//  Created by Barani Elangovan on 2/27/18.
//  Copyright © 2018 1mySOFT. All rights reserved.
//

#import "CommanMethods.h"

@implementation CommanMethods
{
    NSDateFormatter *Formate_Date;
    NSDateFormatter *Formate_ReturnDate;

}

- (NSString *)dateformate:(NSString*)inputdate {
    
    Formate_Date=[[NSDateFormatter alloc]init];
    [Formate_Date setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
    
    Formate_ReturnDate=[[NSDateFormatter alloc]init];
    [Formate_ReturnDate setDateFormat:@"MMM dd, yyyy"];
    
    NSDate *date_InputDate=[Formate_Date dateFromString:inputdate];
    NSString *str_InputDate=[Formate_ReturnDate stringFromDate:date_InputDate];

    if (str_InputDate.length==0) {
        str_InputDate=@"-";
    }
    
    return str_InputDate;
}

-(NSString *) nullHandler:(NSString*)inputVal
{
    NSString *str_OutData;

    if ([inputVal isEqual:[NSNull null]] || inputVal == nil || [inputVal isEqual:nil]) {
        str_OutData=@"";
    }
    else
    {
        str_OutData=inputVal;

    }
    return str_OutData;

}
-(NSData *) serviceVal:(NSString*)inputVal
{
NSMutableArray *arr_val=[[NSMutableArray alloc]init];

[arr_val removeAllObjects];

[arr_val addObject:inputVal];


NSArray *propertyNames =[NSArray arrayWithObjects:@"JsonString",nil];

NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];

NSData *jsonData = [NSJSONSerialization dataWithJSONObject:properties options:kNilOptions error:nil];
NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];

NSString *str_service=[NSString stringWithFormat:@"http://192.168.1.21/1myPOS_Mob/api/GenericAPI/CommonServicewithobject"];

    // str_service=[manage.str_url stringByAppendingString:str_service];
NSMutableURLRequest *request= [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service]];
[request setHTTPMethod:@"POST"];
[request setValue:jsonString forHTTPHeaderField:@"json"];
[request setHTTPBody:jsonData];
[request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
NSError *error = nil;
NSURLResponse *theResponse = [[NSURLResponse alloc]init];
NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];

    return responsedata;
}

@end
