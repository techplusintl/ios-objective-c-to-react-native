//
//  MSSCalendarCollectionViewCell.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MSSCircleLabel.h"

@interface MSSCalendarCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong)UIImageView *imageView;
@property (nonatomic,strong)MSSCircleLabel *dateLabel;
@property (nonatomic,strong)UILabel *subLabel;
@property (nonatomic,assign)BOOL isSelected;

@end
