//
//  StoreProfile.h
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "singleton.h"
#import <MessageUI/MessageUI.h>
#import <MapKit/MapKit.h>
#import "Mapannotation.h"
#import <CoreLocation/CoreLocation.h>
#import "DeliveryLocation.h"

@interface StoreProfile : UIViewController<MFMailComposeViewControllerDelegate,MKMapViewDelegate,CLLocationManagerDelegate>
{
    singleton *manage;
}



@property(weak,nonatomic)IBOutlet MKMapView *mapView;

@property(strong,nonatomic)IBOutlet UILabel *lab_PharmacyName1;

@property(strong,nonatomic)IBOutlet UILabel *lab_PharmacyName;
@property(strong,nonatomic)IBOutlet UILabel *lab_ContactName;
@property(strong,nonatomic)IBOutlet UILabel *lab_Street;
@property(strong,nonatomic)IBOutlet UILabel *lab_CityState;
@property(strong,nonatomic)IBOutlet UILabel *lab_Contry;
@property(strong,nonatomic)IBOutlet UILabel *lab_Time;

@property(strong,nonatomic)IBOutlet UIView *view_Phone;
@property(strong,nonatomic)IBOutlet UIView *view_Mail;
@property(strong,nonatomic)IBOutlet UIView *view_Fax;

@property(strong,nonatomic)IBOutlet UIView *view_WorkingHours;
@property(strong,nonatomic)IBOutlet UIView *view_Address;
@property(strong,nonatomic)IBOutlet UIScrollView *scroll_view;


@property(strong,nonatomic)IBOutlet UILabel *lab_phone;
@property(strong,nonatomic)IBOutlet UILabel *lab_mail;
@property(strong,nonatomic)IBOutlet UILabel *lab_fax;





@end
