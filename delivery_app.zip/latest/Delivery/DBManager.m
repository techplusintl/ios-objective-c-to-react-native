    //
    //  DBManager.m
    //  SQlite_demo
    //
    //  Created by Barani Elangovan on 10/03/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "DBManager.h"
static DBManager *sharedInstance = nil;
static sqlite3 *database = nil;
static sqlite3_stmt *statement = nil;


@implementation DBManager

@synthesize arrLocal,arr_LocalValues;

+(DBManager*)getSharedInstance{
    if (!sharedInstance) {
        sharedInstance = [[super allocWithZone:NULL]init];
        [sharedInstance createDB];
    }
    return sharedInstance;
}

-(BOOL)createDB{
    manage=[singleton share];
    NSString *docsDir;
    NSArray *dirPaths;
        // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
        // Build the path to the database file
    databasePath = [[NSString alloc] initWithString:
                    [docsDir stringByAppendingPathComponent: @"offlineStoreDBProduct.db"]];
    BOOL isSuccess = YES;
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt ="create table if not exists deliverylist (ShipLogID text, RxNumber text,RxID text, DeliveredDate text, Dispatcher text, DrugName text, IsPOS text, PatientCity text, PatientMobile text, PatientName text, PatientState text, PatientStreet text, Qty text, Patientzip text, Patpay text, PickupDate text, RxDate text, ShipNotes text, PickupDateCondition DATETIME, StoreID text, PatientCreditCardNo text,PatientCCExpMMYY text, PatientCCCode text,PatientEmail text,ARAddress text,ARBalance text,Acct text,Ar text,Bill text,State text,City text,Phone1 text, Zip text, ArChargeID text, AlreadyPaid text, PatientID text, HipaaSigID text, HipaaSig text,RxARItemID text,ShippingDetailID text)";
            
            
            if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                != SQLITE_OK)
            {
                isSuccess = NO;
                NSLog(@"Failed to create table");
            }
            sqlite3_close(database);
                //  return  isSuccess;
        }
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt ="create table if not exists localDelivered (Name text,Relation text,Signature text,XmlTrans text,IsPOS text,StoreID text,UserName text, Password text,CounsellingType text,POSID text, RxID text, DeliveryComments text , DeletedRxList text)";
            
            if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                != SQLITE_OK)
            {
                isSuccess = NO;
                NSLog(@"Failed to create table");
            }
            sqlite3_close(database);
                // return  isSuccess;
        }
        
    }
    
    else
    {
       /*
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"GPStrackTable"]length]==0)
        {
            
        }
        else
        {
            
            //
             
              NSArray *propertyNamesGPS =[NSArray arrayWithObjects:@"StoreID",@"UserID",@"DeviceID",@"CommonID",@"CustomerName",@"CustomerAddress",@"CustomerRelationType",@"DriverName",@"AmountPaid",@"Latitude",@"Longitude",@"TravelledDistance",@"ActualDistance",@"PaymentType",@"PatientID",@"PatientName",@"PatientPhone",@"StartLocationLatitude",@"StartLocationLongitude",nil];
             
        
            
            
            const char *dbpath = [databasePath UTF8String];
            if (sqlite3_open(dbpath, &database) == SQLITE_OK)
            {
                char *errMsg;
                const char *sql_stmt ="create table if not exists GPStrackTable (StoreID text, UserID text,DeviceID text, CommonID text, CustomerName text, CustomerAddress text, CustomerRelationType text, DriverName text, AmountPaid text, Latitude text, Longitude text, TravelledDistance text, ActualDistance text, PaymentType text, PatientID text, PatientName text, PatientPhone text, StartLocationLatitude text, StartLocationLongitude text, Comments text)";
                
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                sqlite3_close(database);
                    //  return  isSuccess;
            }
            
            
            
            
            [[NSUserDefaults standardUserDefaults]setObject:contentData forKey:@"GPStrackTable"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        */
        
        BOOL columnExists = NO;
        
       // sqlite3_stmt *selectStmt;
        char *errMsg;
        const char *sqlStatement = "select PatientEmail from deliverylist";
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement, NULL, NULL, &errMsg)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists = YES;
                
            }
        }
        
        
        if (columnExists==NO) {
            
            if (sqlite3_open(dbpath, &database) == SQLITE_OK)
            {
                char *errMsg;
              //  const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table deliverylist add column PatientCreditCardNo text";
                const char *sql_stmt1 ="alter table deliverylist add column PatientCCExpMMYY text";
                const char *sql_stmt2 ="alter table deliverylist add column PatientCCCode text";
                const char *sql_stmt3 ="alter table deliverylist add column PatientEmail text";
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt1, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                if (sqlite3_exec(database, sql_stmt2, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt3, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                sqlite3_close(database);
                    //  return  isSuccess;
            }
        }
        
        BOOL columnExists1 = NO;
        
       // sqlite3_stmt *selectStmt1;
        char *errMsg1;
        const char *sqlStatement1 = "select ARAddress from deliverylist";
        const char *dbpath1 = [databasePath UTF8String];
        if (sqlite3_open(dbpath1, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement1, NULL, NULL, &errMsg1)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists1 = YES;
                
            }
        }
        if (columnExists1==NO) {
            
            if (sqlite3_open(dbpath1, &database) == SQLITE_OK)
            {
                char *errMsg1;
               // const char *dbpath1 = [databasePath UTF8String];
                const char *sql_stmt ="alter table deliverylist add column ARAddress text";
                const char *sql_stmt1 ="alter table deliverylist add column ARBalance text";
                const char *sql_stmt2 ="alter table deliverylist add column Acct text";
                const char *sql_stmt3 ="alter table deliverylist add column Ar text";
                const char *sql_stmt4 ="alter table deliverylist add column Bill text";
                const char *sql_stmt5 ="alter table deliverylist add column State text";
                const char *sql_stmt6 ="alter table deliverylist add column City text";
                const char *sql_stmt7 ="alter table deliverylist add column Phone1 text";
                const char *sql_stmt8 ="alter table deliverylist add column Zip text";
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt1, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                if (sqlite3_exec(database, sql_stmt2, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt3, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                if (sqlite3_exec(database, sql_stmt4, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                if (sqlite3_exec(database, sql_stmt5, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                if (sqlite3_exec(database, sql_stmt6, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                if (sqlite3_exec(database, sql_stmt7, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                if (sqlite3_exec(database, sql_stmt8, NULL, NULL, &errMsg1)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                
                sqlite3_close(database);
                    //  return  isSuccess;
            }
            
            
            
        }
        
            /////////// Local Counseling Alter //////////
        
        
        BOOL columnExists2 = NO;
        
       // sqlite3_stmt *selectStmt2;
        char *errMsg2;
        const char *sqlStatement2 = "select RxID from localDelivered";
        const char *dbpath2 = [databasePath UTF8String];
        if (sqlite3_open(dbpath2, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement2, NULL, NULL, &errMsg2)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists2 = YES;
                
            }
        }
        
        
        if (columnExists2==NO) {
            
            if (sqlite3_open(dbpath2, &database) == SQLITE_OK)
            {
                char *errMsg2;
              //  const char *dbpath2 = [databasePath UTF8String];
                const char *sql_stmt ="alter table localDelivered add column CounsellingType text";
                const char *sql_stmt1 ="alter table localDelivered add column POSID text";
                const char *sql_stmt2 ="alter table localDelivered add column RxID text";
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg2)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                if (sqlite3_exec(database, sql_stmt1, NULL, NULL, &errMsg2)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                if (sqlite3_exec(database, sql_stmt2, NULL, NULL, &errMsg2)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                
                
                sqlite3_close(database);
                    //  return  isSuccess;
            }
        }
        
        
            //////////////////////    Patient ID ///////////////
        
        
        BOOL columnExists10 = NO;
        
      //  sqlite3_stmt *selectStmt10;
        char *errMsg10;
        const char *sqlStatement10 = "select ArChargeID from deliverylist";
        const char *dbpath10 = [databasePath UTF8String];
        if (sqlite3_open(dbpath10, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement10, NULL, NULL, &errMsg10)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists10 = YES;
                
            }
        }
        
        
        if (columnExists10==NO) {
            
            if (sqlite3_open(dbpath10, &database) == SQLITE_OK)
            {
                char *errMsg;
             //   const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table deliverylist add column ArChargeID text";
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                sqlite3_close(database);
            }
        }
        
            //////////////////////    Delivery Commands ///////////////
        
        
        BOOL columnExists11 = NO;
        
      //  sqlite3_stmt *selectStmt11;
        char *errMsg11;
        const char *sqlStatement11 = "select DeliveryComments from localDelivered";
        const char *dbpath11 = [databasePath UTF8String];
        if (sqlite3_open(dbpath11, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement11, NULL, NULL, &errMsg11)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists11 = YES;
                
            }
        }
        
        
        if (columnExists11==NO) {
            
            if (sqlite3_open(dbpath11, &database) == SQLITE_OK)
            {
                char *errMsg;
               // const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table localDelivered add column DeliveryComments text";
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                sqlite3_close(database);
            }
        }
        
        //////////////////////    Deleted Rx List ///////////////
        
        
        BOOL columnExists15 = NO;
        
        //  sqlite3_stmt *selectStmt11;
        char *errMsg15;
        const char *sqlStatement15 = "select DeletedRxList from localDelivered";
        const char *dbpath15 = [databasePath UTF8String];
        if (sqlite3_open(dbpath15, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement15, NULL, NULL, &errMsg15)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists15 = YES;
                
            }
        }
        
        
        if (columnExists15==NO) {
            
            if (sqlite3_open(dbpath15, &database) == SQLITE_OK)
            {
                char *errMsg;
                // const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table localDelivered add column DeletedRxList text";
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                sqlite3_close(database);
            }
        }
        
            //////////////////////    Already Paid Amount ///////////////
        
        
        BOOL columnExists12 = NO;
        
      //  sqlite3_stmt *selectStmt12;
        char *errMsg12;
        const char *sqlStatement12 = "select HipaaSig from deliverylist";
        const char *dbpath12 = [databasePath UTF8String];
        if (sqlite3_open(dbpath12, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement12, NULL, NULL, &errMsg12)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists12 = YES;
                
            }
        }
        
        
        if (columnExists12==NO) {
            
            if (sqlite3_open(dbpath12, &database) == SQLITE_OK)
            {
                char *errMsg;
           //     const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table deliverylist add column AlreadyPaid text";
                const char *sql_stmt1 ="alter table deliverylist add column PatientID text";
                const char *sql_stmt2 ="alter table deliverylist add column HipaaSigID text";
                const char *sql_stmt3 ="alter table deliverylist add column HipaaSig text";
                
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt1, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt2, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                if (sqlite3_exec(database, sql_stmt3, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                sqlite3_close(database);
            }
        }
        
            //////////////////////    AR Item ID ///////////////
        
        
        BOOL columnExists13 = NO;
        
            //  sqlite3_stmt *selectStmt12;
        char *errMsg13;
        const char *sqlStatement13 = "select RxARItemID from deliverylist";
        const char *dbpath13 = [databasePath UTF8String];
        if (sqlite3_open(dbpath13, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement13, NULL, NULL, &errMsg13)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists13 = YES;
                
            }
        }
        
        
        if (columnExists13==NO) {
            
            if (sqlite3_open(dbpath13, &database) == SQLITE_OK)
            {
                char *errMsg;
                    //     const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table deliverylist add column RxARItemID text";
                //const char *sql_stmt1 ="alter table localDelivered add column ARitemID text";

                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
               /* if (sqlite3_exec(database, sql_stmt1, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }*/
                sqlite3_close(database);
            }
        }
        
        
        
        //////////////////////    ShippingDetail ID ///////////////
        
        
        BOOL columnExists14 = NO;
        
        //  sqlite3_stmt *selectStmt12;
        char *errMsg14;
        const char *sqlStatement14 = "select ShippingDetailID from deliverylist";
        const char *dbpath14 = [databasePath UTF8String];
        if (sqlite3_open(dbpath14, &database) == SQLITE_OK)
        {
            if (sqlite3_exec(database, sqlStatement14, NULL, NULL, &errMsg14)
                != SQLITE_OK)
            {
                NSLog(@"no");
            }
            else
            {
                columnExists14 = YES;
                
            }
        }
        
        
        if (columnExists14==NO) {
            
            if (sqlite3_open(dbpath14, &database) == SQLITE_OK)
            {
                char *errMsg;
                //     const char *dbpath = [databasePath UTF8String];
                const char *sql_stmt ="alter table deliverylist add column ShippingDetailID text";
                //const char *sql_stmt1 ="alter table localDelivered add column ARitemID text";
                
                
                if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                    != SQLITE_OK)
                {
                    isSuccess = NO;
                    NSLog(@"Failed to create table");
                }
                /* if (sqlite3_exec(database, sql_stmt1, NULL, NULL, &errMsg)
                 != SQLITE_OK)
                 {
                 isSuccess = NO;
                 NSLog(@"Failed to create table");
                 }*/
                sqlite3_close(database);
            }
        }
        
        
        
    }
    return isSuccess;
}

-(BOOL) saveData:(NSString*)Logid StoreID:(NSString*)StoreID
{
    NSDateFormatter *Formate_DateMonthYearTime1;
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where ShipLogID=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
                // NSLog(@"%@",)
            
            for (int i=0;i<manage.arr_OnlineArray.count; i++)
            {
                if ([Logid isEqualToString:[NSString stringWithFormat:@"%d",[manage.arr_OnlineArray[i][@"ShipLogID"]intValue]]])
                {
                    NSString *ShipLogID =manage.arr_OnlineArray[i][@"ShipLogID"];
                    NSString *RxNumber =manage.arr_OnlineArray[i][@"RxNumber"];
                    
                    NSString *RxID =manage.arr_OnlineArray[i][@"RxID"];
                    
                    
                    NSString *DeliveredDate =manage.arr_OnlineArray[i][@"DeliveredDate"];
                    NSString *Dispatcher =manage.arr_OnlineArray[i][@"DriverName"];
                    NSString *DrugName =manage.arr_OnlineArray[i][@"DrugName"];
                    NSString *IsPOS =manage.arr_OnlineArray[i][@"IsPOS"];
                    NSString *PatientCity =manage.arr_OnlineArray[i][@"PatientCity"];
                    NSString *PatientMobile =manage.arr_OnlineArray[i][@"PatientMobile"];
                    NSString *PatientName =manage.arr_OnlineArray[i][@"PatientName"];
                    NSString *PatientState =manage.arr_OnlineArray[i][@"PatientState"];
                    NSString *PatientStreet =manage.arr_OnlineArray[i][@"PatientStreet"];
                    NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_OnlineArray[i][@"Qty"]floatValue]];
                    NSString *Patientzip =manage.arr_OnlineArray[i][@"Patientzip"];
                    NSString *Patpay =manage.arr_OnlineArray[i][@"Patpay"];
                    NSDate *date12;
                    
                    NSString *str_DateCondition=[Formate_DateMonthYearTime1 stringFromDate:[NSDate date]];
                    date12=[Formate_DateMonthYearTime1 dateFromString:str_DateCondition];
                    
                    NSString *PickupDate;
                    if ([IsPOS isEqualToString:@"1"])
                    {
                        PickupDate =manage.arr_OnlineArray[i][@"RxDate"];
                    }
                    else
                    {
                        PickupDate =manage.arr_OnlineArray[i][@"PickupDate"];
                    }
                    
                    
                    NSString *RxDate =manage.arr_OnlineArray[i][@"RxDate"];
                    NSString *ShipNotes =manage.arr_OnlineArray[i][@"ShipNotes"];
                    
                    NSString *StoreIDD =manage.arr_storeInfoList[@"StoreID"];
                    NSString *CreditCardno =manage.arr_OnlineArray[i][@"PatientCreditCardNo"];
                    NSString *Expdate =manage.arr_OnlineArray[i][@"PatientCCExpMMYY"];
                    NSString *CCcode =manage.arr_OnlineArray[i][@"PatientCCCode"];
                    NSString *patientMail =manage.arr_OnlineArray[i][@"PatientEmail"];
                    
                    
                    NSString *ARAddress =manage.arr_OnlineArray[i][@"ARAddress"];
                    NSString *ARBalance =manage.arr_OnlineArray[i][@"ARBalance"];
                    NSString *Acct =manage.arr_OnlineArray[i][@"Acct"];
                    NSString *Ar =manage.arr_OnlineArray[i][@"Ar"];
                    NSString *Bill =manage.arr_OnlineArray[i][@"Bill"];
                    NSString *State =manage.arr_OnlineArray[i][@"State"];
                    NSString *City =manage.arr_OnlineArray[i][@"City"];
                    NSString *Phone1 =manage.arr_OnlineArray[i][@"Phone1"];
                    NSString *Zip =manage.arr_OnlineArray[i][@"Zip"];
                    
                        // [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
                    
                    NSString *ArChargeID=manage.arr_OnlineArray[i][@"ArChargeID"];
                    
                  //  [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];

                    
                    NSString *PaidAmount=manage.arr_OnlineArray[i][@"BalanceAmt"];
                    NSString *PatientID=manage.arr_OnlineArray[i][@"PatientID"];
                    NSString *HippaSigID=manage.arr_OnlineArray[i][@"HipaaSigID"];
                    NSString *HippaSig=manage.arr_OnlineArray[i][@"HipaaSig"];
                    NSString *RxARItemID=manage.arr_OnlineArray[i][@"RxARItemID"];
                    NSString *ShippingDetailID=manage.arr_OnlineArray[i][@"ShippingDetailID"];

                    
                    
                    NSString *insertSQL = [NSString stringWithFormat:@"insert into deliverylist (ShipLogID, RxNumber, RxID, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,PickupDateCondition,StoreID,PatientCreditCardNo,PatientCCExpMMYY,PatientCCCode,PatientEmail,ARAddress,ARBalance,Acct,Ar,Bill,State,City,Phone1,Zip,ArChargeID,AlreadyPaid,PatientID,HipaaSigID,HipaaSig,RxARItemID,ShippingDetailID) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",ShipLogID,RxNumber,RxID, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes,date12,StoreIDD,CreditCardno,Expdate,CCcode,patientMail,ARAddress,ARBalance,Acct,Ar,Bill,State,City,Phone1,Zip,ArChargeID,PaidAmount,PatientID,HippaSigID,HippaSig,RxARItemID,ShippingDetailID];
                    
                    const char *insert_stmt = [insertSQL UTF8String];
                    sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
                    
                    if (sqlite3_step(statement) == SQLITE_DONE)
                    {
                        if (i==(manage.arr_OnlineArray.count)-1)
                        {
                            return YES;
                        }
                    }
                    else
                    {
                    }
                }
                else
                {
                    if (i==(manage.arr_OnlineArray.count)-1)
                    {
                        return YES;
                    }
                }
            }
            sqlite3_reset(statement);
        }
    }
    return NO;
}

/*-(NSString *) saveBarCodeData:(NSString*)Logid
 {
 
 NSString *str_Conn=@"No";
 
 NSString *RetunVal;
 
 NSDateFormatter *Formate_DateMonthYearTime1;
 Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
 [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
 NSDateFormatter *Formate_DateMonthYear_Service;
 Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
 [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
 
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where ShipLogID=\"%@\"",Logid];
 const char *query_stmt = [querySQL UTF8String];
 if (sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
 {
 RetunVal=@"Exists";
 sqlite3_reset(statement);
 return RetunVal;
 }
 else
 {
 NSLog(@"%lu",(unsigned long)manage.arr_OnlineArray.count);
 NSLog(@"%@",manage.arr_OnlineArray);
 
 if (manage.arr_OnlineArray.count !=0)
 {
 
 NSLog(@"%lu",(unsigned long)manage.arr_OnlineArray.count);
 NSLog(@"%@",manage.arr_OnlineArray);
 
 for (int i=0;i<manage.arr_OnlineArray.count; i++)
 {
 if ([Logid isEqualToString:[NSString stringWithFormat:@"%d",[manage.arr_OnlineArray[i][@"ShipLogID"]intValue]]])
 {
 
 str_Conn=@"Yes";
 
 NSString *ShipLogID =manage.arr_OnlineArray[i][@"ShipLogID"];
 NSString *RxNumber =manage.arr_OnlineArray[i][@"RxNumber"];
 
 NSString *RxID =manage.arr_OnlineArray[i][@"RxID"];
 
 
 NSString *DeliveredDate =manage.arr_OnlineArray[i][@"DeliveredDate"];
 NSString *Dispatcher =manage.arr_OnlineArray[i][@"Dispatcher"];
 NSString *DrugName =manage.arr_OnlineArray[i][@"DrugName"];
 NSString *IsPOS =manage.arr_OnlineArray[i][@"IsPOS"];
 NSString *PatientCity =manage.arr_OnlineArray[i][@"PatientCity"];
 NSString *PatientMobile =manage.arr_OnlineArray[i][@"PatientMobile"];
 NSString *PatientName =manage.arr_OnlineArray[i][@"PatientName"];
 NSString *PatientState =manage.arr_OnlineArray[i][@"PatientState"];
 NSString *PatientStreet =manage.arr_OnlineArray[i][@"PatientStreet"];
 NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_OnlineArray[i][@"Qty"]floatValue]];
 NSString *Patientzip =manage.arr_OnlineArray[i][@"Patientzip"];
 NSString *Patpay =manage.arr_OnlineArray[i][@"Patpay"];
 
 NSDate *date12;
 
 NSString *str_DateCondition=[Formate_DateMonthYearTime1 stringFromDate:[NSDate date]];
 date12=[Formate_DateMonthYearTime1 dateFromString:str_DateCondition];
 
 NSString *PickupDate;
 if ([IsPOS isEqualToString:@"1"])
 {
 PickupDate =manage.arr_OnlineArray[i][@"RxDate"];
 }
 else
 {
 PickupDate =manage.arr_OnlineArray[i][@"PickupDate"];
 }
 
 
 NSString *RxDate =manage.arr_OnlineArray[i][@"RxDate"];
 NSString *ShipNotes =manage.arr_OnlineArray[i][@"ShipNotes"];
 
 NSString *insertSQL = [NSString stringWithFormat:@"insert into deliverylist (ShipLogID, RxNumber, RxID, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,PickupDateCondition) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\",\"%@\",\"%@\")",ShipLogID,RxNumber,RxID, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes,date12];
 const char *insert_stmt = [insertSQL UTF8String];
 sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
 
 if (sqlite3_step(statement) == SQLITE_DONE)
 {
 if (i==(manage.arr_OnlineArray.count)-1)
 {
 RetunVal=@"Yes";
 sqlite3_reset(statement);
 
 return RetunVal;
 }
 }
 else
 {
 }
 }
 else
 {
 if (i==(manage.arr_OnlineArray.count)-1)
 {
 if ([str_Conn isEqualToString:@"Yes"])
 {
 RetunVal=@"Yes";
 sqlite3_reset(statement);
 
 return RetunVal;
 
 }
 else
 {
 RetunVal=@"No";
 sqlite3_reset(statement);
 
 return RetunVal;
 
 }
 }
 }
 }
 }
 else
 {
 RetunVal=@"No";
 sqlite3_reset(statement);
 
 return RetunVal;
 
 }
 sqlite3_reset(statement);
 }
 }
 return @"No";
 }
 */
-(NSString *) saveBarCodeData:(NSString*)Logid isPOS:(NSString*)isPOS StoreID:(NSString*)StoreID
{
    
    NSString *str_Conn=@"No";
    
    NSString *RetunVal;
    
    NSDateFormatter *Formate_DateMonthYearTime1;
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where ShipLogID=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            RetunVal=@"Exists";
            sqlite3_reset(statement);
            return RetunVal;
        }
        else
        {
            NSLog(@"%lu",(unsigned long)manage.arr_OnlineArray.count);
            NSLog(@"%@",manage.arr_OnlineArray);
            
            if (manage.arr_OnlineArray.count !=0)
            {
                
                NSLog(@"%lu",(unsigned long)manage.arr_OnlineArray.count);
                NSLog(@"%@",manage.arr_OnlineArray);
                
                for (int i=0;i<manage.arr_OnlineArray.count; i++)
                {
                    if ([Logid isEqualToString:[NSString stringWithFormat:@"%d",[manage.arr_OnlineArray[i][@"ShipLogID"]intValue]]])
                    {
                        if ([isPOS isEqualToString:[NSString stringWithFormat:@"%d",[manage.arr_OnlineArray[i][@"IsPOS"]intValue]]])
                        {
                            
                            str_Conn=@"Yes";
                            
                            NSString *ShipLogID =manage.arr_OnlineArray[i][@"ShipLogID"];
                            NSString *RxNumber =manage.arr_OnlineArray[i][@"RxNumber"];
                            
                            NSString *RxID =manage.arr_OnlineArray[i][@"RxID"];
                            
                            
                            NSString *DeliveredDate =manage.arr_OnlineArray[i][@"DeliveredDate"];
                            NSString *Dispatcher =manage.arr_OnlineArray[i][@"DriverName"];
                            NSString *DrugName =manage.arr_OnlineArray[i][@"DrugName"];
                            NSString *IsPOS =manage.arr_OnlineArray[i][@"IsPOS"];
                            NSString *PatientCity =manage.arr_OnlineArray[i][@"PatientCity"];
                            NSString *PatientMobile =manage.arr_OnlineArray[i][@"PatientMobile"];
                            NSString *PatientName =manage.arr_OnlineArray[i][@"PatientName"];
                            NSString *PatientState =manage.arr_OnlineArray[i][@"PatientState"];
                            NSString *PatientStreet =manage.arr_OnlineArray[i][@"PatientStreet"];
                            NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_OnlineArray[i][@"Qty"]floatValue]];
                            NSString *Patientzip =manage.arr_OnlineArray[i][@"Patientzip"];
                            NSString *Patpay =manage.arr_OnlineArray[i][@"Patpay"];
                            
                            NSDate *date12;
                            
                            NSString *str_DateCondition=[Formate_DateMonthYearTime1 stringFromDate:[NSDate date]];
                            date12=[Formate_DateMonthYearTime1 dateFromString:str_DateCondition];
                            
                            NSString *PickupDate;
                            if ([IsPOS isEqualToString:@"1"])
                            {
                                PickupDate =manage.arr_OnlineArray[i][@"RxDate"];
                            }
                            else
                            {
                                PickupDate =manage.arr_OnlineArray[i][@"PickupDate"];
                            }
                            
                            
                            NSString *RxDate =manage.arr_OnlineArray[i][@"RxDate"];
                            NSString *ShipNotes =manage.arr_OnlineArray[i][@"ShipNotes"];
                            NSString *StoreIDD =manage.arr_storeInfoList[@"StoreID"];
                            NSString *CreditCardno =manage.arr_OnlineArray[i][@"PatientCreditCardNo"];
                            NSString *Expdate =manage.arr_OnlineArray[i][@"PatientCCExpMMYY"];
                            NSString *CCcode =manage.arr_OnlineArray[i][@"PatientCCCode"];
                            
                            NSString *PatientEmail =manage.arr_OnlineArray[i][@"PatientEmail"];
                            
                            
                            NSString *ARAddress =manage.arr_OnlineArray[i][@"ARAddress"];
                            NSString *ARBalance =manage.arr_OnlineArray[i][@"ARBalance"];
                            NSString *Acct =manage.arr_OnlineArray[i][@"Acct"];
                            NSString *Ar =manage.arr_OnlineArray[i][@"Ar"];
                            NSString *Bill =manage.arr_OnlineArray[i][@"Bill"];
                            NSString *State =manage.arr_OnlineArray[i][@"State"];
                            NSString *City =manage.arr_OnlineArray[i][@"City"];
                            NSString *Phone1 =manage.arr_OnlineArray[i][@"Phone1"];
                            NSString *Zip =manage.arr_OnlineArray[i][@"Zip"];
                            
                            NSString *ArChargeID =manage.arr_OnlineArray[i][@"ArChargeID"];
                            
                            NSString *PaidAmount=manage.arr_OnlineArray[i][@"BalanceAmt"];
                            NSString *PatientID=manage.arr_OnlineArray[i][@"PatientID"];
                            NSString *HippaSigID=manage.arr_OnlineArray[i][@"HipaaSigID"];
                            
                            NSString *HippaSig=manage.arr_OnlineArray[i][@"HipaaSig"];
                            NSString *RxARItemID=manage.arr_OnlineArray[i][@"RxARItemID"];

                            
                            
                            
                            /*    [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 33)] forKey:@"AlreadyPaid"];
                             [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 34)] forKey:@"PatientID"];
                             [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 35)] forKey:@"HipaaSigID"];
                             */
                            NSString *insertSQL = [NSString stringWithFormat:@"insert into deliverylist (ShipLogID, RxNumber, RxID, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,PickupDateCondition,StoreID,PatientCreditCardNo,PatientCCExpMMYY,PatientCCCode,PatientEmail,ARAddress,ARBalance,Acct,Ar,Bill,State,City,Phone1,Zip,ArChargeID,AlreadyPaid,PatientID,HipaaSigID,HipaaSig,RxARItemID) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",ShipLogID,RxNumber,RxID, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes,date12,StoreIDD,CreditCardno,Expdate,CCcode,PatientEmail,ARAddress,ARBalance,Acct,Ar,Bill,State,City,Phone1,Zip,ArChargeID,PaidAmount,PatientID,HippaSigID,HippaSig,RxARItemID];
                            const char *insert_stmt = [insertSQL UTF8String];
                            sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
                            
                            if (sqlite3_step(statement) == SQLITE_DONE)
                            {
                                if (i==(manage.arr_OnlineArray.count)-1)
                                {
                                    RetunVal=@"Yes";
                                    sqlite3_reset(statement);
                                    
                                    return RetunVal;
                                }
                            }
                            else
                            {
                            }
                        }
                        else
                        {
                            i=manage.arr_OnlineArray.count;
                            
                            sqlite3_reset(statement);
                            RetunVal=@"No";
                            
                        }
                    }
                    else
                    {
                        if (i==(manage.arr_OnlineArray.count)-1)
                        {
                            if ([str_Conn isEqualToString:@"Yes"])
                            {
                                RetunVal=@"Yes";
                                sqlite3_reset(statement);
                                
                                return RetunVal;
                                
                            }
                            else
                            {
                                RetunVal=@"No";
                                sqlite3_reset(statement);
                                
                                return RetunVal;
                                
                            }
                        }
                    }
                }
            }
            else
            {
                RetunVal=@"No";
                sqlite3_reset(statement);
                
                return RetunVal;
                
            }
            sqlite3_reset(statement);
        }
    }
    return @"No";
}


-(NSMutableArray*)retrive_LocalValues:(NSString*)StoreID
{
    arr_LocalValues=[[NSMutableArray alloc]init];
    [arr_LocalValues removeAllObjects];
    
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where StoreID = \"%@\"",StoreID];
        
        const char *query_stmt = [querySQL UTF8String];
        
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
                //   sqlite3_pre
        {
            NSLog(@"%d",sqlite3_prepare_v2(database,
                                           query_stmt, -1, &statement, NULL) == SQLITE_OK);
            while(sqlite3_step(statement) == SQLITE_ROW)
            {
                arrLocal = [NSMutableDictionary new];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)] forKey:@"ShipLogID"];
                
                [arr_LocalValues addObject:arrLocal];
            }
            sqlite3_reset(statement);
            
            return arr_LocalValues;
            
        }
    }
    return nil;
    
}



-(NSMutableArray*)retrive_values:(NSString*)SDate EDate:(NSString*)EDate StoreID:(NSString*)StoreID
{
    arr_LocalValues=[[NSMutableArray alloc]init];
    [arr_LocalValues removeAllObjects];
    
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
    
    NSDate *date1=[Formate_DateMonthYear_Service dateFromString:SDate];
    
    NSDate *date2=[Formate_DateMonthYear_Service dateFromString:EDate];
    
    NSDate *EndDate = [date2 dateByAddingTimeInterval:+1*24*60*60];
    
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID, RxNumber, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,RxID,StoreID,PatientCreditCardNo,PatientCCExpMMYY,PatientCCCode,PatientEmail,ARAddress,ARBalance,Acct,Ar,Bill,State,City,Phone1,Zip,ArChargeID,AlreadyPaid,PatientID, HipaaSigID,HipaaSig,RxARItemID,ShippingDetailID from deliverylist where PickupDateCondition >= \"%@\" AND PickupDateCondition < \"%@\" AND StoreID = \"%@\"",date1,EndDate,StoreID];
        
        const char *query_stmt = [querySQL UTF8String];
        
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
                //   sqlite3_pre
        {
            NSLog(@"%d",sqlite3_prepare_v2(database,
                                           query_stmt, -1, &statement, NULL) == SQLITE_OK);
            while(sqlite3_step(statement) == SQLITE_ROW)
            {
                arrLocal = [NSMutableDictionary new];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)] forKey:@"ShipLogID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)] forKey:@"RxNumber"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)] forKey:@"DeliveredDate"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 3)] forKey:@"DriverName"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 4)] forKey:@"DrugName"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 5)] forKey:@"IsPOS"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 6)] forKey:@"PatientCity"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 7)] forKey:@"PatientMobile"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 8)] forKey:@"PatientName"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 9)] forKey:@"PatientState"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 10)] forKey:@"PatientStreet"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 11)] forKey:@"Qty"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 12)] forKey:@"Patientzip"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 13)] forKey:@"Patpay"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 14)] forKey:@"PickupDate"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 15)] forKey:@"RxDate"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 16)] forKey:@"ShipNotes"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 17)] forKey:@"RxID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 18)] forKey:@"StoreID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 19)] forKey:@"PatientCreditCardNo"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 20)] forKey:@"PatientCCExpMMYY"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 21)] forKey:@"PatientCCCode"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 22)] forKey:@"PatientEmail"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 23)] forKey:@"ARAddress"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 24)] forKey:@"ARBalance"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 25)] forKey:@"Acct"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 26)] forKey:@"Ar"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 27)] forKey:@"Bill"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 28)] forKey:@"State"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 29)] forKey:@"City"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 30)] forKey:@"Phone1"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 31)] forKey:@"Zip"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 32)] forKey:@"ArChargeID"];
                
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 33)] forKey:@"BalanceAmt"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 34)] forKey:@"PatientID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 35)] forKey:@"HipaaSigID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 36)] forKey:@"HipaaSig"];
                
                
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 37)] forKey:@"RxARItemID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 38)] forKey:@"ShippingDetailID"];

                /*
                 
                 [arrLocal setObject: ((char *)sqlite3_column_text(statement, 38)) ? [NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 38)]: @"" forKey:@"RxARItemID"];

                 
                 */
                
               // NSString *PaidAmount=manage.arr_OnlineArray[i][@"BalanceAmt"];

                
                [arr_LocalValues addObject:arrLocal];
            }
            sqlite3_reset(statement);
            
            return arr_LocalValues;
            
        }
    }
    return nil;
    
}

-(NSMutableArray*)retrive_DeliveredValues
{
    arr_LocalValues=[[NSMutableArray alloc]init];
    [arr_LocalValues removeAllObjects];
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
            // (Name text,Relation text,Signature text,XmlTrans text,IsPOS text)
        
        
        NSString *querySQL = [NSString stringWithFormat:@"select Name, Relation, Signature, XmlTrans, IsPOS ,StoreID, UserName, Password, CounsellingType, POSID, RxID, DeliveryComments, DeletedRxList from localDelivered"];
        
        const char *query_stmt = [querySQL UTF8String];
        
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
                //   sqlite3_pre
        {
            NSLog(@"%d",sqlite3_prepare_v2(database,
                                           query_stmt, -1, &statement, NULL) == SQLITE_OK);
            while(sqlite3_step(statement) == SQLITE_ROW)
            {
                arrLocal = [NSMutableDictionary new];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)] forKey:@"Name"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)] forKey:@"Relation"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)] forKey:@"Signature"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 3)] forKey:@"XmlTrans"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 4)] forKey:@"IsPOS"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 5)] forKey:@"StoreID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 6)] forKey:@"UserName"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 7)] forKey:@"Password"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 8)] forKey:@"CounsellingType"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 9)] forKey:@"POSID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 10)] forKey:@"RxID"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 11)] forKey:@"DeliveryComments"];
                [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 12)] forKey:@"DeletedRxList"];
                
                
                
                [arr_LocalValues addObject:arrLocal];
            }
            sqlite3_reset(statement);
            
            return arr_LocalValues;
            
        }
    }
    return nil;
    
}
-(BOOL) saveDataSig:(NSString*)Name Relation:(NSString*)Relation
          Signature:(NSString*)Signature XmlTrans:(NSString*)XmlTrans IsPOS:(NSString*)IsPOS StoreID:(NSString*)StoreID UserName:(NSString*)UserName Password:(NSString*)Password CounsellingType:(NSString *)CounsellingType POSID:(NSString *)POSID RxID:(NSString *)RxID DeliveryComments:(NSString *)DeliveryComments DeletedRxList:(NSString*)DeletedRxList
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
            //  NSString *insertSQL = [NSString stringWithFormat:@"delete from signaturedetails"];
        NSString *insertSQL = [NSString stringWithFormat:@"insert into localDelivered (Name,Relation,Signature,XmlTrans,IsPOS,Password,UserName,StoreID,CounsellingType,POSID,RxID,DeliveryComments,DeletedRxList) values(\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",Name,Relation,Signature,XmlTrans,IsPOS,Password,UserName,StoreID,CounsellingType,POSID,RxID,DeliveryComments,DeletedRxList];
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE)
        {
            sqlite3_reset(statement);
            
            return YES;
        }
        else {
            sqlite3_reset(statement);
            
            return NO;
        }
    }
    return NO;
}

-(BOOL)deleteLocalArray:(NSString*)Logid StoreID:(NSString*)StoreID
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"delete from deliverylist where ShipLogID=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            return YES;
            
        }
    }
    return YES;
    
}

-(BOOL)deleteLocalPastValue
{
    
    NSDateFormatter *Formate_DateMonthYearTime1;
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setTimeZone:[NSTimeZone localTimeZone]];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
    
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        // now build a NSDate object for the next day
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setDay:-3];
    [offsetComponents setHour:0];
    [offsetComponents setMinute:0];
    [offsetComponents setSecond:0];
    [offsetComponents setTimeZone:[NSTimeZone localTimeZone]];
    
    
    NSDate *EndDate = [gregorian dateByAddingComponents:offsetComponents toDate:[NSDate date]  options:0];
    
    NSString *str_DateCondition=[Formate_DateMonthYear_Service stringFromDate:EndDate];
    
    NSDate *EndDate1 = [Formate_DateMonthYear_Service dateFromString:str_DateCondition];;
    
    
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"delete from deliverylist where  PickupDateCondition < \"%@\" ",EndDate1];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return YES;
        }
        else
        {
            return NO;
            
        }
    }
    return YES;
    
}
-(BOOL)deleteRxIDList:(NSString *)StoreID LogID:(NSString *)LogID RxID:(NSString *)RxID
{
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"delete from deliverylist where StoreID=\"%@\" and ShipLogID=\"%@\" and  RxID not in (%@)",StoreID,LogID,RxID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            return YES;
            
        }
    }
    return YES;
    
    
    
}


-(BOOL)deleteLocalRxList:(NSString*)Logid
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"delete from deliverylist where RxNumber in (\"%@\")",Logid];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            return YES;
            
        }
    }
    return YES;
    
}


-(BOOL) saveDataRxNum:(NSString*)Logid StoreID:(NSString*)StoreID
{
    NSLog(@"%@",manage.arr_searchVal);
    
    NSDateFormatter *Formate_DateMonthYearTime1;
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
        // NSString *str_RxNUMber=[NSString stringWithFormat:@"#%@",Logid];
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
            //  NSString *querySQL = [NSString stringWithFormat:@"select RxNumber from deliverylist where RxNumber=\"%@\" OR RxNumber=\"%@\"",Logid,str_RxNUMber];
        
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where ShipLogID=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            
            NSString *ShipLogID =[NSString stringWithFormat:@"#%@",manage.arr_searchVal[0][@"RxNumber"]];
            NSString *RxNumber =manage.arr_searchVal[0][@"RxNumber"];
            NSString *RxID =[NSString stringWithFormat:@"%d",[manage.arr_searchVal[0][@"RxID"]intValue]];
            NSString *DeliveredDate=@" ";
            NSString *Dispatcher =@" ";
            NSString *DrugName =manage.arr_searchVal[0][@"DrugName"];
            NSString *IsPOS =@"0";
            NSString *PatientCity =manage.arr_searchVal[0][@"City"];
            NSString *PatientMobile =manage.arr_searchVal[0][@"Mobile"];
            NSString *PatientName =manage.arr_searchVal[0][@"PatientName"];
            NSString *PatientState =manage.arr_searchVal[0][@"State"];
            NSString *PatientStreet =manage.arr_searchVal[0][@"Street1"];
            NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_searchVal[0][@"QtyShipped"]floatValue]];
            NSString *Patientzip =manage.arr_searchVal[0][@"Zip"];
            NSString *Patpay =[NSString stringWithFormat:@"%f",[manage.arr_searchVal[0][@"PatPay"]floatValue]];
            
            NSDate *date12;
            
            NSString *str_DateCondition=[Formate_DateMonthYearTime1 stringFromDate:[NSDate date]];
            date12=[Formate_DateMonthYearTime1 dateFromString:str_DateCondition];
            
            NSString *PickupDate =manage.arr_searchVal[0][@"RxDate"];
            NSString *RxDate =manage.arr_searchVal[0][@"RxDate"];
            NSString *ShipNotes =@" ";
            NSString *StoreIDD =manage.arr_storeInfoList[@"StoreID"];
            NSString *PatientEmail =manage.arr_searchVal[0][@"PatientEmail"];
            
            NSString *CreditCardno =manage.arr_searchVal[0][@"PatientCreditCardNo"];
            NSString *Expdate =manage.arr_searchVal[0][@"PatientCCExpMMYY"];
            NSString *CCcode =manage.arr_searchVal[0][@"PatientCCCode"];
            NSString *ShippingDetailID = @"";

            
            
            NSString *insertSQL = [NSString stringWithFormat:@"insert into deliverylist (ShipLogID, RxNumber, RxID, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,PickupDateCondition,StoreID,PatientEmail,PatientCreditCardNo,PatientCCExpMMYY,PatientCCCode,ShippingDetailID) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\",\"%@\",\"%@\",\"%@\",\"%@\", \"%@\", \"%@\",\"%@\",\"%@\")",ShipLogID,RxNumber,RxID, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes,date12,StoreIDD,PatientEmail,CreditCardno,Expdate,CCcode,ShippingDetailID];
            
            const char *insert_stmt = [insertSQL UTF8String];
            sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
            
            if (sqlite3_step(statement) == SQLITE_DONE)
            {
                return YES;
            }
            else
            {
                return NO;
                
            }
        }
    }
    return NO;
}
-(BOOL) saveDataLogNum:(NSString*)Logid StoreID:(NSString*)StoreID
{
    NSDateFormatter *Formate_DateMonthYearTime1;
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
    
    NSLog(@"%@",manage.arr_searchVal);
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where ShipLogID=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            
            for (int i=0;i<manage.arr_searchVal.count; i++)
            {
                NSString *ShipLogID =Logid;
                NSString *RxNumber =manage.arr_searchVal[i][@"RxNumber"];
                NSString *RxID =manage.arr_searchVal[i][@"RxID"];
                
                NSString *DeliveredDate=@" ";
                NSString *Dispatcher =@" ";
                NSString *DrugName =manage.arr_searchVal[i][@"DrugName"];
                NSString *IsPOS =@"0";
                NSString *PatientCity =manage.arr_searchVal[i][@"City"];
                NSString *PatientMobile =manage.arr_searchVal[i][@"Mobile"];
                NSString *PatientName =manage.arr_searchVal[i][@"PatientName"];
                NSString *PatientState =manage.arr_searchVal[i][@"State"];
                NSString *PatientStreet =manage.arr_searchVal[i][@"Street1"];
                NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_searchVal[i][@"QtyShipped"]floatValue]];
                NSString *Patientzip =manage.arr_searchVal[i][@"Zip"];
                NSString *Patpay =manage.arr_searchVal[i][@"PatPay"];
                
                NSDate *date12;
                
                NSString *str_DateCondition=[Formate_DateMonthYearTime1 stringFromDate:[NSDate date]];
                date12=[Formate_DateMonthYearTime1 dateFromString:str_DateCondition];
                
                
                NSString *PickupDate =manage.arr_searchVal[i][@"PickupDate"];
                
                    //   NSString *PickupDate =@" ";
                NSString *RxDate =manage.arr_searchVal[i][@"RxDate"];
                NSString *ShipNotes =manage.arr_searchVal[i][@"Notes"];
                NSString *StoreIDD =manage.arr_storeInfoList[@"StoreID"];
                NSString *PatientEmail =manage.arr_searchVal[i][@"PatientEmail"];
                
                NSString *CreditCardno =manage.arr_searchVal[i][@"PatientCreditCardNo"];
                NSString *Expdate =manage.arr_searchVal[i][@"PatientCCExpMMYY"];
                NSString *CCcode =manage.arr_searchVal[i][@"PatientCCCode"];
                NSString *ShippingDetailID =manage.arr_searchVal[i][@"ShippingDetailID"];

                
                
                NSString *insertSQL = [NSString stringWithFormat:@"insert into deliverylist (ShipLogID, RxNumber, RxID, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,PickupDateCondition,StoreID,PatientEmail,PatientCreditCardNo,PatientCCExpMMYY,PatientCCCode,ShippingDetailID) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\",\"%@\",\"%@\",\"%@\",\"%@\", \"%@\", \"%@\",\"%@\",\"%@\")",ShipLogID,RxNumber,RxID, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes,date12,StoreIDD,PatientEmail,CreditCardno,Expdate,CCcode,ShippingDetailID];
                const char *insert_stmt = [insertSQL UTF8String];
                sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
                
                if (sqlite3_step(statement) == SQLITE_DONE)
                {
                    if (i==(manage.arr_searchVal.count)-1)
                    {
                        
                        return YES;
                    }
                }
                else
                {
                    
                    return NO;
                    
                }
            }
            sqlite3_reset(statement);
            
        }
    }
    return NO;
}

-(BOOL) saveDataPOSNum:(NSString*)Logid StoreID:(NSString*)StoreID
{
    
    NSDateFormatter *Formate_DateMonthYearTime1;
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDateFormatter *Formate_DateMonthYear_Service;
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    
    
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from deliverylist where ShipLogID=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            
            
            for (int i=0;i<manage.arr_searchVal.count; i++)
            {
                NSString *ShipLogID =manage.arr_searchVal[i][@"PosID"];
                
                NSString *RxNumber =manage.arr_searchVal[i][@"ItemUPC"];
                NSString *RxID =manage.arr_searchVal[i][@"ItemID"];
                
                NSString *DeliveredDate=@" ";
                NSString *Dispatcher =@" ";
                NSString *DrugName =manage.arr_searchVal[i][@"ItemName"];
                NSString *IsPOS =@"1";
                NSString *PatientCity =manage.arr_searchVal[i][@"City"];
                NSString *PatientMobile =manage.arr_searchVal[i][@"Mobile"];
                NSString *PatientName =manage.arr_searchVal[i][@"PatientName"];
                NSString *PatientState =manage.arr_searchVal[i][@"State"];
                NSString *PatientStreet =manage.arr_searchVal[i][@"Street1"];
                NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_searchVal[i][@"Qty"]floatValue]];
                NSString *Patientzip =manage.arr_searchVal[i][@"Zip"];
                NSString *Patpay =manage.arr_searchVal[i][@"Price"];
                
                NSDate *date12;
                
                NSString *str_DateCondition=[Formate_DateMonthYearTime1 stringFromDate:[NSDate date]];
                date12=[Formate_DateMonthYearTime1 dateFromString:str_DateCondition];
                
                
                NSString *PickupDate =manage.arr_searchVal[i][@"TranDate"];
                NSString *RxDate =manage.arr_searchVal[i][@"TranDate"];
                NSString *ShipNotes =@" ";
                NSString *StoreIDD =manage.arr_storeInfoList[@"StoreID"];
                NSString *PatientEmail =manage.arr_searchVal[i][@"PatientEmail"];
                
                NSString *CreditCardno =manage.arr_searchVal[i][@"PatientCreditCardNo"];
                NSString *Expdate =manage.arr_searchVal[i][@"PatientCCExpMMYY"];
                NSString *CCcode =manage.arr_searchVal[i][@"PatientCCCode"];
                NSString *ShippingDetailID = @"";

                
                NSString *insertSQL = [NSString stringWithFormat:@"insert into deliverylist (ShipLogID, RxNumber, RxID, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes,PickupDateCondition,StoreID,PatientEmail,PatientCreditCardNo,PatientCCExpMMYY,PatientCCCode,ShippingDetailID) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",ShipLogID,RxNumber,RxID, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes,date12,StoreIDD,PatientEmail,CreditCardno,Expdate,CCcode,ShippingDetailID];
                const char *insert_stmt = [insertSQL UTF8String];
                sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
                
                if (sqlite3_step(statement) == SQLITE_DONE)
                {
                    if (i==(manage.arr_searchVal.count)-1)
                    {
                        
                        return YES;
                    }
                }
                else
                {
                    
                    return NO;
                    
                }
            }
            sqlite3_reset(statement);
            
        }
    }
    return NO;
}


-(BOOL)deleteSig:(NSString*)Logid StoreID:(NSString*)StoreID
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"delete from localDelivered where Signature=\"%@\" AND StoreID=\"%@\"",Logid,StoreID];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
        }
        else
        {
            sqlite3_reset(statement);
            
            return YES;
            
        }
    }
    return NO;
    
    
}

-(BOOL)deleteLog
{
  //  NSString *str_Log=[NSString stringWithFormat:@"691691,691688,691687,691686,691685,202673,202672,202671,202676,202670,202669,202667,202663"];
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:@"delete from deliverylist where ShipLogID in (691691, 691688, 691687, 691686, 691685, 691684, 202673, 202672, 202671, 202676, 202670, 202669, 202667, 202663)"];
        
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
            
        }
        else
        {
            sqlite3_reset(statement);
            return YES;
            
            
        }
    }
    return NO;
    
}

-(BOOL)addColumn
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"Alter table deliverylist add StoreID text"];
        const char *query_stmt = [insertSQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
            
        }
        else
        {
            sqlite3_reset(statement);
            return YES;
            
            
        }
    }
    return NO;
}
-(BOOL)checkColumnName
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"select StoreID from deliverylist"];
        const char *sqlStatement =[insertSQL UTF8String];
        if(sqlite3_prepare_v2(database,
                              sqlStatement, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            return YES;
            
        }
        else
        {
            return NO;
            
        }
        
    }
    return NO;
}


-(BOOL)addColumnSigStoreID
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"Alter table localDelivered add StoreID text"];
        const char *query_stmt = [insertSQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
            
        }
        else
        {
            sqlite3_reset(statement);
            return YES;
            
            
        }
    }
    return NO;
}
-(BOOL)checkColumnNameSigStoreID
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"select StoreID from localDelivered"];
        const char *sqlStatement =[insertSQL UTF8String];
        if(sqlite3_prepare_v2(database,
                              sqlStatement, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            return YES;
            
        }
        else
        {
            return NO;
            
        }
        
    }
    return NO;
}


-(BOOL)addColumnSigUserName
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"Alter table localDelivered add UserName text"];
        const char *query_stmt = [insertSQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
            
        }
        else
        {
            sqlite3_reset(statement);
            return YES;
            
            
        }
    }
    return NO;
}

-(BOOL)checkColumnSigUserName
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"select UserName from localDelivered"];
        const char *sqlStatement =[insertSQL UTF8String];
        if(sqlite3_prepare_v2(database,
                              sqlStatement, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            return YES;
            
        }
        else
        {
            return NO;
            
        }
        
    }
    return NO;
}


-(BOOL)addColumnSigPassword
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"Alter table localDelivered add Password text"];
        const char *query_stmt = [insertSQL UTF8String];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            sqlite3_reset(statement);
            return NO;
            
        }
        else
        {
            sqlite3_reset(statement);
            return YES;
            
            
        }
    }
    return NO;
}
-(BOOL)checkColumnSigPassword
{
    const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"select Password from localDelivered"];
        const char *sqlStatement =[insertSQL UTF8String];
        if(sqlite3_prepare_v2(database,
                              sqlStatement, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
        {
            return YES;
            
        }
        else
        {
            return NO;
            
        }
        
    }
    return NO;
}





/*
 -(NSMutableArray*) findSignature
 {
 arr_LocalValues=[[NSMutableArray alloc]init];
 [arr_LocalValues removeAllObjects];
 
 
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 NSString *querySQL = [NSString stringWithFormat:@"select Name,Relation,Signature,XmlTrans,IsPOS from localDelivered"];
 
 const char *query_stmt = [querySQL UTF8String];
 
 if (sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK)
 {
 NSLog(@"%d",sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK);
 while(sqlite3_step(statement) == SQLITE_ROW)
 {
 arrLocal = [NSMutableDictionary new];
 
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)] forKey:@"Name"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)] forKey:@"Relation"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)] forKey:@"Signature"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 3)] forKey:@"XmlTrans"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 4)] forKey:@"IsPOS"];
 
 [arr_LocalValues addObject:arrLocal];
 }
 
 sqlite3_reset(statement);
 
 return arr_LocalValues;
 }
 }
 return nil;
 }
 
 */

/*
 -(BOOL) saveDataDelivery:(NSString*)Logid
 {
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID from localDelivered where ShipLogID=\"%@\"",Logid];
 const char *query_stmt = [querySQL UTF8String];
 if (sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
 {
 sqlite3_reset(statement);
 return NO;
 }
 else
 {
 for (int j=0;j<manage.arr_LocatSelectedRx.count; j++)
 {
 NSString *str_RxId=manage.arr_LocatSelectedRx[j];
 
 for (int i=0;i<manage.arr_OnlineArray.count; i++)
 {
 if ([str_RxId isEqualToString:[NSString stringWithFormat:@"%d",[manage.arr_OnlineArray[i][@"RxNumber"]intValue]]])
 {
 
 NSString *ShipLogID =manage.arr_OnlineArray[i][@"ShipLogID"];
 NSString *RxNumber =manage.arr_OnlineArray[i][@"RxNumber"];
 NSString *DeliveredDate =manage.arr_OnlineArray[i][@"DeliveredDate"];
 NSString *Dispatcher =manage.arr_OnlineArray[i][@"Dispatcher"];
 NSString *DrugName =manage.arr_OnlineArray[i][@"DrugName"];
 NSString *IsPOS =manage.arr_OnlineArray[i][@"IsPOS"];
 NSString *PatientCity =manage.arr_OnlineArray[i][@"PatientCity"];
 NSString *PatientMobile =manage.arr_OnlineArray[i][@"PatientMobile"];
 NSString *PatientName =manage.arr_OnlineArray[i][@"PatientName"];
 NSString *PatientState =manage.arr_OnlineArray[i][@"PatientState"];
 NSString *PatientStreet =manage.arr_OnlineArray[i][@"PatientStreet"];
 NSString *Qty =[NSString stringWithFormat:@"%f",[manage.arr_OnlineArray[i][@"Qty"]floatValue]];
 NSString *Patientzip =manage.arr_OnlineArray[i][@"Patientzip"];
 NSString *Patpay =manage.arr_OnlineArray[i][@"Patpay"];
 NSString *PickupDate =manage.arr_OnlineArray[i][@"PickupDate"];
 NSString *RxDate =manage.arr_OnlineArray[i][@"RxDate"];
 NSString *ShipNotes =manage.arr_OnlineArray[i][@"ShipNotes"];
 
 NSString *insertSQL = [NSString stringWithFormat:@"insert into localDelivered (ShipLogID, RxNumber, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes) values(\"%@\",\"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\", \"%@\")",ShipLogID,RxNumber, DeliveredDate, Dispatcher, DrugName,IsPOS, PatientCity,PatientMobile,PatientName,PatientState,PatientStreet,Qty,Patientzip,Patpay,PickupDate,RxDate,ShipNotes];
 const char *insert_stmt = [insertSQL UTF8String];
 sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
 
 if (sqlite3_step(statement) == SQLITE_DONE)
 {
 
 i=manage.arr_OnlineArray.count;
 
 if (j==(manage.arr_LocatSelectedRx.count)-1)
 {
 sqlite3_reset(statement);
 
 return YES;
 }
 }
 
 }
 }
 }
 }
 }
 return NO;
 }
 
 -(BOOL) saveDataSig:(NSString*)Name Relation:(NSString*)Relation
 Signature:(NSString*)Signature Logid:(NSString*)Logid IsPOS:(NSString*)IsPOS
 {
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 //  NSString *insertSQL = [NSString stringWithFormat:@"delete from signaturedetails"];
 NSString *insertSQL = [NSString stringWithFormat:@"insert into signatureDetails (Name,Relation,Signature,ShipLogID,IsPOS) values(\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",Name,Relation,Signature,Logid,IsPOS];
 const char *insert_stmt = [insertSQL UTF8String];
 sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
 if (sqlite3_step(statement) == SQLITE_DONE)
 {
 sqlite3_reset(statement);
 
 return YES;
 }
 else {
 sqlite3_reset(statement);
 
 return NO;
 }
 }
 return NO;
 }
 
 -(NSMutableArray*) findProductDetail_byLogid:(NSString*)Logid
 {
 arr_LocalValues=[[NSMutableArray alloc]init];
 [arr_LocalValues removeAllObjects];
 
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 //NSString *querySQL = [NSString stringWithFormat:@"delete from productdetails"];
 NSString *querySQL = [NSString stringWithFormat:@"select ShipLogID, RxNumber, DeliveredDate, Dispatcher, DrugName, IsPOS, PatientCity, PatientMobile, PatientName, PatientState, PatientStreet, Qty, Patientzip, Patpay, PickupDate, RxDate, ShipNotes from localDelivered where ShipLogID=\"%@\"",Logid];
 
 const char *query_stmt = [querySQL UTF8String];
 
 if (sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK)
 {
 while(sqlite3_step(statement) == SQLITE_ROW)
 {
 arrLocal = [NSMutableDictionary new];
 
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)] forKey:@"ShipLogID"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)] forKey:@"RxNumber"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)] forKey:@"DeliveredDate"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 3)] forKey:@"Dispatcher"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 4)] forKey:@"DrugName"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 5)] forKey:@"IsPOS"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 6)] forKey:@"PatientCity"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 7)] forKey:@"PatientMobile"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 8)] forKey:@"PatientName"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 9)] forKey:@"PatientState"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 10)] forKey:@"PatientStreet"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 11)] forKey:@"Qty"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 12)] forKey:@"Patientzip"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 13)] forKey:@"Patpay"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 14)] forKey:@"PickupDate"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 15)] forKey:@"RxDate"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 16)] forKey:@"ShipNotes"];
 
 [arr_LocalValues addObject:arrLocal];
 }
 sqlite3_reset(statement);
 
 return arr_LocalValues;
 }
 }
 return nil;
 }
 
 -(NSMutableArray*) findSignature
 {
 arr_LocalValues=[[NSMutableArray alloc]init];
 [arr_LocalValues removeAllObjects];
 
 
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 NSString *querySQL = [NSString stringWithFormat:@"select Name,Relation,Signature,ShipLogID,IsPOS from signatureDetails"];
 
 const char *query_stmt = [querySQL UTF8String];
 
 if (sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK)
 {
 NSLog(@"%d",sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK);
 while(sqlite3_step(statement) == SQLITE_ROW)
 {
 arrLocal = [NSMutableDictionary new];
 
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)] forKey:@"Name"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 1)] forKey:@"Relation"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 2)] forKey:@"Signature"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 3)] forKey:@"ShipLogID"];
 [arrLocal setObject:[NSString  stringWithUTF8String:(char *)sqlite3_column_text(statement, 4)] forKey:@"IsPOS"];
 
 [arr_LocalValues addObject:arrLocal];
 }
 
 sqlite3_reset(statement);
 
 return arr_LocalValues;
 }
 }
 return nil;
 }
 -(BOOL)deleteSig:(NSString*)Logid
 {
 const char *dbpath = [databasePath UTF8String];
 if (sqlite3_open(dbpath, &database) == SQLITE_OK)
 {
 NSString *querySQL = [NSString stringWithFormat:@"delete from signatureDetails where ShipLogID=\"%@\"",Logid];
 const char *query_stmt = [querySQL UTF8String];
 if (sqlite3_prepare_v2(database,
 query_stmt, -1, &statement, NULL) == SQLITE_OK && (sqlite3_step(statement) == SQLITE_ROW))
 {
 sqlite3_reset(statement);
 return NO;
 }
 else
 {
 return YES;
 
 }
 }
 return YES;
 
 
 }
 
 */



@end
