//
//  ScanReadyforDeliver.h
//  Delivery
//
//  Created by Rex on 19/02/19.
//  Copyright © 2019 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTBBarcodeScanner.h"
#import "singleton.h"


@interface ScanReadyforDeliver : UIViewController
{
    CGFloat animatedDistance;
    singleton *manage;
}

@property (strong,nonatomic) IBOutlet UIView *view_activity;
@property (strong,nonatomic) IBOutlet UITextField *txt_searchRx;
@property (nonatomic, weak) IBOutlet UIView *previewView;
@property (nonatomic,weak) IBOutlet UIView *view_previewOut;
@property(strong,nonatomic)IBOutlet UIImageView *image_Flash;
@property(strong,nonatomic)IBOutlet UIButton *btn_Scann;
@property (nonatomic, strong) MTBBarcodeScanner *scanner;
@property (nonatomic, strong) NSMutableArray *uniqueCodes;
@property(strong,nonatomic)NSString *str_Type;



@end

