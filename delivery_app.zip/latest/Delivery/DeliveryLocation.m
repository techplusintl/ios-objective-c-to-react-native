    //
    //  DeliveryLocation.m
    //  Delivery
    //
    //  Created by Barani Elangovan on 5/5/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "DeliveryLocation.h"

@interface DeliveryLocation ()
{
    float f_UserLocation1;
    float f_UserLocation2;
    
    float f_DeliverLocation1;
    float f_DeliverLocation2;
    
    NSString *str_firstTime;
    NSString *str_Distance;
    
    NSString *str_ErrMsg;
    
}
@end

@implementation DeliveryLocation
@synthesize mapView,locationManager,str_Address,str_State,str_Street,str_PatientName,lab_PatientName;

- (void)viewDidLoad {
    [super viewDidLoad];
    manage=[singleton share];
    
    lab_PatientName.text=str_PatientName;
    
    str_ErrMsg=@"No";
    str_firstTime=@"Yes";
    
    mapView.mapType = MKMapTypeStandard;
    
    self.locationManager = [[CLLocationManager alloc]init];
    self.locationManager.delegate = self;
    if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
        [self.locationManager requestAlwaysAuthorization];
    }
    
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        [self.locationManager startUpdatingLocation];
        self.mapView.showsUserLocation = YES;
        
    }
    
    if (self.locationManager == nil)
    {
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
        self.locationManager.delegate = self;
    }
    [self.locationManager startUpdatingLocation];
    
    [self.mapView setVisibleMapRect:self.mapView.visibleMapRect edgePadding:UIEdgeInsetsMake(500, 500, 10, 10) animated:YES];

    
    [self FindDirection];
    
        // Do any additional setup after loading the view.
}

#pragma mark - Map Direction


-(void)FindDirection
{
  
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder geocodeAddressString:str_Address completionHandler:^(NSArray *placemarks, NSError *error)
     {
         if(!error)
         {
             CLPlacemark *placemark = [placemarks objectAtIndex:0];
             
             CLLocationCoordinate2D touchMapCoordinate;
             
             CLLocationCoordinate2D userCoordinate;
             
             userCoordinate.latitude = f_UserLocation1;
             userCoordinate.longitude = f_UserLocation2;
             
             f_DeliverLocation1=placemark.location.coordinate.latitude;
             f_DeliverLocation2=placemark.location.coordinate.longitude;
             
             touchMapCoordinate.latitude = placemark.location.coordinate.latitude;
             touchMapCoordinate.longitude = placemark.location.coordinate.longitude;
             
             
             MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
             
             MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
             [srcMapItem setName:@""];
             
             MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(placemark.location.coordinate.latitude, placemark.location.coordinate.longitude) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
             
                 //  MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(37.327043, -122.030690) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
             
             
             MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
             [distMapItem setName:@""];
             
             
             MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
             [request setSource:srcMapItem];
             [request setDestination:distMapItem];
                 //[request requestsAlternateRoutes];
             
             [request setTransportType:MKDirectionsTransportTypeAutomobile];
             
             MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
             
             [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                 
                 NSArray *arrRoutes = [response routes];
                 
                 
                 
                 [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                     
                     str_firstTime=@"No";
                     
                     MKRoute *route = obj;
                     
                     str_Distance=[NSString stringWithFormat:@"%.0f",route.distance];

                     MKPointAnnotation *annotationPoint = [[MKPointAnnotation alloc] init];
                     annotationPoint.coordinate = touchMapCoordinate;
                     annotationPoint.title =str_Street;
                     annotationPoint.subtitle = str_State;
                     [self.mapView addAnnotation:annotationPoint];

                     
                     [mapView removeOverlays:mapView.overlays];
                     MKPolyline *line = [route polyline];
                    [self.mapView setVisibleMapRect:[line boundingMapRect]];
                     [self.mapView addOverlay:line];
                     
                     NSUInteger pointCount = route.polyline.pointCount;
                     CLLocationCoordinate2D *routeCoordinates
                     = malloc(pointCount * sizeof(CLLocationCoordinate2D));
                     [route.polyline getCoordinates:routeCoordinates
                                              range:NSMakeRange(0, pointCount)];
                     CLLocationCoordinate2D coordinates1[2] = {userCoordinate, routeCoordinates[0]};
                     MKPolyline *line1 = [MKPolyline polylineWithCoordinates:coordinates1 count:2];
                     [self.mapView addOverlay:line1];
                     CLLocationCoordinate2D coordinates2[2] = {routeCoordinates[pointCount - 1], touchMapCoordinate};
                     MKPolyline *line2 = [MKPolyline polylineWithCoordinates:coordinates2 count:2];
                     [self.mapView addOverlay:line2];
                     free(routeCoordinates);
                     
                 }];
             }];
             
             
         }
         else
         {
             
             if([str_ErrMsg isEqualToString:@"No"])
             {
                 str_ErrMsg=@"Yes";
                 UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Address not found." preferredStyle:UIAlertControllerStyleAlert];
                 
                 UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                 [alertController addAction:ok];
                 
                 [self presentViewController:alertController animated:YES completion:nil];

             }
             else
             {
                 
             }
            
             
                 // NSLog(@"There was a forward geocoding error\n%@",[error localizedDescription]);
         }
     }
     ];
    
}

-(void)trackLocation
{
    
    CLLocationCoordinate2D touchMapCoordinate;
    
    CLLocationCoordinate2D userCoordinate;
    
    userCoordinate.latitude = f_UserLocation1;
    userCoordinate.longitude = f_UserLocation2;
    
    
    touchMapCoordinate.latitude = f_DeliverLocation1;
    touchMapCoordinate.longitude =f_DeliverLocation2;
    
    
    MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
    
    MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
    [srcMapItem setName:@""];
    
    MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_DeliverLocation1, f_DeliverLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
    
    MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
    [distMapItem setName:@""];
    
    
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
    [request setSource:srcMapItem];
    [request setDestination:distMapItem];
        //[request requestsAlternateRoutes];
    
    [request setTransportType:MKDirectionsTransportTypeAutomobile];
    
    MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
    
    [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
        
        NSArray *arrRoutes = [response routes];
        [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            
            MKRoute *route = obj;
            
            str_Distance=[NSString stringWithFormat:@"%.0f",route.distance];

            
            [mapView removeOverlays:mapView.overlays];
            MKPolyline *line = [route polyline];
                //[self.mapView setVisibleMapRect:[line boundingMapRect]];
            [self.mapView addOverlay:line];
            
            NSUInteger pointCount = route.polyline.pointCount;
            CLLocationCoordinate2D *routeCoordinates
            = malloc(pointCount * sizeof(CLLocationCoordinate2D));
            [route.polyline getCoordinates:routeCoordinates
                                     range:NSMakeRange(0, pointCount)];
            CLLocationCoordinate2D coordinates1[2] = {userCoordinate, routeCoordinates[0]};
            MKPolyline *line1 = [MKPolyline polylineWithCoordinates:coordinates1 count:2];
            [self.mapView addOverlay:line1];
            CLLocationCoordinate2D coordinates2[2] = {routeCoordinates[pointCount - 1], touchMapCoordinate};
            MKPolyline *line2 = [MKPolyline polylineWithCoordinates:coordinates2 count:2];
            [self.mapView addOverlay:line2];
            free(routeCoordinates);
            
        }];
    }];
    
}

#pragma mark - Location Update


- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
         f_UserLocation1=newLocation.coordinate.latitude;
          f_UserLocation2=newLocation.coordinate.longitude;
    
//    f_UserLocation1=33.659885;
//    f_UserLocation2=-117.755047;
    
    if ([str_firstTime isEqualToString:@"Yes"])
    {
        [self FindDirection];

    }
    else
    {
        if ((oldLocation.coordinate.latitude == newLocation.coordinate.latitude)||(oldLocation.coordinate.longitude == newLocation.coordinate.longitude))
        {
            
        }
        else
        {
            
            [self trackLocation];
        }

    }
    
    
}

#pragma mark - Custom Annotaion Pin


-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    static NSString * const kPinAnnotationIdentifier = @"PinIdentifier";
    if(annotation == self.mapView.userLocation)
    {
        return nil;
    }
    
    
    
    CustomAnnotation *myAnnotation  = (CustomAnnotation *)annotation;
    
    
    
    MKAnnotationView *newAnnotation = (MKAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:kPinAnnotationIdentifier];
    
    if(!newAnnotation){
        newAnnotation = [[MKAnnotationView alloc] initWithAnnotation:myAnnotation reuseIdentifier:@"userloc"];
    }
    
        //NSDictionary *dict=[alertInfoArray objectAtIndex:myAnnotation.ann_tag];
    
    
    UIView *anView=[[UIView alloc] init];
    anView.backgroundColor=[UIColor clearColor];
    
    UILabel *lab_Distancee=[[UILabel alloc] init];
    lab_Distancee.font=[UIFont systemFontOfSize:12];
    
    lab_Distancee.textAlignment=NSTextAlignmentCenter;
    lab_Distancee.textColor=[UIColor blackColor];
    lab_Distancee.backgroundColor=[UIColor clearColor];
    float str_distancee=str_Distance.floatValue;
    float f_distance=str_distancee/1609.34;
    lab_Distancee.text=[NSString stringWithFormat:@"%.2f",f_distance];
    lab_Distancee.frame=CGRectMake(5,13,40,15);
    
    
    
    
    UILabel *lblduration=[[UILabel alloc] init];
    lblduration.font=[UIFont systemFontOfSize:10];
    lblduration.textAlignment=NSTextAlignmentCenter;
    lblduration.textColor=[UIColor blackColor];
    lblduration.backgroundColor=[UIColor clearColor];
    lblduration.text=[NSString stringWithFormat:@"Miles"];
    lblduration.frame=CGRectMake(5,28,40,15);
    
    
    
    newAnnotation.frame=CGRectMake(0, 0, 50, 120);
    anView.frame=CGRectMake(0, 0, 50, 60);
    UIImageView *bgImg=[[UIImageView alloc] init];
    bgImg.frame=CGRectMake(0, 0, 50, 60);
    bgImg.image=[UIImage imageNamed:@"ClusterAnnotation.png"];
    [anView addSubview:bgImg];
    
    [anView addSubview:lab_Distancee];
    
    [anView addSubview:lblduration];
    
        // [anView addSubview:lblSeparate];
    
    
    [newAnnotation addSubview:anView];
    
    newAnnotation.canShowCallout = YES;
    newAnnotation.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeInfoLight];
        //   newAnnotation.canShowCallout=YES;
    [newAnnotation setEnabled:YES];

    
    return newAnnotation;
    
}
/*{
    static NSString * const kPinAnnotationIdentifier = @"PinIdentifier";
    if(annotation == self.mapView.userLocation)
    {
        return nil;
    }
    
    CustomAnnotation *myAnnotation  = (CustomAnnotation *)annotation;
    MKAnnotationView *newAnnotation = (MKAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:kPinAnnotationIdentifier];
    
    if(!newAnnotation){
        newAnnotation = [[MKAnnotationView alloc] initWithAnnotation:myAnnotation reuseIdentifier:@"userloc"];
    }
    
    
    UIView *anView=[[UIView alloc] init];
    anView.backgroundColor=[UIColor clearColor];
    
    newAnnotation.frame=CGRectMake(0, 0, 30, 60);
    anView.frame=CGRectMake(0, 0, 30, 30);
    UIImageView *bgImg=[[UIImageView alloc] init];
    bgImg.frame=CGRectMake(0, 0, 30, 30);
    bgImg.image=[UIImage imageNamed:@"marker.png"];
    [anView addSubview:bgImg];
    [newAnnotation addSubview:anView];
    newAnnotation.canShowCallout=YES;
    [newAnnotation setEnabled:YES];
    return newAnnotation;
    
}*/

#pragma mark - Apple Map Redirect Method


- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    
    CustomAnnotation *annotation = (CustomAnnotation *)view.annotation;
    
        //  NSLog(@"%@",annotation.title);
        // NSLog(@"%@",annotation.subtitle);
    
        // NSLog(@"%@",annotation.coordinate.longitude);
    
        // http://maps.apple.com/?daddr=San+Francisco&dirflg=d&t=h
    
    
    NSString* directionsURL = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%f,%f&dirflg=d&t=m", annotation.coordinate.latitude, annotation.coordinate.longitude];
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: directionsURL]];
    
    /*   if ([str_ListType isEqualToString:@"Delivered"])
     {
     DeliveredDetailedScreen *ln = [[DeliveredDetailedScreen alloc]initWithNibName:@"DeliveredDetailedScreen" bundle:nil];
     ln.str_addresss=[NSString stringWithFormat:@"%@,%@",annotation.title,annotation.subtitle];
     ln.str_isMapView=@"Yes";
     [self.navigationController pushViewController:ln animated:NO];
     }
     else
     {
     DetailedScreen *ln = [[DetailedScreen alloc]initWithNibName:@"DetailedScreen" bundle:nil];
     ln.str_addresss=[NSString stringWithFormat:@"%@,%@",annotation.title,annotation.subtitle];
     ln.str_isMapView=@"Yes";
     [self.navigationController pushViewController:ln animated:NO];
     }
     */
    
}

#pragma mark - Polyline


- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id)overlay {
    
    if ([overlay isKindOfClass:[MKPolyline class]]) {
        MKPolylineView* aView = [[MKPolylineView alloc]initWithPolyline:(MKPolyline*)overlay] ;
        aView.strokeColor = [UIColor colorWithRed:0.0/255.0 green:169.0/255.0 blue:252.0/255.0 alpha:1.0];
        aView.lineWidth = 8;
        return aView;
    }
    
    return nil;
}

#pragma mark - Button Back


-(IBAction)btn_Back:(id)sender
{
    if ([manage.GPSallow isEqualToString:@"Yes"])
    {
        
    }
    else
    {
       // [self.locationManager stopUpdatingLocation];
        
    }

    
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
