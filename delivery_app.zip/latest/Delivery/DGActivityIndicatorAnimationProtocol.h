//
//  DGActivityIndicatorAnimationProtocol.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol DGActivityIndicatorAnimationProtocol <NSObject>

- (void)setupAnimationInLayer:(CALayer *)layer withSize:(CGSize)size tintColor:(UIColor *)tintColor;

@end
