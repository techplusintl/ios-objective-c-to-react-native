//
//  MSSCalendarViewController.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "singleton.h"

@protocol MSSCalendarViewControllerDelegate <NSObject>
- (void)calendarViewConfirmClickWithStartDate:(NSInteger)startDate endDate:(NSInteger)endDate;
@end

typedef NS_ENUM(NSInteger, MSSCalendarViewControllerType)
{
    MSSCalendarViewControllerLastType = 0,
    MSSCalendarViewControllerMiddleType,
    MSSCalendarViewControllerNextType
};

@interface MSSCalendarViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource>
{
    singleton *manage;
}
@property (nonatomic,weak)id<MSSCalendarViewControllerDelegate> delegate;
@property (nonatomic,assign)NSInteger startDate;
@property (nonatomic,assign)NSInteger endDate;

@property (nonatomic,assign)NSInteger limitMonth;
@property (nonatomic,assign)MSSCalendarViewControllerType type;
@property (nonatomic,assign)BOOL afterTodayCanTouch;
@property (nonatomic,assign)BOOL beforeTodayCanTouch;

@property (nonatomic,assign)BOOL showChineseHoliday;
@property (nonatomic,assign)BOOL showChineseCalendar;
@property (nonatomic,assign)BOOL showHolidayDifferentColor;

@property (nonatomic,assign)BOOL showAlertView;


@property(strong,nonatomic)IBOutlet UILabel *lab_title;

@end
