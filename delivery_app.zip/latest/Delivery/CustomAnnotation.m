//
//  CustomAnnotation.m
//  RXfill
//
//  Created by Barani Elangovan on 1/1/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//

#import "CustomAnnotation.h"

@implementation CustomAnnotation
@synthesize title,subtitle,phone;

@end
