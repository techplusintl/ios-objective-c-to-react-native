//
//  AppDelegate.m
//  Delivery
//
//  Created by Rex on 16/02/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"
#import "OnlineList.h"
#import "IQKeyboardManager.h"

@interface AppDelegate ()
{
    NSTimer *Timer10;
    float f_UserLocation1;
    float f_UserLocation2;
}
@property (nonatomic, retain) NSTimer *Timer10;
@end

@implementation AppDelegate

@synthesize window,viewController;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    IQKeyboardManager.sharedManager.enable = true;
    manage=[singleton share];
    
    
    
    [self needsUpdate];

   // NSLog(@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:@"CrashLog"]);
    
    
   // [[NSUserDefaults standardUserDefaults]setObject:@"test mail" forKey:@"CrashLog"];
  //  [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"CrashLog"]length]==0)
    {
        
    }
    else
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
            });
            NSString *str = [[NSString alloc] initWithData:[[NSUserDefaults standardUserDefaults]objectForKey:@"CrashLog"] encoding:NSUTF8StringEncoding];
            
            str=[NSString stringWithFormat:@"Device Name: %@\n Device UUID: %@\n %@",[[UIDevice currentDevice] name],[[[UIDevice currentDevice] identifierForVendor] UUIDString],str];
           
                 NSLog(@"%@",str);
            
            SKPSMTPMessage *emailMessage = [[SKPSMTPMessage alloc] init];
            
            emailMessage.delegate=self;
                 emailMessage.fromEmail = @"donotreply@rxcity.com"; //sender email address
                  emailMessage.toEmail = @"appalert@rxcity.com";  //receiver email address
            
                           emailMessage.relayHost = @"smtp.gmail.com";
                          emailMessage.requiresAuth = YES;
            
                   emailMessage.login = @"donotreply@rxcity.com"; //sender email address
                  emailMessage.pass = @"donotreply298+"; //sender email password
            
                       
            emailMessage.subject =@"digitalRx Delivery iPhone App - Crash Report";
            emailMessage.wantsSecure = YES;
            NSDictionary *plainMsg = [NSDictionary
                                      dictionaryWithObjectsAndKeys:@"text/plain",kSKPSMTPPartContentTypeKey,
                                      str,kSKPSMTPPartMessageKey,@"8bit",kSKPSMTPPartContentTransferEncodingKey,nil];
            emailMessage.parts = [NSArray arrayWithObjects:plainMsg,nil]; //including plain msg and attached file msg
            dispatch_async(dispatch_get_main_queue(), ^{
                
            [emailMessage send];
                
            });
        });
    }

    NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);

    
    manage.GPSallow=@"No";
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    //self.restrictRotation=YES;

    self.viewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    
    // self.window.rootViewController = self.viewController;
    self.navigationcontroller = [[UINavigationController alloc]initWithRootViewController:self.viewController];
    self.window.rootViewController = self.navigationcontroller;
    [self.window makeKeyAndVisible];

    return YES;
}

-(BOOL) needsUpdate
{
    
    
    
    NSDictionary* infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString* appID = infoDictionary[@"CFBundleIdentifier"];
    NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"http://itunes.apple.com/lookup?bundleId=%@", appID]];
    NSData* data = [NSData dataWithContentsOfURL:url];
    
    if (data)
    {
        NSDictionary* lookup = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        if ([lookup[@"resultCount"] integerValue] == 1){
            NSString* appStoreVersion = lookup[@"results"][0][@"version"];
            NSString* currentVersion = infoDictionary[@"CFBundleShortVersionString"];
            NSString *AppId = [[[lookup objectForKey:@"results"] objectAtIndex:0] objectForKey:@"trackId"];
            
            manage.str_CurrentVresion=currentVersion;
            manage.str_iTunesVersion=appStoreVersion;
            manage.str_iTunesAppID=AppId;
            
        }
        
    }
    else
    {
        
    }
    return NO;
}

BOOL exceptionAlertDismissed = FALSE;

void uncaughtExceptionHandler(NSException *exception)
{
        // NSLog(@"CRASH: %@", exception);
        // NSLog(@"Stack Trace: %@", [exception callStackSymbols]);
        //  NSLog(@"Stack Trace: %@", [exception reason]);
    
    NSMutableString* logContent = [[NSMutableString alloc] initWithCapacity:0];
    
    [logContent appendFormat:@"CRASH: %@\r\n",exception ];
    [logContent appendFormat:@"Stack Trace: %@\r\n",[exception callStackSymbols] ];
    [logContent appendFormat:@"             %@\r\n",[exception callStackReturnAddresses] ];
    [logContent appendFormat:@"             %@\r\n",[exception userInfo] ];

    NSData* contentData = [logContent dataUsingEncoding:NSUTF8StringEncoding];
    
    
    
    [[NSUserDefaults standardUserDefaults]setObject:contentData forKey:@"CrashLog"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Unable to process your request. Please try again later!" preferredStyle:UIAlertControllerStyleAlert];
//    
//    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
//    [alertController addAction:ok];
//    
//    [.rootViewController.presentViewController:alertController animated:YES completion:nil];
    
    /*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                    message:@"Unable to process your request. Please try again later!"
                                                   delegate:[[UIApplication sharedApplication] delegate] cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [alert show];
    */
 
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    exceptionAlertDismissed = TRUE;
}

-(void)messageSent:(SKPSMTPMessage *)message
{
    
    [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"CrashLog"];
    
    
        //NSLog(@"Message Send");
}
-(void)messageFailed:(SKPSMTPMessage *)message error:(NSError *)error
{
    
    
    
}


-(NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {

    if(self.restrictRotation)
        return UIInterfaceOrientationMaskLandscapeLeft;
    else
        return UIInterfaceOrientationMaskPortrait;// | UIInterfaceOrientationPortraitUpsideDown;
        
    }
    
    else
    {
        if(self.restrictRotation)
        {
            return UIInterfaceOrientationMaskAll;

        }
        else{
            return UIInterfaceOrientationMaskAll;

            
        }
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    
    
        //  if ([manage.GPSallow isEqualToString:@"Yes"])
        //  {
        UIBackgroundTaskIdentifier bgTask = 0;
        UIApplication  *app = [UIApplication sharedApplication];
        bgTask = [app beginBackgroundTaskWithExpirationHandler:^{
            [app endBackgroundTask:bgTask];
        }];

   /*     [self.locationManagerBack setAllowsBackgroundLocationUpdates:YES];
        self.locationManagerBack = [[CLLocationManager alloc]init];
        self.locationManagerBack.delegate = self;
        if ([self.locationManagerBack respondsToSelector:@selector(requestAlwaysAuthorization)]) {
            [self.locationManagerBack requestAlwaysAuthorization];
        }
        
        CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
        
        if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
            authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
            authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
            
            [self.locationManagerBack startUpdatingLocation];
                // self.mapView.showsUserLocation = YES;
            
        }
        
        if (self.locationManagerBack == nil)
        {
            self.locationManagerBack = [[CLLocationManager alloc] init];
            self.locationManagerBack.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
            self.locationManagerBack.delegate = self;
        }
            [self.locationManagerBack startUpdatingLocation];
        */
        
       /* Timer10 = [NSTimer scheduledTimerWithTimeInterval:60
                                                 target:self selector:@selector(GPSservice10:) userInfo:nil repeats:YES];*/
        //  }
    
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
        // NSLog(@"OldLocation %f %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude);
        // NSLog(@"NewLocation %f %f", newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    
    f_UserLocation1=newLocation.coordinate.latitude;
    f_UserLocation2=newLocation.coordinate.longitude;
      
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    
    
    if ([manage.str_updatee isEqualToString:@"Yes"]) {
        
    }
    else{
        
    }
    
        // [self.locationManagerBack stopUpdatingLocation];

    
        //  [Timer10 invalidate];
        //  Timer10 = nil;

    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
