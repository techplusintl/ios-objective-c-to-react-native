//
//  LocationFind.h
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/5/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Mapannotation.h"
#import <CoreLocation/CoreLocation.h>
#import "CustomAnnotation.h"


#import "singleton.h"


#import "RouteCell.h"

@interface LocationFind : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    singleton *manage;
}

@property(strong,nonatomic)NSString *str_IsPharmacy;

@property(weak,nonatomic)IBOutlet MKMapView *mapView;
@property (nonatomic,strong) CLLocationManager *locationManager;

@property(strong,nonatomic)IBOutlet UIView *view_Route;
@property(strong,nonatomic)IBOutlet UITableView *table_Route;
@property(strong,nonatomic)IBOutlet UIImageView *image_Route;


@end
