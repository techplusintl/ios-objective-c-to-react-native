//
//  DriverListCell.h
//  Delivery
//
//  Created by Rex on 06/03/19.
//  Copyright © 2019 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DriverListCell : UITableViewCell
@property(strong,nonatomic) IBOutlet UILabel *labl_drivername;
@property(strong,nonatomic) IBOutlet UILabel *labl_driverID;

@end

NS_ASSUME_NONNULL_END
