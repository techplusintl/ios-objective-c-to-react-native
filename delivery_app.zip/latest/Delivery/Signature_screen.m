    //
    //  Signature_screen.m
    //  Delivery_offline
    //
    //  Created by Barani Elangovan on 16/03/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "Signature_screen.h"
#import "AppDelegate.h"
#import "DGActivityIndicatorView.h"

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;


@interface Signature_screen ()
{
    DGActivityIndicatorView *activityIndicatorView;
    NSArray *activityTypes;
    
    
    UIImage *image100;
    NSString *str_100;
    
    NSString *transaction_id3;
    NSString *internet_flag;
    NSString *orientation_detect;
    int con;
    int con2;
    
    float f_UserLocation1;
    float f_UserLocation2;
    
    NSString *delivery_date;
    
    NSString *str_counselType;
    NSMutableArray *arr_relationList;
    NSMutableArray *arr_relationListName;
    
}



@end

@implementation Signature_screen
@synthesize  txt_name,txt_relation,btn_sig_clear,btn_sig_download,view_signature, str_internet,btn_pay_online;

@synthesize str_logid,view_name,view_relation,view_offline_alert,btn_back, view_activityView;

@synthesize str_PatientName,str_IsPOS,str_POSID,str_Cash,str_ccard,str_CCAuth,str_checks,str_CCTranID,str_Comments,str_CardIssuer,str_CCardNumber, str_CCNumber1,str_ExpDate1,str_CVV1,str_ZipCode1;

@synthesize arr_RxNumberr,arr_RxID,arr_RxPrice,lab_deliveredCount,view_PaymentConfirm,btn_payConfirmation;

@synthesize str_TotalTender,str_CVV,str_ExpDate,str_PayType,str_ZipCode,str_CCNumber,str_RefNumber,str_PatientAddresss, img_rotate, view_sig, view_activity,str_PaymentType, str_street,str_city,str_state,arr_del_Qty,str_pat_email,arr_PatientID,arr_HipaaSigID,arr_HipaaSig,arr_BalanceAmount,str_RxSearch,arr_RxARItemID;


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [self.navigationItem setHidesBackButton:YES animated:NO];
    
    activityTypes = @[@(DGActivityIndicatorAnimationTypeBallClipRotate)];
    
    manage=[singleton share];
    arr_relationList = [[NSMutableArray alloc] init];
    arr_relationListName = [[NSMutableArray alloc] init];
    
    /*
    if ([str_street isEqualToString:@""] || str_street == NULL) {
        
        str_street = @"";
    }
    */
    /*[arrayOfData setObject: storeConfigg[@"DeliveryAppDefaultRelation"] forKey:@"DeliveryAppDefaultRelation"];
     [arrayOfData setObject: storeConfigg[@"DeliveryAppDisplayDrugName"] forKey:@"DeliveryAppDisplayDrugName"];
     */
    
    if ([manage.arr_storeInfoList[@"DeliveryAppDefaultRelation"] isEqualToString:@""] || [manage.arr_storeInfoList[@"DeliveryAppDefaultRelation"] isEqualToString:@"0"] ) {
        
        txt_relation.text=@"Self";
        txt_name.text=str_PatientName;
        
        /*txt_relation.text=@"Self";
         txt_name.text=str_PatientName;*/
    }
    else
    {
        txt_relation.text=@"";
        txt_name.text=@"";
        /*txt_relation.text=@"";
         txt_name.text=@"";*/
    }
    
    
    
    [self restrictRotation:YES];
    
        //str_RefNumber=@"";
    
    view_activity.hidden=YES;
    view_PaymentConfirm.hidden=YES;
    
    view_activityView.hidden = YES;
    CGFloat borderWidth = 1.0f;
    view_name.layer.borderColor = [UIColor lightGrayColor].CGColor;
    view_name.layer.borderWidth = borderWidth;
    view_name.layer.cornerRadius = 3;
    
    view_relation.layer.borderColor = [UIColor lightGrayColor].CGColor;
    view_relation.layer.borderWidth = borderWidth;
    view_relation.layer.cornerRadius = 3;
    
    
    
    btn_payConfirmation.layer.borderColor = [UIColor lightGrayColor].CGColor;
    btn_payConfirmation.layer.borderWidth = borderWidth;
    btn_payConfirmation.layer.cornerRadius = 3;
    
    
    view_signature.layer.cornerRadius=3;
    btn_sig_clear.layer.cornerRadius=3;
    btn_sig_download.layer.cornerRadius=3;
    btn_pay_online.layer.cornerRadius=3;
        //  signatureView= [[PJRSignatureView alloc]init];
        //  signatureView= [[PJRSignatureView alloc] initWithFrame:CGRectMake(0,0,308,229)];
        //view_sig.layer.cornerRadius =  3;
        //  signatureView.backgroundColor = [UIColor lightGrayColor];
    signatureView.backgroundColor =  [UIColor clearColor];
    signatureView.layer.cornerRadius=3;
        //  [view_signature addSubview:signatureView];
        //   signatureView.backgroundColor=[UIColor colorWithRed:243.0/255 green:244.0/255 blue:247.0/255 alpha:1.0];
    
        // Do any additional setup after loading the view.
    
    if ([str_internet isEqual:@"yes"]) {
        btn_sig_download.hidden=YES;
    }
    
    else if([str_internet  isEqual:@"no"])
    {
        
        
        btn_pay_online.hidden=YES;
    }
    
    
    self.locationManager = [[CLLocationManager alloc]init];
    self.locationManager.delegate = self;
    if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
        [self.locationManager requestAlwaysAuthorization];
    }
    
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        [self.locationManager startUpdatingLocation];
        
    }
    
    if (self.locationManager == nil)
    {
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
        self.locationManager.delegate = self;
    }
    [self.locationManager startUpdatingLocation];
    
    
    
    NSLog(@"%@",manage.arr_OnlineArray);
    
    
    NSLog(@"%@",manage.arr_storeInfoList);
    NSLog(@"%@",str_ZipCode);
    NSLog(@"%@",str_ZipCode1);
    
    [self RelationList];
}
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
    f_UserLocation1=newLocation.coordinate.latitude;
    f_UserLocation2=newLocation.coordinate.longitude;
    
    
}


- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==10) {
        
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MM/dd/yyyy hh:mm a"];
        
        delivery_date = [dateFormatter stringFromDate:[NSDate date]];
        
        
        if( 0 == buttonIndex )
        { //cancel button
            [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
            str_counselType=@"0";
            [self pay];
        } else if ( 1 == buttonIndex ){
            [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
            str_counselType=@"1";
            [self pay];
        }
    }
    else
    {
        
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    
    if ([str_internet isEqualToString:@"no"]) {
        view_offline_alert.hidden = YES;
    }
    
    
        // signatureView=[[PJRSignatureView alloc]init];
    
        //  NSLog(@"%f" @"%f",view_Sig.frame.size.width,view_Sig.frame.size.height);
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
            //  NSLog(@"iphone");
        if(orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight)
        {
            NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
            
        }
        else
        {
            NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }
        
        
    }
    
    
    
    /*  if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
     
     //  NSLog(@"%f",[[UIScreen mainScreen]bounds].size.width);
     
     {
     
     NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
     [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
     }
     */
    else
    {
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
        {
            if(orientation == UIInterfaceOrientationPortrait)
            {
                orientation_detect=@"portrait_up";
            }
            else if(orientation == UIInterfaceOrientationLandscapeLeft)
            {
                
                orientation_detect=@"landscape_left";
            }
            
            else if (orientation == UIInterfaceOrientationLandscapeRight)
            {
                
                orientation_detect=@"landscape_right";
            }
            else if (orientation == UIInterfaceOrientationPortraitUpsideDown)
            {
                
                orientation_detect=@"portrait_down";
            }
            
        }
    }
    
    [self restrictRotation:YES];
    
    [signatureView removeFromSuperview];
    signatureView= [[PJRSignatureView alloc]init];
    signatureView=[[PJRSignatureView alloc] initWithFrame:CGRectMake(0, 0, view_signature.frame.size.width, view_signature.frame.size.height)];
    
    
    signatureView.layer.cornerRadius =5;
    signatureView. layer.masksToBounds =YES;
    signatureView.backgroundColor=[UIColor whiteColor];
    [view_signature addSubview:signatureView];
    
    
    
    
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(orientationChanged:)    name:UIDeviceOrientationDidChangeNotification  object:nil];
    
        // do something before rotation
    [signatureView removeFromSuperview];
    signatureView= [[PJRSignatureView alloc]init];
    signatureView=[[PJRSignatureView alloc] initWithFrame:CGRectMake(0, 0, view_signature.frame.size.width, view_signature.frame.size.height)];
    
    
    signatureView.layer.cornerRadius =5;
    signatureView. layer.masksToBounds =YES;
    signatureView.backgroundColor=[UIColor whiteColor];
    [view_signature addSubview:signatureView];
    
    /*
     if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
     
     //  NSLog(@"%f",[[UIScreen mainScreen]bounds].size.width);
     
     {
     }
     
     else
     {
     UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
     {
     if(orientation == UIInterfaceOrientationPortrait)
     {
     orientation_detect=@"portrait_up";
     }
     else if(orientation == UIInterfaceOrientationLandscapeLeft)
     {
     
     orientation_detect=@"landscape_left";
     }
     
     else if (orientation == UIInterfaceOrientationLandscapeRight)
     {
     
     orientation_detect=@"landscape_right";
     }
     else if (orientation == UIInterfaceOrientationPortraitUpsideDown)
     {
     
     orientation_detect=@"portrait_down";
     }
     
     }
     }
     
     
     
     
     */
    
    
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
        // do something after rotation
    [signatureView removeFromSuperview];
    signatureView= [[PJRSignatureView alloc]init];
    signatureView=[[PJRSignatureView alloc] initWithFrame:CGRectMake(0, 0, view_signature.frame.size.width, view_signature.frame.size.height)];
    
    
    signatureView.layer.cornerRadius =5;
    signatureView. layer.masksToBounds =YES;
    signatureView.backgroundColor=[UIColor whiteColor];
    [view_signature addSubview:signatureView];
    
    
    
}
-(void)viewWillAppear:(BOOL)animated
{
    
    [self restrictRotation:YES];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(orientationChanged:)    name:UIDeviceOrientationDidChangeNotification  object:nil];
    
    
}

- (void)orientationChanged:(NSNotification *)notification{
    [self adjustViewsForOrientation:[[UIApplication sharedApplication] statusBarOrientation]];
}

- (void) adjustViewsForOrientation:(UIInterfaceOrientation) orientation
{
    
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
    }
    else
    {
        switch (orientation)
        {
            case UIInterfaceOrientationPortrait:
            {
                NSLog(@"portrait");
                orientation_detect=@"portrait_up";
            }
                break;
                
            case UIInterfaceOrientationPortraitUpsideDown:
            {
                    //load the portrait view
                
                
                NSLog(@"portrait_down");
                orientation_detect=@"portrait_down";
                
            }
                break;
            case UIInterfaceOrientationLandscapeLeft:
            {
                NSLog(@"landscape_left");
                orientation_detect=@"landscape_left";
            }
                break;
            case UIInterfaceOrientationLandscapeRight:
            {
                    //load the landscape view
                NSLog(@"landscape");
                orientation_detect=@"landscape_right";
                
            }
                break;
            case UIInterfaceOrientationUnknown:break;
        }
        
    }
}



-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
}


-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}

#pragma mark - Clear Signature


-(IBAction)btn_clr_signature:(id)sender
{
    [signatureView clearSignature];
    
    /*
     UIImage *image1 = [UIImage imageNamed:@""];
     UIImageView *img_rotate = [[UIImageView alloc] initWithImage:image1];
     [self.view_sig removeFromSuperview];
     
     */
    
    
    
}

- (UIImage *)imageRotatedByDegrees:(UIImage*)oldImage deg:(CGFloat)degrees{
        //Calculate the size of the rotated view's containing box for our drawing space
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,oldImage.size.width, oldImage.size.height)];
    CGAffineTransform t = CGAffineTransformMakeRotation(degrees * M_PI / 180);
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;
    
        //Create the bitmap context
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
        //Move the origin to the middle of the image so we will rotate and scale around the center.
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
        //Rotate the image context
    CGContextRotateCTM(bitmap, (degrees * M_PI / 180));
    
        //Now, draw the rotated/scaled image into the context
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-oldImage.size.width / 2, -oldImage.size.height / 2, oldImage.size.width, oldImage.size.height), [oldImage CGImage]);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark - Button Payment

/*
 -(IBAction)btn_Pay:(id)sender
 {
 [self.view addSubview:view_sig];
 image100 = [signatureView getSignatureImage];
 
 if ([txt_name.text isEqual:@""]) {
 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
 @"Please Enter Name" message:nil delegate:nil cancelButtonTitle:
 @"OK" otherButtonTitles:nil];
 [alert show];
 }
 
 else if(image100==nil)
 {
 
 
 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please Enter Signature"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
 [alert show];
 
 }
 else
 {
 if ([manage.str_InternetFlag isEqualToString:@"Yes"])
 {
 
 if ([orientation_detect  isEqual:@"portrait_up"]) {
 UIImage *rotatedImage;
 
 image100 = [signatureView getSignatureImage];
 //            if([orientation_detect isEqual:@"portrait_up"] || [orientation_detect isEqual:@"landscape_right"])
 //            {
 rotatedImage = [self imageRotatedByDegrees:image100 deg:270];
 //}
 img_rotate = [[UIImageView alloc] initWithImage:rotatedImage];
 //img_rotate.frame = CGRectMake(0,0, 50,50);
 //[self.view_sig addSubview:img_rotate];
 
 
 
 }
 
 else if ([orientation_detect isEqual:@"portrait_down"])
 {
 UIImage *rotatedImage;
 
 image100 = [signatureView getSignatureImage];
 //            if([orientation_detect isEqual:@"portrait_up"] || [orientation_detect isEqual:@"landscape_right"])
 //            {
 rotatedImage = [self imageRotatedByDegrees:image100 deg:360];
 //}
 img_rotate = [[UIImageView alloc] initWithImage:rotatedImage];
 //[self.view_sig addSubview:img_rotate];
 
 
 }
 
 else if ([orientation_detect isEqual:@"landscape_left"])
 {
 UIImage *rotatedImage;
 
 image100 = [signatureView getSignatureImage];
 //            if([orientation_detect isEqual:@"portrait_up"] || [orientation_detect isEqual:@"landscape_right"])
 //            {
 rotatedImage = [self imageRotatedByDegrees:image100 deg:180];
 //}
 img_rotate = [[UIImageView alloc] initWithImage:rotatedImage];
 // [self.view_sig addSubview:img_rotate];
 
 
 }
 
 else if ([orientation_detect isEqual:@"landscape_right"])
 {
 UIImage *rotatedImage;
 
 image100 = [signatureView getSignatureImage];
 //            if([orientation_detect isEqual:@"portrait_up"] || [orientation_detect isEqual:@"landscape_right"])
 //            {
 rotatedImage = [self imageRotatedByDegrees:image100 deg:90];
 //}
 img_rotate = [[UIImageView alloc] initWithImage:rotatedImage];
 //[self.view_sig addSubview:img_rotate];
 
 
 }
 
 
 
 
 
 
 }
 }
 }
 
 
 */
-(IBAction)btn_Pay:(id)sender
{
    
    
    image100 = [signatureView getSignatureImage];
    
    if ([txt_relation.text isEqual:@""]) {
        
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please Select Relation" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
            //        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
            //                              @"Please Select Relation" message:nil delegate:nil cancelButtonTitle:
            //                              @"OK" otherButtonTitles:nil];
            //        [alert show];
    }
    else if ([txt_name.text isEqual:@""]) {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please Enter Name" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
            //        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
            //                              @"Please Enter Name" message:nil delegate:nil cancelButtonTitle:
            //                              @"OK" otherButtonTitles:nil];
            //        [alert show];
    }
    
    else if(image100==nil)
    {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please Enter Signature" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
            //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please Enter Signature"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            //        [alert show];
        
    }
    else
    {
        
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                            message:@"Counselling Required"
                                                           delegate:self
                                                  cancelButtonTitle:@"No"
                                                  otherButtonTitles:@"Yes", nil];
        alertView.tag=10;
        [alertView show];
    }
}



-(void)pay
{
    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
    {
        view_activity.hidden=NO;
        UIImage *rotatedImage;
        
        image100 = [signatureView getSignatureImage];
        rotatedImage = [self imageRotatedByDegrees:image100 deg:270];
        
            //  NSString *RxNumberss;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            
            CGRect rect = CGRectMake(0.0, 0.0,200, 200);
            UIGraphicsBeginImageContext(rect.size);
            [rotatedImage drawInRect:rect];
        }
        else
        {
            
            CGRect rect = CGRectMake(0.0, 0.0,300, 300);
            UIGraphicsBeginImageContext(rect.size);
            [rotatedImage drawInRect:rect];
            
        }
        
        
        UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        NSData *imageData =UIImageJPEGRepresentation(img,0.0);
        str_100 = [imageData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
        
            //  str_ExpDate=@"02/25";
        
        
        
        if ([str_CCNumber rangeOfString:@"X"].location == NSNotFound) {
            NSLog(@"string does not \"");
            NSLog(@"%@",str_CCNumber);
            
        } else {
            NSLog(@"string contains \"");
            str_CCNumber=str_CCNumber1;
            NSLog(@"%@",str_CCNumber);
        }
        
        if ([str_ExpDate rangeOfString:@"X"].location == NSNotFound) {
            NSLog(@"string does not \"");
            
        } else {
            NSLog(@"string contains \"");
            str_ExpDate=str_ExpDate1;
        }
        
        if ([str_CVV rangeOfString:@"X"].location == NSNotFound) {
            NSLog(@"string does not \"");
            
        } else {
            NSLog(@"string contains \"");
            str_CVV=str_CVV1;
            
        }
        if ([str_ZipCode rangeOfString:@"X"].location == NSNotFound) {
            NSLog(@"string does not \"");
            
        } else {
            NSLog(@"string contains \"");
            str_ZipCode=str_ZipCode1;
            
        }
        
        
        str_CCNumber= [str_CCNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
        str_ExpDate= [str_ExpDate stringByReplacingOccurrencesOfString:@"/" withString:@""];
        
        if ([manage.GPSallow isEqualToString:@"Yes"])
        {
            [self DistanceCalc];
            
        }
        else
        {
            
            [self DistanceCalc];
            
        }
        
    }
    else
    {
        
        if ([str_PaymentType isEqualToString:@"Card"])
        {
            
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"You are in offline. Cash and AR Payment will be acceptable in offline" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
                //            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"You are in offline. Cash and AR Payment will be acceptable in offline"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                //
                //            alert.tag=100;
                //
                //            [alert show];
        }
        else
        {
                //NSString *alertString = @"Product not delivered.";
            BOOL success = NO;
            
            NSString *xmlDetail=@"";
                /// NSString *RxNumberss;
            
                // NSString *xmlDetail=@"";
            
            NSString *xmlHeader = [NSString stringWithFormat:@"<transHeader><EmailTo></EmailTo><TotalTender>%@</TotalTender><Paytype>%@</Paytype><RefNumber>%@</RefNumber><CCNumber>%@</CCNumber><ExpDate>%@</ExpDate><CVV>%@</CVV><ZipCode>%@</ZipCode><UserName>%@</UserName><Password>%@</Password><StoreID>%@</StoreID><DeliveryComments>%@</DeliveryComments></transHeader>",str_TotalTender,str_PayType,str_RefNumber,str_CCNumber,str_ExpDate,str_CVV,str_ZipCode,manage.str_DriverName,manage.str_LoginPassword,manage.arr_storeInfoList[@"StoreID"],str_Comments];
            
            if ([str_IsPOS isEqualToString:@"0"])    ////// Rx Transaction
            {
                for (int i=0; i<arr_RxNumberr.count; i++)
                {
                    xmlDetail = [NSString stringWithFormat:@"%@<Item><Iname>#%@</Iname><price>%@</price><ItemID>%@</ItemID><PatientID>%@</PatientID><PatID>%@</PatID><HipaaSigID>%@</HipaaSigID><HipaaSig>%@</HipaaSig><RxARItemID>%@</RxARItemID></Item>", xmlDetail,arr_RxNumberr[i],arr_BalanceAmount[i],arr_RxID[i],manage.arr_ArChargeID[i],arr_PatientID[i],arr_HipaaSigID[i],arr_HipaaSig[i],arr_RxARItemID[i]];
                    
                }
            }
            else
            {
                for (int i=0; i<arr_RxNumberr.count; i++)
                {
                    xmlDetail = [NSString stringWithFormat:@"%@<Item><Iname>%@</Iname><price>%@</price><ItemID>%@</ItemID><PatientID>%@</PatientID><PatID>%@</PatID><HipaaSigID>%@</HipaaSigID><HipaaSig>%@</HipaaSig><RxARItemID>%@</RxARItemID></Item>",xmlDetail,arr_RxNumberr[i],arr_BalanceAmount[i],arr_RxID[i],manage.arr_ArChargeID[i],arr_PatientID[i],arr_HipaaSigID[i],arr_HipaaSig[i],arr_RxARItemID[i]];
                    
                }
            }
            
            NSString *xmlDetail1 = [NSString stringWithFormat:@"<tranDetail>%@</tranDetail>",xmlDetail];
            
            NSString *xmltrans = [NSString stringWithFormat:@"<Root>%@%@</Root>",xmlHeader,xmlDetail1];
            
            
            NSString *str_rxIDvalue=@"";
            for (int i=0; i<arr_RxID.count; i++)
            {
                str_rxIDvalue=[NSString stringWithFormat:@"%@,%@",arr_RxID[i],str_rxIDvalue];
            }
            
            image100 = [signatureView getSignatureImage];
            
            UIImage *rotatedImage = [self imageRotatedByDegrees:image100 deg:270];
            
            
            CGRect rect = CGRectMake(0.0, 0.0,300, 300);
            UIGraphicsBeginImageContext(rect.size);
            [rotatedImage drawInRect:rect];
            UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            NSData *imageData =UIImageJPEGRepresentation(img,0.0);
            str_100 = [imageData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
            
            /* (Name,Relation,Signature,XmlTrans,IsPOS)*/
            
            if ([str_IsPOS isEqualToString:@"0"])    ////// Rx Transaction
            {
                if ([str_RxSearch isEqualToString:@"1"]) {
                    str_POSID=@"";
                    
                }
                else
                {
                    
                }
            }
            else
            {
                str_POSID=@"";
            }
            success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS StoreID:manage.arr_storeInfoList[@"StoreID"] UserName:manage.str_DriverName Password:manage.str_LoginPassword CounsellingType:str_counselType POSID:str_POSID RxID:str_rxIDvalue DeliveryComments:str_Comments DeletedRxList:manage.str_deletedRxList];
            
            NSLog(@"%@   %@",manage.str_DriverName,manage.str_LoginPassword);
            if (success == NO) {
                
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Product not delivered." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
                    //                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                    //                                      @"Alert" message:@"Product not delivered."
                    //                                                              delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    //                [alert show];
                    //
                
            }
            else
            {
                
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                    // BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalRxList:RxNumberss];
                
                    //  [self DistanceCalc];
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
            }
            
        }
    }
    
}

-(void)DistanceCalc
{
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            for (int i = 0; i < activityTypes.count; i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });
        
        
        MKPlacemark *source10 = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake([[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude1"] floatValue],[[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude1"] floatValue]) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
        
        MKMapItem *srcMapItem10 = [[MKMapItem alloc]initWithPlacemark:source10];
        [srcMapItem10 setName:@""];
        
        MKPlacemark *destination10 = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake([[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude"] floatValue], [[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude"] floatValue]) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
        
        
        
        
        MKMapItem *distMapItem10 = [[MKMapItem alloc]initWithPlacemark:destination10];
        [distMapItem10 setName:@""];
        
        
        MKDirectionsRequest *requestmap = [[MKDirectionsRequest alloc]init];
        [requestmap setSource:srcMapItem10];
        [requestmap setDestination:distMapItem10];
            //[request requestsAlternateRoutes];
        
        [requestmap setTransportType:MKDirectionsTransportTypeAutomobile];
        
        MKDirections *direction = [[MKDirections alloc]initWithRequest:requestmap];
        
        [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
            
            if (error)
            {
                
                [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"ActualDistance"];
                
                
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    [self SignatureUpdate];
                });
                
            }
            
            else
            {
                NSArray *arrRoutes = [response routes];
                
                
                [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                    
                    MKRoute *route10 = obj;
                    
                    
                    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%.2f",route10.distance] forKey:@"ActualDistance"];
                    
                    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude"];
                    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude"];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [self SignatureUpdate];
                    });
                    
                }];
            }
        }];
    });
    
}
-(void)SignatureUpdate
{
    
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            for (int i = 0; i < activityTypes.count; i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });
        
        NSString *xmlDetail=@"";
        
        NSString *xmlHeader = [NSString stringWithFormat:@"<transHeader><EmailTo></EmailTo><TotalTender>%@</TotalTender><Paytype>%@</Paytype><RefNumber>%@</RefNumber><CCNumber>%@</CCNumber><ExpDate>%@</ExpDate><CVV>%@</CVV><ZipCode>%@</ZipCode><UserName>%@</UserName><Password>%@</Password><StoreID>%@</StoreID><DeliveryComments>%@</DeliveryComments></transHeader>",str_TotalTender,str_PayType,str_RefNumber,str_CCNumber,str_ExpDate,str_CVV,str_ZipCode,manage.str_DriverName,manage.str_LoginPassword,manage.arr_storeInfoList[@"StoreID"],str_Comments];
        
        if ([str_IsPOS isEqualToString:@"0"])    ////// Rx Transaction
        {
            for (int i=0; i<arr_RxNumberr.count; i++)
            {
                xmlDetail = [NSString stringWithFormat:@"%@<Item><Iname>#%@</Iname><price>%@</price><ItemID>%@</ItemID><PatientID>%@</PatientID><PatID>%@</PatID><HipaaSigID>%@</HipaaSigID><HipaaSig>%@</HipaaSig><RxARItemID>%@</RxARItemID></Item>",xmlDetail,arr_RxNumberr[i],arr_BalanceAmount[i],arr_RxID[i],manage.arr_ArChargeID[i],arr_PatientID[i],arr_HipaaSigID[i],arr_HipaaSig[i],arr_RxARItemID[i]];
            }
        }
        else
        {
            NSLog(@"%@",manage.arr_ArChargeID);
            
            for (int i=0; i<arr_RxNumberr.count; i++)
            {
                xmlDetail = [NSString stringWithFormat:@"%@<Item><Iname>%@</Iname><price>%@</price><ItemID>%@</ItemID><PatientID>%@</PatientID><PatID>%@</PatID><HipaaSigID>%@</HipaaSigID><HipaaSig>%@</HipaaSig><RxARItemID>%@</RxARItemID></Item>",xmlDetail,arr_RxNumberr[i],arr_BalanceAmount[i],arr_RxID[i],manage.arr_ArChargeID[i],arr_PatientID[i],arr_HipaaSigID[i],arr_HipaaSig[i],arr_RxARItemID[i]];
                
            }
        }
        
        
        NSString *xmlDetail1 = [NSString stringWithFormat:@"<tranDetail>%@</tranDetail>",xmlDetail];
        
        NSString *xmltrans = [NSString stringWithFormat:@"<Root>%@%@</Root>",xmlHeader,xmlDetail1];
        
        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        
        [arr_val addObject:txt_relation.text];
        [arr_val addObject:txt_name.text];
        [arr_val addObject:xmltrans];
        [arr_val addObject:str_100];
        
        [arr_val addObject:@"DELIVERY APP - iPhone"];
        
        [arr_val addObject:@"P0$P@%m#n79@tew@%"];
        NSArray *propertyNames =[NSArray arrayWithObjects: @"Relation",@"SignedBy",@"XmlTrans",@"Signature",@"Source",@"TransactionPassword" ,nil];
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"objDelivery"];
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
       // NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"http://www.dbsuatserver.com/DigitalRxPOSPayment/POSPaymentGateway.svc/PostPOSDelivery2"];

        //  NSString *str_service3=[NSString stringWithFormat:@"http://146.148.93.102/POSPaymentGateway/POSPaymentGateway.svc/PostPOSDelivery2"];
        
            //str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000000];
        [request setHTTPMethod:@"POST"];
        //[request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
       // NSLog(@"Content-Type: %@", [request valueForHTTPHeaderField:@"Content-Type"]);

        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            
            NSString* myString;
            myString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
            
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
            NSLog(@"%@",jsonArray3);
            
            NSString *str_SigID=jsonArray3[@"PostPOSDelivery2Result"];
            
                // NSString *str_SigID=tranID2[@"TransactionId"];
            
            if ([str_SigID isEqualToString:@"OK"])
            {
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [self MailUpdate];
                    
                });
                
                
                
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    activityIndicatorView.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    view_activity.hidden=YES;
                    
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Product not delivered." preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                        //                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                        //                                          @"Alert" message:@"Product not delivered."
                        //                                                                  delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                        //                    [alert show];
                });
                
                
            }
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Product not delivered." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                
                    //                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                    //                                      @"Alert" message:@"Product not delivered."
                    //                                                              delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    //                [alert show];
            });
            
        }
    });
    
}

-(void)MailUpdate
{
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    
    
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            for (int i = 0; i < activityTypes.count; i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });
        
        NSString *xmlDetail1= @"";
        
        NSString *xmlHeader1 = [NSString stringWithFormat:@"<StoreName>%@</StoreName><StoreStreet>%@</StoreStreet><StoreCity>%@</StoreCity><StoreState>%@</StoreState><StoreZip>%@</StoreZip><StorePhone>%@</StorePhone><StoreMail>%@</StoreMail><Relation>%@</Relation><Name>%@</Name><DeliveredBy>%@</DeliveredBy><CustomerName>%@</CustomerName><CustomerStreet>%@</CustomerStreet><CustomerCity>%@</CustomerCity><CustomerState>%@</CustomerState><CustomerZip>%@</CustomerZip><DeliveredDate>%@</DeliveredDate><Payment>%@</Payment><TotalAmount>%@</TotalAmount>",manage.arr_storeInfoList[@"PharmacyName"],manage.arr_storeInfoList[@"PharmacyStreet"],manage.arr_storeInfoList[@"PharmacyCity"],manage.arr_storeInfoList[@"PharmacyState"],manage.arr_storeInfoList[@"PharmacyZip"],manage.arr_storeInfoList[@"PharmacyPhone"],manage.arr_storeInfoList[@"PharmacyEmail"],txt_relation.text,txt_name.text,manage.str_DriverName, str_PatientName,str_street,str_city,str_state,str_ZipCode1,delivery_date,str_PaymentType,str_TotalTender];
        
        NSLog(@"%@",xmlHeader1);
        NSLog(@"%@",manage.str_DriverName);
        
        if ([str_IsPOS isEqualToString:@"0"])    ////// Rx Transaction
        {
            for (int i=0; i<arr_RxNumberr.count; i++)
            {
                
                NSString *price= [NSString stringWithFormat:@"%.2f", [arr_BalanceAmount[i]floatValue]];
                xmlDetail1 = [NSString stringWithFormat:@"%@<Item><ItemName>#%@</ItemName><ItemQty>%@</ItemQty><Amount>%@</Amount></Item>",xmlDetail1,arr_RxNumberr[i],[NSString stringWithFormat:@"%.2f", [arr_del_Qty[i]floatValue]],price];
                
            }
        }
        else
        {
            for (int i=0; i<arr_RxNumberr.count; i++)
            {
                
                    //price=[NSString stringWithFormat:@"%@", arr_RxPrice[i]];
                NSString *price= [NSString stringWithFormat:@"%.2f", [arr_BalanceAmount[i]floatValue]];
                
                xmlDetail1 = [NSString stringWithFormat:@"%@<Item><ItemName>%@</ItemName><ItemQty>%@</ItemQty><Amount>%@</Amount></Item>",xmlDetail1,arr_RxNumberr[i],[NSString stringWithFormat:@"%.2f", [arr_del_Qty[i]floatValue]],price];
                
                
            }
        }
        
        
        NSString *xmlDetail2 = [NSString stringWithFormat:@"<Items>%@</Items>",xmlDetail1];
        
        NSString *xmltrans1 = [NSString stringWithFormat:@"<details>%@%@</details>",xmlHeader1,xmlDetail2];
  
        NSMutableArray *arr_mail=[[NSMutableArray alloc]init];
        [arr_mail removeAllObjects];
        
        
        [arr_mail addObject:@"donotreply@rxcity.com"];
        [arr_mail addObject:[NSString stringWithFormat:@"%@",str_pat_email]];
        [arr_mail addObject:[NSString stringWithFormat:@"%@",manage.arr_storeInfoList[@"PharmacyEmail"]]];
        [arr_mail addObject:@"donotreply298+"];
        
        
        [arr_mail addObject:@"Confirmation for Delivery Payment Receipt"];
        
        
        [arr_mail addObject:xmltrans1];
        
        NSArray *property_mail =[NSArray arrayWithObjects:@"FromMail",@"CustomerMail",@"PharmacyMail",@"Password",@"subject",@"MailDetails",nil];
        
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_mail forKeys:property_mail];
        
        NSMutableDictionary *newUserObject3 = [NSMutableDictionary dictionary];
        
        [newUserObject3 setObject:properties forKey:@"ObjMail"];
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject3 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"UpdateMailStatus"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request setHTTPMethod:@"POST"];
       // [request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
            
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
                //   NSDictionary *tranID2=jsonArray3[@"PostPosDeliveryResult"];
            
                //   NSString *str_SigID=tranID2[@"TransactionId"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self CouncleingUpdate];
                
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
                
                if ([manage.GPSallow isEqualToString:@"Yes"])
                {
                    
                }
                else
                {
                        //[self.locationManager stopUpdatingLocation];
                    
                }
            });
            
        }
    });
}


-(void)CouncleingUpdate
{
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (activityTypes.count != 0)
            {
                for (int i = 0; i < activityTypes.count; i++)
                {
                    activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                    CGFloat width = self.view.bounds.size.width ;
                    CGFloat height = self.view.bounds.size.height;
                    
                    activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                    [self.view_activity addSubview:activityIndicatorView];
                    [activityIndicatorView startAnimating];
                }
            }            
            
        });
        
        
        NSString *str_rxIDvalue=@"";
        
        for (int i=0; i<arr_RxID.count; i++)
        {
            str_rxIDvalue=[NSString stringWithFormat:@"%@,%@",arr_RxID[i],str_rxIDvalue];
        }
        
        NSMutableArray *arr_11=[[NSMutableArray alloc]init];
        [arr_11 removeAllObjects];
        
        [arr_11 addObject:manage.arr_storeInfoList[@"StoreID"]];
        
        if ([str_IsPOS isEqualToString:@"0"])    ////// Rx Transaction
        {
            if ([str_RxSearch isEqualToString:@"1"])
            {
                [arr_11 addObject:@""];
                
            }
            else
            {
                [arr_11 addObject:str_POSID];
                
            }
        }
        else{
            [arr_11 addObject:@""];
            
        }
        
        [arr_11 addObject:str_rxIDvalue];
        [arr_11 addObject:manage.str_DriverName];
        [arr_11 addObject:str_counselType];
        [arr_11 addObject:str_Comments];
        if( manage.str_deletedRxList != nil ){
            [arr_11 addObject:manage.str_deletedRxList];
        }else{
            [arr_11 addObject:@""];
        }
        
        [arr_11 addObject:manage.arr_storeInfoList[@"UserFirstName"]];
        
        NSArray *property_11 =[NSArray arrayWithObjects:@"StoreID",@"LogID",@"RxID",@"DeliveredBy",@"CounselType",@"DeliveryComments",@"ShippingDetailID",@"LoggedInBy", nil];
        
        
        NSDictionary *properties4 = [NSDictionary dictionaryWithObjects:arr_11 forKeys:property_11];
        
        NSMutableDictionary *newUserObject4 = [NSMutableDictionary dictionary];
        
        [newUserObject4 setObject:properties4 forKey:@"ObjShippingLog"];
        
        NSData *jsonData4 = [NSJSONSerialization dataWithJSONObject:newUserObject4 options:kNilOptions error:nil];
        NSString *jsonString4 = [[NSString alloc] initWithData:jsonData4 encoding:NSUTF8StringEncoding];
        NSString *str_service4=[NSString stringWithFormat:@"UpdateShippingLogDetailsByID"];
        str_service4=[manage.str_url stringByAppendingString:str_service4];
        NSMutableURLRequest *request4 = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service4] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request4 setHTTPMethod:@"POST"];
        //[request4 setValue:jsonString4 forHTTPHeaderField:@"json"];
        [request4 setHTTPBody:jsonData4];
        [request4 setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error4 = nil;
        NSURLResponse *theResponse4 = [[NSURLResponse alloc]init];
        NSData *data4 = [NSURLConnection sendSynchronousRequest:request4 returningResponse:&theResponse4 error:&error4];
        if(data4)
        {
            NSDictionary *jsonArray4 =[NSJSONSerialization JSONObjectWithData:data4 options:NSJSONReadingMutableContainers error:&error4];
            
                //   NSDictionary *tranID4=jsonArray4[@"UpdateShippingLogDetailsByIDResult"];
            
                //   NSString *str_SigID4=tranID4[@"ReturnID"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self IsDownloaded];
                
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
                
                if ([manage.GPSallow isEqualToString:@"Yes"])
                {
                    
                }
                else
                {
                        // [self.locationManager stopUpdatingLocation];
                    
                }
            });
            
        }
    });
}

/*
-(void)UpdateDeletedRx
{
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            for (int i = 0; i < activityTypes.count; i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });
        
        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        [arr_val addObject:manage.arr_storeInfoList[@"StoreID"]];
        [arr_val addObject:str_POSID];
        [arr_val addObject:@"0"];
        
        NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"ID", @"LoggedInBy" ,nil];
        
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"ObjAppuser"];
        
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"UpdateByAppUser"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request setHTTPMethod:@"POST"];
        //[request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
            // NSDictionary *tranID2=jsonArray3[@"UpdateIsDownloadedFieldByIDResult"];
            
            // NSString *str_SigID=tranID2[@"TransID"];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self LocationUpdate];
                
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
                
                if ([manage.GPSallow isEqualToString:@"Yes"])
                {
                    
                }
                else
                {
                    //[self.locationManager stopUpdatingLocation];
                    
                }
            });
            
        }
    });
}
*/
-(void)IsDownloaded
{
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            for (int i = 0; i < activityTypes.count; i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });

        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        [arr_val addObject:manage.arr_storeInfoList[@"StoreID"]];
        //[arr_val addObject:str_POSID];
        if(str_POSID != nil ){
            [arr_val addObject:str_POSID];
        }else{
            [arr_val addObject:@"0"];
        }
        [arr_val addObject:@"0"];
        
        NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"IsDownloaded" ,nil];
        
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"ObjDownloadedField"];
        
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"UpdateIsDownloadedFieldByID"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request setHTTPMethod:@"POST"];
        //[request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
                // NSDictionary *tranID2=jsonArray3[@"UpdateIsDownloadedFieldByIDResult"];
            
                // NSString *str_SigID=tranID2[@"TransID"];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self LocationUpdate];
                
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
                
                if ([manage.GPSallow isEqualToString:@"Yes"])
                {
                    
                }
                else
                {
                        //[self.locationManager stopUpdatingLocation];
                    
                }
            });
            
        }
    });
}

-(void)LocationUpdate
{
    
    [activityIndicatorView removeFromSuperview];
    view_activity.hidden=NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            for (int i = 0; i < activityTypes.count; i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width ;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });
        
        
        
        NSMutableArray *arr_valGPS=[[NSMutableArray alloc]init];
        [arr_valGPS removeAllObjects];
        
        [arr_valGPS addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
        [arr_valGPS addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
        [arr_valGPS addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
        
        if ([str_IsPOS isEqualToString:@"0"])    ////// Rx Transaction
        {
            if ([str_POSID hasPrefix:@"#"])
            {
                if( str_POSID == nil ){
                    [arr_valGPS addObject:[NSString stringWithFormat:@"%@",@"0"]];
                }else{
                    [arr_valGPS addObject:[NSString stringWithFormat:@"%@",str_POSID]];
                }
                
                
            }
            else
            {
                 if( str_POSID == nil ){
                   [arr_valGPS addObject:[NSString stringWithFormat:@"%@",@"0"]];
               }else{
                   [arr_valGPS addObject:[NSString stringWithFormat:@"%@",str_POSID]];
               }
                
            }
            
        }
        else
        {
            if( str_POSID == nil ){
                [arr_valGPS addObject:[NSString stringWithFormat:@"-%@",@"0"]];
            }else{
                [arr_valGPS addObject:[NSString stringWithFormat:@"-%@",str_POSID]];
            }
            
            
        }
        NSLog(@"%@",[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude"]);
        NSLog(@"%@",[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude"]);
        
        [arr_valGPS addObject:txt_name.text];
        if( str_PatientAddresss == nil ){
            [arr_valGPS addObject:@"N/A"];
        }else{
           [arr_valGPS addObject:str_PatientAddresss];
        }
        
        [arr_valGPS addObject:txt_relation.text];
        [arr_valGPS addObject:[NSString stringWithFormat:@"%@",manage.str_DriverName]];
        [arr_valGPS addObject:str_TotalTender];
        
        [arr_valGPS addObject:[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude"]];
        [arr_valGPS addObject:[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude"]];
        
        float f_Traveldid=[[[NSUserDefaults standardUserDefaults]stringForKey:@"RouteDistance"]floatValue]/1609.34;
        float f_Actualdid=[[[NSUserDefaults standardUserDefaults]stringForKey:@"ActualDistance"]floatValue]/1609.34;
        
        [arr_valGPS addObject:[NSString stringWithFormat:@"%.2f",f_Traveldid]];
        [arr_valGPS addObject:[NSString stringWithFormat:@"%.2f",f_Actualdid]];
        
        [arr_valGPS addObject:str_PayType];
        
        [arr_valGPS addObject:@""];
        if( str_PatientName == nil ){
            [arr_valGPS addObject:@"N/A"];
        }else{
           [arr_valGPS addObject:str_PatientName];
        }
        //[arr_valGPS addObject:str_PatientName];
        
        
        if( manage.str_DelPatientPhone == nil ){
            [arr_valGPS addObject:@"N/A"];
        }else{
            NSLog(@"%@",manage.str_DelPatientPhone);
           [arr_valGPS addObject:manage.str_DelPatientPhone];
        }
        //[arr_valGPS addObject:manage.str_DelPatientPhone];
        
        
        [arr_valGPS addObject:[NSString stringWithFormat:@"%f",f_UserLocation1]];
        [arr_valGPS addObject:[NSString stringWithFormat:@"%f",f_UserLocation2]];
        
        
        [[NSUserDefaults standardUserDefaults]setObject:[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude"] forKey:@"StartLatitude1"];
        [[NSUserDefaults standardUserDefaults]setObject:[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude"] forKey:@"StartLongitude1"];
        
        
        [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
        [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"ActualDistance"];
        
        NSArray *propertyNamesGPS =[NSArray arrayWithObjects:@"StoreID",@"UserID",@"DeviceID",@"CommonID",@"CustomerName",@"CustomerAddress",@"CustomerRelationType",@"DriverName",@"AmountPaid",@"Latitude",@"Longitude",@"TravelledDistance",@"ActualDistance",@"PaymentType",@"PatientID",@"PatientName",@"PatientPhone",@"StartLocationLatitude",@"StartLocationLongitude",nil];
        
        NSDictionary *propertiesGPS = [NSDictionary dictionaryWithObjects:arr_valGPS forKeys:propertyNamesGPS];
        
        NSMutableDictionary *newUserObjectGPS = [NSMutableDictionary dictionary];
        
        [newUserObjectGPS setObject:propertiesGPS forKey:@"ObjGPSDeliveredInfo"];
        
        
        NSData *jsonDataGPS = [NSJSONSerialization dataWithJSONObject:newUserObjectGPS options:kNilOptions error:nil];
        NSString *jsonStringGPS = [[NSString alloc] initWithData:jsonDataGPS encoding:NSUTF8StringEncoding];
        NSString *str_service3GPS=[NSString stringWithFormat:@"GPSDeliveredInfo"];
        
        
        str_service3GPS=[manage.str_url stringByAppendingString:str_service3GPS];
        
        
        NSMutableURLRequest *requestGPS = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3GPS] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [requestGPS setHTTPMethod:@"POST"];
       // [requestGPS setValue:jsonStringGPS forHTTPHeaderField:@"json"];
        [requestGPS setHTTPBody:jsonDataGPS];
        [requestGPS setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *errorGPS = nil;
        NSURLResponse *theResponseGPS = [[NSURLResponse alloc]init];
        NSData *dataGPS = [NSURLConnection sendSynchronousRequest:requestGPS returningResponse:&theResponseGPS error:&errorGPS];
        if(dataGPS)
        {
            NSDictionary *jsonArrayGPS =[NSJSONSerialization JSONObjectWithData:dataGPS options:NSJSONReadingMutableContainers error:&errorGPS];
            NSLog(@"%@",jsonArrayGPS);
            
                // NSDictionary *tranGPS=jsonArrayGPS[@"GPSDeliveredInfoResult"];
            
                //  NSString *str_GPS=tranGPS[@"TransactionId"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
                
                if ([manage.GPSallow isEqualToString:@"Yes"])
                {
                    
                }
                else
                {
                        //[self.locationManager stopUpdatingLocation];
                    
                }
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                BOOL ConditionSig=[[DBManager getSharedInstance]deleteLocalArray:str_POSID StoreID:manage.arr_storeInfoList[@"StoreID"]];
                
                
                
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                view_activity.hidden=YES;
                
                view_PaymentConfirm.hidden=NO;
                
                lab_deliveredCount.text=[NSString stringWithFormat:@"Total number of Items Delivered: %lu",(unsigned long)arr_RxNumberr.count];
                
                if ([manage.GPSallow isEqualToString:@"Yes"])
                {
                    
                }
                else
                {
                        //[self.locationManager stopUpdatingLocation];
                    
                }
            });
            
        }
    });
    
}

#pragma mark - Payment Confirmation


-(IBAction)btn_ok:(id)sender
{
    [self restrictRotation:NO];
    
    [manage.arr_ArChargeID removeAllObjects];
    
    
    OnlineList *vc=[[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
    vc.str_DelivSearchDate=@"No";
    vc.str_PaymentLogID=str_POSID;
    [self.navigationController pushViewController:vc animated:NO];
    [self restrictRotation:NO];
    
}
/*
 -(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
 {
 if (alertView.tag==999)
 {
 
 
 }
 }
 
 */


#pragma mark - Button Back


-(IBAction)btn_back:(id)sender
{
    
    if ([manage.GPSallow isEqualToString:@"Yes"])
    {
        
    }
    else
    {
            // [self.locationManager stopUpdatingLocation];
        
    }
    
    
    
    txt_name.text=@"";
    txt_relation.text=@"";
    [signatureView clearSignature];
    
    [self restrictRotation:NO];
    
    [self.navigationController popViewControllerAnimated:NO];
    
}


-(void)RelationList
{
    self.view_activity.hidden=NO;
    
    [arr_relationList removeAllObjects];
    [arr_relationListName removeAllObjects];

    
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
            // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
        // NSString *myurlString = @"http://192.168.1.58:8085/Delivery.svc/DeliveryLogByUserID/100010/15/2-23-2017/2-23-2017";
        // str_StartDate=@"04-19-2017";
        // str_EndDate=@"04-19-2017";
        
        // NSString *str_DriverName1=@"";
        
        NSString *str_urrl=[NSString stringWithFormat:@"GetPatientRelationByStoreID/%@",manage.arr_storeInfoList[@"StoreID"]];
        
        // NSString *str_urrl=[NSString stringWithFormat:@"DeliveryDetailByID/%@/%@/%@/%@/CURRENT",manage.arr_storeInfoList[@"StoreID"],str_StartDate,str_EndDate,str_DriverName1];
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
        // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
            //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"GetPatientRelationByStoreIDResult"];
            
            NSLog(@"%@",arr_Content);
            
            //  arr_LogIDList= jsonArray[@"DeliveryLogByUserIDResult"];
            
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    
                    
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        [itemshowdetails setValue:temp[@"ID"] forKey:@"ID"];
                        [itemshowdetails setValue:temp[@"RelationShipType"] forKey:@"RelationShipType"];
                        [itemshowdetails setValue:temp[@"RelationShipTypeDesc"] forKey:@"RelationShipTypeDesc"];

                        [arr_relationList addObject:itemshowdetails];
                    }
                    
                    for (int i = 0; i<arr_relationList.count; i++) {
                        
                        [arr_relationListName addObject:arr_relationList[i][@"RelationShipType"]];
                    }
                    
                    NSLog(@"%@", arr_relationList);
                    
                    
                    
                    //  [table_driverlist reloadData];
                    
                    self.view_activity.hidden=YES;
                    
                    
                });
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [activityIndicatorView stopAnimating];
                
                
                self.view_activity.hidden=YES;
                
                
            });
        }
    });
}



#pragma mark - Button Relation

-(IBAction)btn_relation:(id)sender
{
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select"
                                                             delegate:self
                                                    cancelButtonTitle:@"Cancel"
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:nil, nil];
    for (NSString *title in arr_relationListName)
        
    {
        [actionSheet addButtonWithTitle:title];
    }
    actionSheet.tag = 10;
    [actionSheet showInView:self.view];
    
    // else if (str_am_flag isEqualToString:@"")
    
}


/*
-(IBAction)btn_relation:(id)sender
{
    
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
    {
        
     //    Device is iPad
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select Relation"
                                                                 delegate:self
                                                        cancelButtonTitle:@"Cancel"
                                                   destructiveButtonTitle:@"Self"
                                                        otherButtonTitles:@"Spouse",@"Father",@"Mother", @"Child",@"Siblings", @"Employee", @"Life Partner",@"Other Relationship", nil];
        
        [actionSheet showInView:self.view];
        
        
    }
    
    
    else{
        
        UIAlertController *actionSheet = [[UIAlertController alloc]init];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            
                // Cancel button tappped.
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Spouse" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            txt_relation.text=@"Spouse";
            txt_name.text=@"";
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Self" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            txt_relation.text=@"Self";
            txt_name.text=str_PatientName;
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Father" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            txt_relation.text=@"Father";
            txt_name.text=@"";
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Mother" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            txt_relation.text=@"Mother";
            txt_name.text=@"";
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Child" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            txt_relation.text=@"Child";
            txt_name.text=@"";
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Siblings" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            txt_relation.text=@"Siblings";
            txt_name.text=@"";
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Employee" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            txt_relation.text=@"Employee";
            txt_name.text=@"";
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Life Partner" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            txt_relation.text=@"Life Partner";
            txt_name.text=@"";
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Other Relationship" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            txt_relation.text=@"Other Relationship";
            txt_name.text=@"";
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [self presentViewController:actionSheet animated:YES completion:nil];
        
    }
    
}
*/



-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (actionSheet.tag==10)
    {
        if (buttonIndex==0) {
            
        }
        else{
            NSString *strname = arr_relationListName[buttonIndex-1];
            if ([strname isEqualToString:@"Self"]) {
                txt_relation.text=arr_relationListName[buttonIndex-1];
                txt_name.text=str_PatientName;
            }
            else{
                txt_relation.text=arr_relationListName[buttonIndex-1];
                txt_name.text=@"";
            }
            
        }
        
        /*
    if  ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Spouse"])
    {
        
        txt_relation.text=@"Spouse";
        txt_name.text=@"";
        
    }
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Self"])
    {
        
        txt_relation.text=@"Self";
        txt_name.text=str_PatientName;
        
        
    }
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Unknown"])
    {
        
        txt_relation.text=@"Unknown";
        txt_name.text=@"";
        
        
    }
    
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Child"])
    {
        txt_relation.text=@"Child";
        txt_name.text=@"";
        
        
    }
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Employee"])
    {
        
        txt_relation.text=@"Employee";
        txt_name.text=@"";
        
    }
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Organ Donor"])
    {
        
        txt_relation.text=@"Organ Donor";
        txt_name.text=@"";
        
    }
    
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Cadaver Donor"])
        
    {
        
        txt_relation.text=@"Cadaver Donor";
        txt_name.text=@"";
        
    }
    
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Life Partner"])
        
    {
        txt_relation.text=@"Life Partner";
        txt_name.text=@"";
        
        
    }
    
    else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Other Relationship"])
        
    {
        txt_relation.text=@"Other Relationship";
        txt_name.text=@"";
        
        
    }
    */
        //([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Custom"])
    
    
    
    
}
}



#pragma mark - Textfield


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==txt_name)
    {
        [txt_name resignFirstResponder];
    }
    
    return YES;
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}


- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self view] endEditing:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
