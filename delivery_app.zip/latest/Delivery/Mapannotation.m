//
//  Mapannotation.m
//
//
//  Created by Barani Elangovan on 10/6/16.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "Mapannotation.h"

@implementation Mapannotation

-(id)initWithTitle:(NSString *)title andCoordinate:
(CLLocationCoordinate2D)coordinate2d{
    self.title = title;
    self.coordinate= coordinate2d;
  
    return self;
}

@end
