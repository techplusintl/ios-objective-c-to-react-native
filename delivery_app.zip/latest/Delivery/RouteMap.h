//
//  RouteMap.h
//  Delivery
//
//  Created by Barani Elangovan on 4/18/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "CustomAnnotation.h"
#import "AppDelegate.h"

#import "singleton.h"
#import "OnlineListCellDistance.h"
#import <UIKit/UIKit.h>

#import "DeliveredDetailedScreen.h"
#import "DetailedScreen.h"

@interface RouteMap : UIViewController<CLLocationManagerDelegate>
{
    singleton *manage;
}
@property(strong,nonatomic)NSString *str_viewType;
@property(strong,nonatomic)NSString *str_ListType;


@property(strong,nonatomic)NSMutableArray *arr_AddressMain;

@property(strong,nonatomic)IBOutlet UIView *view_Walk;
@property(strong,nonatomic)IBOutlet UIView *view_Driving;


@property (nonatomic,strong) CLLocationManager *locationManager;
@property (strong, nonatomic) IBOutlet MKMapView * mapView;
@property(strong,nonatomic)IBOutlet UIView *view_Map;
@property(strong,nonatomic)IBOutlet UIView *view_List;
@property(strong,nonatomic)IBOutlet UITableView *table_List;
@property(strong,nonatomic)IBOutlet UIImageView *image_Location;
@property(strong,nonatomic)IBOutlet UIButton *btn_Location;

@property(strong,nonatomic)IBOutlet UIView *view_NoData;

@end
