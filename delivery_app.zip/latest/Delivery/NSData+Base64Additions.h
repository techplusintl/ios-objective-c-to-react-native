//
//  NSData+Base64Additions.h
//  RockPaperScissors
//
//  Created by Barani Elangovan on Tue Mar 18 2017.
//  Copyright (c) 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NSData (Base64Additions)

+(id)decodeBase64ForString:(NSString *)decodeString;
+(id)decodeWebSafeBase64ForString:(NSString *)decodeString;

-(NSString *)encodeBase64ForData;
-(NSString *)encodeWebSafeBase64ForData;
-(NSString *)encodeWrappedBase64ForData;

@end
