//
//  AppDelegate.h
//  Delivery
//
//  Created by Rex on 16/02/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>


@class ViewController;

@class OnlineList;

#import "singleton.h"
#import <CoreLocation/CoreLocation.h>

#import "SKPSMTPMessage.h"
#import "NSData+Base64Additions.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate,SKPSMTPMessageDelegate,UIAlertViewDelegate>
{
    singleton *manage;
}
void uncaughtExceptionHandler(NSException *exception);

@property BOOL restrictRotation;

@property (nonatomic,strong) CLLocationManager *locationManagerBack;


@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;
@property (strong, nonatomic) UINavigationController *navigationcontroller;


@end

