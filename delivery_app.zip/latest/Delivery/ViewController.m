//
//  ViewController.m
//  Delivery
//
//  Created by Rex on 16/02/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "ViewController.h"

#import "DGActivityIndicatorView.h"
#import "AppDelegate.h"
#import <LocalAuthentication/LocalAuthentication.h>
static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;



@interface ViewController ()
{
    
    NSMutableDictionary *arrayOfData;

    NSMutableArray *arr_LoginPharmacy;
    DGActivityIndicatorView *activityIndicatorView;
    
    NSArray *activityTypes;

    NSString *str_localserverHostURL;
    CommanMethods* commonmethod;
}
//@property(strong, nonatomic) NSMutableArray *ResultArray;

@end

@implementation ViewController
@synthesize text_StoreNumber, text_UserId, text_Password,  btn_login, image_background,view_activity,view_offline_alert, view_offlineBackground,str_AutoLogOut,view_fingerprint;
- (void)viewDidLoad {
    [super viewDidLoad];
    /*
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"HasLaunchedOnce"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    */
    text_Password.text = @"user1";
    BOOL hasTouchID = NO;
    // if the LAContext class is available
    if ([LAContext class]) {
        LAContext *context = [LAContext new];
        NSError *error = nil;
        hasTouchID = [context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    }
    
    
    
  //  view_fingerprint.hidden = YES;
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"HasLaunchedOnce"] == NO) {
        view_fingerprint.hidden = YES;
    }
    else
    {
        if (@available(iOS 11.0, *)) {
            LAContext *context = [[LAContext alloc] init];
            if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:nil]){
                BOOL faceID = ( context.biometryType == LABiometryTypeFaceID);
                if (faceID)
                {
                    view_fingerprint.hidden = YES;
                }
                else
                {
                    view_fingerprint.hidden = NO;
                    [self FingerPrint];
                }
            }
            else
            {
                view_fingerprint.hidden = YES;
            }
        }
        
        
        
    }
    
    
    /*
    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] isEqualToString:@""] || [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] == nil ||  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] isEqual:[NSNull null]] || [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] isEqualToString:@""] ||
       [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] == nil ||  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] isEqual:[NSNull null]] ||[[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] isEqualToString:@""] ||
       [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] == nil ||  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] isEqual:[NSNull null]])
    {
        view_fingerprint.hidden = YES;
    }
    else
    {
        view_fingerprint.hidden = NO;
    }
    */

    
    arrayOfData=[[NSMutableDictionary alloc]init];
          NSLog(@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]);
    NSLog(@"%@", arrayOfData);
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
            
        [self restrictRotation:NO];
        
    }
    
    else
    {
        
        
    }
    if ([str_AutoLogOut isEqualToString:@"Yes"])
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Unable to process your request. Please try again later!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else
    {
        
    }
    
    
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLatitude"];
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLongitude"];
    
    [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
    
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLatitude1"];
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLongitude1"];
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"ActualDistance"];
    [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"AdminLogin"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    
    
    manage=[singleton share];
    
    
    NSLog(@"%@ &&&& %@",manage.str_iTunesVersion,manage.str_CurrentVresion);
    
    
    if ([manage.str_iTunesVersion compare:manage.str_CurrentVresion options:NSNumericSearch] == NSOrderedDescending)
    {
        NSString *str_msg=[NSString stringWithFormat:@"A new version of digitalRx Delivery is available. Please update to version %@ now.",manage.str_iTunesVersion];
        
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Update Available" message:str_msg preferredStyle:UIAlertControllerStyleAlert];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"Update" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                    {
                                            //1184319808
                                        
                                            //https://itunes.apple.com/us/app/digitalrx-delivery/id1206878488?mt=8
                                        
                                        manage.str_updatee=@"Yes";
                                        
                                        NSString *iTunesLink = @"https://itunes.apple.com/us/app/digitalrx-delivery/id1206878488";
                                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
                                    }]];
        
        
        dispatch_async(dispatch_get_main_queue(), ^ {
            [self presentViewController:alertController animated:YES completion:nil];
        });
        
    }

    else
    {
        manage.str_updatee=@"No";

    }
    
    
    view_activity.hidden=YES;
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
    [self.navigationController setNavigationBarHidden:YES];
    
    
    
    view_offlineBackground.hidden=YES;

    
    
    
    btn_login.layer.cornerRadius = 3;

    
    BOOL isIPhone = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone;
    BOOL isIPhone_4s = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=481.0);
    BOOL isIPhone_se = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=569.0);
    BOOL isIPhone_6s = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=668.0);
    BOOL isIPhone_6s_plus = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=
                                         737);
    
    
    //BOOL isIPad = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
        //  NSLog(@"iphone");
        if(orientation == UIInterfaceOrientationPortrait)
        {
            if (isIPhone_4s) {
                image_background.image = [UIImage imageNamed:@"320x480.jpg"];
            }
            else if (isIPhone_se) {
                image_background.image = [UIImage imageNamed:@"320x568.jpg"];
            }
            
            else if (isIPhone_6s) {
                image_background.image = [UIImage imageNamed:@"375x667.jpg"];
            }
            else if (isIPhone_6s_plus) {
                image_background.image = [UIImage imageNamed:@"414x736.jpg"];
            }
            else{
                image_background.image = [UIImage imageNamed:@"414x736.jpg"];
            }
            
        }
        
        else if(orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight)
        {
            
        }
    }
    else
    {
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
        
        if(orientation == UIInterfaceOrientationPortrait)
        {
    }
        else if(orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight)
        {
            
        }
    }
    
  

 //   str_localserverHostURL=@"http://www.dbsuatserver.com/DeliveryTest/Delivery.svc/";

// Development
  //  str_localserverHostURL=@"http://www.dbsuatserver.com/DigitalRxDeliveryIOS/Delivery.svc/";
  //  str_localserverHostURL=@"http://35.188.173.117/DigitalRxDeliveryIOS/Delivery.svc/";
   // str_localserverHostURL=@"http://192.168.2.12:8082/DeliveryIOS/Delivery.svc/";
    
    
    // Production
    str_localserverHostURL=@"http://www.dbsuatserver.com/DigitalRxDeliveryIOS/Delivery.svc/";

    
    
 ///////   str_localserverHostURL=@"http://146.148.93.102/DeliveryTest/Delivery.svc/";
  //  str_localserverHostURL=@"http://146.148.93.102/DigitalRxDeliveryIOS/Delivery.svc/";

    
    
    manage.str_url=str_localserverHostURL;
    
    
    manage.activityTypes = @[@(DGActivityIndicatorAnimationTypeBallClipRotate)];
    
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"HasLaunchedOnce"] == NO) {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
            });
            
            SKPSMTPMessage *emailMessage = [[SKPSMTPMessage alloc] init];
            
                emailMessage.fromEmail = @"donotreply@rxcity.com"; //sender email address
                emailMessage.toEmail = @"admin@rxcity.com";  //receiver email address
            
              
            
            emailMessage.relayHost = @"smtp.gmail.com";
                //emailMessage.ccEmail =@"your cc address";
                //emailMessage.bccEmail =@"your bcc address";
            emailMessage.requiresAuth = YES;
            
            
            
                emailMessage.login = @"donotreply@rxcity.com"; //sender email address
                emailMessage.pass = @"donotreply298+"; //sender email password
            
                      
            
            emailMessage.subject =@"digitalRx Delivery iPhone App - New User";
            emailMessage.wantsSecure = YES;
            emailMessage.delegate = self; // you must include <SKPSMTPMessageDelegate> to your class
                                          // UIDevice *deviceInfo = [UIDevice currentDevice];
                                          //  NSLog(@"%@",deviceInfo.)
            NSString *messageBody = [NSString stringWithFormat:@"User Device UDID Number: %@\nUser Device Model: %@\nUser Device Name: %@",[[[UIDevice currentDevice] identifierForVendor] UUIDString],[[UIDevice currentDevice] model], [[UIDevice currentDevice] name]];
                // Now creating plain text email message
            NSDictionary *plainMsg = [NSDictionary
                                      dictionaryWithObjectsAndKeys:@"text/plain",kSKPSMTPPartContentTypeKey,
                                      messageBody,kSKPSMTPPartMessageKey,@"8bit",kSKPSMTPPartContentTransferEncodingKey,nil];
            emailMessage.parts = [NSArray arrayWithObjects:plainMsg,nil]; //including plain msg and attached file msg
            dispatch_async(dispatch_get_main_queue(), ^{
                
            [emailMessage send];
            });
        });
    } else
    {
            // app already launched
    }


    NSString *checkcond= [[NSUserDefaults standardUserDefaults]stringForKey:@"checked"];
    if ([checkcond isEqualToString:@"YES"]) {
        text_UserId.text=[[NSUserDefaults standardUserDefaults]stringForKey:@"username"];
        text_StoreNumber.text=[[NSUserDefaults standardUserDefaults]stringForKey:@"storeAccount"];
        [self.mySwitch setOn:YES];
    }
    else{
        // text_UserId.text=@"";
        [self.mySwitch setOn:NO];
    }
    
    [self.mySwitch addTarget:self
                      action:@selector(switchIsChanged:)
            forControlEvents:UIControlEventValueChanged];
    
 activityTypes = @[@(DGActivityIndicatorAnimationTypeBallClipRotate)]; activityTypes = @[@(DGActivityIndicatorAnimationTypeBallClipRotate)];

    // Do any additional setup after loading the view, typically from a nib.
}


-(void)FingerPrint{
    
    LAContext *context = [[LAContext alloc] init];
    NSError *error = nil;
    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics
                localizedReason:@"Login using Touch ID?"
                          reply:^(BOOL success, NSError *error) {
                              dispatch_async(dispatch_get_main_queue(), ^{
                                  if (error) {
                                      /*
                                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                      message:@"There was a problem verifying your identity."
                                                                                     delegate:nil
                                                                            cancelButtonTitle:@"Ok"
                                                                            otherButtonTitles:nil];
                                      [alert show];
                                       */
                                      return;
                                  }
                                  
                                  if (success) {
                                      
                                      
                                      if([[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] isEqualToString:@""] || [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] == nil ||  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] isEqual:[NSNull null]] || [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] isEqualToString:@""] ||
                                         [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] == nil ||  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] isEqual:[NSNull null]] ||[[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] isEqualToString:@""] ||
                                          [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] == nil ||  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] isEqual:[NSNull null]])
                                      {
                                          UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                                                          message:@"Login Details Not Available."
                                                                                         delegate:nil
                                                                                cancelButtonTitle:@"Ok"
                                                                                otherButtonTitles:nil];
                                          [alert show];
                                      }
                                      else
                                      {
                                          text_StoreNumber.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"];
                                          text_UserId.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"];
                                          text_Password.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"];
                                          [self login];
                                      }
                                      /*
                                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                                                                      message:@"You are the device owner!"
                                                                                     delegate:nil
                                                                            cancelButtonTitle:@"Ok"
                                                                            otherButtonTitles:nil];
                                      [alert show];
                                      */
                                      
                                      
                                  } else {
                                      
                                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                      message:@"Your Touch ID not registered."
                                                                                     delegate:nil
                                                                            cancelButtonTitle:@"Ok"
                                                                            otherButtonTitles:nil];
                                      [alert show];
                                      
                                  }
                              });
                          }];
        
    } else {
        view_fingerprint.hidden = YES;
        /*
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:@"Your device cannot authenticate using TouchID."
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil];
        [alert show];
        */
    }
}

-(IBAction)btn_fingerprint:(id)sender
{
    [self FingerPrint];
}

#pragma mark - Rotation fuction

-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}

#pragma mark - New Install Mail

-(void)messageSent:(SKPSMTPMessage *)message
{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"HasLaunchedOnce"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
        //NSLog(@"Message Send");
}
-(void)messageFailed:(SKPSMTPMessage *)message error:(NSError *)error
{
    
    
}

#pragma mark - Switch Button

- (void) switchIsChanged:(UISwitch *)paramSender{
    
    if ([paramSender isOn]){
        // NSLog(@"The switch is turned on.");
        [[NSUserDefaults standardUserDefaults]setObject:text_UserId.text forKey:@"username"];
        [[NSUserDefaults standardUserDefaults]setObject:text_StoreNumber.text forKey:@"storeAccount"];
        
        // user=@"hello";
        [[NSUserDefaults standardUserDefaults]setObject:@"YES" forKey:@"checked"];
        
    } else {
        // NSLog(@"The switch is turned off.");
        [[NSUserDefaults standardUserDefaults]removeSuiteNamed:@"username"];
        [[NSUserDefaults standardUserDefaults]removeSuiteNamed:@"storeAccount"];
        
        [[NSUserDefaults standardUserDefaults]setObject:@"NO" forKey:@"checked"];
        //user=@"";
    }
    [[NSUserDefaults standardUserDefaults]synchronize];
    
}


#pragma mark - Login Service

-(IBAction)btn_login:(id)sender
/*{
    HomeScreen *ln = [[HomeScreen alloc]initWithNibName:@"HomeScreen" bundle:nil];
    [self.navigationController pushViewController:ln animated:NO];
}*/
{
    [self login];
}

-(void)login
{
    NSString *strLoginId=text_StoreNumber.text;
    NSString *strLoginName=text_UserId.text;
    NSString *strLoginPass=text_Password.text;
    
    [arr_LoginPharmacy removeAllObjects];
    [[self view] endEditing:YES];
    
    if (text_StoreNumber.text.length ==0)
    {
        [text_StoreNumber becomeFirstResponder];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Store Account # is empty!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    else if (text_UserId.text.length ==0 )
    {
        [text_UserId becomeFirstResponder];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"User ID is empty!" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else if (text_Password.text.length ==0)
    {
        [text_Password becomeFirstResponder];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Password is empty!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
    else
    {
        if (_mySwitch.isOn)
        {
            [[NSUserDefaults standardUserDefaults]setObject:text_UserId.text forKey:@"username"];
            // user=@"hello";
            [[NSUserDefaults standardUserDefaults]setObject:@"YES" forKey:@"checked"];
            [[NSUserDefaults standardUserDefaults]setObject:text_StoreNumber.text forKey:@"storeAccount"];
            
        }
        else
        {
            [[NSUserDefaults standardUserDefaults]removeSuiteNamed:@"username"];
            [[NSUserDefaults standardUserDefaults]removeSuiteNamed:@"storeAccount"];
            [[NSUserDefaults standardUserDefaults]setObject:@"NO" forKey:@"checked"];
            
        }
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        self.view_activity.hidden=NO;
        [activityIndicatorView removeFromSuperview];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
            dispatch_async(dispatch_get_main_queue(), ^{
                
                for(int i=0; i<activityTypes.count;i++)
                {
                    activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                    CGFloat width = self.view.bounds.size.width;
                    CGFloat height = self.view.bounds.size.height;
                    
                    activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                    [self.view addSubview:activityIndicatorView];
                    [activityIndicatorView startAnimating];
                }
                
            });
            
            NSString *str_urrl=[NSString stringWithFormat:@"DeliveryInfo/%@/%@/%@",strLoginId,strLoginName,strLoginPass];
            
            NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
            NSLog(@"%@", myurlString);
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
            
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            NSError *err;
            NSURLResponse *response;
            
            NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            //   NSLog(@"%@",responsedata);
            
            if (responsedata)
            {
                NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"%@",jsonArray);
                
                manage.arr_storeInfoList=jsonArray[@"DeliveryInfoResult"];
                NSLog(@"%@",manage.arr_storeInfoList);
                
                if ([manage.arr_storeInfoList[@"StoreID"]intValue]<=0)
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        
                        
                        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid information to Sign In" preferredStyle:UIAlertControllerStyleAlert];
                        
                        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                        [alertController addAction:ok];
                        
                        [self presentViewController:alertController animated:YES completion:nil];
                        
                        [activityIndicatorView stopAnimating];
                        activityIndicatorView.hidden = YES;
                        
                    });
                }
                else
                {
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        manage.str_DriverName=text_UserId.text;
                        manage.str_LoginPassword=text_Password.text;
                        [activityIndicatorView stopAnimating];
                        
                        [[NSUserDefaults standardUserDefaults]setObject:text_UserId.text forKey:@"LastLoginUserID"];
                        [[NSUserDefaults standardUserDefaults]setObject:text_Password.text forKey:@"LastLoginPassword"];
                        [[NSUserDefaults standardUserDefaults]setObject:text_StoreNumber.text forKey:@"LastLoginStoreID"];
                        
                        /* [arrayOfData setObject: manage.arr_storeInfoList[@"AccessLevel"] forKey:@"AccessLevel"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"AccessLevelID"] forKey:@"AccessLevelID"];
                         
                         [arrayOfData setObject: manage.arr_storeInfoList[@"DeliveryAppAccessLevel"] forKey:@"DeliveryAppAccessLevel"];
                         
                         [arrayOfData setObject: manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"] forKey:@"DeliveryAppAccessLevelID"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"MerchantAccount"] forKey:@"MerchantAccount"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"MerchantPassword"] forKey:@"MerchantPassword"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyCity"] forKey:@"PharmacyCity"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyEmail"] forKey:@"PharmacyEmail"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyFax"] forKey:@"PharmacyFax"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyName"] forKey:@"PharmacyName"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyPhone"] forKey:@"PharmacyPhone"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyState"] forKey:@"PharmacyState"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyZip"] forKey:@"PharmacyZip"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"StoreID"] forKey:@"StoreID"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"UserFirstName"] forKey:@"UserFirstName"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"UserID"] forKey:@"UserID"];
                         [arrayOfData setObject: manage.arr_storeInfoList[@"UserLastName"] forKey:@"UserLastName"];
                         
                         
                         
                         [[NSUserDefaults standardUserDefaults]setObject:arrayOfData forKey:@"LastLoginResult"];
                         
                         
                         DeviceAuthentication *ln = [[DeviceAuthentication alloc]initWithNibName:@"DeviceAuthentication" bundle:nil];
                         
                         [self.navigationController pushViewController:ln animated:NO];
                         */
                        
                        [self storeConfig];
                        
                    });
                    
                    
                }
            }
            
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginStoreID"] isEqualToString:text_StoreNumber.text] && [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] isEqualToString:text_UserId.text] && [[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginPassword"] isEqualToString:text_Password.text] )
                    {
                        manage.str_DriverName=text_UserId.text;
                        manage.str_LoginPassword=text_Password.text;
                        [activityIndicatorView stopAnimating];
                        self.view_activity.hidden=YES;
                        
                        manage.arr_storeInfoList=[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginResult"];
                        
                        OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
                        ln.str_DelivSearchDate=@"Login";
                        [self.navigationController pushViewController:ln animated:NO];
                    }
                    else
                    {
                        if([[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"] isEqualToString:text_UserId.text])
                        {
                            self.view_activity.hidden=YES;
                            [activityIndicatorView stopAnimating];
                            
                            
                            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please provide valid information to Sign In" preferredStyle:UIAlertControllerStyleAlert];
                            
                            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                            [alertController addAction:ok];
                            
                            [self presentViewController:alertController animated:YES completion:nil];
                            
                            [activityIndicatorView stopAnimating];
                            activityIndicatorView.hidden = YES;
                        }
                        else
                        {
                            self.view_activity.hidden=YES;
                            [activityIndicatorView stopAnimating];
                            
                            NSString *str_TTLogName=[NSString stringWithFormat:@"You have already logged by '%@' before offline, can't login by another user in offline",[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginUserID"]];
                            
                            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:str_TTLogName preferredStyle:UIAlertControllerStyleAlert];
                            
                            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                            [alertController addAction:ok];
                            
                            [self presentViewController:alertController animated:YES completion:nil];
                            
                            [activityIndicatorView stopAnimating];
                            activityIndicatorView.hidden = YES;
                        }
                        
                    }
                    
                });
            }
        });
    }
    
    
}
    



-(void)storeConfig
{
    
    NSString *strLoginId=text_StoreNumber.text;

    
    self.view_activity.hidden=NO;
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            
            for(int i=0; i<activityTypes.count;i++)
            {
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[activityTypes[i] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                CGFloat width = self.view.bounds.size.width;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                [self.view addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            }
            
        });
        
        NSString *str_urrl1=[NSString stringWithFormat:@"GetStoreInfoByStoreID/%@",strLoginId];
        
        NSString *myurlString1 = [manage.str_url stringByAppendingString:str_urrl1];
        
        
        NSMutableURLRequest *request1 = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString1] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
        
        [request1 setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err1;
        NSURLResponse *response1;
        
        NSData *responsedata1 = [NSURLConnection sendSynchronousRequest:request1 returningResponse:&response1 error:&err1];
            //   NSLog(@"%@",responsedata);
        
        if (responsedata1)
        {
            NSDictionary *jsonArray1 = [NSJSONSerialization JSONObjectWithData:responsedata1 options:NSJSONReadingMutableContainers error:&err1];
            
            NSDictionary *storeConfigg=jsonArray1[@"GetStoreInfoByStoreIDResult"];
            
            /*AccessLevel = Admin;
             AccessLevelID = 4;
             DeliveryAppAccessLevel = Admin;
             DeliveryAppAccessLevelID = 4;
             MerchantAccount = 7515979;
             MerchantPassword = "loopw$4Rfs";
             PharmacyCity = IRVINE;
             PharmacyEmail = "qateam@rxcity.com";
             PharmacyFax = "866-740-4689";
             PharmacyName = "DBS OUTLOOK DEVELOPMENT SERVER STORE";
             PharmacyPhone = "949-298-6661";
             PharmacyState = CA;
             PharmacyStreet = "200 Rittenhouse Circle East, Suite 3";
             PharmacyZip = 90002;
             StoreID = 900100;
             UserFirstName = RXUSER;
             UserID = 1;
             UserLastName = RXUSER;
*/
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                manage.str_DriverName=text_UserId.text;
                manage.str_LoginPassword=text_Password.text;
                [activityIndicatorView stopAnimating];
                
                [[NSUserDefaults standardUserDefaults]setObject:text_UserId.text forKey:@"LastLoginUserID"];
                [[NSUserDefaults standardUserDefaults]setObject:text_Password.text forKey:@"LastLoginPassword"];
                [[NSUserDefaults standardUserDefaults]setObject:text_StoreNumber.text forKey:@"LastLoginStoreID"];
                
                [arrayOfData setObject: manage.arr_storeInfoList[@"AccessLevel"] forKey:@"AccessLevel"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"AccessLevelID"] forKey:@"AccessLevelID"];
                
                [arrayOfData setObject: manage.arr_storeInfoList[@"DeliveryAppAccessLevel"] forKey:@"DeliveryAppAccessLevel"];
                
                [arrayOfData setObject: manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"] forKey:@"DeliveryAppAccessLevelID"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"MerchantAccount"] forKey:@"MerchantAccount"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"MerchantPassword"] forKey:@"MerchantPassword"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyCity"] forKey:@"PharmacyCity"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyEmail"] forKey:@"PharmacyEmail"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyFax"] forKey:@"PharmacyFax"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyName"] forKey:@"PharmacyName"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyPhone"] forKey:@"PharmacyPhone"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyState"] forKey:@"PharmacyState"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyStreet"] forKey:@"PharmacyStreet"];
                
                [arrayOfData setObject: manage.arr_storeInfoList[@"PharmacyZip"] forKey:@"PharmacyZip"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"StoreID"] forKey:@"StoreID"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"UserFirstName"] forKey:@"UserFirstName"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"UserID"] forKey:@"UserID"];
                [arrayOfData setObject: manage.arr_storeInfoList[@"UserLastName"] forKey:@"UserLastName"];
              //  [arrayOfData setObject: manage.arr_storeInfoList[@"AccessToDeleteRx"] forKey:@"AccessToDeleteRx"];
                [arrayOfData setObject:[[CommanMethods alloc]nullHandler:manage.arr_storeInfoList[@"AccessToDeleteRx"]] forKey:@"AccessToDeleteRx"];
                [arrayOfData setObject:[[CommanMethods alloc]nullHandler:manage.arr_storeInfoList[@"EditThisDelivery"]] forKey:@"EditThisDelivery"];

            
             //   [arrayOfData setObject:[commonmethod nullHandler:storeConfigg[@"DeliveryAppDisplayDrugName"]] forKey:@"DeliveryAppDisplayDrugName"];
                [arrayOfData setObject:[[CommanMethods alloc]nullHandler:manage.arr_storeInfoList[@"AccessToOutForDelivery"]] forKey:@"AccessToOutForDelivery"];


                [arrayOfData setObject:[[CommanMethods alloc]nullHandler:storeConfigg[@"DeliveryAppDefaultRelation"]] forKey:@"DeliveryAppDefaultRelation"];
                [arrayOfData setObject:[[CommanMethods alloc]nullHandler:storeConfigg[@"DeliveryAppDisplayDrugName"]] forKey:@"DeliveryAppDisplayDrugName"];
                [arrayOfData setObject:[[CommanMethods alloc]nullHandler:storeConfigg[@"DeliveryAppDisplayPatientName"]] forKey:@"DeliveryAppDisplayPatientName"];


                
                [[NSUserDefaults standardUserDefaults]setObject:arrayOfData forKey:@"LastLoginResult"];
                
                manage.arr_storeInfoList=[[NSUserDefaults standardUserDefaults] objectForKey:@"LastLoginResult"];
/*
                if ([text_UserId.text isEqualToString:@"rxuser"] && [text_StoreNumber.text isEqualToString:@"100999"] && [text_Password.text isEqualToString:@"user1"]) {
                    OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
                    ln.str_DelivSearchDate=@"Login";
                    [self.navigationController pushViewController:ln animated:NO];
                }
                else{
 }
                    */
                
                //Old way with device auth
                //DeviceAuthentication *ln = [[DeviceAuthentication alloc]initWithNibName:@"DeviceAuthentication" bundle:nil];
                
                //bypass device auth
                OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
                
                [self.navigationController pushViewController:ln animated:NO];
                
                
            });
            
            
        }
    });
}
-(IBAction)btn_SignInHelp:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Sign In Help";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Terms:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Terms and Condition";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Privacy:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Privacy Statement";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Call:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Help";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Map:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Map";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_ForgotUserID:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Forgot User ID";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_ForgotPassword:(id)sender
{
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Forgot Password";
    [self.navigationController pushViewController:ln animated:NO];
}

-(IBAction)btn_DeleteTable:(id)sender
{
    BOOL success = NO;
    success=  [[DBManager getSharedInstance]addColumn];
    if (success ==NO)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Not Added" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        [activityIndicatorView stopAnimating];
        activityIndicatorView.hidden = YES;
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Column Added" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        [activityIndicatorView stopAnimating];
        activityIndicatorView.hidden = YES;

    }

}
#pragma mark - Textfield

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self view] endEditing:YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==text_StoreNumber)
    {
        [text_UserId becomeFirstResponder];
    }
   else if (textField==text_UserId)
    {
        [text_Password becomeFirstResponder];
    }
    else if (textField==text_Password)
    {
        [text_Password resignFirstResponder];
        
    }
    
    
    return YES;
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
