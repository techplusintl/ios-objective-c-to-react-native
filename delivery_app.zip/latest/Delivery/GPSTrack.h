//
//  GPSTrack.h
//  Delivery
//
//  Created by Barani Elangovan on 4/27/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

#import "singleton.h"

@interface GPSTrack : UIViewController<MKMapViewDelegate>
{
    singleton *manage;
}

@property(strong,nonatomic)IBOutlet MKMapView *mapVieww;

@end
