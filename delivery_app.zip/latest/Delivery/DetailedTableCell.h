//
//  DetailedTableCell.h
//  Delivery
//
//  Created by Barani Elangovan on 5/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailedTableCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lab_Number;
@property(strong,nonatomic)IBOutlet UILabel *lab_Date;
@property(strong,nonatomic)IBOutlet UILabel *lab_Qty;
@property(strong,nonatomic)IBOutlet UILabel *lab_Cost;


@end
