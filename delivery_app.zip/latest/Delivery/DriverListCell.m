//
//  DriverListCell.m
//  Delivery
//
//  Created by Rex on 06/03/19.
//  Copyright © 2019 digitalRx. All rights reserved.
//

#import "DriverListCell.h"

@implementation DriverListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
