    //
    //  OnlineList.m
    //  Delivery
    //
    //  Created by Barani Elangovan on 5/3/17.
    //  Copyright © 2017 digitalRx. All rights reserved.
    //

#import "OnlineList.h"
#import "MSSCalendarViewController.h"
#import "MSSCalendarDefine.h"
#import "DGActivityIndicatorView.h"
#import "AppDelegate.h"
#import "ArPaymentVc.h"
#import "ArSearchVc.h"

@interface OnlineList ()<MSSCalendarViewControllerDelegate>
{
    
    NSString *str_FirstTime;
    
    NSString *str_StartDate;
    NSString *str_EndDate;
    NSString *str_dateType;
    NSString *str_datee;
    NSString *str_logid_Driverupdate;
    NSString *str_Drivername_Driverupdate;
    NSString *str_DriverID_Driverupdate;
    NSString *str_FromDriver;
    NSString *str_FromDriverID;



    
    NSDateFormatter *Formate_CurrentDate;
    NSDateFormatter *Formate_DateMonthYear;
    NSDateFormatter *Formate_DateMonthYearTime;
    NSDateFormatter *Formate_DateMonthYearTime1;
    
    NSDateFormatter *Formate_DateMonthYear_Service;
    
    
    DGActivityIndicatorView *activityIndicatorView;
    
    
    NSMutableArray *arr_CurrentRxID;
    NSMutableArray *arr_CurrentDriverName;
    NSMutableArray *arr_CurrentDriverName_filter;
    
    NSMutableArray *arr_DeliveredDriverName;
    NSMutableArray *arr_DeliveredDriverName_filter;
    NSMutableArray *arr_CurrentDelivery;
    NSMutableArray *arr_CurrentDelivery_filter;
    
    
    NSMutableArray *arr_CurrentRxID_filter;
    
    NSMutableArray *arr_CurrentDelivery_sort;
    NSMutableArray *arr_CurrentDelivery_sort_new;
    
    
    NSMutableArray *arr_CurrentDelivery_sort_didselect;
    
    NSMutableArray *arr_DeliveredRxID;
    
    NSMutableArray *arr_DeliveredRxID_filter;
    NSMutableArray *arr_DeliveredDelivery;
    NSMutableArray *arr_DeliveredDelivery_filter;
    
    NSMutableArray *arr_LocalVal;
    NSMutableArray *arr_LocalVal_sort;
    
    NSString *str_tableType;
    NSString *str_storeID;
    
    NSIndexPath *selectedIndexPath;
    NSIndexPath *Table_selectedIndexPath;
    
    
    float f_UserLocation1;
    float f_UserLocation2;
    
    NSTimer *Timer;
    NSTimer *Timer_DeviceAuthentication;
    
    NSString *str_BarCode;
    NSString *str_CodeBack;
    NSInteger int_index;
    
    NSString *strLogID1;
    
    
    NSString *str_isDelivered;
    NSString *str_bulkCustomCalender;
    NSString *str_date_select_bulk;
    
    NSMutableArray *arr_pendindRxList;
    NSMutableArray *arr_driverlist;
}

@property (nonatomic) Reachability *hostReachability;
@property (nonatomic) Reachability *internetReachability;
@property (nonatomic) UITextField * alertTextField;
@end

@implementation OnlineList

@synthesize lab_Date,view_Current,view_Delivered,table_Current,table_Delivered,view_Current_NoData,view_Delivered_NoData,view_Current_Line,view_Delivered_Line,view_Date_Large,view_Date_Small,lab_Date1,viewMain,sidepage,scroll_SidePage,lab_DriverName,btn_Search,image_Search,str_DelivSearchDate,image_Scan,btn_Scan,view_BarCode,view_BarCode1,view_BarCode2,btn_MapListt, view_current_background, view_delivered_background, btn_current, btn_delivered, view_scrl_inside, alertTextField,searchbar_current, searchbar_delivered, btn_bulk_download, img_download, view_scanLogID,view_scanSide,view_driverlist,table_driverlist,viewArPayment;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        [self restrictRotation:NO];
        
    }
    
    else
    {
        
        
    }
    
    view_driverlist.hidden = YES;
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
    [self.navigationController setNavigationBarHidden:YES];
    
    manage=[singleton share];
    
    btn_MapListt.enabled=YES;
    
    
    
    
    
    BOOL DelCon;
    DelCon= [[DBManager getSharedInstance]deleteLocalPastValue];
    
    
    if (DelCon == NO)
    {
        NSLog(@"No");
        
    }
    else
    {
        NSLog(@"Deleted");
    }
    
    
    
    [[UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil]
     setTitleTextAttributes:@{
                              NSForegroundColorAttributeName: [UIColor darkGrayColor],
                              NSFontAttributeName: [UIFont systemFontOfSize:13]}
     forState:UIControlStateNormal];
    
    
    
    
    
    str_BarCode=@"No";
    
    str_BarCode=@"No";
    view_BarCode.hidden=YES;
    str_storeID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];
    
  //  [self DriverList];
    lab_DriverName.text=[NSString stringWithFormat:@"%@ %@",manage.arr_storeInfoList[@"UserFirstName"],manage.arr_storeInfoList[@"UserLastName"]];
    [self restrictRotation:NO];
    arr_CurrentRxID=[[NSMutableArray alloc]init];
    arr_CurrentDelivery=[[NSMutableArray alloc]init];
    arr_CurrentDelivery_sort=[[NSMutableArray alloc] init];
    arr_CurrentDelivery_sort_new=[[NSMutableArray alloc]init];
    arr_CurrentDelivery_sort_didselect=[[NSMutableArray alloc] init];
    arr_DeliveredDelivery_filter=[[NSMutableArray alloc] init];
    arr_CurrentRxID_filter=[[NSMutableArray alloc]init];
    arr_DeliveredRxID=[[NSMutableArray alloc]init];
    arr_DeliveredDelivery=[[NSMutableArray alloc]init];
    arr_driverlist=[[NSMutableArray alloc] init];
    arr_CurrentDelivery_filter=[[NSMutableArray alloc]init];
    arr_DeliveredRxID_filter=[[NSMutableArray alloc] init];
    arr_LocalVal=[[NSMutableArray alloc]init];
    arr_LocalVal_sort=[[NSMutableArray alloc]init];
    
    arr_CurrentDriverName=[[NSMutableArray alloc] init];
    arr_CurrentDriverName_filter=[[NSMutableArray alloc] init];
    
    arr_DeliveredDriverName=[[NSMutableArray alloc]init];
    arr_DeliveredDriverName_filter=[[NSMutableArray alloc] init];
    view_Delivered.hidden=YES;
    
    arr_pendindRxList=[[NSMutableArray alloc]init];
    
    
    view_Delivered_Line.hidden=YES;
    view_Current_Line.hidden=NO;
    
    view_Delivered.hidden=YES;
    view_Current.hidden=NO;
    str_dateType=@"Small";
    str_tableType=@"Current";
    Formate_CurrentDate=[[NSDateFormatter alloc]init];
    Formate_DateMonthYear=[[NSDateFormatter alloc]init];
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    Formate_DateMonthYearTime=[[NSDateFormatter alloc]init];
    Formate_DateMonthYearTime1=[[NSDateFormatter alloc]init];
    
    [Formate_CurrentDate setDateFormat:@"MMMM dd, yyyy"];
    [Formate_DateMonthYear_Service setDateFormat:@"MM-dd-yyyy"];
    [Formate_DateMonthYear setDateFormat:@"MM/dd/yyyy"];
    [Formate_DateMonthYearTime setDateFormat:@"MM/dd/yyyy hh:mm a"];
    [Formate_DateMonthYearTime1 setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    
    lab_Date.text=@"Today";
    str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
    str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
    
    view_Date_Large.hidden=YES;
    
    
    
    
    if ([str_DelivSearchDate isEqualToString:@"Login"]) {
        
        str_FirstTime=@"Yes";
        
        
        
        
        
        Timer_DeviceAuthentication = [NSTimer scheduledTimerWithTimeInterval:120
                                                                      target:self selector:@selector(DeviceAuthentication:) userInfo:nil repeats:YES];
        
        self.locationManager = [[CLLocationManager alloc]init];
        self.locationManager.delegate = self;
        if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
            [self.locationManager requestAlwaysAuthorization];
        }
        
        CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
        
        if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
            authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
            authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
            
            [self.locationManager startUpdatingLocation];
                // self.mapView.showsUserLocation = YES;
            
        }
        
        if (self.locationManager == nil)
        {
            self.locationManager = [[CLLocationManager alloc] init];
            self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
            self.locationManager.delegate = self;
        }
        
            // [self.locationManager setAllowsBackgroundLocationUpdates:YES];
        
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"digitalRx Delivery wants to Track your Location?"
                                                           delegate:self cancelButtonTitle:@"Don't Allow" otherButtonTitles:@"Allow", nil];
            alert.tag=100;
            [alert show];
        }
        
        
        
        NSString *str_datte =[Formate_CurrentDate stringFromDate:[NSDate date]];
        str_datee=str_datte;
        manage.str_dateLabText=str_datee;
        
        manage.str_DateLabel=@"Today";
        manage.str_StartDatee=str_StartDate;
        manage.str_EndDatee=str_EndDate;
    }
    else
    {
        
        
        
            // NSLog(@"%lu",(unsigned long)manage.str_DateLabel.length);
        
        if (manage.str_DateLabel.length==23)
        {
            
            view_Date_Large.hidden=NO;
            view_Date_Small.hidden=YES;
            
            lab_Date1.text=manage.str_DateLabel;
            
        }
        else
        {
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            lab_Date.text=manage.str_DateLabel;
        }
            // manage.str_StartDatee=str_StartDate;
            //manage.str_EndDatee=str_EndDate;
    }
    if ([manage.arr_storeInfoList[@"AccessToOutForDelivery"]intValue]==0 || [manage.arr_storeInfoList[@"AccessToOutForDelivery"] isEqual:@""])
    {
        view_scanSide.hidden = YES;
    }
    else
    {
        view_scanSide.hidden = NO;
    }
    
    if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
    {
        if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]>0)
        {
            [arr_LocalVal removeAllObjects];
            
            arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
            
            NSArray *tempArr= [arr_LocalVal copy];
            
            NSInteger idx = [tempArr count] - 1;
            
            for (id object in [tempArr reverseObjectEnumerator]) {
                
                if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                    [arr_LocalVal removeObjectAtIndex:idx];
                }
                idx--;
            }
            
            
            
                // arr_LocalVal=arr_CurrentDelivery;
            
            btn_Search.hidden=NO;
            image_Search.hidden=NO;
            
            btn_Scan.hidden=NO;
            image_Scan.hidden=NO;
            
            btn_bulk_download.hidden=YES;
            img_download.hidden=YES;
            [self CurrentList];
            
            
        }
        else
        {
            if ([str_DelivSearchDate isEqualToString:@"Login"]) {
                
                btn_Search.hidden=YES;
                image_Search.hidden=YES;
                
                btn_Scan.hidden=YES;
                image_Scan.hidden=YES;
                
                btn_bulk_download.hidden=NO;
                img_download.hidden=NO;
                
                
                arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                
                
                for (NSDictionary *temp1 in arr_CurrentDelivery)
                {
                    NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                    [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                    [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                    [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                    [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                    [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                    [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                    [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                    [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                    [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                    [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                    
                    [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                    
                    [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                    [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                    [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                    [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                    [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                    [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                    [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                    [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                    [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                    [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                    [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                    
                    
                    [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                    [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                    [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                    [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                    [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                    [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                    [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                    [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                    [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                    
                    [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                    
                    [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                    [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                    [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                    [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                    [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                    [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                    [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                    
                    [itemshowdetails1 setValue:@"" forKey:@"flag"];
                    [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                }
                
                
                    //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                
                
                if (arr_CurrentDelivery.count<=0)
                {
                    view_Current_NoData.hidden=NO;
                    self.view_activity.hidden=YES;
                    
                }
                else
                {
                    for (int i=0; i<arr_CurrentDelivery.count; i++)
                    {
                        NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                        [arr_CurrentRxID addObject:str];
                        
                        NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                        [arr_CurrentDriverName addObject:str1];
                    }
                    NSArray *tempArr= [arr_CurrentRxID copy];
                    
                    NSInteger idx = [tempArr count] - 1;
                    
                    for (id object in [tempArr reverseObjectEnumerator]) {
                        
                        if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                            [arr_CurrentRxID removeObjectAtIndex:idx];
                        }
                        idx--;
                    }
                    
                    view_Current_NoData.hidden=YES;
                    
                    manage.arr_OnlineArray=arr_CurrentDelivery;
                    
                    NSLog(@"%@",manage.arr_OnlineArray);
                    [table_Current reloadData];
                    self.view_activity.hidden=YES;
                    
                }
            }
            else
            {
                
                btn_Search.hidden=YES;
                image_Search.hidden=YES;
                
                btn_Scan.hidden=YES;
                image_Scan.hidden=YES;
                
                
                btn_bulk_download.hidden=NO;
                img_download.hidden=NO;
                
                NSLog(@"%@",manage.arr_OnlineArray);
                
                for (NSDictionary *temp1 in manage.arr_OnlineArray)
                {
                    if ([_str_PaymentLogID isEqualToString:temp1[@"ShipLogID"]]) {
                        
                    }
                    else
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        
                        [itemshowdetails1 setValue:temp1[@"flag"] forKey:@"flag"];
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                }
                
                arr_CurrentDelivery=arr_CurrentDelivery_sort;
                
                if (arr_CurrentDelivery_sort.count<=0)
                {
                    view_Current_NoData.hidden=NO;
                    self.view_activity.hidden=YES;
                    
                }
                else
                {
                    for (int i=0; i<arr_CurrentDelivery_sort.count; i++) {
                        NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery_sort)[i][@"ShipLogID"]];
                        [arr_CurrentRxID addObject:str];
                        NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery_sort)[i][@"DriverName"]];
                        [arr_CurrentDriverName addObject:str1];
                    }
                    NSArray *tempArr= [arr_CurrentRxID copy];
                    
                    NSInteger idx = [tempArr count] - 1;
                    
                    for (id object in [tempArr reverseObjectEnumerator]) {
                        
                        if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                            [arr_CurrentRxID removeObjectAtIndex:idx];
                        }
                        idx--;
                    }
                    view_Current_NoData.hidden=YES;
                    
                    manage.arr_OnlineArray=arr_CurrentDelivery_sort;
                    
                    NSLog(@"%@",manage.arr_OnlineArray);
                    [table_Current reloadData];
                    self.view_activity.hidden=YES;
                    
                }
                
            }
            [self DeliveredList];
        }
        
    }
    else
    {
        
            //        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLatitude"];
            //        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLongitude"];
            //
            //        [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
            //
            //
            //        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLatitude1"];
            //        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLongitude1"];
        
    /*    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude"];
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude"];
        
        [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
        
        
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude1"];
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude1"];
        
        [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"AdminLogin"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        */
        
            // [self.locationManager stopUpdatingLocation];
        [arr_LocalVal removeAllObjects];
        
        arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
        
        NSArray *tempArr= [arr_LocalVal copy];
        
        NSInteger idx = [tempArr count] - 1;
        
        for (id object in [tempArr reverseObjectEnumerator]) {
            
            if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                [arr_LocalVal removeObjectAtIndex:idx];
            }
            idx--;
        }
        
        
        
            // arr_LocalVal=arr_CurrentDelivery;
        
        btn_Search.hidden=NO;
        image_Search.hidden=NO;
        
        btn_Scan.hidden=NO;
        image_Scan.hidden=NO;
        
        
        btn_bulk_download.hidden=YES;
        img_download.hidden=YES;
        [self CurrentList];
        
    }
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    NSString *remoteHostName = @"www.apple.com";
    self.hostReachability = [Reachability reachabilityWithHostName:remoteHostName];
    [self.hostReachability startNotifier];
    [self updateInterfaceWithReachability:self.hostReachability];
    
    
    self.internetReachability = [Reachability reachabilityForInternetConnection];
    [self.internetReachability startNotifier];
    [self updateInterfaceWithReachability:self.internetReachability];
    
    
    
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.minimumPressDuration = 2.0; //seconds
    lpgr.delegate = self;
    [self.table_Current addGestureRecognizer:lpgr];
    
    
    
        // Do any additional setup after loading the view.
}



-(void)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer
{
    CGPoint p = [gestureRecognizer locationInView:self.table_Current];
    
    NSIndexPath *indexPath = [self.table_Current indexPathForRowAtPoint:p];
    NSLog(@"%ld",(long)indexPath.row);
    int_index=indexPath.row;
    
    if (indexPath == nil) {
        
        NSLog(@"long press on table view but not on a row");
        
        /*
         NSMutableDictionary *newDict = [[NSMutableDictionary alloc] init];
         NSDictionary *oldDict = (NSDictionary *)[arr_CurrentDelivery_sort objectAtIndex:0];
         [newDict addEntriesFromDictionary:oldDict];
         [newDict setValue:[NSString stringWithFormat:@"%d",i_count] forKey:@"flag"];
         [arr_CurrentDelivery_sort replaceObjectAtIndex:0 withObject:newDict];
         */
            //[itemshowdetails removeObjectForKey:@"flag"];
        
        
            //  [arr_CurrentDelivery_sort_new addObject:itemshowdetails];
        
            //  [itemshowdetails setObject:[NSString stringWithFormat:@""] forKey:@"flag"];
        
            // [arr_CurrentDelivery_sort addObject:itemshowdetails];
        
    }
    
    
    
    else if (gestureRecognizer.state == UIGestureRecognizerStateBegan)
    {
        if (isSearching) {
            
            [arr_CurrentDelivery_sort_didselect removeAllObjects];
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            [itemshowdetails setValue:arr_CurrentRxID_filter[indexPath.row] forKey:@"ShipLogID"];
            
            
            [arr_CurrentDelivery_sort_didselect addObject:itemshowdetails];
            
            
            
            
                // arr_CurrentDelivery_sort=arr_CurrentDelivery;
            NSLog(@"long press on table view at row %ld", indexPath.row);
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Enter Your Preference" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok",nil];
            
            alert.alertViewStyle = UIAlertViewStylePlainTextInput;
            alertTextField = [alert textFieldAtIndex:0];
            alertTextField.keyboardType = UIKeyboardTypeNumberPad;
            alertTextField.placeholder = @"Preference Number";
            alertTextField.delegate=self;
            
            for (int b=0; b<arr_CurrentDelivery_sort.count; b++)
            {
                if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_sort[b][@"ShipLogID"]]) {
                    
                    alertTextField.text=arr_CurrentDelivery_sort[b][@"flag"];
                    b=arr_CurrentDelivery_sort.count;
                }
                else
                {
                    alertTextField.text=@"";
                    
                }
                
                
            }
            
            
            alert.tag=300;
            [alert show];
            
            
            
        }
        else
        {
            [arr_CurrentDelivery_sort_didselect removeAllObjects];
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            
            
            [itemshowdetails setValue:arr_CurrentRxID[indexPath.row] forKey:@"ShipLogID"];
            
            
            [arr_CurrentDelivery_sort_didselect addObject:itemshowdetails];
            
                // arr_CurrentDelivery_sort=arr_CurrentDelivery;
            NSLog(@"long press on table view at row %ld", indexPath.row);
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Enter Your Preference" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok",nil];
            
            alert.alertViewStyle = UIAlertViewStylePlainTextInput;
            alertTextField = [alert textFieldAtIndex:0];
            alertTextField.keyboardType = UIKeyboardTypeNumberPad;
            alertTextField.placeholder = @"Preference Number";
            alertTextField.delegate=self;
            
            for (int b=0; b<arr_CurrentDelivery_sort.count; b++)
            {
                if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_sort[b][@"ShipLogID"]]) {
                    
                    alertTextField.text=arr_CurrentDelivery_sort[b][@"flag"];
                    b=arr_CurrentDelivery_sort.count;
                }
                else
                {
                    alertTextField.text=@"";
                    
                }
                
                
            }
            
            
            alert.tag=300;
            [alert show];
            
            
            
        }
        
        
        
    }
    
    else {
        NSLog(@"gestureRecognizer.state = %ld", gestureRecognizer.state);
    }
}



- (void) DeviceAuthentication:(NSTimer *)timer
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            
        });
        
        NSString *str_ssID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];
        NSString *str_uuID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]];
        NSString *str_ddID=[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]];
        
        
        NSString *str_serviceAuthLog=[NSString stringWithFormat:@"GetLoginDeviceDetailByID/%@/%@/%@",str_ssID,str_uuID,str_ddID];
        str_serviceAuthLog=[manage.str_url stringByAppendingString:str_serviceAuthLog];
        NSMutableURLRequest *requestAuthLog = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_serviceAuthLog]];
        
        [requestAuthLog setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        NSError *errorAuthLog = nil;
        NSURLResponse *theResponseAuthLog = [[NSURLResponse alloc]init];
        NSData *dataAuthLog = [NSURLConnection sendSynchronousRequest:requestAuthLog returningResponse:&theResponseAuthLog error:&errorAuthLog];
        if(dataAuthLog)
        {
            NSDictionary *jsonArrayAuthLog =[NSJSONSerialization JSONObjectWithData:dataAuthLog options:NSJSONReadingMutableContainers error:&errorAuthLog];
            
            NSDictionary *tranIDAuthLog=jsonArrayAuthLog[@"GetLoginDeviceDetailByIDResult"];
            
            
            
            NSString *transaction_idAuthLog=tranIDAuthLog[@"Result"];
            
                // transaction_idAuthLog=[NSNull null];
            
            if ([transaction_idAuthLog isEqual:[NSNull null]]) {
                
            }
            else
            {
                if ([transaction_idAuthLog isEqualToString:@"LoggedIn"])
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                    });
                }
                else
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [self restrictRotation:NO];
                        
                        [self.locationManager stopUpdatingLocation];
                        [Timer invalidate];
                        Timer = nil;
                        [Timer_DeviceAuthentication invalidate];
                        Timer_DeviceAuthentication = nil;
                        manage.GPSallow=@"No";
                            //[self.locationManager stopUpdatingLocation];
                        
                        ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
                        home.str_AutoLogOut=@"Yes";
                        [self.navigationController pushViewController:home animated:NO];
                        
                        
                    });
                    
                }
            }
            
        }
    });
    
    
}

#pragma mark - GPS Track Service

- (void) GPSservice:(NSTimer *)timer
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            //back to the main thread for the UI call
        dispatch_async(dispatch_get_main_queue(), ^{
            
        });
        
        
        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        
        
        
        [arr_val removeAllObjects];
        [arr_val addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
        [arr_val addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
        [arr_val addObject:[NSString stringWithFormat:@"%f",f_UserLocation1]];
        [arr_val addObject:[NSString stringWithFormat:@"%f",f_UserLocation2]];
        [arr_val addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
        [arr_val addObject:[NSString stringWithFormat:@"%@",manage.str_DriverName]];
        
        
        
        
        NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"UserID", @"Latitude",@"Longitude",@"DeviceID",@"DriverName",nil];
        
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"ObjTracking"];
        
        NSLog(@"%@",newUserObject2);
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"GPSMobileTracking"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3]];
        [request setHTTPMethod:@"POST"];
        [request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
            // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
            
            
            NSDictionary *tranID2=jsonArray3[@"GPSMobileTrackingResult"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                
                MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake([[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude"] floatValue],[[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude"] floatValue]) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
                
                MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
                [srcMapItem setName:@""];
                
                MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1, f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
                
                
                MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
                [distMapItem setName:@""];
                
                
                MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
                [request setSource:srcMapItem];
                [request setDestination:distMapItem];
                    //[request requestsAlternateRoutes];
                
                [request setTransportType:MKDirectionsTransportTypeAutomobile];
                
                MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
                
                [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                    
                    NSArray *arrRoutes = [response routes];
                    
                    
                    [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                        
                        
                        MKRoute *route = obj;
                        
                        float f_distancee=[[[NSUserDefaults standardUserDefaults]stringForKey:@"RouteDistance"] floatValue] + route.distance;
                        
                        NSLog(@"%f",f_distancee);
                        
                        NSLog(@"%f",[[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLatitude"] floatValue]);
                        NSLog(@"%f",[[[NSUserDefaults standardUserDefaults]stringForKey:@"StartLongitude"] floatValue]);
                        
                        
                        NSLog(@"%f",f_UserLocation1);
                        NSLog(@"%f",f_UserLocation2);
                        
                        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%.2f",f_distancee] forKey:@"RouteDistance"];
                        
                        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude"];
                        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude"];
                        
                        
                        
                    }];
                }];
                
            });
            
            
                // NSString *transaction_id3=tranID2[@"ReturnID"];
                //  con2=[transaction_id3 intValue];
            
            
        }
        
        
        
    });
    
    
}


-(void)viewWillAppear:(BOOL)animated
{
    
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        scroll_SidePage.scrollEnabled=YES;
        scroll_SidePage.contentSize=CGSizeMake(246,642);
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
            //  NSLog(@"iphone");
        if(orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationMaskPortrait)
        {
            
        }
        else
        {
            NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationMaskPortrait];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }
        
    }
    else
    {
        
        scroll_SidePage.scrollEnabled=YES;
        scroll_SidePage.contentSize=CGSizeMake(self.view_scrl_inside.frame.size.width, self.view_scrl_inside.frame.size.height);
    }
    if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
    {
        if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
        {
        }
        else
        {
            if ([str_BarCode isEqualToString:@"No"])
            {
                    // str_FirstTime=@"No";
                
            }
            
            else
            {
                
                    //str_BarCode=@"No";
                [arr_LocalVal removeAllObjects];
                arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
                
                NSArray *tempArr= [arr_LocalVal copy];
                
                NSInteger idx = [tempArr count] - 1;
                
                for (id object in [tempArr reverseObjectEnumerator]) {
                    
                    if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                        [arr_LocalVal removeObjectAtIndex:idx];
                    }
                    idx--;
                }
                
                
                [table_Current reloadData];
            }
            
        }
    }
    else
    {
        if ([str_BarCode isEqualToString:@"No"])
        {
                // str_FirstTime=@"No";
            
        }
        
        else
        {
            
                //str_BarCode=@"No";
            [arr_LocalVal removeAllObjects];
            arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
            
            NSArray *tempArr= [arr_LocalVal copy];
            
            NSInteger idx = [tempArr count] - 1;
            
            for (id object in [tempArr reverseObjectEnumerator]) {
                
                if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                    [arr_LocalVal removeObjectAtIndex:idx];
                }
                idx--;
            }
            
            
            [table_Current reloadData];
        }
        
    }
    
}

-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}


#pragma mark - sidepage view

-(IBAction)menu:(id)sender
{
    
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    
    if(viewMain.frame.origin.x== 0) //only show the menu if it is not already shown
    {
        [self showMenu];
    }
    else
    {
        [self hideMenu];
    }
    
}
-(void)showMenu{
    
        //slide the content view to the right to reveal the menu
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [viewMain setFrame:CGRectMake(sidepage.frame.size.width, viewMain.frame.origin.y, viewMain.frame.size.width, viewMain.frame.size.height)];
                         }
         ];
    }
    else
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [viewMain setFrame:CGRectMake(sidepage.frame.size.width, viewMain.frame.origin.y, viewMain.frame.size.width, viewMain.frame.size.height)];
                         }
         ];
        
    }
    
}

-(void)hideMenu{
    
        //slide the content view to the left to hide the menu
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [viewMain setFrame:CGRectMake(0, viewMain.frame.origin.y, viewMain.frame.size.width, viewMain.frame.size.height)];
                         }
         ];
    }
    else
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [viewMain setFrame:CGRectMake(0, viewMain.frame.origin.y, viewMain.frame.size.width, viewMain.frame.size.height)];
                         }
         ];
        
    }
}
-(void)hideMenuspeed{
    
        //slide the content view to the left to hide the menu
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [UIView animateWithDuration:.0
                         animations:^{
                             
                             [viewMain setFrame:CGRectMake(0, 0, viewMain.frame.size.width, viewMain.frame.size.height)];
                         }
         ];
    }
    else
    {
        [UIView animateWithDuration:.0
                         animations:^{
                             
                             [viewMain setFrame:CGRectMake(0, 0, viewMain.frame.size.width, viewMain.frame.size.height)];
                         }
         ];
        
    }
}

-(IBAction)btn_home:(id)sender
{
    [self hideMenu];
    
}
-(IBAction)btn_Profile:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Profile";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Groups:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Groups";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Pharmacy:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Pharmacy";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Stores:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Stores";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Dashboard:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Dashboard";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Settings:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Settings";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Contact:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Contact Us";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Terms:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Terms & Conditions";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_Privacy:(id)sender
{
    [self hideMenu];
    
    CustomMessage *ln = [[CustomMessage alloc]initWithNibName:@"CustomMessage" bundle:nil];
    ln.str_Title=@"Privacy Policy";
    [self.navigationController pushViewController:ln animated:NO];
}

- (IBAction)btnArPayment_Click:(id)sender {
    [self hideMenu];
    ArSearchVc *ln = [[ArSearchVc alloc]initWithNibName:@"ArSearchVc" bundle:nil];
    [self.navigationController pushViewController:ln animated:NO];
}


#pragma mark - logout


-(IBAction)sign_out:(id)sender
{
    
    
    if ([manage.str_InternetFlag isEqual:@"Yes"]) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sign Out" message:@"Do you want to sign out?"
                                                       delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Confirm", nil];
        alert.tag=999;
        [alert show];
        
    }
    
    else
    {
            //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No network connection"
            //                                                        message:@"You must be connected to the internet to Sign Out this app."
            //                                                       delegate:nil
            //                                              cancelButtonTitle:@"OK"
            //                                              otherButtonTitles:nil];
            //        [alert show];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sign Out" message:@"Do you want to sign out?"
                                                       delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Confirm", nil];
        alert.tag=1000;
        [alert show];
        
    }
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==10) {
        if (buttonIndex==0) {
            [self UpdateDriver:str_Drivername_Driverupdate];
        }
        else{
        
        }
    }
    
    if (alertView.tag==999)
    {
        if (buttonIndex==0) {
        }
        else
        {
            
            [UIView animateWithDuration:.0
                             animations:^{
                                 
                                 [viewMain setFrame:CGRectMake(0, viewMain.frame.origin.y, viewMain.frame.size.width, viewMain.frame.size.height)];
                             }
             ];
            
            
            self.view_activity.hidden=NO;
            
            [activityIndicatorView removeFromSuperview];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                        //  NSLog(@"%@",manage.activityTypes);
                    
                    activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                    
                    CGFloat width = self.view.bounds.size.width;
                    CGFloat height = self.view.bounds.size.height;
                    
                    activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                        // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
                    [self.view_activity addSubview:activityIndicatorView];
                    [activityIndicatorView startAnimating];
                });
                
                
                NSMutableArray *arr_valAuth=[[NSMutableArray alloc]init];
                
                [arr_valAuth removeAllObjects];
                [arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
                [arr_valAuth addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
                
                NSArray *propertyAuth =[NSArray arrayWithObjects:@"StoreID",@"UserID",nil];
                
                
                NSDictionary *propertiesAuth = [NSDictionary dictionaryWithObjects:arr_valAuth forKeys:propertyAuth];
                
                NSMutableDictionary *newUserObjectAuth = [NSMutableDictionary dictionary];
                
                [newUserObjectAuth setObject:propertiesAuth forKey:@"ObjLoginStatus"];
                
                NSLog(@"%@",newUserObjectAuth);
                
                NSData *jsonDataAuth = [NSJSONSerialization dataWithJSONObject:newUserObjectAuth options:kNilOptions error:nil];
                NSString *jsonString = [[NSString alloc] initWithData:jsonDataAuth encoding:NSUTF8StringEncoding];
                NSString *str_service3=[NSString stringWithFormat:@"UpdateLoginStatus"];
                str_service3=[manage.str_url stringByAppendingString:str_service3];
                NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3]];
                [request setHTTPMethod:@"POST"];
                [request setValue:jsonString forHTTPHeaderField:@"json"];
                [request setHTTPBody:jsonDataAuth];
                    // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                
                NSError *error = nil;
                NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                if(data)
                {
                    NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                        //   NSDictionary *tranID2=jsonArray3[@"UpdateLoginStatusResult"];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.locationManager stopUpdatingLocation];
                        self.view_activity.hidden=YES;
                        
                        [Timer invalidate];
                        Timer = nil;
                        
                        [Timer_DeviceAuthentication invalidate];
                        Timer_DeviceAuthentication = nil;
                        
                        manage.GPSallow=@"No";
                        [self.locationManager stopUpdatingLocation];
                        
                        ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
                        [self.navigationController pushViewController:home animated:NO];
                    });
                    
                    
                }
                else
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [self.locationManager stopUpdatingLocation];
                        self.view_activity.hidden=YES;
                        
                        [Timer invalidate];
                        Timer = nil;
                        
                        [Timer_DeviceAuthentication invalidate];
                        Timer_DeviceAuthentication = nil;
                        
                        manage.GPSallow=@"No";
                        [self.locationManager stopUpdatingLocation];
                        
                        ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
                        [self.navigationController pushViewController:home animated:NO];
                    });
                }
            });
            
            
            
        }
    }
    if (alertView.tag==1000)
    {
        if (buttonIndex==0) {
        }
        else
        {
            
            [UIView animateWithDuration:.0
                             animations:^{
                                 
                                 [viewMain setFrame:CGRectMake(0, viewMain.frame.origin.y, viewMain.frame.size.width, viewMain.frame.size.height)];
                             }
             ];
            
            [self.locationManager stopUpdatingLocation];
            self.view_activity.hidden=YES;
            
            [Timer invalidate];
            Timer = nil;
            
            [Timer_DeviceAuthentication invalidate];
            Timer_DeviceAuthentication = nil;
            
            manage.GPSallow=@"No";
            [self.locationManager stopUpdatingLocation];
            
            ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
            [self.navigationController pushViewController:home animated:NO];
            
        }
    }
    
    if (alertView.tag==100)
    {
        if (buttonIndex==0) {
            
            [self.locationManager startUpdatingLocation];
            
                //            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLatitude"];
                //            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLongitude"];
                //
                //            [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
                //
                //
                //            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLatitude1"];
                //            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"0.00"] forKey:@"StartLongitude1"];
            
            
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude"];
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude"];
            
            [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
            
            
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude1"];
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude1"];
            [[NSUserDefaults standardUserDefaults] synchronize];

        }
        else
        {
            manage.GPSallow=@"Yes";
            
            
            [self.locationManager startUpdatingLocation];
            
            
            Timer = [NSTimer scheduledTimerWithTimeInterval:60
                                                     target:self selector:@selector(GPSservice:) userInfo:nil repeats:YES];
            
            
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude"];
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude"];
            
            [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
            
            
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude1"];
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude1"];
            [[NSUserDefaults standardUserDefaults] synchronize];

            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
                
                
                NSMutableArray *arr_vall=[[NSMutableArray alloc]init];
                
                
                
                [arr_vall removeAllObjects];
                [arr_vall addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]]];
                [arr_vall addObject:[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"UserID"]intValue]]];
                [arr_vall addObject:[NSString stringWithFormat:@"%f",f_UserLocation1]];
                [arr_vall addObject:[NSString stringWithFormat:@"%f",f_UserLocation2]];
                [arr_vall addObject:[NSString stringWithFormat:@"%@",[[[UIDevice currentDevice] identifierForVendor] UUIDString]]];
                [arr_vall addObject:[NSString stringWithFormat:@"%@",manage.str_DriverName]];
                
                
                NSArray *propertyNamesVall =[NSArray arrayWithObjects:@"StoreID",@"UserID", @"Latitude",@"Longitude",@"DeviceID",@"DriverName",nil];
                
                
                NSDictionary *propertiesVall = [NSDictionary dictionaryWithObjects:arr_vall forKeys:propertyNamesVall];
                
                NSMutableDictionary *newUserObjectVall = [NSMutableDictionary dictionary];
                
                [newUserObjectVall setObject:propertiesVall forKey:@"ObjTracking"];
                
                NSLog(@"%@",newUserObjectVall);
                
                NSData *jsonDataVall = [NSJSONSerialization dataWithJSONObject:newUserObjectVall options:kNilOptions error:nil];
                NSString *jsonStringVall = [[NSString alloc] initWithData:jsonDataVall encoding:NSUTF8StringEncoding];
                NSString *str_serviceVall=[NSString stringWithFormat:@"GPSMobileTracking"];
                str_serviceVall=[manage.str_url stringByAppendingString:str_serviceVall];
                NSMutableURLRequest *requestVall = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_serviceVall]];
                [requestVall setHTTPMethod:@"POST"];
                [requestVall setValue:jsonStringVall forHTTPHeaderField:@"json"];
                [requestVall setHTTPBody:jsonDataVall];
                    // [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                [requestVall setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                
                NSError *errorVall = nil;
                NSURLResponse *theResponseVall = [[NSURLResponse alloc]init];
                NSData *dataVall = [NSURLConnection sendSynchronousRequest:requestVall returningResponse:&theResponseVall error:&errorVall];
                if(dataVall)
                {
                    NSDictionary *jsonArrayVall =[NSJSONSerialization JSONObjectWithData:dataVall options:NSJSONReadingMutableContainers error:&errorVall];
                    
                        // NSDictionary *tranID2=jsonArrayVall[@"GPSMobileTrackingResult"];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                    });
                }
            });
            
            
            
        }
    }
    
    
    if (alertView.tag==300) {
        
        if (buttonIndex == [alertView cancelButtonIndex]){
            
            
            NSLog(@"cancel");
        }
        else{
                //reset clicked
            
            int i_count=[alertTextField.text intValue];
            
            if (i_count<=0) {
                if (isSearching) {
                    
                    for (int k=0; k<arr_CurrentDelivery_filter.count; k++) {
                        if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_filter[k][@"ShipLogID"] ])
                        {
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DeliveredDate"] forKey:@"DeliveredDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DriverName"] forKey:@"DriverName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"IsPOS"] forKey:@"IsPOS"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCity"] forKey:@"PatientCity"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientMobile"] forKey:@"PatientMobile"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientName"] forKey:@"PatientName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientState"] forKey:@"PatientState"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientStreet"] forKey:@"PatientStreet"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxID"] forKey:@"RxID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Qty"] forKey:@"Qty"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Patientzip"] forKey:@"Patientzip"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Patpay"] forKey:@"Patpay"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PickupDate"] forKey:@"PickupDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShipLogID"] forKey:@"ShipLogID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShipNotes"] forKey:@"ShipNotes"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"IsDownloaded"] forKey:@"IsDownloaded"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Acct"] forKey:@"Acct"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Ar"] forKey:@"Ar"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Bill"] forKey:@"Bill"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"State"] forKey:@"State"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"City"] forKey:@"City"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Phone1"] forKey:@"Phone1"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Zip"] forKey:@"Zip"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ArChargeID"] forKey:@"ArChargeID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                            
                            
                            [itemshowdetails setValue:@"" forKey:@"flag"];
                            
                            [arr_CurrentDelivery_filter replaceObjectAtIndex:k withObject:itemshowdetails];
                            
                        }
                        
                        
                    }
                    
                    
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_sort.count; i++) {
                        if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_sort[i][@"ShipLogID"]])
                        {
                            
                            
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DeliveredDate"] forKey:@"DeliveredDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DriverName"] forKey:@"DriverName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"IsPOS"] forKey:@"IsPOS"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCity"] forKey:@"PatientCity"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientMobile"] forKey:@"PatientMobile"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientName"] forKey:@"PatientName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientState"] forKey:@"PatientState"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientStreet"] forKey:@"PatientStreet"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxID"] forKey:@"RxID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Qty"] forKey:@"Qty"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Patientzip"] forKey:@"Patientzip"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Patpay"] forKey:@"Patpay"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PickupDate"] forKey:@"PickupDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShipLogID"] forKey:@"ShipLogID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShipNotes"] forKey:@"ShipNotes"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"IsDownloaded"] forKey:@"IsDownloaded"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Acct"] forKey:@"Acct"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Ar"] forKey:@"Ar"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Bill"] forKey:@"Bill"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"State"] forKey:@"State"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"City"] forKey:@"City"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Phone1"] forKey:@"Phone1"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Zip"] forKey:@"Zip"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ArChargeID"] forKey:@"ArChargeID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                            
                            [itemshowdetails setValue:@"" forKey:@"flag"];
                            
                            [arr_CurrentDelivery_sort replaceObjectAtIndex:i withObject:itemshowdetails];
                            
                        }
                    }
                    
                    
                }
                
                else
                {
                    
                    
                    for (int k=0; k<arr_CurrentDelivery_sort.count; k++) {
                        if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_sort[k][@"ShipLogID"] ])
                        {
                            
                            
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DeliveredDate"] forKey:@"DeliveredDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DriverName"] forKey:@"DriverName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"IsPOS"] forKey:@"IsPOS"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCity"] forKey:@"PatientCity"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientMobile"] forKey:@"PatientMobile"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientName"] forKey:@"PatientName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientState"] forKey:@"PatientState"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientStreet"] forKey:@"PatientStreet"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxID"] forKey:@"RxID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Qty"] forKey:@"Qty"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Patientzip"] forKey:@"Patientzip"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Patpay"] forKey:@"Patpay"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PickupDate"] forKey:@"PickupDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShipLogID"] forKey:@"ShipLogID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShipNotes"] forKey:@"ShipNotes"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"IsDownloaded"] forKey:@"IsDownloaded"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Acct"] forKey:@"Acct"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Ar"] forKey:@"Ar"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Bill"] forKey:@"Bill"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"State"] forKey:@"State"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"City"] forKey:@"City"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Phone1"] forKey:@"Phone1"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Zip"] forKey:@"Zip"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ArChargeID"] forKey:@"ArChargeID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                            
                            [itemshowdetails setValue:@"" forKey:@"flag"];
                            
                            [arr_CurrentDelivery_sort replaceObjectAtIndex:k withObject:itemshowdetails];
                            
                        }
                        
                        
                    }
                    
                    
                    
                }
                
                [table_Current reloadData];
            }
            else
            {
                if (isSearching) {
                    
                    for (int k=0; k<arr_CurrentDelivery_filter.count; k++) {
                        if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_filter[k][@"ShipLogID"] ])
                        {
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DeliveredDate"] forKey:@"DeliveredDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DriverName"] forKey:@"DriverName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"IsPOS"] forKey:@"IsPOS"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCity"] forKey:@"PatientCity"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientMobile"] forKey:@"PatientMobile"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientName"] forKey:@"PatientName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientState"] forKey:@"PatientState"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientStreet"] forKey:@"PatientStreet"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxID"] forKey:@"RxID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Qty"] forKey:@"Qty"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Patientzip"] forKey:@"Patientzip"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Patpay"] forKey:@"Patpay"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PickupDate"] forKey:@"PickupDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShipLogID"] forKey:@"ShipLogID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShipNotes"] forKey:@"ShipNotes"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"IsDownloaded"] forKey:@"IsDownloaded"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Acct"] forKey:@"Acct"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Ar"] forKey:@"Ar"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Bill"] forKey:@"Bill"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"State"] forKey:@"State"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"City"] forKey:@"City"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Phone1"] forKey:@"Phone1"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Zip"] forKey:@"Zip"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ArChargeID"] forKey:@"ArChargeID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                            
                            [itemshowdetails setValue:[NSString stringWithFormat:@"%d",i_count] forKey:@"flag"];
                            
                            [arr_CurrentDelivery_filter replaceObjectAtIndex:k withObject:itemshowdetails];
                            
                        }
                        
                        
                    }
                    
                    
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_sort.count; i++) {
                        if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_sort[i][@"ShipLogID"]])
                        {
                            
                            
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DeliveredDate"] forKey:@"DeliveredDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DriverName"] forKey:@"DriverName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"IsPOS"] forKey:@"IsPOS"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCity"] forKey:@"PatientCity"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientMobile"] forKey:@"PatientMobile"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientName"] forKey:@"PatientName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientState"] forKey:@"PatientState"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientStreet"] forKey:@"PatientStreet"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxID"] forKey:@"RxID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Qty"] forKey:@"Qty"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Patientzip"] forKey:@"Patientzip"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Patpay"] forKey:@"Patpay"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PickupDate"] forKey:@"PickupDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShipLogID"] forKey:@"ShipLogID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShipNotes"] forKey:@"ShipNotes"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"IsDownloaded"] forKey:@"IsDownloaded"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Acct"] forKey:@"Acct"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Ar"] forKey:@"Ar"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Bill"] forKey:@"Bill"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"State"] forKey:@"State"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"City"] forKey:@"City"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Phone1"] forKey:@"Phone1"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Zip"] forKey:@"Zip"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ArChargeID"] forKey:@"ArChargeID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                            
                            [itemshowdetails setValue:[NSString stringWithFormat:@"%d",i_count] forKey:@"flag"];
                            
                            [arr_CurrentDelivery_sort replaceObjectAtIndex:i withObject:itemshowdetails];
                            
                        }
                    }
                    
                    
                }
                
                else
                {
                    
                    
                    for (int k=0; k<arr_CurrentDelivery_sort.count; k++) {
                        if ([arr_CurrentDelivery_sort_didselect[0][@"ShipLogID"] isEqualToString:arr_CurrentDelivery_sort[k][@"ShipLogID"] ])
                        {
                            
                            
                            
                            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DeliveredDate"] forKey:@"DeliveredDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DriverName"] forKey:@"DriverName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DrugName"] forKey:@"DrugName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"IsPOS"] forKey:@"IsPOS"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCity"] forKey:@"PatientCity"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientMobile"] forKey:@"PatientMobile"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientName"] forKey:@"PatientName"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientState"] forKey:@"PatientState"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientStreet"] forKey:@"PatientStreet"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxID"] forKey:@"RxID"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Qty"] forKey:@"Qty"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Patientzip"] forKey:@"Patientzip"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Patpay"] forKey:@"Patpay"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PickupDate"] forKey:@"PickupDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxDate"] forKey:@"RxDate"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxNumber"] forKey:@"RxNumber"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShipLogID"] forKey:@"ShipLogID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShipNotes"] forKey:@"ShipNotes"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCCCode"] forKey:@"PatientCCCode"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientEmail"] forKey:@"PatientEmail"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"IsDownloaded"] forKey:@"IsDownloaded"];
                            
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ARAddress"] forKey:@"ARAddress"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ARBalance"] forKey:@"ARBalance"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Acct"] forKey:@"Acct"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Ar"] forKey:@"Ar"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Bill"] forKey:@"Bill"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"State"] forKey:@"State"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"City"] forKey:@"City"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Phone1"] forKey:@"Phone1"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Zip"] forKey:@"Zip"];
                            
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ArChargeID"] forKey:@"ArChargeID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"HipaaSigID"] forKey:@"HipaaSigID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientID"] forKey:@"PatientID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"HipaaSig"] forKey:@"HipaaSig"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"BalanceAmt"] forKey:@"BalanceAmt"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxARItemID"] forKey:@"RxARItemID"];
                            [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                            
                            [itemshowdetails setValue:[NSString stringWithFormat:@"%d",i_count] forKey:@"flag"];
                            
                            [arr_CurrentDelivery_sort replaceObjectAtIndex:k withObject:itemshowdetails];
                            
                        }
                        
                        
                    }
                    
                    
                    
                }
                
                manage.arr_OnlineArray=arr_CurrentDelivery_sort;
                
                [table_Current reloadData];
            }
        }
        
        
        NSLog(@"%@",arr_CurrentDelivery_sort);
        
        
        
        NSLog(@"ok");
    }
    
    
    if (alertView.tag==12) {
        
        if (buttonIndex == [alertView cancelButtonIndex]){
            
            
            [self today_Refresh];
        }
        
        
        
    }
    
    
}




#pragma mark - Button Change

-(IBAction)btn_Current:(id)sender
{
    
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    
    OnlineListCellTest *cell1 = [table_Current cellForRowAtIndexPath:selectedIndexPath];
    
    cell1.view_Download.hidden=YES;
    
    [UIView animateWithDuration:.0
                     animations:^{
                         
                         [cell1.view_Scroll setFrame:CGRectMake(0, cell1.view_Scroll.frame.origin.y, cell1.view_Scroll.frame.size.width, cell1.view_Scroll.frame.size.height)];
                     }
     ];
    
    view_delivered_background.backgroundColor=[UIColor whiteColor];
    view_current_background.backgroundColor=[UIColor colorWithRed:64.0/255 green:212.0/255 blue:64.0/255 alpha:1.0];
    [btn_delivered setTitleColor:[UIColor colorWithRed:85.0/255 green:85.0/255 blue:85.0/255 alpha:1.0] forState:UIControlStateNormal];
    [btn_current setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    
    view_Delivered_Line.hidden=YES;
    view_Current_Line.hidden=NO;
    str_tableType=@"Current";
    view_Delivered.hidden=YES;
    view_Current.hidden=NO;
    [table_Current reloadData];
    
    
    
}


#pragma mark - Date Selection

-(IBAction)btn_Delivered:(id)sender
{
    
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    
    
    OnlineListCellTest *cell1 = [table_Current cellForRowAtIndexPath:selectedIndexPath];
    
    cell1.view_Download.hidden=YES;
    
    [UIView animateWithDuration:.0
                     animations:^{
                         
                         [cell1.view_Scroll setFrame:CGRectMake(0, cell1.view_Scroll.frame.origin.y, cell1.view_Scroll.frame.size.width, cell1.view_Scroll.frame.size.height)];
                     }
     ];
    
    
    [btn_current setTitleColor:[UIColor colorWithRed:85.0/255 green:85.0/255 blue:85.0/255 alpha:1.0] forState:UIControlStateNormal];
    [btn_delivered setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    view_delivered_background.backgroundColor=[UIColor colorWithRed:64.0/255 green:212.0/255 blue:64.0/255 alpha:1.0];
    view_current_background.backgroundColor=[UIColor whiteColor];
    
    
    view_Delivered_Line.hidden=NO;
    view_Current_Line.hidden=YES;
    str_tableType=@"Delivered";
    
    view_Delivered.hidden=NO;
    view_Current.hidden=YES;
    [table_Delivered reloadData];
    
    
    
}

-(IBAction)btn_dateFormate:(id)sender
{
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        
        /* Device is iPad */
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select Date"
                                                                 delegate:self
                                                        cancelButtonTitle:@"Cancel"
                                                   destructiveButtonTitle:@"Today"
                                                        otherButtonTitles:@"Yesterday", @"This Week", @"Custom", nil];
        
        [actionSheet showInView:self.view];
        
        
    }
    
    else{
        
        UIAlertController *actionSheet = [[UIAlertController alloc]init];// alertControllerWithTitle:@"Action Sheet" message:@"alert controller" preferredStyle:UIAlertControllerStyleActionSheet];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            
                // Cancel button tappped.
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Today" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            lab_Date.text=@"Today";
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            str_dateType=@"Small";
            
            manage.str_DateLabel=@"Today";
            
            
            manage.str_StartDatee=str_StartDate;
            manage.str_EndDatee=str_EndDate;
            
                //manage.str_StartDatee=@"06-11-2017";
                //manage.str_EndDatee=@"06-11-2017";
            
                //  Formate_CurrentDate
            
            NSString *str_datte =[Formate_CurrentDate stringFromDate:[NSDate date]];
            
            
            str_datee=str_datte;
            manage.str_dateLabText=str_datee;
            
            if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
            {
                
                if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                {
                    
                    [arr_CurrentDelivery_sort removeAllObjects];
                    arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    
                    for (NSDictionary *temp1 in arr_CurrentDelivery)
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        [itemshowdetails1 setValue:@"" forKey:@"flag"];
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                    
                    [arr_CurrentRxID removeAllObjects];
                    
                        //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                    
                    
                    if (arr_CurrentDelivery.count<=0)
                    {
                        view_Current_NoData.hidden=NO;
                        self.view_activity.hidden=YES;
                        
                    }
                    else
                    {
                        for (int i=0; i<arr_CurrentDelivery.count; i++) {
                            NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                            [arr_CurrentRxID addObject:str];
                            NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                            [arr_CurrentDriverName addObject:str1];
                            
                        }
                        NSArray *tempArr= [arr_CurrentRxID copy];
                        
                        NSInteger idx = [tempArr count] - 1;
                        
                        for (id object in [tempArr reverseObjectEnumerator]) {
                            
                            if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                [arr_CurrentRxID removeObjectAtIndex:idx];
                            }
                            idx--;
                        }
                        view_Current_NoData.hidden=YES;
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery;
                        [table_Current reloadData];
                        self.view_activity.hidden=YES;
                        
                    }
                    
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self DeliveredList];
                    }
                    else
                    {
                        [arr_DeliveredRxID_filter removeAllObjects];
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                    }
                    
                }
                else
                {
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self CurrentList];
                    }
                    else
                    {
                        [arr_CurrentRxID_filter removeAllObjects];
                        [arr_DeliveredRxID_filter removeAllObjects];
                        [arr_CurrentRxID removeAllObjects];
                        [arr_CurrentDriverName removeAllObjects];
                        [arr_CurrentDelivery removeAllObjects];
                        [arr_CurrentDelivery_sort removeAllObjects];
                        [activityIndicatorView removeFromSuperview];
                        self.view_activity.hidden=YES;
                        view_Current_NoData.hidden=NO;
                        [table_Current reloadData];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                        
                    }
                    
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }
            }
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Yesterday" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            NSDate *back_date = [[NSDate date] dateByAddingTimeInterval:-1*24*60*60];
            
            NSString *str_datte =[Formate_CurrentDate stringFromDate:back_date];
            
            
            str_datee=str_datte;
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            lab_Date.text=@"Yesterday";
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            str_dateType=@"Small";
            manage.str_DateLabel=@"Yesterday";
            
            manage.str_StartDatee=str_StartDate;
            manage.str_EndDatee=str_EndDate;
            manage.str_dateLabText=str_datee;
            
            if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
            {
                
                
                if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                {
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    
                    arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    for (NSDictionary *temp1 in arr_CurrentDelivery)
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        [itemshowdetails1 setValue:@"" forKey:@"flag"];
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                    
                        //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                    
                    
                    if (arr_CurrentDelivery.count<=0)
                    {
                        view_Current_NoData.hidden=NO;
                        self.view_activity.hidden=YES;
                        
                    }
                    else
                    {
                        for (int i=0; i<arr_CurrentDelivery.count; i++) {
                            NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                            [arr_CurrentRxID addObject:str];
                            NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                            [arr_CurrentDriverName addObject:str1];
                            
                        }
                        NSArray *tempArr= [arr_CurrentRxID copy];
                        
                        NSInteger idx = [tempArr count] - 1;
                        
                        for (id object in [tempArr reverseObjectEnumerator]) {
                            
                            if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                [arr_CurrentRxID removeObjectAtIndex:idx];
                            }
                            idx--;
                        }
                        view_Current_NoData.hidden=YES;
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery;
                        [table_Current reloadData];
                        self.view_activity.hidden=YES;
                        
                    }
                    
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self DeliveredList];
                    }
                    else
                    {
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                    }
                }
                else
                {
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self CurrentList];
                    }
                    else
                    {
                        [arr_CurrentRxID_filter removeAllObjects];
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_CurrentRxID removeAllObjects];
                        [arr_CurrentDriverName removeAllObjects];
                        [arr_CurrentDelivery removeAllObjects];
                        [arr_CurrentDelivery_sort removeAllObjects];
                        [activityIndicatorView removeFromSuperview];
                        self.view_activity.hidden=YES;
                        view_Current_NoData.hidden=NO;
                        [table_Current reloadData];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                        
                    }
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }
            }
            
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"This Week" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            lab_Date.text=@"This Week";
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            str_dateType=@"Small";
            
            NSCalendar *cal = [NSCalendar currentCalendar];
            NSDate *now = [NSDate date];
            NSDate *startOfTheWeek;
            NSDate *endOfWeek;
            NSTimeInterval interval;
            [cal rangeOfUnit:NSCalendarUnitWeekOfMonth
                   startDate:&startOfTheWeek
                    interval:&interval
                     forDate:now];
                //startOfWeek holds now the first day of the week, according to locale (monday vs. sunday)
                // startOfTheWeek=
            endOfWeek = [startOfTheWeek dateByAddingTimeInterval:interval-1];
            
            
            
            
            NSString *dateString1 = [Formate_DateMonthYear stringFromDate:startOfTheWeek];
            NSString *dateString2 = [Formate_DateMonthYear stringFromDate:endOfWeek];
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:startOfTheWeek];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:endOfWeek];
            
            manage.str_StartDatee=str_StartDate;
            manage.str_EndDatee=str_EndDate;
            
            str_datee=[NSString stringWithFormat:@"%@ - %@",dateString1,dateString2];
            
            manage.str_DateLabel=@"This Week";
            manage.str_dateLabText=str_datee;
            
            if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
            {
                
                if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                {
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    
                    arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    for (NSDictionary *temp1 in arr_CurrentDelivery)
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        [itemshowdetails1 setValue:@"" forKey:@"flag"];
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                    
                        //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                    
                    
                    if (arr_CurrentDelivery.count<=0)
                    {
                        view_Current_NoData.hidden=NO;
                        self.view_activity.hidden=YES;
                        
                    }
                    else
                    {
                        for (int i=0; i<arr_CurrentDelivery.count; i++) {
                            NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                            [arr_CurrentRxID addObject:str];
                            NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                            [arr_CurrentDriverName addObject:str1];
                            
                        }
                        NSArray *tempArr= [arr_CurrentRxID copy];
                        
                        NSInteger idx = [tempArr count] - 1;
                        
                        for (id object in [tempArr reverseObjectEnumerator]) {
                            
                            if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                [arr_CurrentRxID removeObjectAtIndex:idx];
                            }
                            idx--;
                        }
                        view_Current_NoData.hidden=YES;
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery;
                        [table_Current reloadData];
                        self.view_activity.hidden=YES;
                        
                    }
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self DeliveredList];
                    }
                    else
                    {
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                    }
                }
                else
                {
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self CurrentList];
                    }
                    else
                    {
                        [arr_CurrentRxID_filter removeAllObjects];
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_CurrentRxID removeAllObjects];
                        [arr_CurrentDriverName removeAllObjects];
                        [arr_CurrentDelivery removeAllObjects];
                        [arr_CurrentDelivery_sort removeAllObjects];
                        [activityIndicatorView removeFromSuperview];
                        self.view_activity.hidden=YES;
                        view_Current_NoData.hidden=NO;
                        [table_Current reloadData];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                        
                    }
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }
                
            }
            
            
                // NSString *str_weekStart=[dateString1 stringByAppendingString:@" - "];
                // lab_Date.text=[str_weekStart stringByAppendingString:dateString2];
            
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Custom" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
            
            if ([str_dateType isEqualToString:@"Small"]) {
                
            }
            else
            {
                
            }
            
            
            MSSCalendarViewController *cvc = [[MSSCalendarViewController alloc]init];
            cvc.limitMonth = 12 * 5;
            /*
             MSSCalendarViewControllerLastType
             MSSCalendarViewControllerMiddleType
             MSSCalendarViewControllerNextType
             */
            cvc.type = MSSCalendarViewControllerLastType;
            cvc.beforeTodayCanTouch = YES;
            cvc.afterTodayCanTouch = NO;
            
            
            NSDate *date = [Formate_DateMonthYear_Service dateFromString:manage.str_StartDatee];
            NSDate *date1 = [Formate_DateMonthYear_Service dateFromString:manage.str_EndDatee];
            long dateInSeconds =  [date timeIntervalSince1970];
            long dateInSeconds1 =  [date1 timeIntervalSince1970];
            cvc.startDate = dateInSeconds;
            cvc.endDate = dateInSeconds1;
            cvc.showChineseHoliday = NO;
            cvc.showChineseCalendar = NO;
            cvc.showHolidayDifferentColor = NO;
            cvc.showAlertView = NO;
            cvc.delegate = self;
            [self presentViewController:cvc animated:YES completion:nil];
            
        }]];
            // Present action sheet.
        [self presentViewController:actionSheet animated:YES completion:nil];
        
    }
    
}





-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if ([str_date_select_bulk isEqualToString:@"yes"]) {
        if  ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Today"])
        {
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            
            manage.str_startdate_bulk=str_StartDate;
            manage.str_enddate_bulk=str_EndDate;
            
            
            [self bulkDownload];
            
            
        }
        else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Yesterday"])
        {
            
            NSDate *back_date = [[NSDate date] dateByAddingTimeInterval:-1*24*60*60];
            
            NSString *str_datte =[Formate_CurrentDate stringFromDate:back_date];
            
            
            str_datee=str_datte;
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            manage.str_startdate_bulk=str_StartDate;
            manage.str_enddate_bulk=str_EndDate;
            
            [self bulkDownload];
            
            
        }
        
        
        else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"This Week"])
        {
            
            
            
            NSCalendar *cal = [NSCalendar currentCalendar];
            NSDate *now = [NSDate date];
            NSDate *startOfTheWeek;
            NSDate *endOfWeek;
            NSTimeInterval interval;
            [cal rangeOfUnit:NSCalendarUnitWeekOfMonth
                   startDate:&startOfTheWeek
                    interval:&interval
                     forDate:now];
            endOfWeek = [startOfTheWeek dateByAddingTimeInterval:interval-1];
            
            
            
            
                //  NSString *dateString1 = [Formate_DateMonthYear stringFromDate:startOfTheWeek];
                //  NSString *dateString2 = [Formate_DateMonthYear stringFromDate:endOfWeek];
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:startOfTheWeek];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:endOfWeek];
            
            manage.str_startdate_bulk=str_StartDate;
            manage.str_enddate_bulk=str_EndDate;
            
            
            
            
            
            
            [self bulkDownload];
            
        }
        
        else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Custom"])
            
            
        {
            
            
            MSSCalendarViewController *cvc = [[MSSCalendarViewController alloc]init];
            cvc.limitMonth = 12 * 5;
            cvc.type = MSSCalendarViewControllerLastType;
            cvc.beforeTodayCanTouch = YES;
            cvc.afterTodayCanTouch = NO;
            
            
            NSDate *date = [Formate_DateMonthYear_Service dateFromString:manage.str_startdate_bulk];
            NSDate *date1 = [Formate_DateMonthYear_Service dateFromString:manage.str_enddate_bulk];
            long dateInSeconds =  [date timeIntervalSince1970];
            long dateInSeconds1 =  [date1 timeIntervalSince1970];
            cvc.startDate = dateInSeconds;
            cvc.endDate = dateInSeconds1;
            cvc.showChineseHoliday = NO;
            cvc.showChineseCalendar = NO;
            cvc.showHolidayDifferentColor = NO;
            cvc.showAlertView = NO;
            cvc.delegate = self;
            
            
            str_bulkCustomCalender=@"yes";
            
            
        }
        
        str_date_select_bulk=@"no";
    }
    
    else
    {
        
        if  ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Today"])
        {
                //NSLog(@"Today");
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            lab_Date.text=@"Today";
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            str_dateType=@"Small";
            
            manage.str_DateLabel=@"Today";
            
            
            manage.str_StartDatee=str_StartDate;
            manage.str_EndDatee=str_EndDate;
            
                //manage.str_StartDatee=@"06-11-2017";
                //manage.str_EndDatee=@"06-11-2017";
            
                //  Formate_CurrentDate
            
            NSString *str_datte =[Formate_CurrentDate stringFromDate:[NSDate date]];
            
            
            str_datee=str_datte;
            manage.str_dateLabText=str_datee;
            
            if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
            {
                
                if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                {
                    [arr_CurrentDelivery_sort removeAllObjects];
                    
                    arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    for (NSDictionary *temp1 in arr_CurrentDelivery)
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        [itemshowdetails1 setValue:@"" forKey:@"flag"];
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                    
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                        //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                    
                    
                    if (arr_CurrentDelivery.count<=0)
                    {
                        view_Current_NoData.hidden=NO;
                        self.view_activity.hidden=YES;
                        
                    }
                    else
                    {
                        for (int i=0; i<arr_CurrentDelivery.count; i++) {
                            NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                            [arr_CurrentRxID addObject:str];
                            NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                            [arr_CurrentDriverName addObject:str1];
                            
                            
                        }
                        NSArray *tempArr= [arr_CurrentRxID copy];
                        
                        NSInteger idx = [tempArr count] - 1;
                        
                        for (id object in [tempArr reverseObjectEnumerator]) {
                            
                            if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                [arr_CurrentRxID removeObjectAtIndex:idx];
                            }
                            idx--;
                        }
                        view_Current_NoData.hidden=YES;
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery;
                        [table_Current reloadData];
                        self.view_activity.hidden=YES;
                        
                    }
                    
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self DeliveredList];
                    }
                    else
                    {
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                    }
                }
                else
                {
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self CurrentList];
                    }
                    else
                    {
                        [arr_CurrentRxID_filter removeAllObjects];
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_CurrentRxID removeAllObjects];
                        [arr_CurrentDriverName removeAllObjects];
                        [arr_CurrentDelivery removeAllObjects];
                        [arr_CurrentDelivery_sort removeAllObjects];
                        [activityIndicatorView removeFromSuperview];
                        self.view_activity.hidden=YES;
                        view_Current_NoData.hidden=NO;
                        [table_Current reloadData];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                        
                    }
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }
                
            }
            
            
        }
        else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Yesterday"])
        {
                //NSLog(@"This Week");
            
            NSDate *back_date = [[NSDate date] dateByAddingTimeInterval:-1*24*60*60];
            
            NSString *str_datte =[Formate_CurrentDate stringFromDate:back_date];
            
            
            str_datee=str_datte;
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            lab_Date.text=@"Yesterday";
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            str_dateType=@"Small";
            manage.str_DateLabel=@"Yesterday";
            
            manage.str_StartDatee=str_StartDate;
            manage.str_EndDatee=str_EndDate;
            manage.str_dateLabText=str_datee;
            
            if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
            {
                
                if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                {
                    [arr_CurrentRxID removeAllObjects];
                    
                    arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    for (NSDictionary *temp1 in arr_CurrentDelivery)
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:@"" forKey:@"flag"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        
                        
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                    [arr_CurrentDriverName removeAllObjects];
                        //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                    
                    
                    if (arr_CurrentDelivery.count<=0)
                    {
                        view_Current_NoData.hidden=NO;
                        self.view_activity.hidden=YES;
                        
                    }
                    else
                    {
                        for (int i=0; i<arr_CurrentDelivery.count; i++) {
                            NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                            [arr_CurrentRxID addObject:str];
                            NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                            [arr_CurrentDriverName addObject:str1];
                            
                        }
                        NSArray *tempArr= [arr_CurrentRxID copy];
                        
                        NSInteger idx = [tempArr count] - 1;
                        
                        for (id object in [tempArr reverseObjectEnumerator]) {
                            
                            if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                [arr_CurrentRxID removeObjectAtIndex:idx];
                            }
                            idx--;
                        }
                        view_Current_NoData.hidden=YES;
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery;
                        [table_Current reloadData];
                        self.view_activity.hidden=YES;
                        
                    }
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self DeliveredList];
                    }
                    else
                    {
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                    }
                }
                else
                {
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self CurrentList];
                    }
                    else
                    {
                        [arr_CurrentRxID_filter removeAllObjects];
                        [arr_DeliveredRxID_filter removeAllObjects];
                        [arr_CurrentRxID removeAllObjects];
                        [arr_CurrentDriverName removeAllObjects];
                        [arr_CurrentDelivery removeAllObjects];
                        [arr_CurrentDelivery_sort removeAllObjects];
                        [activityIndicatorView removeFromSuperview];
                        self.view_activity.hidden=YES;
                        view_Current_NoData.hidden=NO;
                        [table_Current reloadData];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                        
                    }
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }
                
            }
            
            
        }
        else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"This Week"])
        {
                //NSLog(@"This Month");
            
            lab_Date.text=@"This Week";
            view_Date_Large.hidden=YES;
            view_Date_Small.hidden=NO;
            str_dateType=@"Small";
            
            NSCalendar *cal = [NSCalendar currentCalendar];
            NSDate *now = [NSDate date];
            NSDate *startOfTheWeek;
            NSDate *endOfWeek;
            NSTimeInterval interval;
            [cal rangeOfUnit:NSCalendarUnitWeekOfMonth
                   startDate:&startOfTheWeek
                    interval:&interval
                     forDate:now];
                //startOfWeek holds now the first day of the week, according to locale (monday vs. sunday)
            
            endOfWeek = [startOfTheWeek dateByAddingTimeInterval:interval-1];
            
            
            
            
            NSString *dateString1 = [Formate_DateMonthYear stringFromDate:startOfTheWeek];
            NSString *dateString2 = [Formate_DateMonthYear stringFromDate:endOfWeek];
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:startOfTheWeek];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:endOfWeek];
            
            manage.str_StartDatee=str_StartDate;
            manage.str_EndDatee=str_EndDate;
            
            str_datee=[NSString stringWithFormat:@"%@ - %@",dateString1,dateString2];
            
            manage.str_DateLabel=@"This Week";
            manage.str_dateLabText=str_datee;
            
            if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
            {
                
                if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                {
                    [arr_CurrentRxID removeAllObjects];
                    
                    arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    for (NSDictionary *temp1 in arr_CurrentDelivery)
                    {
                        NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                        [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails1 setValue:@"" forKey:@"flag"];
                        [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                        
                        
                        [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                        [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                        [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                        
                        [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                    }
                    
                    
                        //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                    
                    
                    if (arr_CurrentDelivery.count<=0)
                    {
                        view_Current_NoData.hidden=NO;
                        self.view_activity.hidden=YES;
                        
                    }
                    else
                    {
                        for (int i=0; i<arr_CurrentDelivery.count; i++) {
                            NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                            [arr_CurrentRxID addObject:str];
                            NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                            [arr_CurrentDriverName addObject:str1];
                            
                        }
                        NSArray *tempArr= [arr_CurrentRxID copy];
                        
                        NSInteger idx = [tempArr count] - 1;
                        
                        for (id object in [tempArr reverseObjectEnumerator]) {
                            
                            if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                [arr_CurrentRxID removeObjectAtIndex:idx];
                            }
                            idx--;
                        }
                        view_Current_NoData.hidden=YES;
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery;
                        [table_Current reloadData];
                        self.view_activity.hidden=YES;
                        
                    }
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self DeliveredList];
                    }
                    else
                    {
                        
                        [arr_DeliveredRxID_filter removeAllObjects];
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                    }
                }
                else
                {
                    if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                    {
                        [self CurrentList];
                    }
                    else
                    {
                        [arr_CurrentRxID_filter removeAllObjects];
                        [arr_DeliveredRxID_filter removeAllObjects];
                        
                        [arr_CurrentRxID removeAllObjects];
                        [arr_CurrentDriverName removeAllObjects];
                        [arr_CurrentDelivery removeAllObjects];
                        [arr_CurrentDelivery_sort removeAllObjects];
                        [activityIndicatorView removeFromSuperview];
                        self.view_activity.hidden=YES;
                        view_Current_NoData.hidden=NO;
                        [table_Current reloadData];
                        
                        [arr_DeliveredRxID removeAllObjects];
                        [arr_DeliveredDelivery removeAllObjects];
                        [arr_DeliveredDelivery_filter removeAllObjects];
                        [arr_DeliveredDriverName removeAllObjects];
                        view_Delivered_NoData.hidden=NO;
                        [table_Delivered reloadData];
                        
                    }
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }            }
            
            
        }
        else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Custom"])
            
                //([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"Custom"])
            
        {
                //NSLog(@"This Year");
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
            
            if ([str_dateType isEqualToString:@"Small"]) {
                
            }
            else
            {
                
            }
            
            
            MSSCalendarViewController *cvc = [[MSSCalendarViewController alloc]init];
            cvc.limitMonth = 12 * 5;
            /*
             MSSCalendarViewControllerLastType
             MSSCalendarViewControllerMiddleType
             MSSCalendarViewControllerNextType
             */
            cvc.type = MSSCalendarViewControllerLastType;
            cvc.beforeTodayCanTouch = YES;
            cvc.afterTodayCanTouch = NO;
            
            
            NSDate *date = [Formate_DateMonthYear_Service dateFromString:manage.str_StartDatee];
            NSDate *date1 = [Formate_DateMonthYear_Service dateFromString:manage.str_EndDatee];
            long dateInSeconds =  [date timeIntervalSince1970];
            long dateInSeconds1 =  [date1 timeIntervalSince1970];
            cvc.startDate = dateInSeconds;
            cvc.endDate = dateInSeconds1;
            cvc.showChineseHoliday = NO;
            cvc.showChineseCalendar = NO;
            cvc.showHolidayDifferentColor = NO;
            cvc.showAlertView = NO;
            cvc.delegate = self;
            [self presentViewController:cvc animated:YES completion:nil];
            
            
        }
        
        
    }
    
}
- (void)calendarViewConfirmClickWithStartDate:(NSInteger)startDate endDate:(NSInteger)endDate
{
    
    if ([str_bulkCustomCalender isEqualToString:@"yes"]) {
        
        str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate dateWithTimeIntervalSince1970:startDate]];
        str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate dateWithTimeIntervalSince1970:endDate]];
        
        manage.str_startdate_bulk=str_StartDate;
        manage.str_enddate_bulk=str_EndDate;
        
        [self bulkDownload];
        
        str_bulkCustomCalender=@"no";
        
    }
    
    else
    {
        
        if (startDate==endDate)
        {
            NSString *startDateString = [Formate_DateMonthYear stringFromDate:[NSDate dateWithTimeIntervalSince1970:startDate]];
            NSString *endDateString = [Formate_DateMonthYear stringFromDate:[NSDate dateWithTimeIntervalSince1970:endDate]];
            lab_Date1.text=[NSString stringWithFormat:@"%@ - %@",startDateString,endDateString];
            view_Date_Large.hidden=NO;
            view_Date_Small.hidden=YES;
            str_dateType=@"Large";
            manage.str_dateLabText=lab_Date1.text;
            
            manage.str_DateLabel=lab_Date1.text;
            
            
        }
        else
        {
            
            NSString *startDateString = [Formate_DateMonthYear stringFromDate:[NSDate dateWithTimeIntervalSince1970:startDate]];
            NSString *endDateString = [Formate_DateMonthYear stringFromDate:[NSDate dateWithTimeIntervalSince1970:endDate]];
            lab_Date1.text=[NSString stringWithFormat:@"%@ - %@",startDateString,endDateString];
            view_Date_Large.hidden=NO;
            view_Date_Small.hidden=YES;
            str_dateType=@"Large";
            manage.str_dateLabText=lab_Date1.text;
            
            manage.str_DateLabel=lab_Date1.text;
            
            
        }
        str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate dateWithTimeIntervalSince1970:startDate]];
        str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate dateWithTimeIntervalSince1970:endDate]];
        
        manage.str_StartDatee=str_StartDate;
        manage.str_EndDatee=str_EndDate;
        
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            
            if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
            {
                
                [arr_CurrentRxID removeAllObjects];
                [arr_CurrentDelivery_sort removeAllObjects];
                arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                for (NSDictionary *temp1 in arr_CurrentDelivery)
                {
                    NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                    [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                    [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                    [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                    [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                    [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                    [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                    [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                    [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                    [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                    [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                    
                    [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                    
                    [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                    [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                    [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                    [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                    [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                    [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                    [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                    [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                    [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                    [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                    [itemshowdetails1 setValue:@"" forKey:@"flag"];
                    [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                    
                    
                    [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                    [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                    [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                    [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                    [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                    [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                    [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                    [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                    [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                    [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                    [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                    [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                    [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                    [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                    [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                    [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                    [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                    
                    [arr_CurrentDelivery_sort addObject:itemshowdetails1];
                }
                
                
                    //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
                
                
                if (arr_CurrentDelivery.count<=0)
                {
                    view_Current_NoData.hidden=NO;
                    self.view_activity.hidden=YES;
                    
                }
                else
                {
                    for (int i=0; i<arr_CurrentDelivery.count; i++) {
                        NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                        [arr_CurrentRxID addObject:str];
                        
                        NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                        [arr_CurrentDriverName addObject:str1];
                        
                    }
                    NSArray *tempArr= [arr_CurrentRxID copy];
                    
                    NSInteger idx = [tempArr count] - 1;
                    
                    for (id object in [tempArr reverseObjectEnumerator]) {
                        
                        if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                            [arr_CurrentRxID removeObjectAtIndex:idx];
                        }
                        idx--;
                    }
                    view_Current_NoData.hidden=YES;
                    
                    manage.arr_OnlineArray=arr_CurrentDelivery;
                    [table_Current reloadData];
                    self.view_activity.hidden=YES;
                    
                }
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self DeliveredList];
                }
                else
                {
                    [arr_DeliveredRxID_filter removeAllObjects];
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                }
            }
            else
            {
                if ([manage.str_InternetFlag isEqualToString:@"Yes"])
                {
                    [self CurrentList];
                }
                else
                {
                    [arr_CurrentRxID_filter removeAllObjects];
                    [arr_DeliveredRxID_filter removeAllObjects];
                    [arr_CurrentRxID removeAllObjects];
                    [arr_CurrentDriverName removeAllObjects];
                    [arr_CurrentDelivery removeAllObjects];
                    [arr_CurrentDelivery_sort removeAllObjects];
                    [activityIndicatorView removeFromSuperview];
                    self.view_activity.hidden=YES;
                    view_Current_NoData.hidden=NO;
                    [table_Current reloadData];
                    
                    [arr_DeliveredRxID removeAllObjects];
                    [arr_DeliveredDelivery removeAllObjects];
                    [arr_DeliveredDelivery_filter removeAllObjects];
                    [arr_DeliveredDriverName removeAllObjects];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                }            }
        }
        else
        {
            if ([manage.str_InternetFlag isEqualToString:@"Yes"])
            {
                [self CurrentList];
            }
            else
            {
                [arr_CurrentRxID_filter removeAllObjects];
                [arr_DeliveredRxID_filter removeAllObjects];
                
                [arr_CurrentRxID removeAllObjects];
                [arr_CurrentDriverName removeAllObjects];
                [arr_CurrentDelivery removeAllObjects];
                [arr_CurrentDelivery_sort removeAllObjects];
                [activityIndicatorView removeFromSuperview];
                self.view_activity.hidden=YES;
                view_Current_NoData.hidden=NO;
                [table_Current reloadData];
                
                
                [arr_DeliveredRxID removeAllObjects];
                [arr_DeliveredDelivery removeAllObjects];
                [arr_DeliveredDelivery_filter removeAllObjects];
                [arr_DeliveredDriverName removeAllObjects];
                view_Delivered_NoData.hidden=NO;
                [table_Delivered reloadData];
                
            }        }
        
        
    }
}



#pragma mark - Current and Delivered Service Functions

-(void)CurrentList
{
    searchbar_current.text  = @"";
    self.view_activity.hidden=NO;
    [arr_CurrentRxID removeAllObjects];
    [arr_CurrentRxID_filter removeAllObjects];
    
    [arr_CurrentDriverName removeAllObjects];
    [arr_CurrentDelivery removeAllObjects];
    [arr_CurrentDelivery_sort removeAllObjects];
    [arr_CurrentDelivery_filter removeAllObjects];
    
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
                //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
            // NSString *myurlString = @"http://192.168.1.58:8085/Delivery.svc/DeliveryLogByUserID/100010/15/2-23-2017/2-23-2017";
            // str_StartDate=@"04-19-2017";
            // str_EndDate=@"04-19-2017";
        
            // NSString *str_DriverName1=@"";
        
        NSString *str_urrl=[NSString stringWithFormat:@"IOSDeliveryDetailByID/%@/%@/%@/NULL/CURRENT",str_storeID,manage.str_StartDatee,manage.str_EndDatee];
        
            // NSString *str_urrl=[NSString stringWithFormat:@"DeliveryDetailByID/%@/%@/%@/%@/CURRENT",manage.arr_storeInfoList[@"StoreID"],str_StartDate,str_EndDate,str_DriverName1];
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
            // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"IOSDeliveryDetailByIDResult"];
            
            NSLog(@"%@",arr_Content);
            
                //  arr_LogIDList= jsonArray[@"DeliveryLogByUserIDResult"];
            
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    view_Current_NoData.hidden=NO;
                    [self DeliveredList];
                    [table_Current reloadData];
                    
                    
                    
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    view_Current_NoData.hidden=YES;
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    
                    for (int i=0; i<arr_Content.count; i++) {
                        NSString *str=[NSString stringWithFormat:@"%d",[(arr_Content)[i][@"ShipLogID"]intValue]];
                        [arr_CurrentRxID addObject:str];
                        NSString *str1=[NSString stringWithFormat:@"%@",arr_Content[i][@"DriverName"]];
                        [arr_CurrentDriverName addObject:str1];
                        
                    }
                    NSArray *tempArr= [arr_CurrentRxID copy];
                    
                    NSInteger idx = [tempArr count] - 1;
                    
                    for (id object in [tempArr reverseObjectEnumerator]) {
                        
                        if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                            [arr_CurrentRxID removeObjectAtIndex:idx];
                        }
                        idx--;
                    }
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails setValue:temp[@"Dispatcher"] forKey:@"Dispatcher"];
                        [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                        [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
                        [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                        
                        [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                        
                        [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                        [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
                        
                        
                        [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                        [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                        [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                        [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
                        
                            // [itemshowdetails setValue:NULL forKey:@"ArChargeID"];
                        
                        [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];

                        
                        
                        [arr_CurrentDelivery addObject:itemshowdetails];
                        [itemshowdetails setValue:@"" forKey:@"flag"];
                        [arr_CurrentDelivery_sort addObject:itemshowdetails];
                        
                    }
                    
                    
                    
                    manage.arr_OnlineArray=arr_CurrentDelivery;
                    
                    [table_Current reloadData];
                    
                    self.view_activity.hidden=YES;
                    [self DeliveredList];
                    
                    
                });
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [activityIndicatorView stopAnimating];
                view_Current_NoData.hidden=NO;
                [table_Current reloadData];
                [self DeliveredList];
                
                self.view_activity.hidden=YES;
                
                
            });
        }
    });
}

-(void)DriverList
{
    self.view_activity.hidden=NO;

    [arr_driverlist removeAllObjects];
    
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
            // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
        // NSString *myurlString = @"http://192.168.1.58:8085/Delivery.svc/DeliveryLogByUserID/100010/15/2-23-2017/2-23-2017";
        // str_StartDate=@"04-19-2017";
        // str_EndDate=@"04-19-2017";
        
        // NSString *str_DriverName1=@"";
        
        NSString *str_urrl=[NSString stringWithFormat:@"GetDriverDetailsByStoreID/%@",str_storeID];
        
        // NSString *str_urrl=[NSString stringWithFormat:@"DeliveryDetailByID/%@/%@/%@/%@/CURRENT",manage.arr_storeInfoList[@"StoreID"],str_StartDate,str_EndDate,str_DriverName1];
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
        // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
            //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"GetDriverDetailsByStoreIDResult"];

            NSLog(@"%@",arr_Content);
            
            //  arr_LogIDList= jsonArray[@"DeliveryLogByUserIDResult"];
            
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    
                    
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        [itemshowdetails setValue:temp[@"UserID"] forKey:@"UserID"];
                        [itemshowdetails setValue:temp[@"UserName"] forKey:@"UserName"];
                        [arr_driverlist addObject:itemshowdetails];
                    }
                    
                    NSLog(@"%@", arr_driverlist);
                    
                    
                    [table_driverlist reloadData];
                    
                  //  [table_driverlist reloadData];
                    
                    self.view_activity.hidden=YES;
                    
                    
                });
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [activityIndicatorView stopAnimating];
                view_Current_NoData.hidden=NO;
                
                
                self.view_activity.hidden=YES;
                
                
            });
        }
    });
}
-(IBAction)btn_driverListClose:(id)sender
{
    view_driverlist.hidden = YES;
}
-(void)DeliveredList
{
    self.view_activity.hidden=NO;
    
    [arr_DeliveredRxID_filter removeAllObjects];
    
    [arr_DeliveredRxID removeAllObjects];
    [arr_DeliveredDelivery removeAllObjects];
    [arr_DeliveredDriverName removeAllObjects];
    [arr_DeliveredDelivery_filter removeAllObjects];
    
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
                //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
            // NSString *myurlString = @"http://192.168.1.58:8085/Delivery.svc/DeliveryLogByUserID/100010/15/2-23-2017/2-23-2017";
            // str_StartDate=@"04-19-2017";
            //str_EndDate=@"04-19-2017";
        
            //  NSString *str_DriverName1=@"";
        NSString *str_urrl;
        
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            str_urrl=[NSString stringWithFormat:@"IOSDeliveryDetailByID/%@/%@/%@/%@/DELIVERED",str_storeID,manage.str_StartDatee,manage.str_EndDatee,manage.str_DriverName];
            
        }
        else
        {
            str_urrl=[NSString stringWithFormat:@"IOSDeliveryDetailByID/%@/%@/%@/NULL/DELIVERED",str_storeID,manage.str_StartDatee,manage.str_EndDatee];
            
        }
        
        
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
            // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"IOSDeliveryDetailByIDResult"];
            
            NSLog(@"%@",arr_Content);
            
            
                //  arr_LogIDList= jsonArray[@"DeliveryLogByUserIDResult"];
            
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    view_Delivered_NoData.hidden=NO;
                    [table_Delivered reloadData];
                    
                    
                    
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    view_Delivered_NoData.hidden=YES;
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    for (int i=0; i<arr_Content.count; i++) {
                        NSString *str=[NSString stringWithFormat:@"%d",[(arr_Content)[i][@"ShipLogID"]intValue]];
                        [arr_DeliveredRxID addObject:str];
                        
                        NSString *str1=[NSString stringWithFormat:@"%@",arr_Content[i][@"DriverName"]];
                        [arr_DeliveredDriverName addObject:str1];
                        
                    }
                    NSArray *tempArr= [arr_DeliveredRxID copy];
                    
                    NSInteger idx = [tempArr count] - 1;
                    
                    for (id object in [tempArr reverseObjectEnumerator]) {
                        
                        if ([arr_DeliveredRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                            [arr_DeliveredRxID removeObjectAtIndex:idx];
                        }
                        idx--;
                    }
                    
                    
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        
                        [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                        [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                        [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
                        [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                        [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
                        [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
                        [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                        [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
                        [itemshowdetails setValue:temp[@"Dispatcher"] forKey:@"Dispatcher"];
                        [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
                        [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                        
                        [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
                        [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
                        [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                        [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                        [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
                        [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                        [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                        [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
                        
                        [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                        [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
                        [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
                        [itemshowdetails setValue:temp[@"Patientphone"] forKey:@"Patientphone"];
                        [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
                        [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
                        [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
                        [itemshowdetails setValue:temp[@"Phone2"] forKey:@"Phone2"];
                        [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
                        [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                        [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                        [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                        [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                        [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
                        [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
                        [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                        [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                        
                        [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                        [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                        [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                        [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                        [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
                        [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                        [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];
                        [arr_DeliveredDelivery addObject:itemshowdetails];
                    }
                    
                    [table_Delivered reloadData];
                    
                    self.view_activity.hidden=YES;
                    
                });
                
                
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [activityIndicatorView stopAnimating];
                view_Delivered_NoData.hidden=NO;
                [table_Delivered reloadData];
                self.view_activity.hidden=YES;
                
                
            });
        }
    });
}

-(void)UpdateDriver:(NSString*)str_drivername
{
    [activityIndicatorView removeFromSuperview];
    self.view_activity.hidden=NO;
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
            // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
       // StoreID,LogID,DriverName,LoggedInBy
        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        [arr_val addObject:manage.arr_storeInfoList[@"StoreID"]];
        [arr_val addObject:str_logid_Driverupdate];
        [arr_val addObject:str_drivername];
        [arr_val addObject:manage.arr_storeInfoList[@"UserFirstName"]];

        
        NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"DriverName",@"LoggedInBy",nil];
        
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"ObjUpdateDriver"];
        
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"UpdateDriverNameByLogID"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request setHTTPMethod:@"POST"];
        //[request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
             NSDictionary *tranID2=jsonArray3[@"UpdateDriverNameByLogIDResult"];
            
             NSString *str_SigID=tranID2[@"DriverLogID"];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if (str_SigID.intValue>0) {
                    [self UpdateDriverCloud:str_Drivername_Driverupdate];
                }
                else
                {
                    [self UpdateDriverCloud:str_Drivername_Driverupdate];
                }
                
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                
                [self UpdateDriverCloud:str_Drivername_Driverupdate];
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                self.view_activity.hidden=YES;

                
            });
            
        }
    });
}

-(void)UpdateDriverCloud:(NSString*)str_drivername
{
    [activityIndicatorView removeFromSuperview];
    self.view_activity.hidden=NO;
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
            // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        // StoreID,LogID,DriverName,LoggedInBy
        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        [arr_val addObject:manage.arr_storeInfoList[@"StoreID"]];
        [arr_val addObject:str_logid_Driverupdate];
        [arr_val addObject:str_DriverID_Driverupdate];
        [arr_val addObject:str_FromDriverID];
        [arr_val addObject:manage.arr_storeInfoList[@"UserFirstName"]];
        
      //  LoggedInBy,StoreID,DriverNameChangedBy,LogAssignedFromUserID,LogAssignedToUserID,ShippingLogID
        NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"ShippingLogID", @"LogAssignedToUserID",@"LogAssignedFromUserID",@"LoggedInBy",nil];
        
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"ObjShippingLogInfo"];
        
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"InsertShippingLogInfo"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request setHTTPMethod:@"POST"];
        //[request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
            NSDictionary *tranID2=jsonArray3[@"InsertShippingLogInfoResult"];
            
             NSString *str_SigID=tranID2[@"ID"];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if (str_SigID.intValue>0) {
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Update Successfully!" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    self.view_driverlist.hidden=YES;
                    [self CurrentList];
                }
                else
                {
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Update Failed!" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    [self CurrentList];

                }
                
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Check your Internet Connection!" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                activityIndicatorView.hidden=YES;
                [activityIndicatorView stopAnimating];
                self.view_activity.hidden=YES;
                
                
            });
            
        }
    });
}

#pragma mark - TableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView==table_Current)
    {
        return 1;
    }
    else
    {
        return 1;
            //return arr_SectionHeaderPending.count ;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView==table_Current)
    {
        if (isSearching) {
            return arr_CurrentRxID_filter.count;
        }
        else
        {
            
            return arr_CurrentRxID.count;
            
        }
    }
    if (tableView == table_Delivered)
    {
        
        if (isSearching_delivered) {
            return arr_DeliveredRxID_filter.count;
        }
        else
        {
            
            return arr_DeliveredRxID.count;
        }
        
        
    }
    else
    {
        return arr_driverlist.count;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return nil;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==table_Current)
    {
        if (isSearching)
        {
            strLogID1=arr_CurrentRxID_filter[indexPath.row];
        }
        else
        {
            strLogID1=arr_CurrentRxID[indexPath.row];
        }
        
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            
            if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
            {
                static NSString *SimpletableIndentifier=@"OnlineListCellTest";
                OnlineListCellTest *cell = [table_Current dequeueReusableCellWithIdentifier:SimpletableIndentifier];
                if (cell == nil) {
                    cell = [[OnlineListCellTest alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
                    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCellTest" owner:self options:nil];
                    cell = [nib objectAtIndex:0];
                    UIView *bgColorView = [[UIView alloc] init];
                    bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
                    [cell setSelectedBackgroundView:bgColorView];
                        //cell = [nib objectAtIndex:0];
                }
                
                cell.labl_driver_name.text=@"Driver :";
                cell.view_driver.hidden = NO;
                if (isSearching) {
                    cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID_filter[indexPath.row]] stringByAppendingString:@""];
                    
                    NSString *strLogID=arr_CurrentRxID_filter[indexPath.row];
                    float f_Cost=0.0;
                    int i_count=0;
                    NSString *str_Dispacher=@"";
                    NSString *str_Date=@"";
                    
                    NSString *str_Street=@"";
                    NSString *str_City=@"";
                    NSString *str_State=@"";
                    NSString *str_Zip=@"";
                    
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_filter.count; i++)
                    {
                        if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_filter[i][@"ShipLogID"]]]) {
                            f_Cost=f_Cost+[arr_CurrentDelivery_filter[i][@"Patpay"]floatValue];
                            
                            if(i_count==0)
                            {
                                str_FromDriver=arr_CurrentDelivery_filter[i][@"DriverName"];
                                str_FromDriverID=arr_CurrentDelivery_filter[i][@"DriverID"];

                                str_Dispacher=arr_CurrentDelivery_filter[i][@"DriverName"];
                                
                                
                                NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_filter[i][@"PickupDate"]];
                                
                                str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                
                                str_Street=arr_CurrentDelivery_filter[i][@"PatientStreet"];
                                str_City=arr_CurrentDelivery_filter[i][@"PatientCity"];
                                str_State=arr_CurrentDelivery_filter[i][@"PatientState"];
                                str_Zip=arr_CurrentDelivery_filter[i][@"Patientzip"];
                                
                                if ([arr_CurrentDelivery_filter[i][@"flag"] isEqualToString:@""]) {
                                    
                                    cell.view_preference.hidden=YES;
                                    
                                }
                                else
                                {
                                    cell.view_preference.hidden=NO;
                                    cell.view_preference.layer.cornerRadius=8;
                                    cell.labl_preference_num.text=arr_CurrentDelivery_filter[i][@"flag"];
                                    
                                }
                                
                                
                                    //////////////////  Color Change   ///////////////
                                if ([arr_CurrentDelivery_filter[i][@"IsDownloaded"]intValue]==1) {
                                    cell.lab_ID.textColor=[UIColor orangeColor];
                                }
                                else
                                {
                                    
                                    cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                                    
                                }
                                
                                
                                
                            }
                            
                            
                            i_count=i_count+1;
                        }
                        
                    }
                    
                    
                        ////////////////////   preference  /////////////////////////
                    
                    
                    cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                    
                    
                    
                        // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                    cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                    
                    
                    
                    if (str_Date == nil)
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=@"";
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                            
                        }
                        
                    }
                    else
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            
                        }
                        
                    }
                    
                    
                    cell.btn_driverlist.tag = indexPath.row;
                    [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];
                    
                    cell.view_Download.hidden=YES;
                    
                    
                    return cell;
                    
                }
                
                else
                {
                    cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID[indexPath.row]] stringByAppendingString:@""];
                    
                    NSString *strLogID=arr_CurrentRxID[indexPath.row];
                    float f_Cost=0.0;
                    int i_count=0;
                    NSString *str_Dispacher=@"";
                    NSString *str_Date=@"";
                    
                    NSString *str_Street=@"";
                    NSString *str_City=@"";
                    NSString *str_State=@"";
                    NSString *str_Zip=@"";
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                    {
                        if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                            f_Cost=f_Cost+[arr_CurrentDelivery_sort[i][@"Patpay"]floatValue];
                            
                            if(i_count==0)
                            {
                                str_FromDriver=arr_CurrentDelivery_sort[i][@"DriverName"];
                                str_FromDriverID=arr_CurrentDelivery_sort[i][@"DriverID"];
                                
                                str_Dispacher=arr_CurrentDelivery_sort[i][@"DriverName"];
                                
                                NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_sort[i][@"PickupDate"]];
                                
                                str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                
                                str_Street=arr_CurrentDelivery_sort[i][@"PatientStreet"];
                                str_City=arr_CurrentDelivery_sort[i][@"PatientCity"];
                                str_State=arr_CurrentDelivery_sort[i][@"PatientState"];
                                str_Zip=arr_CurrentDelivery_sort[i][@"Patientzip"];
                                
                                if ([arr_CurrentDelivery_sort[i][@"flag"] isEqualToString:@""]) {
                                    
                                    cell.view_preference.hidden=YES;
                                    
                                }
                                else
                                {
                                    cell.view_preference.hidden=NO;
                                    cell.view_preference.layer.cornerRadius=8;
                                    cell.labl_preference_num.text=arr_CurrentDelivery_sort[i][@"flag"];
                                    
                                }
                                    //////////////////  Color Change   ///////////////
                                if ([arr_CurrentDelivery_sort[i][@"IsDownloaded"]intValue]==1 ) {
                                    cell.lab_ID.textColor=[UIColor orangeColor];
                                }
                                
                                else
                                {
                                    
                                    cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                                }
                                
                                
                                
                            }
                            i_count=i_count+1;
                        }
                        
                    }
                    
                    
                    
                    
                        ////////////////////   preference  /////////////////////////
                    
                    
                    cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                    
                    
                    
                        // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                    cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                    
                    
                    
                    if (str_Date == nil)
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=@"";
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                            
                        }
                        
                    }
                    else
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            
                        }
                        
                    }
                    
                    cell.btn_driverlist.tag = indexPath.row;
                    [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];

                    
                    cell.view_Download.hidden=YES;
                    
                    
                    return cell;
                    
                }
                
                
                
            }
            else
            {
                NSString *str_color;
                for (int k=0; k<arr_LocalVal.count; k++)
                {
                    if ([strLogID1 isEqualToString:arr_LocalVal[k][@"ShipLogID"]]) {
                        
                        str_color=@"No";
                        
                    }
                    
                }
                if (![str_color isEqualToString:@"No"])
                {
                    static NSString *SimpletableIndentifier=@"OnlineListCellTest";
                    OnlineListCellTest *cell = [table_Current dequeueReusableCellWithIdentifier:SimpletableIndentifier];
                    if (cell == nil) {
                        cell = [[OnlineListCellTest alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
                        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCellTest" owner:self options:nil];
                        cell = [nib objectAtIndex:0];
                        UIView *bgColorView = [[UIView alloc] init];
                        bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
                        [cell setSelectedBackgroundView:bgColorView];
                            //cell = [nib objectAtIndex:0];
                    }
                    
                    cell.view_driver.hidden = NO;
                        ///////////////////////// Filter ///////////////////////
                    if (isSearching) {
                        
                        
                        cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID_filter[indexPath.row]] stringByAppendingString:@""];
                        
                        NSString *strLogID=arr_CurrentRxID_filter[indexPath.row];
                        float f_Cost=0.0;
                        int i_count=0;
                        NSString *str_Dispacher=@"";
                        NSString *str_Date=@"";
                        
                        NSString *str_Street=@"";
                        NSString *str_City=@"";
                        NSString *str_State=@"";
                        NSString *str_Zip=@"";
                        
                        
                        for (int i=0; i<arr_CurrentDelivery_filter.count; i++)
                        {
                            if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_filter[i][@"ShipLogID"]]]) {
                                f_Cost=f_Cost+[arr_CurrentDelivery_filter[i][@"Patpay"]floatValue];
                                
                                if(i_count==0)
                                {
                                    str_FromDriver=arr_CurrentDelivery_filter[i][@"DriverName"];
                                    str_FromDriverID=arr_CurrentDelivery_filter[i][@"DriverID"];
                                    
                                    str_Dispacher=arr_CurrentDelivery_filter[i][@"DriverName"];
                                    
                                    NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_filter[i][@"PickupDate"]];
                                    
                                    str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                    
                                    str_Street=arr_CurrentDelivery_filter[i][@"PatientStreet"];
                                    str_City=arr_CurrentDelivery_filter[i][@"PatientCity"];
                                    str_State=arr_CurrentDelivery_filter[i][@"PatientState"];
                                    str_Zip=arr_CurrentDelivery_filter[i][@"Patientzip"];
                                    
                                    if ([arr_CurrentDelivery_filter[i][@"flag"] isEqualToString:@""]) {
                                        
                                        cell.view_preference.hidden=YES;
                                        
                                    }
                                    else
                                    {
                                        cell.view_preference.hidden=NO;
                                        cell.view_preference.layer.cornerRadius=8;
                                        cell.labl_preference_num.text=arr_CurrentDelivery_filter[i][@"flag"];
                                        
                                    }
                                    
                                    
                                        //////////////////  Color Change   ///////////////
                                    if ([arr_CurrentDelivery_filter[i][@"IsDownloaded"]intValue]==1) {
                                        cell.lab_ID.textColor=[UIColor orangeColor];
                                    }
                                    
                                    
                                    else
                                    {
                                        
                                        cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                                    }
                                    
                                    
                                }
                                i_count=i_count+1;
                            }
                            
                        }
                        
                        cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                        
                        
                        
                            // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                        cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                        
                        
                            /////////////////// Preference  ///////////////////
                        
                        
                        
                        
                        if (str_Date == nil)
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=@"";
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                                
                            }
                            
                        }
                        else
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                                
                            }
                            
                        }
                        
                        cell.view_Download.hidden=YES;
                        
                        [UIView animateWithDuration:.0
                                         animations:^{
                                             
                                             [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                                         }
                         ];
                        
                        
                        [cell.btn_download addTarget:self action:@selector(btn_download:withEvent:) forControlEvents:UIControlEventTouchUpInside];
                        [cell.btn_download setTag:indexPath.row];
                        
                        
                        UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeLeft:)];
                        [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
                        [cell.view_Scroll addGestureRecognizer:swipeLeft];
                        
                        UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeRight1:)];
                        [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
                        [cell.view_Scroll addGestureRecognizer:swipeRight];
                        
                        
                        cell.btn_driverlist.tag = indexPath.row;
                        [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];
                        
                        return cell;
                    }
                    
                    
                    
                    else
                    {
                        
                        
                        cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID[indexPath.row]] stringByAppendingString:@""];
                        
                        NSString *strLogID=arr_CurrentRxID[indexPath.row];
                        float f_Cost=0.0;
                        int i_count=0;
                        NSString *str_Dispacher=@"";
                        NSString *str_Date=@"";
                        
                        NSString *str_Street=@"";
                        NSString *str_City=@"";
                        NSString *str_State=@"";
                        NSString *str_Zip=@"";
                        
                        
                        for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                        {
                            if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                                f_Cost=f_Cost+[arr_CurrentDelivery_sort[i][@"Patpay"]floatValue];
                                
                                if(i_count==0)
                                {
                                    str_FromDriver=arr_CurrentDelivery_sort[i][@"DriverName"];
                                    str_FromDriverID=arr_CurrentDelivery_sort[i][@"DriverID"];
                                    str_Dispacher=arr_CurrentDelivery_sort[i][@"DriverName"];
                                    
                                    NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_sort[i][@"PickupDate"]];
                                    
                                    str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                    
                                    str_Street=arr_CurrentDelivery_sort[i][@"PatientStreet"];
                                    str_City=arr_CurrentDelivery_sort[i][@"PatientCity"];
                                    str_State=arr_CurrentDelivery_sort[i][@"PatientState"];
                                    str_Zip=arr_CurrentDelivery_sort[i][@"Patientzip"];
                                    
                                    if ([arr_CurrentDelivery_sort[i][@"flag"] isEqualToString:@""]) {
                                        
                                        cell.view_preference.hidden=YES;
                                        
                                    }
                                    else
                                    {
                                        cell.view_preference.hidden=NO;
                                        cell.view_preference.layer.cornerRadius=8;
                                        cell.labl_preference_num.text=arr_CurrentDelivery_sort[i][@"flag"];
                                        
                                    }
                                        //////////////////  Color Change   ///////////////
                                    if([arr_CurrentDelivery_sort[i][@"IsDownloaded"]intValue]==1)
                                    {
                                        
                                        cell.lab_ID.textColor=[UIColor orangeColor];
                                        
                                    }
                                    
                                    
                                    else
                                    {
                                        
                                        cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                                    }
                                    
                                    
                                    
                                }
                                i_count=i_count+1;
                                
                            }
                            
                        }
                        
                        
                        /*
                         
                         //////////////////  Color Change   ///////////////
                         for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                         {
                         if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                         
                         if([arr_CurrentDelivery_sort[indexPath.row][@"IsDownloaded"]intValue]==1)
                         {
                         
                         cell.lab_ID.textColor=[UIColor orangeColor];
                         
                         }
                         
                         
                         else
                         {
                         
                         cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                         }
                         
                         }
                         }
                         
                         */
                        
                        cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                        
                        
                        
                            // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                        cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                        
                        
                        
                        if (str_Date == nil)
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=@"";
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                                
                            }
                            
                        }
                        else
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                                
                            }
                            
                        }
                        
                        cell.view_Download.hidden=YES;
                        
                        [UIView animateWithDuration:.0
                                         animations:^{
                                             
                                             [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                                         }
                         ];
                        
                        
                        [cell.btn_download addTarget:self action:@selector(btn_download:withEvent:) forControlEvents:UIControlEventTouchUpInside];
                        [cell.btn_download setTag:indexPath.row];
                        
                        
                        UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeLeft:)];
                        [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
                        [cell.view_Scroll addGestureRecognizer:swipeLeft];
                        
                        UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeRight1:)];
                        [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
                        [cell.view_Scroll addGestureRecognizer:swipeRight];
                        
                        cell.btn_driverlist.tag = indexPath.row;
                        [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];
                        
                        return cell;
                    }
                    
                }
                else
                {
                    
                    
                    
                    static NSString *SimpletableIndentifier=@"OnlineListCell";
                    OnlineListCell *cell = [table_Current dequeueReusableCellWithIdentifier:SimpletableIndentifier];
                    if (cell == nil) {
                        cell = [[OnlineListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
                        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCell" owner:self options:nil];
                        cell = [nib objectAtIndex:0];
                        UIView *bgColorView = [[UIView alloc] init];
                        bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
                        [cell setSelectedBackgroundView:bgColorView];
                            //cell = [nib objectAtIndex:0];
                    }
                    cell.labl_driver_name.text=@"Driver :";
                    cell.view_driver.hidden = NO;
                    if (isSearching) {
                        cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID_filter[indexPath.row]] stringByAppendingString:@""];
                        
                        NSString *strLogID=arr_CurrentRxID_filter[indexPath.row];
                        float f_Cost=0.0;
                        int i_count=0;
                        NSString *str_Dispacher=@"";
                        NSString *str_Date=@"";
                        
                        NSString *str_Street=@"";
                        NSString *str_City=@"";
                        NSString *str_State=@"";
                        NSString *str_Zip=@"";
                        
                        
                        for (int i=0; i<arr_CurrentDelivery_filter.count; i++)
                        {
                            if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_filter[i][@"ShipLogID"]]]) {
                                f_Cost=f_Cost+[arr_CurrentDelivery_filter[i][@"Patpay"]floatValue];
                                
                                if(i_count==0)
                                {
                                    str_FromDriver=arr_CurrentDelivery_filter[i][@"DriverName"];
                                    str_FromDriverID=arr_CurrentDelivery_filter[i][@"DriverID"];
                                    str_Dispacher=arr_CurrentDelivery_filter[i][@"DriverName"];
                                    
                                    NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_filter[i][@"PickupDate"]];
                                    
                                    str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                    
                                    str_Street=arr_CurrentDelivery_filter[i][@"PatientStreet"];
                                    str_City=arr_CurrentDelivery_filter[i][@"PatientCity"];
                                    str_State=arr_CurrentDelivery_filter[i][@"PatientState"];
                                    str_Zip=arr_CurrentDelivery_filter[i][@"Patientzip"];
                                    
                                    if ([arr_CurrentDelivery_filter[i][@"flag"] isEqualToString:@""]) {
                                        
                                        cell.view_preference.hidden=YES;
                                        
                                    }
                                    else
                                    {
                                        cell.view_preference.hidden=NO;
                                        cell.view_preference.layer.cornerRadius=8;
                                        cell.labl_preference_num.text=arr_CurrentDelivery_filter[i][@"flag"];
                                        
                                    }
                                    
                                }
                                i_count=i_count+1;
                            }
                            
                        }
                        
                        cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                        
                        
                        
                            // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                        cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                        
                        
                        
                        if (str_Date == nil)
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=@"";
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                                
                            }
                            
                        }
                        else
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            }
                        }
                        cell.btn_driverlist.tag = indexPath.row;
                        [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];

                        cell.view_Download.hidden=YES;
                        
                        
                        return cell;
                        
                        
                    }
                    else
                    {
                        cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID[indexPath.row]] stringByAppendingString:@""];
                        
                        NSString *strLogID=arr_CurrentRxID[indexPath.row];
                        float f_Cost=0.0;
                        int i_count=0;
                        NSString *str_Dispacher=@"";
                        NSString *str_Date=@"";
                        
                        NSString *str_Street=@"";
                        NSString *str_City=@"";
                        NSString *str_State=@"";
                        NSString *str_Zip=@"";
                        
                        
                        for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                        {
                            if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                                f_Cost=f_Cost+[arr_CurrentDelivery_sort[i][@"Patpay"]floatValue];
                                
                                if(i_count==0)
                                {
                                    str_FromDriver=arr_CurrentDelivery_sort[i][@"DriverName"];
                                    str_FromDriverID=arr_CurrentDelivery_sort[i][@"DriverID"];
                                    str_Dispacher=arr_CurrentDelivery_sort[i][@"DriverName"];
                                    
                                    NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_sort[i][@"PickupDate"]];
                                    
                                    str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                    
                                    str_Street=arr_CurrentDelivery_sort[i][@"PatientStreet"];
                                    str_City=arr_CurrentDelivery_sort[i][@"PatientCity"];
                                    str_State=arr_CurrentDelivery_sort[i][@"PatientState"];
                                    str_Zip=arr_CurrentDelivery_sort[i][@"Patientzip"];
                                    
                                    if ([arr_CurrentDelivery_sort[i][@"flag"] isEqualToString:@""]) {
                                        cell.view_preference.hidden=YES;
                                    }
                                    else
                                    {
                                        cell.view_preference.hidden=NO;
                                        
                                        cell.view_preference.layer.cornerRadius=8;
                                        cell.labl_preference_num.text=arr_CurrentDelivery_sort[i][@"flag"];
                                        
                                    }
                                }
                                i_count=i_count+1;
                            }
                            
                        }
                        
                        cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                        
                        
                        
                            // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                        cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                        
                        
                        
                        if (str_Date == nil)
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=@"";
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                                
                            }
                            
                        }
                        else
                        {
                            if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                                
                            }
                            else
                            {
                                cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                                
                            }
                            
                        }
                        cell.btn_driverlist.tag = indexPath.row;
                        [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];

                        cell.view_Download.hidden=YES;
                        
                        
                        return cell;
                        
                        
                    }
                }
                
                
            }
        }
        else
        {
            NSString *str_color;
            for (int k=0; k<arr_LocalVal.count; k++)
            {
                if ([strLogID1 isEqualToString:arr_LocalVal[k][@"ShipLogID"]]) {
                    
                    str_color=@"No";
                    
                }
                
            }
            if (![str_color isEqualToString:@"No"])
            {
                static NSString *SimpletableIndentifier=@"OnlineListCellTest";
                OnlineListCellTest *cell = [table_Current dequeueReusableCellWithIdentifier:SimpletableIndentifier];
                if (cell == nil) {
                    cell = [[OnlineListCellTest alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
                    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCellTest" owner:self options:nil];
                    cell = [nib objectAtIndex:0];
                    UIView *bgColorView = [[UIView alloc] init];
                    bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
                    [cell setSelectedBackgroundView:bgColorView];
                        //cell = [nib objectAtIndex:0];
                }
                cell.view_driver.hidden = NO;
                
                    ///////////////////////// Filter ///////////////////////
                if (isSearching) {
                    
                    
                    cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID_filter[indexPath.row]] stringByAppendingString:@""];
                    
                    NSString *strLogID=arr_CurrentRxID_filter[indexPath.row];
                    float f_Cost=0.0;
                    int i_count=0;
                    NSString *str_Dispacher=@"";
                    NSString *str_Date=@"";
                    
                    NSString *str_Street=@"";
                    NSString *str_City=@"";
                    NSString *str_State=@"";
                    NSString *str_Zip=@"";
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_filter.count; i++)
                    {
                        if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_filter[i][@"ShipLogID"]]]) {
                            f_Cost=f_Cost+[arr_CurrentDelivery_filter[i][@"Patpay"]floatValue];
                            
                            if(i_count==0)
                            {
                                str_FromDriver=arr_CurrentDelivery_filter[i][@"DriverName"];
                                str_FromDriverID=arr_CurrentDelivery_filter[i][@"DriverID"];
                                str_Dispacher=arr_CurrentDelivery_filter[i][@"DriverName"];
                                
                                NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_filter[i][@"PickupDate"]];
                                
                                str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                
                                str_Street=arr_CurrentDelivery_filter[i][@"PatientStreet"];
                                str_City=arr_CurrentDelivery_filter[i][@"PatientCity"];
                                str_State=arr_CurrentDelivery_filter[i][@"PatientState"];
                                str_Zip=arr_CurrentDelivery_filter[i][@"Patientzip"];
                                
                                if ([arr_CurrentDelivery_filter[i][@"flag"] isEqualToString:@""]) {
                                    
                                    cell.view_preference.hidden=YES;
                                    
                                }
                                else
                                {
                                    cell.view_preference.hidden=NO;
                                    cell.view_preference.layer.cornerRadius=8;
                                    cell.labl_preference_num.text=arr_CurrentDelivery_filter[i][@"flag"];
                                    
                                }
                                
                                
                                    //////////////////  Color Change   ///////////////
                                if ([arr_CurrentDelivery_filter[i][@"IsDownloaded"]intValue]==1) {
                                    cell.lab_ID.textColor=[UIColor orangeColor];
                                }
                                
                                
                                else
                                {
                                    
                                    cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                                }
                                
                                
                            }
                            i_count=i_count+1;
                        }
                        
                    }
                    
                    cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                    
                    
                    
                        // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                    cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                    
                    
                        /////////////////// Preference  ///////////////////
                    
                    
                    
                    
                    if (str_Date == nil)
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=@"";
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                            
                        }
                        
                    }
                    else
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            
                        }
                        
                    }
                    
                    cell.view_Download.hidden=YES;
                    
                    [UIView animateWithDuration:.0
                                     animations:^{
                                         
                                         [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                                     }
                     ];
                    
                    
                    [cell.btn_download addTarget:self action:@selector(btn_download:withEvent:) forControlEvents:UIControlEventTouchUpInside];
                    [cell.btn_download setTag:indexPath.row];
                    
                    
                    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeLeft:)];
                    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
                    [cell.view_Scroll addGestureRecognizer:swipeLeft];
                    
                    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeRight1:)];
                    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
                    [cell.view_Scroll addGestureRecognizer:swipeRight];
                    
                    cell.btn_driverlist.tag = indexPath.row;
                    [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];
                    
                    return cell;
                }
                
                
                
                else
                {
                    
                    
                    cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID[indexPath.row]] stringByAppendingString:@""];
                    
                    NSString *strLogID=arr_CurrentRxID[indexPath.row];
                    float f_Cost=0.0;
                    int i_count=0;
                    NSString *str_Dispacher=@"";
                    NSString *str_Date=@"";
                    
                    NSString *str_Street=@"";
                    NSString *str_City=@"";
                    NSString *str_State=@"";
                    NSString *str_Zip=@"";
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                    {
                        if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                            f_Cost=f_Cost+[arr_CurrentDelivery_sort[i][@"Patpay"]floatValue];
                            
                            if(i_count==0)
                            {
                                str_FromDriver=arr_CurrentDelivery_sort[i][@"DriverName"];
                                str_FromDriverID=arr_CurrentDelivery_sort[i][@"DriverID"];
                                str_Dispacher=arr_CurrentDelivery_sort[i][@"DriverName"];
                                
                                NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_sort[i][@"PickupDate"]];
                                
                                str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                
                                str_Street=arr_CurrentDelivery_sort[i][@"PatientStreet"];
                                str_City=arr_CurrentDelivery_sort[i][@"PatientCity"];
                                str_State=arr_CurrentDelivery_sort[i][@"PatientState"];
                                str_Zip=arr_CurrentDelivery_sort[i][@"Patientzip"];
                                
                                if ([arr_CurrentDelivery_sort[i][@"flag"] isEqualToString:@""]) {
                                    
                                    cell.view_preference.hidden=YES;
                                    
                                }
                                else
                                {
                                    cell.view_preference.hidden=NO;
                                    cell.view_preference.layer.cornerRadius=8;
                                    cell.labl_preference_num.text=arr_CurrentDelivery_sort[i][@"flag"];
                                    
                                }
                                    //////////////////  Color Change   ///////////////
                                if([arr_CurrentDelivery_sort[i][@"IsDownloaded"]intValue]==1)
                                {
                                    
                                    cell.lab_ID.textColor=[UIColor orangeColor];
                                    
                                }
                                
                                
                                else
                                {
                                    
                                    cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                                }
                                
                                
                                
                            }
                            i_count=i_count+1;
                            
                        }
                        
                    }
                    
                    
                    /*
                     
                     //////////////////  Color Change   ///////////////
                     for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                     {
                     if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                     
                     if([arr_CurrentDelivery_sort[indexPath.row][@"IsDownloaded"]intValue]==1)
                     {
                     
                     cell.lab_ID.textColor=[UIColor orangeColor];
                     
                     }
                     
                     
                     else
                     {
                     
                     cell.lab_ID.textColor=[UIColor colorWithRed:7/255.0 green:113/255.0 blue:222/255.0 alpha:1.0];
                     }
                     
                     }
                     }
                     
                     */
                    
                    cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                    
                    
                    
                        // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                    cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                    
                    
                    
                    if (str_Date == nil)
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=@"";
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                            
                        }
                        
                    }
                    else
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            
                        }
                        
                    }
                    
                    cell.view_Download.hidden=YES;
                    
                    [UIView animateWithDuration:.0
                                     animations:^{
                                         
                                         [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                                     }
                     ];
                    
                    
                    [cell.btn_download addTarget:self action:@selector(btn_download:withEvent:) forControlEvents:UIControlEventTouchUpInside];
                    [cell.btn_download setTag:indexPath.row];
                    
                    
                    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeLeft:)];
                    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
                    [cell.view_Scroll addGestureRecognizer:swipeLeft];
                    
                    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeRight1:)];
                    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
                    [cell.view_Scroll addGestureRecognizer:swipeRight];
                    
                    cell.btn_driverlist.tag = indexPath.row;
                    [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];
                    
                    return cell;
                }
                
            }
            else
            {
                
                
                
                static NSString *SimpletableIndentifier=@"OnlineListCell";
                OnlineListCell *cell = [table_Current dequeueReusableCellWithIdentifier:SimpletableIndentifier];
                if (cell == nil) {
                    cell = [[OnlineListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
                    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCell" owner:self options:nil];
                    cell = [nib objectAtIndex:0];
                    UIView *bgColorView = [[UIView alloc] init];
                    bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
                    [cell setSelectedBackgroundView:bgColorView];
                        //cell = [nib objectAtIndex:0];
                }
                cell.labl_driver_name.text=@"Driver :";
                
                if (isSearching) {
                    cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID_filter[indexPath.row]] stringByAppendingString:@""];
                    
                    NSString *strLogID=arr_CurrentRxID_filter[indexPath.row];
                    float f_Cost=0.0;
                    int i_count=0;
                    NSString *str_Dispacher=@"";
                    NSString *str_Date=@"";
                    
                    NSString *str_Street=@"";
                    NSString *str_City=@"";
                    NSString *str_State=@"";
                    NSString *str_Zip=@"";
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_filter.count; i++)
                    {
                        if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_filter[i][@"ShipLogID"]]]) {
                            f_Cost=f_Cost+[arr_CurrentDelivery_filter[i][@"Patpay"]floatValue];
                            
                            if(i_count==0)
                            {
                                str_FromDriver=arr_CurrentDelivery_filter[i][@"DriverName"];
                                str_FromDriverID=arr_CurrentDelivery_filter[i][@"DriverID"];
                                str_Dispacher=arr_CurrentDelivery_filter[i][@"DriverName"];
                                
                                NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_filter[i][@"PickupDate"]];
                                
                                str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                
                                str_Street=arr_CurrentDelivery_filter[i][@"PatientStreet"];
                                str_City=arr_CurrentDelivery_filter[i][@"PatientCity"];
                                str_State=arr_CurrentDelivery_filter[i][@"PatientState"];
                                str_Zip=arr_CurrentDelivery_filter[i][@"Patientzip"];
                                
                                if ([arr_CurrentDelivery_filter[i][@"flag"] isEqualToString:@""]) {
                                    
                                    cell.view_preference.hidden=YES;
                                    
                                }
                                else
                                {
                                    cell.view_preference.hidden=NO;
                                    cell.view_preference.layer.cornerRadius=8;
                                    cell.labl_preference_num.text=arr_CurrentDelivery_filter[i][@"flag"];
                                    
                                }
                                
                            }
                            i_count=i_count+1;
                        }
                        
                    }
                    
                    cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                    
                    
                    
                        // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                    cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                    
                    
                    
                    if (str_Date == nil)
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=@"";
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                            
                        }
                        
                    }
                    else
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            
                        }
                        
                    }
                    cell.btn_driverlist.tag = indexPath.row;
                    [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];

                    cell.view_Download.hidden=YES;
                    
                    
                    return cell;
                    
                    
                }
                else
                {
                    cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_CurrentRxID[indexPath.row]] stringByAppendingString:@""];
                    
                    NSString *strLogID=arr_CurrentRxID[indexPath.row];
                    float f_Cost=0.0;
                    int i_count=0;
                    NSString *str_Dispacher=@"";
                    NSString *str_Date=@"";
                    
                    NSString *str_Street=@"";
                    NSString *str_City=@"";
                    NSString *str_State=@"";
                    NSString *str_Zip=@"";
                    
                    
                    for (int i=0; i<arr_CurrentDelivery_sort.count; i++)
                    {
                        if ([strLogID isEqualToString:[NSString stringWithFormat:@"%@",arr_CurrentDelivery_sort[i][@"ShipLogID"]]]) {
                            f_Cost=f_Cost+[arr_CurrentDelivery_sort[i][@"Patpay"]floatValue];
                            
                            if(i_count==0)
                            {
                                str_FromDriver=arr_CurrentDelivery_sort[i][@"DriverName"];
                                str_FromDriverID=arr_CurrentDelivery_sort[i][@"DriverID"];
                                str_Dispacher=arr_CurrentDelivery_sort[i][@"DriverName"];
                                
                                NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_CurrentDelivery_sort[i][@"PickupDate"]];
                                
                                str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                                
                                str_Street=arr_CurrentDelivery_sort[i][@"PatientStreet"];
                                str_City=arr_CurrentDelivery_sort[i][@"PatientCity"];
                                str_State=arr_CurrentDelivery_sort[i][@"PatientState"];
                                str_Zip=arr_CurrentDelivery_sort[i][@"Patientzip"];
                                
                                if ([arr_CurrentDelivery_sort[i][@"flag"] isEqualToString:@""]) {
                                    cell.view_preference.hidden=YES;
                                }
                                else
                                {
                                    cell.view_preference.hidden=NO;
                                    
                                    cell.view_preference.layer.cornerRadius=8;
                                    cell.labl_preference_num.text=arr_CurrentDelivery_sort[i][@"flag"];
                                    
                                }
                            }
                            i_count=i_count+1;
                        }
                        
                    }
                    
                    cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
                    
                    
                    
                        // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
                    cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
                    
                    
                    
                    if (str_Date == nil)
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=@"";
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                            
                        }
                        
                    }
                    else
                    {
                        if (str_Dispacher.length==0 || [str_Dispacher isEqualToString:@" "])
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                            
                        }
                        else
                        {
                            cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                            
                        }
                        
                    }
                    cell.btn_driverlist.tag = indexPath.row;
                    [cell.btn_driverlist addTarget:self action:@selector(DriverlistClick:) forControlEvents:UIControlEventTouchUpInside];

                    cell.view_Download.hidden=YES;
                    
                    
                    return cell;
                    
                    
                }
            }
            
            
        }
    }
    if(tableView == table_Delivered)
    {
        static NSString *SimpletableIndentifier=@"OnlineListCellTest";
        OnlineListCellTest *cell = [table_Delivered dequeueReusableCellWithIdentifier:SimpletableIndentifier];
        if (cell == nil) {
            cell = [[OnlineListCellTest alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCellTest" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            UIView *bgColorView = [[UIView alloc] init];
            bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
            [cell setSelectedBackgroundView:bgColorView];
                //cell = [nib objectAtIndex:0];
        }
        
        cell.labl_driver_name.text=@"Delivered By :";
        cell.view_driver.hidden = YES;
        if (isSearching_delivered) {
            
            cell.view_preference.hidden=YES;
            cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_DeliveredRxID_filter[indexPath.row]] stringByAppendingString:@""];
            
            
            NSString *strLogID=arr_DeliveredRxID_filter[indexPath.row];
            float f_Cost=0.0;
            int i_count=0;
            NSString *str_Dispacher=@"";
            NSString *str_Date=@"";
            
            NSString *str_Street=@"";
            NSString *str_City=@"";
            NSString *str_State=@"";
            NSString *str_Zip=@"";
            
            
            for (int i=0; i<arr_DeliveredDelivery_filter.count; i++)
            {
                if ([strLogID isEqualToString:[NSString stringWithFormat:@"%d",[arr_DeliveredDelivery_filter[i][@"ShipLogID"]intValue]]]) {
                    f_Cost=f_Cost+[arr_DeliveredDelivery_filter[i][@"Patpay"]floatValue];
                    
                    if(i_count==0)
                    {
                        str_Dispacher=arr_DeliveredDelivery_filter[i][@"DriverName"];
                        NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_DeliveredDelivery_filter[i][@"DeliveredDate"]];
                        str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                        
                        str_Street=arr_DeliveredDelivery_filter[i][@"PatientStreet"];
                        str_City=arr_DeliveredDelivery_filter[i][@"PatientCity"];
                        str_State=arr_DeliveredDelivery_filter[i][@"PatientState"];
                        str_Zip=arr_DeliveredDelivery_filter[i][@"Patientzip"];
                        
                        
                    }
                    i_count=i_count+1;
                }
                
            }
            
            
            
            cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
            
            cell.view_Download.hidden=YES;
            
            
                // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
            cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
            
            if (str_Date == nil)
            {
                if (str_Dispacher.length==0)
                {
                    cell.lab_Dispacher_Date.text=@"";
                    
                }
                else
                {
                    cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                    
                }
                
            }
            else
            {
                if (str_Dispacher.length==0)
                {
                    cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                    
                }
                else
                {
                    cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                    
                }
                
            }
            
            
            return cell;
            
        }
        else{
            
            cell.lab_ID.text=[[NSString stringWithFormat:@"%@",arr_DeliveredRxID[indexPath.row]] stringByAppendingString:@""];
            
            cell.view_preference.hidden=YES;
            NSString *strLogID=arr_DeliveredRxID[indexPath.row];
            float f_Cost=0.0;
            int i_count=0;
            NSString *str_Dispacher=@"";
            NSString *str_Date=@"";
            
            NSString *str_Street=@"";
            NSString *str_City=@"";
            NSString *str_State=@"";
            NSString *str_Zip=@"";
            
            
            for (int i=0; i<arr_DeliveredDelivery.count; i++)
            {
                if ([strLogID isEqualToString:[NSString stringWithFormat:@"%d",[arr_DeliveredDelivery[i][@"ShipLogID"]intValue]]]) {
                    f_Cost=f_Cost+[arr_DeliveredDelivery[i][@"Patpay"]floatValue];
                    
                    if(i_count==0)
                    {
                        str_Dispacher=arr_DeliveredDelivery[i][@"DriverName"];
                        NSDate *date11=[Formate_DateMonthYearTime1 dateFromString:arr_DeliveredDelivery[i][@"DeliveredDate"]];
                        str_Date=[Formate_DateMonthYearTime stringFromDate:date11];
                        
                        str_Street=arr_DeliveredDelivery[i][@"PatientStreet"];
                        str_City=arr_DeliveredDelivery[i][@"PatientCity"];
                        str_State=arr_DeliveredDelivery[i][@"PatientState"];
                        str_Zip=arr_DeliveredDelivery[i][@"Patientzip"];
                        
                        
                    }
                    i_count=i_count+1;
                }
                
            }
            
            
            
            cell.lab_Count.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
            
            cell.view_Download.hidden=YES;
            
            
                // cell.lab_Cost.text=[NSString stringWithFormat:@"%.2f",f_Cost];
            cell.lab_Address.text=[NSString stringWithFormat:@"%@, %@, %@ - %@",str_Street,str_City,str_State,str_Zip];
            
            if (str_Date == nil)
            {
                if (str_Dispacher.length==0)
                {
                    cell.lab_Dispacher_Date.text=@"";
                    
                }
                else
                {
                    cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@",str_Dispacher];
                    
                }
                
            }
            else
            {
                if (str_Dispacher.length==0)
                {
                    cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@" ;  %@",str_Date];
                    
                }
                else
                {
                    cell.lab_Dispacher_Date.text=[NSString stringWithFormat:@"%@;  %@",str_Dispacher,str_Date];
                    
                }
                
            }
            
            
            return cell;
            
        }
    }
    else
    {
        static NSString *SimpletableIndentifier=@"DriverListCell";
        DriverListCell *cell = [table_driverlist dequeueReusableCellWithIdentifier:SimpletableIndentifier];
        if (cell == nil) {
            cell = [[DriverListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DriverListCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            UIView *bgColorView = [[UIView alloc] init];
            bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
            [cell setSelectedBackgroundView:bgColorView];
            //cell = [nib objectAtIndex:0];
        }
        cell.labl_driverID.text=[NSString stringWithFormat:@"DriverID :%@",arr_driverlist[indexPath.row][@"UserID"]];
        cell.labl_drivername.text=[NSString stringWithFormat:@"DriverName :%@",arr_driverlist[indexPath.row][@"UserName"]];

        return cell;
    }
}

-(void)DriverlistClick:(UIButton*)sender
{
    view_driverlist.hidden = NO;
    [self DriverList];
    /*
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            
            if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
            {
            }
            else{
                OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:selectedIndexPath];
                
                cell.view_Download.hidden=YES;
                
                [UIView animateWithDuration:.10
                                 animations:^{
                                     
                                     [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                                 }
                 ];
                
            }
        }
        else
        {
            OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:selectedIndexPath];
            
            cell.view_Download.hidden=YES;
            
            [UIView animateWithDuration:.10
                             animations:^{
                                 
                                 [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                             }
             ];
            
        }
*/
    
            if (isSearching) {
                str_logid_Driverupdate=arr_CurrentRxID_filter[sender.tag];
            }
            else
            {
                str_logid_Driverupdate=arr_CurrentRxID[sender.tag];
            }
            

}

- (void)searchTableList {
    [arr_CurrentDelivery_filter removeAllObjects];
    NSString *searchString = searchbar_current.text;
    
    for (NSString *tempStr in arr_CurrentRxID) {
        
        if (tempStr.length<searchString.length) {
            /* NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [tempStr length])];
             if (result == NSOrderedSame) {
             [arr_DeliveredRxID_filter addObject:tempStr];
             }*/
            
        }else
        {
            
            NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [searchString length])];
            if (result == NSOrderedSame) {
                [arr_CurrentRxID_filter addObject:tempStr];
            }
        }
        
        
        
    }
    for (NSDictionary *temp in arr_CurrentDelivery_sort)
    {
            // for (int i=0; arr_CurrentDelivery.count; i++) {
        
        
            // NSLog(@"%@", arr_CurrentDelivery[i][@"ShipLogID"]);
        
        if (( [arr_CurrentRxID_filter containsObject:temp[@"ShipLogID"]] )) {
            
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
            [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
            [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
            [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
            [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
            [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
            [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
            [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
            [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
            [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
            [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
            
            [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
            [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
            [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
            [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
            [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
            [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
            [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
            [itemshowdetails setValue:temp[@"flag"] forKey:@"flag"];
            [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
            
            
            
            [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
            [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
            [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
            [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
            [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
            [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
            [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
            [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
            [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
            [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
            [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
            [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
            [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
            [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
            [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
            [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
            [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];
            [arr_CurrentDelivery_filter addObject:itemshowdetails];
        }
        
        
            //}
        
    }
    
}


- (void)searchTableList_byDrivername {
    [arr_CurrentDelivery_filter removeAllObjects];
    [arr_CurrentRxID_filter removeAllObjects];
    [arr_CurrentDriverName_filter removeAllObjects];
    NSString *searchString = searchbar_current.text;
    
    for (NSString *tempStr in arr_CurrentDriverName) {
        
        if (tempStr.length<searchString.length) {
            /* NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [tempStr length])];
             if (result == NSOrderedSame) {
             [arr_DeliveredRxID_filter addObject:tempStr];
             }*/
            
        }else
        {
            
            NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [searchString length])];
            if (result == NSOrderedSame) {
                [arr_CurrentDriverName_filter addObject:tempStr];
            }
        }
        
        
        
    }
    
    for (NSDictionary *temp in arr_CurrentDelivery_sort)
    {
            // for (int i=0; arr_CurrentDelivery.count; i++) {
        
        
            // NSLog(@"%@", arr_CurrentDelivery[i][@"ShipLogID"]);
        
        if (( [arr_CurrentDriverName_filter containsObject:temp[@"DriverName"]] )) {
            
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
            [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
            [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
            [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
            [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
            [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
            [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
            [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
            [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
            [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
            [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
            
            [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
            [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
            [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
            [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
            [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
            [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
            [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
            [itemshowdetails setValue:temp[@"flag"] forKey:@"flag"];
            [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
            
            
            
            [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
            [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
            [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
            [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
            [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
            [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
            [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
            [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
            [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
            [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
            [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
            [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
            [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
            [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
            [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
            [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
            [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];
            [arr_CurrentDelivery_filter addObject:itemshowdetails];
        }
        
        
        for (int i=0; i<arr_CurrentDelivery_filter.count; i++) {
            NSString *str=[NSString stringWithFormat:@"%d",[(arr_CurrentDelivery_filter)[i][@"ShipLogID"]intValue]];
            [arr_CurrentRxID_filter addObject:str];
        }
        NSArray *tempArr= [arr_CurrentRxID_filter copy];
        
        NSInteger idx = [tempArr count] - 1;
        
        for (id object in [tempArr reverseObjectEnumerator]) {
            
            if ([arr_CurrentRxID_filter indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                [arr_CurrentRxID_filter removeObjectAtIndex:idx];
            }
            idx--;
        }
        
        
            //}
        
    }
    
    
    
}




- (void)searchTableList_deliver {
    [arr_DeliveredDelivery_filter removeAllObjects];
    NSString *searchString = searchbar_delivered.text;
    
    for (NSString *tempStr in arr_DeliveredRxID) {
        
        if (tempStr.length<searchString.length) {
            /* NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [tempStr length])];
             if (result == NSOrderedSame) {
             [arr_DeliveredRxID_filter addObject:tempStr];
             }*/
            
        }else{
            NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [searchString length])];
            if (result == NSOrderedSame) {
                [arr_DeliveredRxID_filter addObject:tempStr];
            }
            
        }
    }
    
    if (arr_DeliveredRxID_filter.count!=0) {
        
        
        
        for (NSDictionary *temp in arr_DeliveredDelivery)
        {
                // for (int i=0; arr_CurrentDelivery.count; i++) {
            
            
                // NSLog(@"%@", arr_CurrentDelivery[i][@"ShipLogID"]);
            
            if (( [arr_DeliveredRxID_filter containsObject:temp[@"ShipLogID"]] )) {
                
                NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                
                [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
                [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
                [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
                [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
                [itemshowdetails setValue:temp[@"Dispatcher"] forKey:@"Dispatcher"];
                [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
                [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                
                [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
                [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
                [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
                [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
                
                [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
                [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
                [itemshowdetails setValue:temp[@"Patientphone"] forKey:@"Patientphone"];
                [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
                [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
                [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
                [itemshowdetails setValue:temp[@"Phone2"] forKey:@"Phone2"];
                [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
                [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
                [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
                [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
                [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];
                [arr_DeliveredDelivery_filter addObject:itemshowdetails];
            }
            
            
                //}
            
        }
    }
    else
    {
        [arr_DeliveredDelivery_filter removeAllObjects];
    }
    
}


- (void)searchTableList_deliver_byDrivername {
    [arr_DeliveredDelivery_filter removeAllObjects];
    
    [arr_DeliveredRxID_filter removeAllObjects];
    [arr_DeliveredDriverName_filter removeAllObjects];
    NSString *searchString = searchbar_delivered.text;
    
    for (NSString *tempStr in arr_DeliveredDriverName) {
        
        if (tempStr.length<searchString.length) {
            /* NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [tempStr length])];
             if (result == NSOrderedSame) {
             [arr_DeliveredRxID_filter addObject:tempStr];
             }*/
            
        }else{
            NSComparisonResult result = [tempStr compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [searchString length])];
            if (result == NSOrderedSame) {
                [arr_DeliveredDriverName_filter addObject:tempStr];
            }
            
        }
    }
    
    
    
    
    
    for (NSDictionary *temp in arr_DeliveredDelivery)
    {
            // for (int i=0; arr_CurrentDelivery.count; i++) {
        
        
            // NSLog(@"%@", arr_CurrentDelivery[i][@"ShipLogID"]);
        
        if (( [arr_DeliveredDriverName_filter containsObject:temp[@"DriverName"]] )) {
            
            
            NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
            
            [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
            [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
            [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
            [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
            [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
            [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
            [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
            [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
            [itemshowdetails setValue:temp[@"Dispatcher"] forKey:@"Dispatcher"];
            [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
            [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
            
            [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
            [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
            [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
            [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
            [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
            [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
            [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
            [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
            
            [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
            [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
            [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
            [itemshowdetails setValue:temp[@"Patientphone"] forKey:@"Patientphone"];
            [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
            [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
            [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
            [itemshowdetails setValue:temp[@"Phone2"] forKey:@"Phone2"];
            [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
            [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
            [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
            [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
            [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
            [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
            [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
            [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
            [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
            [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
            [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
            [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
            [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
            [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
            [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
            [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];
            [arr_DeliveredDelivery_filter addObject:itemshowdetails];
        }
        
        
        
        
            //}
        for (int i=0; i<arr_DeliveredDelivery_filter.count; i++) {
            NSString *str=[NSString stringWithFormat:@"%d",[(arr_DeliveredDelivery_filter)[i][@"ShipLogID"]intValue]];
            [arr_DeliveredRxID_filter addObject:str];
        }
        NSArray *tempArr1= [arr_DeliveredRxID_filter copy];
        
        NSInteger idx1 = [tempArr1 count] - 1;
        
        for (id object1 in [tempArr1 reverseObjectEnumerator]) {
            
            if ([arr_DeliveredRxID_filter indexOfObject:object1 inRange:NSMakeRange(0, idx1)] != NSNotFound) {
                [arr_DeliveredRxID_filter removeObjectAtIndex:idx1];
            }
            idx1--;
        }
        
        
        
    }
    
    
    
}

    ///////////////////  Current Filter /////////////////

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    
    return YES;
}

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    if (arr_CurrentDelivery_filter.count != 0) {
        [arr_CurrentDelivery_filter removeAllObjects];
    }
    for (int i=0; i< [arr_CurrentDelivery count]; i++)
    {
        NSString *string = [[arr_CurrentDelivery objectAtIndex:i] valueForKey:@"ShipLogID"];
        NSRange rangeValue = [string rangeOfString:searchText options:NSCaseInsensitiveSearch];
        if (rangeValue.length > 0)
        {
            NSLog(@"string contains bla!");
            
            [arr_CurrentDelivery_filter addObject:[arr_CurrentDelivery objectAtIndex:i]];
        }
        else
        {
            NSLog(@"string does not contain bla");
        }
    }
    NSLog(@"fiilterArray : %@",arr_CurrentDelivery_filter);
}




- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    if (searchBar==searchbar_current) {
            //  isSearching = YES;
    }
    else if(searchBar==searchbar_delivered)
    {
            // isSearching = YES;
    }
    
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    NSCharacterSet* notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    if ([searchText rangeOfCharacterFromSet:notDigits].location == NSNotFound)
    {
            // newString consists only of the digits 0 through 9
        if (searchBar==searchbar_current) {
            
            NSLog(@"Text change - %d",isSearching);
            
                //Remove all objects first.
            [arr_CurrentRxID_filter removeAllObjects];
            
            if([searchText length] != 0) {
                isSearching = YES;
                [self searchTableList];
            }
            else {
                isSearching = NO;
            }
            [self.table_Current reloadData];
        }
        
        
        
        else
        {
            
            [arr_DeliveredRxID_filter removeAllObjects];
            
            if([searchText length] != 0) {
                isSearching_delivered = YES;
                [self searchTableList_deliver];
            }
            else {
                isSearching_delivered = NO;
            }
            [self.table_Delivered reloadData];
            
        }
    }
    else
    {
        
        if (searchBar==searchbar_current) {
            
            NSLog(@"Text change - %d",isSearching);
            
                //Remove all objects first.
            [arr_CurrentRxID_filter removeAllObjects];
            
            if([searchText length] != 0) {
                isSearching = YES;
                [self searchTableList_byDrivername];
            }
            else {
                isSearching = NO;
            }
            [self.table_Current reloadData];
        }
        
        
        
        else
        {
            
            [arr_DeliveredRxID_filter removeAllObjects];
            
            if([searchText length] != 0) {
                isSearching_delivered = YES;
                [self searchTableList_deliver_byDrivername];
            }
            else {
                isSearching_delivered = NO;
            }
            [self.table_Delivered reloadData];
            
        }
        
    }
    
}


- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Cancel clicked");
    [searchBar resignFirstResponder];
        //isSearching = NO;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
        //[self searchTableList];
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self view] endEditing:YES];
}


- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if (searchBar==searchbar_current)
    /*
     NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
     // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
     
     NSString *filtered = [[text componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
     
     if ([text isEqualToString:filtered]) {
     CGFloat borderWidth = 1.0f;
     
     */{
         return ([searchbar_current.text length] + [text length] - range.length > 15) ? NO : YES;
         
     }
    
    
    else
    {
        /*
         NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
         // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
         
         NSString *filtered = [[text componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
         
         if ([text isEqualToString:filtered]) {
         CGFloat borderWidth = 1.0f;
         */
        
        return ([searchbar_delivered.text length] + [text length] - range.length > 15) ? NO : YES;
        
        
    }
}

    ////////////////// Delivered Filter ///////////////









-(void)btn_download:(UIButton*)sender withEvent:(UIEvent *) event
{
    NSString *str_ID;
    if (isSearching) {
        str_ID=arr_CurrentRxID_filter[sender.tag];
    }
    else
    {
        str_ID=arr_CurrentRxID[sender.tag];
    }
    
    BOOL success = NO;
    
    success=  [[DBManager getSharedInstance]saveData:str_ID StoreID:str_storeID];
    
    if (success == NO) {
            // [activityIndicatorView stopAnimating];
            // activityIndicatorView.hidden=YES;
        /*  UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
         @"Data Already Exists" message:nil
         delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
         [alert show];*/
    }
    else if(success==YES)
    {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
            });
            
            
            
            
            
            NSMutableArray *arr_val=[[NSMutableArray alloc]init];
            [arr_val addObject:str_storeID];
            [arr_val addObject:str_ID];
            [arr_val addObject:@"1"];
            
            NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"IsDownloaded" ,nil];
            
            
            NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
            
            NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
            
            [newUserObject2 setObject:properties forKey:@"ObjDownloadedField"];
            
            
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            NSString *str_service3=[NSString stringWithFormat:@"UpdateIsDownloadedFieldByID"];
            str_service3=[manage.str_url stringByAppendingString:str_service3];
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
            [request setHTTPMethod:@"POST"];
            [request setValue:jsonString forHTTPHeaderField:@"json"];
            [request setHTTPBody:jsonData];
            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
            
            NSError *error = nil;
            NSURLResponse *theResponse = [[NSURLResponse alloc]init];
            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
            if(data)
            {
                NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                
                NSDictionary *tranID2=jsonArray3[@"UpdateIsDownloadedFieldByIDResult"];
                
                NSString *str_SigID=tranID2[@"TransID"];
                
                if (str_SigID.intValue>0) {
                        //  NSLog(@"%@",jsonArray3);
                    
                    
                    
                }
                
            }
            
            
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                });
                
            }
        });
        
        
        
        
        
        [arr_LocalVal removeAllObjects];
        arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
        
        NSArray *tempArr= [arr_LocalVal copy];
        
        NSInteger idx = [tempArr count] - 1;
        
        for (id object in [tempArr reverseObjectEnumerator]) {
            
            if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                [arr_LocalVal removeObjectAtIndex:idx];
            }
            idx--;
        }
        
        
        
        /* UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
         @"Download Successfully" message:nil delegate:nil cancelButtonTitle:
         @"OK" otherButtonTitles:nil];
         [alert show];*/
        
    }
    
    [table_Current reloadData];
    
    /*NSSet *touches = [event allTouches];
     
     UITouch *touch = [touches anyObject];
     
     CGPoint currentTouchPosition = [touch locationInView:table_Current];
     
     NSIndexPath *indexPath = [table_Current indexPathForRowAtPoint: currentTouchPosition];
     NSLog(@"%ld",(long)indexPath.row);
     
     
     
     OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:indexPath];
     
     
     [UIView animateWithDuration:.25
     animations:^{
     
     [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
     }
     ];
     cell.view_Download.hidden=YES;
     */
}
/*-(void) btn_download:(UIButton*)sender
 {
 NSString *str_ID=arr_CurrentRxID[sender.tag];
 
 BOOL success = NO;
 
 success=  [[DBManager getSharedInstance]saveData:str_ID];
 
 if (success == NO) {
 [activityIndicatorView stopAnimating];
 activityIndicatorView.hidden=YES;
 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
 @"Data Already Exist" message:nil
 delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
 [alert show];
 }
 else if(success==YES)
 {
 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
 @"Saved successfully" message:nil delegate:nil cancelButtonTitle:
 @"OK" otherButtonTitles:nil];
 [alert show];
 
 }
 
 
 }
 */

- (void)handleSwipeLeft:(UISwipeGestureRecognizer*)recognizer
{
    
    CGPoint currentTouchPosition = [recognizer locationInView:table_Current];
    
    NSIndexPath *indexPath = [table_Current indexPathForRowAtPoint: currentTouchPosition];
    
        // NSLog(@"%ld",(long)indexPath.row);
    
    
    
    OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:indexPath];
    
    
    [UIView animateWithDuration:.25
                     animations:^{
                         
                         [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                     }
     ];
    cell.view_Download.hidden=YES;
    
    
    
}

-(void)handleSwipeRight1:(UISwipeGestureRecognizer*)recognizer{
    
    [table_Current reloadData];
    OnlineListCellTest *cell1 = [table_Current cellForRowAtIndexPath:selectedIndexPath];
    
    cell1.view_Download.hidden=YES;
    
    [UIView animateWithDuration:.25
                     animations:^{
                         
                         [cell1.view_Scroll setFrame:CGRectMake(0, cell1.view_Scroll.frame.origin.y, cell1.view_Scroll.frame.size.width, cell1.view_Scroll.frame.size.height)];
                     }
     ];
    
    CGPoint currentTouchPosition = [recognizer locationInView:table_Current];
    
    NSIndexPath *indexPath = [table_Current indexPathForRowAtPoint: currentTouchPosition];
    
    selectedIndexPath=indexPath;
    
        // NSLog(@"%ld",(long)indexPath.row);
    
    OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:indexPath];
    
    cell.view_Download.hidden=NO;
    
    [UIView animateWithDuration:.25
                     animations:^{
                         
                         [cell.view_Scroll setFrame:CGRectMake(120, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                     }
     ];
    
        //[table_Current reloadData];
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    [activityIndicatorView removeFromSuperview];
    [arr_pendindRxList removeAllObjects];
    
    
    str_BarCode=@"No";
    if (tableView==table_Current)
    {
        
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            
            if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
            {
            }
            else{
                OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:selectedIndexPath];
                
                cell.view_Download.hidden=YES;
                
                [UIView animateWithDuration:.10
                                 animations:^{
                                     
                                     [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                                 }
                 ];
                
            }
        }
        else
        {
            OnlineListCellTest *cell = [table_Current cellForRowAtIndexPath:selectedIndexPath];
            
            cell.view_Download.hidden=YES;
            
            [UIView animateWithDuration:.10
                             animations:^{
                                 
                                 [cell.view_Scroll setFrame:CGRectMake(0, cell.view_Scroll.frame.origin.y, cell.view_Scroll.frame.size.width, cell.view_Scroll.frame.size.height)];
                             }
             ];
            
        }
        self.view_activity.hidden=NO;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
                    //  NSLog(@"%@",manage.activityTypes);
                
                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                
                CGFloat width = self.view.bounds.size.width;
                CGFloat height = self.view.bounds.size.height;
                
                activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                    // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            });
            
            NSString *str_logid;
            if (isSearching) {
                str_logid=arr_CurrentRxID_filter[indexPath.row];
            }
            else
            {
                str_logid=arr_CurrentRxID[indexPath.row];
            }
            
            NSString *str_urrl11=[NSString stringWithFormat:@"GetShippingLogIsDelivered/%@/%@",str_storeID,str_logid];
            
            NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl11];
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
            
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            NSError *err;
            NSURLResponse *response;
            
            NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
                //   NSLog(@"%@",responsedata);
            
            
            if (responsedata)
            {
                
                NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                    //NSLog(@"%@",jsonArray);
                NSArray *tranID2=jsonArray[@"GetShippingLogIsDeliveredResult"];
                
                if (tranID2.count<=0)
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        DetailedScreen *ln = [[DetailedScreen alloc]initWithNibName:@"DetailedScreen" bundle:nil];
                        ln.arr_pendingRxlist=arr_pendindRxList;
                        if (isSearching) {
                            ln.str_LogID=arr_CurrentRxID_filter[indexPath.row];
                            
                        }
                        else
                        {
                            ln.str_LogID=arr_CurrentRxID[indexPath.row];
                        }
                        
                        manage.arr_OnlineArray=arr_CurrentDelivery_sort;
                        NSLog(@"%@",manage.arr_OnlineArray);
                        [self.navigationController pushViewController:ln animated:NO];
                        
                    });
                }
                else
                {
                    for (NSDictionary *temp in tranID2)
                    {
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        
                        [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                        [arr_pendindRxList addObject:itemshowdetails];
                        
                    }
                    NSString *str_RRxID;
                    for (int k=0; k<arr_pendindRxList.count; k++)
                    {
                        
                        if (k==0)
                        {
                            str_RRxID=[NSString stringWithFormat:@"%@",arr_pendindRxList[k][@"RxID"]];
                        }
                        else
                        {
                            str_RRxID=[NSString stringWithFormat:@"%@, %@",str_RRxID,arr_pendindRxList[k][@"RxID"]];
                        }
                    }
                    
                    BOOL issuccess=NO;
                    
                    issuccess=[[DBManager getSharedInstance] deleteRxIDList:str_storeID LogID:str_logid RxID:str_RRxID];
                    
                        //     arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                    
                    
                    if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
                    {
                        
                        if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
                        {
                            
                            NSString *str_Deleted=@"";
                            
                            for (int b=0; b<arr_CurrentDelivery_sort.count; b++)
                            {
                                if ([str_logid isEqualToString:arr_CurrentDelivery_sort[b][@"ShipLogID"]])
                                {
                                    
                                    NSString *RxCond=@"";
                                    
                                    for (int e=0; e<arr_pendindRxList.count; e++)
                                    {
                                        if ([arr_CurrentDelivery_sort[b][@"RxID"]intValue] ==[arr_pendindRxList[e][@"RxID"]intValue])
                                        {
                                            RxCond=@"Yes";
                                        }
                                    }//8261798
                                    if ([RxCond isEqualToString:@"Yes"]) {
                                        
                                    }
                                    else
                                    {
                                        str_Deleted=@"Yes";
                                        [arr_CurrentDelivery_sort removeObjectAtIndex:b];
                                        b--;
                                    }
                                }
                            }
                            
                            if ([str_Deleted isEqualToString:@"Yes"])
                            {
                                
                            }
                            else
                            {
                                
                            }
                            
                        }
                        
                        
                        
                    }
                    
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.view_activity.hidden=YES;
                        [activityIndicatorView stopAnimating];
                        
                        
                        
                        
                        DetailedScreen *ln = [[DetailedScreen alloc]initWithNibName:@"DetailedScreen" bundle:nil];
                        ln.arr_pendingRxlist=arr_pendindRxList;
                        if (isSearching) {
                            ln.str_LogID=arr_CurrentRxID_filter[indexPath.row];
                            
                        }
                        else
                        {
                            ln.str_LogID=arr_CurrentRxID[indexPath.row];
                            
                        }
                        manage.arr_OnlineArray=arr_CurrentDelivery_sort;
                        NSLog(@"%@",manage.arr_OnlineArray);
                        [self.navigationController pushViewController:ln animated:NO];
                        
                    });
                    
                }
                
            }
            
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    [arr_pendindRxList addObject:@"1"];
                    
                    DetailedScreen *ln = [[DetailedScreen alloc]initWithNibName:@"DetailedScreen" bundle:nil];
                    
                    ln.arr_pendingRxlist=arr_pendindRxList;
                    if (isSearching) {
                        ln.str_LogID=arr_CurrentRxID_filter[indexPath.row];
                    }
                    else
                    {
                        ln.str_LogID=arr_CurrentRxID[indexPath.row];
                    }
                    manage.arr_OnlineArray=arr_CurrentDelivery_sort;
                    NSLog(@"%@",manage.arr_OnlineArray);
                    [self.navigationController pushViewController:ln animated:NO];
                });
            }
        });
    }
    else if(tableView==table_Delivered)
    {
        DeliveredDetailedScreen *ln = [[DeliveredDetailedScreen alloc]initWithNibName:@"DeliveredDetailedScreen" bundle:nil];
        
        manage.arr_OnlineDeliveredArray=arr_DeliveredDelivery;
        manage.arr_OnlineArray=arr_CurrentDelivery_sort;
        
        if (isSearching_delivered) {
            ln.str_LogID=arr_DeliveredRxID_filter[indexPath.row];
            
        }
        else
        {
            ln.str_LogID=arr_DeliveredRxID[indexPath.row];
            
        }
        
        [self.navigationController pushViewController:ln animated:NO];
        
    }
    else{
      //  StoreID,LogID,DriverName,LoggedInBy
        
        str_Drivername_Driverupdate=arr_driverlist[indexPath.row][@"UserName"];
        str_DriverID_Driverupdate = arr_driverlist[indexPath.row][@"UserID"];
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:[NSString stringWithFormat:@"Do you want to Reassign '%@' to '%@', driver? ",str_FromDriver,str_Drivername_Driverupdate] delegate:self cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
        alert.tag = 10;
        [alert show];
    }
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==table_Current)
    {
        if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
        {
            if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
            {
                return NO;
            }
            else
            {
                NSString *strLogID10=@"";
                
                if (isSearching) {
                    strLogID10=arr_CurrentRxID_filter[indexPath.row];
                    
                }
                else
                {
                    strLogID10=arr_CurrentRxID[indexPath.row];
                    
                }
                
                NSString *str_color10;
                
                for (int k=0; k<arr_LocalVal.count; k++)
                {
                    if ([strLogID10 isEqualToString:arr_LocalVal[k][@"ShipLogID"]]) {
                        
                        str_color10=@"No";
                        
                    }
                    
                }
                if (![str_color10 isEqualToString:@"No"])
                {
                    return NO;
                }
                else
                {
                    OnlineListCellTest *cell1 = [table_Current cellForRowAtIndexPath:selectedIndexPath];
                    
                    cell1.view_Download.hidden=YES;
                    
                    [UIView animateWithDuration:.25
                                     animations:^{
                                         
                                         [cell1.view_Scroll setFrame:CGRectMake(0, cell1.view_Scroll.frame.origin.y, cell1.view_Scroll.frame.size.width, cell1.view_Scroll.frame.size.height)];
                                     }
                     ];
                    
                    return YES;
                    
                }
                
            }
        }
        else
        {
            NSString *strLogID10=@"";
            
            if (isSearching) {
                strLogID10=arr_CurrentRxID_filter[indexPath.row];
                
            }
            else
            {
                strLogID10=arr_CurrentRxID[indexPath.row];
                
            }
            
            NSString *str_color10;
            
            for (int k=0; k<arr_LocalVal.count; k++)
            {
                if ([strLogID10 isEqualToString:arr_LocalVal[k][@"ShipLogID"]]) {
                    
                    str_color10=@"No";
                    
                }
                
            }
            if (![str_color10 isEqualToString:@"No"])
            {
                return NO;
            }
            else
            {
                OnlineListCellTest *cell1 = [table_Current cellForRowAtIndexPath:selectedIndexPath];
                
                cell1.view_Download.hidden=YES;
                
                [UIView animateWithDuration:.25
                                 animations:^{
                                     
                                     [cell1.view_Scroll setFrame:CGRectMake(0, cell1.view_Scroll.frame.origin.y, cell1.view_Scroll.frame.size.width, cell1.view_Scroll.frame.size.height)];
                                 }
                 ];
                
                return YES;
                
            }
            
        }
    }
    else
    {
        return NO;
    }
}



/*
 -(NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
 if (tableView==table_Current)
 {
 UITableViewRowAction *editAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"Delete Local" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath){
 
 
 NSString *str_iddd=arr_CurrentRxID[indexPath.row];
 BOOL success=[[DBManager getSharedInstance]deleteLocalArray:str_iddd];
 
 if (success == NO)
 {
 
 }
 else if(success==YES)
 {
 [arr_LocalVal removeAllObjects];
 arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues];
 
 NSArray *tempArr= [arr_LocalVal copy];
 
 NSInteger idx = [tempArr count] - 1;
 
 for (id object in [tempArr reverseObjectEnumerator]) {
 
 if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
 [arr_LocalVal removeObjectAtIndex:idx];
 }
 idx--;
 }
 [table_Current reloadData];
 }
 
 }];
 editAction.backgroundColor = [UIColor redColor];
 
 
 return @[editAction];
 }
 else
 {
 return nil;
 
 }
 }
 */

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        self.view_activity.hidden=NO;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                
                    //  NSLog(@"%@",manage.activityTypes);
                /*
                 activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                 
                 CGFloat width = self.view.bounds.size.width;
                 CGFloat height = self.view.bounds.size.height;
                 
                 activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                 // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
                 
                 */
                [self.view_activity addSubview:activityIndicatorView];
                [activityIndicatorView startAnimating];
            });
            
            
            NSString *str_iddd=@"";
            if (isSearching) {
                str_iddd=arr_CurrentRxID_filter[indexPath.row];
                
            }
            else
            {
                str_iddd=arr_CurrentRxID[indexPath.row];
                
            }
            BOOL success=[[DBManager getSharedInstance]deleteLocalArray:str_iddd StoreID:str_storeID];
            
            if (success == NO)
            {
                
                [arr_LocalVal removeAllObjects];
                arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
                
                NSArray *tempArr= [arr_LocalVal copy];
                
                NSInteger idx = [tempArr count] - 1;
                
                for (id object in [tempArr reverseObjectEnumerator]) {
                    
                    if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                        [arr_LocalVal removeObjectAtIndex:idx];
                    }
                    idx--;
                }
                
                [table_Current reloadData];
                
            }
            else if(success==YES)
            {
                
                
                
                
                
                NSMutableArray *arr_val=[[NSMutableArray alloc]init];
                [arr_val addObject:str_storeID];
                [arr_val addObject:str_iddd];
                [arr_val addObject:@"0"];
                
                NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"IsDownloaded" ,nil];
                
                
                NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
                
                NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
                
                [newUserObject2 setObject:properties forKey:@"ObjDownloadedField"];
                
                
                NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
                NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                NSString *str_service3=[NSString stringWithFormat:@"UpdateIsDownloadedFieldByID"];
                str_service3=[manage.str_url stringByAppendingString:str_service3];
                NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
                [request setHTTPMethod:@"POST"];
                [request setValue:jsonString forHTTPHeaderField:@"json"];
                [request setHTTPBody:jsonData];
                [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                
                NSError *error = nil;
                NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                if(data)
                {
                    NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                    
                    NSDictionary *tranID2=jsonArray3[@"UpdateIsDownloadedFieldByIDResult"];
                    
                    NSString *str_SigID=tranID2[@"TransID"];
                    
                    if (str_SigID.intValue>0) {
                            //  NSLog(@"%@",jsonArray3);
                        if (isSearching) {
                            
                            for (int k=0; k<arr_CurrentDelivery_filter.count; k++) {
                                
                                if ([str_iddd isEqualToString:arr_CurrentDelivery_filter[k][@"ShipLogID"] ])
                                {
                                    
                                    NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DeliveredDate"] forKey:@"DeliveredDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DriverName"] forKey:@"DriverName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"DrugName"] forKey:@"DrugName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"IsPOS"] forKey:@"IsPOS"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCity"] forKey:@"PatientCity"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientMobile"] forKey:@"PatientMobile"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientName"] forKey:@"PatientName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientState"] forKey:@"PatientState"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientStreet"] forKey:@"PatientStreet"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxID"] forKey:@"RxID"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Qty"] forKey:@"Qty"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Patientzip"] forKey:@"Patientzip"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Patpay"] forKey:@"Patpay"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PickupDate"] forKey:@"PickupDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxDate"] forKey:@"RxDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxNumber"] forKey:@"RxNumber"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShipLogID"] forKey:@"ShipLogID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShipNotes"] forKey:@"ShipNotes"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientCCCode"] forKey:@"PatientCCCode"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientEmail"] forKey:@"PatientEmail"];
                                    
                                    [itemshowdetails setValue:@"0" forKey:@"IsDownloaded"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ARAddress"] forKey:@"ARAddress"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ARBalance"] forKey:@"ARBalance"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Acct"] forKey:@"Acct"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Ar"] forKey:@"Ar"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Bill"] forKey:@"Bill"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"State"] forKey:@"State"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"City"] forKey:@"City"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Phone1"] forKey:@"Phone1"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"Zip"] forKey:@"Zip"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ArChargeID"] forKey:@"ArChargeID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"HipaaSigID"] forKey:@"HipaaSigID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"PatientID"] forKey:@"PatientID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"HipaaSig"] forKey:@"HipaaSig"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"BalanceAmt"] forKey:@"BalanceAmt"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"RxARItemID"] forKey:@"RxARItemID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                                    [itemshowdetails setValue:arr_CurrentDelivery_filter[k][@"flag"] forKey:@"flag"];


                                    [arr_CurrentDelivery_filter replaceObjectAtIndex:k withObject:itemshowdetails];
                                    
                                    
                                }
                                
                            }
                            
                            
                            
                            
                            for (int i=0; i<arr_CurrentDelivery_sort.count; i++) {
                                
                                if ([str_iddd isEqualToString:arr_CurrentDelivery_sort[i][@"ShipLogID"]])
                                {
                                    
                                    
                                    NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DeliveredDate"] forKey:@"DeliveredDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DriverName"] forKey:@"DriverName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"DrugName"] forKey:@"DrugName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"IsPOS"] forKey:@"IsPOS"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCity"] forKey:@"PatientCity"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientMobile"] forKey:@"PatientMobile"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientName"] forKey:@"PatientName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientState"] forKey:@"PatientState"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientStreet"] forKey:@"PatientStreet"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxID"] forKey:@"RxID"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Qty"] forKey:@"Qty"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Patientzip"] forKey:@"Patientzip"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Patpay"] forKey:@"Patpay"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PickupDate"] forKey:@"PickupDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxDate"] forKey:@"RxDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxNumber"] forKey:@"RxNumber"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShipLogID"] forKey:@"ShipLogID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShipNotes"] forKey:@"ShipNotes"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientCCCode"] forKey:@"PatientCCCode"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientEmail"] forKey:@"PatientEmail"];
                                    
                                    
                                    [itemshowdetails setValue:@"0" forKey:@"IsDownloaded"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ARAddress"] forKey:@"ARAddress"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ARBalance"] forKey:@"ARBalance"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Acct"] forKey:@"Acct"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Ar"] forKey:@"Ar"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Bill"] forKey:@"Bill"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"State"] forKey:@"State"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"City"] forKey:@"City"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Phone1"] forKey:@"Phone1"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"Zip"] forKey:@"Zip"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ArChargeID"] forKey:@"ArChargeID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"HipaaSigID"] forKey:@"HipaaSigID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"PatientID"] forKey:@"PatientID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"HipaaSig"] forKey:@"HipaaSig"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"BalanceAmt"] forKey:@"BalanceAmt"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"RxARItemID"] forKey:@"RxARItemID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"ShippingDetailID"] forKey:@"ShippingDetailID"];

                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[i][@"flag"] forKey:@"flag"];
                                    
                                    [arr_CurrentDelivery_sort replaceObjectAtIndex:i withObject:itemshowdetails];
                                    
                                }
                            }
                            
                            
                        }
                        
                        else
                        {
                            
                            
                            for (int k=0; k<arr_CurrentDelivery_sort.count; k++) {
                                
                                if ([str_iddd isEqualToString:arr_CurrentDelivery_sort[k][@"ShipLogID"] ])
                                {
                                    
                                    
                                    NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                                    
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DeliveredDate"] forKey:@"DeliveredDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DriverName"] forKey:@"DriverName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"DrugName"] forKey:@"DrugName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"IsPOS"] forKey:@"IsPOS"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCity"] forKey:@"PatientCity"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientMobile"] forKey:@"PatientMobile"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientName"] forKey:@"PatientName"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientState"] forKey:@"PatientState"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientStreet"] forKey:@"PatientStreet"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxID"] forKey:@"RxID"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Qty"] forKey:@"Qty"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Patientzip"] forKey:@"Patientzip"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Patpay"] forKey:@"Patpay"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PickupDate"] forKey:@"PickupDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxDate"] forKey:@"RxDate"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxNumber"] forKey:@"RxNumber"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShipLogID"] forKey:@"ShipLogID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShipNotes"] forKey:@"ShipNotes"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientCCCode"] forKey:@"PatientCCCode"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientEmail"] forKey:@"PatientEmail"];
                                    
                                    
                                    [itemshowdetails setValue:@"0" forKey:@"IsDownloaded"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ARAddress"] forKey:@"ARAddress"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ARBalance"] forKey:@"ARBalance"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Acct"] forKey:@"Acct"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Ar"] forKey:@"Ar"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Bill"] forKey:@"Bill"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"State"] forKey:@"State"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"City"] forKey:@"City"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Phone1"] forKey:@"Phone1"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"Zip"] forKey:@"Zip"];
                                    
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ArChargeID"] forKey:@"ArChargeID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"HipaaSigID"] forKey:@"HipaaSigID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"PatientID"] forKey:@"PatientID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"HipaaSig"] forKey:@"HipaaSig"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"BalanceAmt"] forKey:@"BalanceAmt"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"RxARItemID"] forKey:@"RxARItemID"];
                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"ShippingDetailID"] forKey:@"ShippingDetailID"];


                                    [itemshowdetails setValue:arr_CurrentDelivery_sort[k][@"flag"] forKey:@"flag"];
                                    
                                    [arr_CurrentDelivery_sort replaceObjectAtIndex:k withObject:itemshowdetails];
                                    
                                    
                                }
                            }
                            
                            
                            
                            
                            
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                            [arr_LocalVal removeAllObjects];
                            arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
                            
                            NSArray *tempArr= [arr_LocalVal copy];
                            
                            NSInteger idx = [tempArr count] - 1;
                            
                            for (id object in [tempArr reverseObjectEnumerator]) {
                                
                                if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                                    [arr_LocalVal removeObjectAtIndex:idx];
                                }
                                idx--;
                            }
                            
                            [table_Current reloadData];
                            [activityIndicatorView stopAnimating];
                            self.view_activity.hidden=YES;
                            
                            
                            
                        });
                        
                        
                        
                        
                    }
                    else
                    {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                            [table_Current reloadData];
                            [activityIndicatorView stopAnimating];
                            self.view_activity.hidden=YES;
                            
                            
                            
                        });
                    }
                }
                
                
                else
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [activityIndicatorView stopAnimating];
                        self.view_activity.hidden=YES;
                        
                        
                        
                    });
                    
                }
                
                
                
                
                    //[tableView endUpdates];
            }
        });
    }
}

#pragma mark - Button Search

-(IBAction)btn_Search:(id)sender
{
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    
    [table_Current reloadData];
    str_BarCode=@"Yes";
    
    OnlineListCell *cell1 = [table_Current cellForRowAtIndexPath:selectedIndexPath];
    
    cell1.view_Download.hidden=YES;
    
    [UIView animateWithDuration:0
                     animations:^{
                         
                         [cell1.view_Scroll setFrame:CGRectMake(0, cell1.view_Scroll.frame.origin.y, cell1.view_Scroll.frame.size.width, cell1.view_Scroll.frame.size.height)];
                     }
     ];
    
    
    DeliveryOrderScreen *ln = [[DeliveryOrderScreen alloc]initWithNibName:@"DeliveryOrderScreen" bundle:nil];
    [self.navigationController pushViewController:ln animated:NO];
}



-(void)today_Refresh
{
    
    str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
    str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
    lab_Date.text=@"Today";
    view_Date_Large.hidden=YES;
    view_Date_Small.hidden=NO;
    str_dateType=@"Small";
    
    manage.str_DateLabel=@"Today";
    
    
    manage.str_StartDatee=str_StartDate;
    manage.str_EndDatee=str_EndDate;
    
        //manage.str_StartDatee=@"06-11-2017";
        //manage.str_EndDatee=@"06-11-2017";
    
        //  Formate_CurrentDate
    
    NSString *str_datte =[Formate_CurrentDate stringFromDate:[NSDate date]];
    
    
    str_datee=str_datte;
    manage.str_dateLabText=str_datee;
    
    if ([manage.arr_storeInfoList[@"AccessLevelID"]intValue]==0)
    {
        
        if ([manage.arr_storeInfoList[@"DeliveryAppAccessLevelID"]intValue]==0)
        {
            
            [arr_CurrentDelivery_sort removeAllObjects];
            arr_CurrentDelivery= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
            
            for (NSDictionary *temp1 in arr_CurrentDelivery)
            {
                NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
                [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
                [itemshowdetails1 setValue:temp1[@"DriverName"] forKey:@"DriverName"];
                [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
                [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
                [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
                [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
                [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
                [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
                [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
                [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
                
                [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
                
                [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
                [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
                [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
                [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
                [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
                [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
                [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
                [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
                [itemshowdetails1 setValue:temp1[@"PatientEmail"] forKey:@"PatientEmail"];
                
                [itemshowdetails1 setValue:temp1[@"ARAddress"] forKey:@"ARAddress"];
                [itemshowdetails1 setValue:temp1[@"ARBalance"] forKey:@"ARBalance"];
                [itemshowdetails1 setValue:temp1[@"Acct"] forKey:@"Acct"];
                [itemshowdetails1 setValue:temp1[@"Ar"] forKey:@"Ar"];
                [itemshowdetails1 setValue:temp1[@"Bill"] forKey:@"Bill"];
                [itemshowdetails1 setValue:temp1[@"State"] forKey:@"State"];
                [itemshowdetails1 setValue:temp1[@"City"] forKey:@"City"];
                [itemshowdetails1 setValue:temp1[@"Phone1"] forKey:@"Phone1"];
                [itemshowdetails1 setValue:temp1[@"Zip"] forKey:@"Zip"];
                [itemshowdetails1 setValue:temp1[@"ArChargeID"] forKey:@"ArChargeID"];
                [itemshowdetails1 setValue:temp1[@"HipaaSigID"] forKey:@"HipaaSigID"];
                [itemshowdetails1 setValue:temp1[@"PatientID"] forKey:@"PatientID"];
                [itemshowdetails1 setValue:temp1[@"HipaaSig"] forKey:@"HipaaSig"];
                [itemshowdetails1 setValue:temp1[@"BalanceAmt"] forKey:@"BalanceAmt"];
                [itemshowdetails1 setValue:temp1[@"RxARItemID"] forKey:@"RxARItemID"];
                [itemshowdetails1 setValue:temp1[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                [itemshowdetails1 setValue:temp1[@"DriverID"] forKey:@"DriverID"];
                [itemshowdetails1 setValue:@"" forKey:@"flag"];
                [arr_CurrentDelivery_sort addObject:itemshowdetails1];
            }
            
            
            [arr_CurrentRxID removeAllObjects];
            
                //    success=[[DBManager getSharedInstance]saveDataSig:txt_name.text Relation:txt_relation.text Signature:str_100 XmlTrans:xmltrans IsPOS:str_IsPOS];
            
            
            if (arr_CurrentDelivery.count<=0)
            {
                view_Current_NoData.hidden=NO;
                self.view_activity.hidden=YES;
                
            }
            else
            {
                for (int i=0; i<arr_CurrentDelivery.count; i++) {
                    NSString *str=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"ShipLogID"]];
                    [arr_CurrentRxID addObject:str];
                    NSString *str1=[NSString stringWithFormat:@"%@",(arr_CurrentDelivery)[i][@"DriverName"]];
                    [arr_CurrentDriverName addObject:str1];
                    
                }
                NSArray *tempArr= [arr_CurrentRxID copy];
                
                NSInteger idx = [tempArr count] - 1;
                
                for (id object in [tempArr reverseObjectEnumerator]) {
                    
                    if ([arr_CurrentRxID indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                        [arr_CurrentRxID removeObjectAtIndex:idx];
                    }
                    idx--;
                }
                view_Current_NoData.hidden=YES;
                
                manage.arr_OnlineArray=arr_CurrentDelivery;
                [table_Current reloadData];
                self.view_activity.hidden=YES;
                
            }
            [self DeliveredList];
            
        }
        else
        {
            [self CurrentList];
            
        }
    }
    else
    {
        [self CurrentList];
        
    }
    
}

-(void)bulkDownload
{
    
    self.view_activity.hidden=NO;
    [arr_CurrentRxID removeAllObjects];
    [arr_CurrentDriverName removeAllObjects];
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
                //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
            // NSString *myurlString = @"http://192.168.1.58:8085/Delivery.svc/DeliveryLogByUserID/100010/15/2-23-2017/2-23-2017";
            // str_StartDate=@"04-19-2017";
            // str_EndDate=@"04-19-2017";
        
            //   NSString *str_DriverName1=@"";
        
        NSString *str_urrl=[NSString stringWithFormat:@"IOSDeliveryDetailByID/%@/%@/%@/%@/CURRENT",str_storeID,manage.str_startdate_bulk,manage.str_enddate_bulk,manage.str_DriverName];
        
            // NSString *str_urrl=[NSString stringWithFormat:@"DeliveryDetailByID/%@/%@/%@/%@/CURRENT",manage.arr_storeInfoList[@"StoreID"],str_StartDate,str_EndDate,str_DriverName1];
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
            // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"IOSDeliveryDetailByIDResult"];
            
                //  arr_LogIDList= jsonArray[@"DeliveryLogByUserIDResult"];
            
            if (arr_Content.count==0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                                    message:@"No DeliveredLogID Found"
                                                                   delegate:self
                                                          cancelButtonTitle:@"OK"
                                                          otherButtonTitles:nil, nil];
                    
                    alert.tag=12;
                    [alert show];
                    
                    
                    [table_Current reloadData];
                    
                    
                    
                });
            }
            else
            {
                [arr_CurrentDelivery removeAllObjects];
                [arr_CurrentDelivery_sort removeAllObjects];
                
                for (NSDictionary *temp in arr_Content)
                {
                    NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                    [itemshowdetails setValue:temp[@"DeliveredDate"] forKey:@"DeliveredDate"];
                    [itemshowdetails setValue:temp[@"Dispatcher"] forKey:@"Dispatcher"];
                    [itemshowdetails setValue:temp[@"DrugName"] forKey:@"DrugName"];
                    [itemshowdetails setValue:temp[@"IsPOS"] forKey:@"IsPOS"];
                    [itemshowdetails setValue:temp[@"PatientCity"] forKey:@"PatientCity"];
                    [itemshowdetails setValue:temp[@"PatientMobile"] forKey:@"PatientMobile"];
                    [itemshowdetails setValue:temp[@"PatientName"] forKey:@"PatientName"];
                    [itemshowdetails setValue:temp[@"PatientState"] forKey:@"PatientState"];
                    [itemshowdetails setValue:temp[@"PatientStreet"] forKey:@"PatientStreet"];
                    [itemshowdetails setValue:temp[@"RxID"] forKey:@"RxID"];
                    
                    [itemshowdetails setValue:temp[@"Qty"] forKey:@"Qty"];
                    
                    [itemshowdetails setValue:temp[@"Patientzip"] forKey:@"Patientzip"];
                    [itemshowdetails setValue:temp[@"Patpay"] forKey:@"Patpay"];
                    [itemshowdetails setValue:temp[@"PickupDate"] forKey:@"PickupDate"];
                    [itemshowdetails setValue:temp[@"RxDate"] forKey:@"RxDate"];
                    [itemshowdetails setValue:temp[@"RxNumber"] forKey:@"RxNumber"];
                    [itemshowdetails setValue:temp[@"ShipLogID"] forKey:@"ShipLogID"];
                    [itemshowdetails setValue:temp[@"ShipNotes"] forKey:@"ShipNotes"];
                    [itemshowdetails setValue:temp[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
                    [itemshowdetails setValue:temp[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
                    [itemshowdetails setValue:temp[@"PatientCCCode"] forKey:@"PatientCCCode"];
                    [itemshowdetails setValue:temp[@"PatientEmail"] forKey:@"PatientEmail"];
                    [itemshowdetails setValue:temp[@"DriverName"] forKey:@"DriverName"];
                    [itemshowdetails setValue:temp[@"IsDownloaded"] forKey:@"IsDownloaded"];
                    
                    
                    [itemshowdetails setValue:temp[@"ARAddress"] forKey:@"ARAddress"];
                    [itemshowdetails setValue:temp[@"ARBalance"] forKey:@"ARBalance"];
                    [itemshowdetails setValue:temp[@"Acct"] forKey:@"Acct"];
                    [itemshowdetails setValue:temp[@"Ar"] forKey:@"Ar"];
                    [itemshowdetails setValue:temp[@"Bill"] forKey:@"Bill"];
                    [itemshowdetails setValue:temp[@"State"] forKey:@"State"];
                    [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                    [itemshowdetails setValue:temp[@"Phone1"] forKey:@"Phone1"];
                    [itemshowdetails setValue:temp[@"Zip"] forKey:@"Zip"];
                    
                    [itemshowdetails setValue:temp[@"ArChargeID"] forKey:@"ArChargeID"];
                    [itemshowdetails setValue:temp[@"HipaaSigID"] forKey:@"HipaaSigID"];
                    [itemshowdetails setValue:temp[@"PatientID"] forKey:@"PatientID"];
                    [itemshowdetails setValue:temp[@"HipaaSig"] forKey:@"HipaaSig"];
                    
                    [itemshowdetails setValue:temp[@"BalanceAmt"] forKey:@"BalanceAmt"];
                    [itemshowdetails setValue:temp[@"RxARItemID"] forKey:@"RxARItemID"];
                    [itemshowdetails setValue:temp[@"ShippingDetailID"] forKey:@"ShippingDetailID"];
                    [itemshowdetails setValue:temp[@"DriverID"] forKey:@"DriverID"];
                    
                    [itemshowdetails setValue:@"" forKey:@"flag"];
                    
                    [arr_CurrentDelivery addObject:itemshowdetails];
                    
                        //[arr_CurrentDelivery_sort addObject:itemshowdetails];
                }
                
                    //  NSMutableArray *arr_test=[[NSMutableArray alloc]init];
                
                    //   arr_test= [[DBManager getSharedInstance]retrive_values:manage.str_StartDatee EDate:manage.str_EndDatee StoreID:str_storeID];
                
                manage.arr_OnlineArray=arr_CurrentDelivery;
                arr_CurrentDelivery_sort=manage.arr_OnlineArray;
                NSLog(@"%@",manage.arr_OnlineArray);
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                    view_Current_NoData.hidden=YES;
                    
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    
                    
                    int ii=0;
                    for (ii; ii<manage.arr_OnlineArray.count; ii++) {
                        
                        BOOL success = NO;
                        
                        success=  [[DBManager getSharedInstance]saveData:manage.arr_OnlineArray[ii][@"ShipLogID"] StoreID:str_storeID];
                        
                        if (success == NO) {
                            
                        }
                        else if(success==YES)
                        {
                            
                            NSMutableArray *arr_val=[[NSMutableArray alloc]init];
                            [arr_val addObject:str_storeID];
                            [arr_val addObject:manage.arr_OnlineArray[ii][@"ShipLogID"]];
                            [arr_val addObject:@"1"];
                            
                            NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"IsDownloaded" ,nil];
                            
                            
                            NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
                            
                            NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
                            
                            [newUserObject2 setObject:properties forKey:@"ObjDownloadedField"];
                            
                            
                            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
                            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                            NSString *str_service3=[NSString stringWithFormat:@"UpdateIsDownloadedFieldByID"];
                            str_service3=[manage.str_url stringByAppendingString:str_service3];
                            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
                            [request setHTTPMethod:@"POST"];
                            [request setValue:jsonString forHTTPHeaderField:@"json"];
                            [request setHTTPBody:jsonData];
                            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                            
                            NSError *error = nil;
                            NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                            if(data)
                            {
                                NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                
                                NSDictionary *tranID2=jsonArray3[@"UpdateIsDownloadedFieldByIDResult"];
                                
                                NSString *str_SigID=tranID2[@"TransID"];
                                
                                if (str_SigID.intValue>0) {
                                        //  NSLog(@"%@",jsonArray3);
                                    
                                    
                                    
                                }
                                
                            }
                            
                            
                            else
                            {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    self.view_activity.hidden=YES;
                                    [activityIndicatorView stopAnimating];
                                    
                                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                                    
                                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                                    [alertController addAction:ok];
                                    
                                    [self presentViewController:alertController animated:YES completion:nil];
                                    [self today_Refresh];
                                    
                                });
                                
                            }
                            
                            
                            
                            
                            
                            
                            
                            /* UIAlertView *alert = [[UIAlertView alloc]initWithTitle:
                             @"Download Successfully" message:nil delegate:nil cancelButtonTitle:
                             @"OK" otherButtonTitles:nil];
                             [alert show];*/
                            
                        }
                        
                        
                        
                        
                        
                        self.view_activity.hidden=YES;
                        
                        
                        
                    }
                    
                    [arr_LocalVal removeAllObjects];
                    arr_LocalVal= [[DBManager getSharedInstance]retrive_LocalValues:str_storeID];
                    
                    NSArray *tempArr= [arr_LocalVal copy];
                    
                    NSInteger idx = [tempArr count] - 1;
                    
                    for (id object in [tempArr reverseObjectEnumerator]) {
                        
                        if ([arr_LocalVal indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
                            [arr_LocalVal removeObjectAtIndex:idx];
                        }
                        idx--;
                    }
                    
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                                    message:@"Download Successfully"
                                                                   delegate:self
                                                          cancelButtonTitle:@"OK"
                                                          otherButtonTitles:nil, nil];
                    
                    alert.tag=12;
                    [alert show];
                    
                    
                        //   [table_Current reloadData];
                    
                    
                });
                
            }
        }
        
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.view_activity.hidden=YES;
                [activityIndicatorView stopAnimating];
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your internet connection" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
                [self today_Refresh];
                
            });
        }
        
    });
    
}

-(IBAction)btn_Bulk_Download:(id)sender
{
    [searchbar_current resignFirstResponder];
    [searchbar_delivered resignFirstResponder];
    
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
    {
        
        /* Device is iPad */
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select Date"
                                                                 delegate:self
                                                        cancelButtonTitle:@"Cancel"
                                                   destructiveButtonTitle:@"Today"
                                                        otherButtonTitles:@"Yesterday", @"This Week", @"Custom", nil];
        
        [actionSheet showInView:self.view];
        
        str_date_select_bulk=@"yes";
        
        
    }
    
    else{
        
        UIAlertController *actionSheet = [[UIAlertController alloc]init];// alertControllerWithTitle:@"Action Sheet" message:@"alert controller" preferredStyle:UIAlertControllerStyleActionSheet];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            
            
                // Cancel button tappped.
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Today" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:[NSDate date]];
            NSString *str_datte =[Formate_CurrentDate stringFromDate:[NSDate date]];
            
            manage.str_startdate_bulk=str_StartDate;
            manage.str_enddate_bulk=str_EndDate;
            
            
            [self bulkDownload];
            
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Yesterday" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            NSDate *back_date = [[NSDate date] dateByAddingTimeInterval:-1*24*60*60];
            
            NSString *str_datte =[Formate_CurrentDate stringFromDate:back_date];
            
            
            str_datee=str_datte;
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:back_date];
            manage.str_startdate_bulk=str_StartDate;
            manage.str_enddate_bulk=str_EndDate;
            
            [self bulkDownload];
            
            
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"This Week" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            NSCalendar *cal = [NSCalendar currentCalendar];
            NSDate *now = [NSDate date];
            NSDate *startOfTheWeek;
            NSDate *endOfWeek;
            NSTimeInterval interval;
            [cal rangeOfUnit:NSCalendarUnitWeekOfMonth
                   startDate:&startOfTheWeek
                    interval:&interval
                     forDate:now];
                //startOfWeek holds now the first day of the week, according to locale (monday vs. sunday)
                // startOfTheWeek=
            endOfWeek = [startOfTheWeek dateByAddingTimeInterval:interval-1];
            
            
            
            
            NSString *dateString1 = [Formate_DateMonthYear stringFromDate:startOfTheWeek];
            NSString *dateString2 = [Formate_DateMonthYear stringFromDate:endOfWeek];
            
            str_StartDate=[Formate_DateMonthYear_Service stringFromDate:startOfTheWeek];
            str_EndDate=[Formate_DateMonthYear_Service stringFromDate:endOfWeek];
            
            manage.str_startdate_bulk=str_StartDate;
            manage.str_enddate_bulk=str_EndDate;
            
            
                // NSString *str_weekStart=[dateString1 stringByAppendingString:@" - "];
                // lab_Date.text=[str_weekStart stringByAppendingString:dateString2];
            
            
            [self bulkDownload];
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Custom" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            [self dismissViewControllerAnimated:YES completion:^{
            }];
            
            
            
            MSSCalendarViewController *cvc = [[MSSCalendarViewController alloc]init];
            cvc.limitMonth = 12 * 5;
            /*
             MSSCalendarViewControllerLastType
             MSSCalendarViewControllerMiddleType
             MSSCalendarViewControllerNextType
             */
            cvc.type = MSSCalendarViewControllerLastType;
            cvc.beforeTodayCanTouch = YES;
            cvc.afterTodayCanTouch = NO;
            
            
            NSDate *date = [Formate_DateMonthYear_Service dateFromString:manage.str_startdate_bulk];
            NSDate *date1 = [Formate_DateMonthYear_Service dateFromString:manage.str_enddate_bulk];
            long dateInSeconds =  [date timeIntervalSince1970];
            long dateInSeconds1 =  [date1 timeIntervalSince1970];
            cvc.startDate = dateInSeconds;
            cvc.endDate = dateInSeconds1;
            cvc.showChineseHoliday = NO;
            cvc.showChineseCalendar = NO;
            cvc.showHolidayDifferentColor = NO;
            cvc.showAlertView = NO;
            cvc.delegate = self;
            
            
            str_bulkCustomCalender=@"yes";
            [self presentViewController:cvc animated:YES completion:nil];
            
        }]];
            // Present action sheet.
        [self presentViewController:actionSheet animated:YES completion:nil];
        
    }
    
}

#pragma mark - Button Scan
-(IBAction)btn_scanOut_delivery:(id)sender
{
    ScanReadyforDeliver *scan = [[ScanReadyforDeliver alloc]initWithNibName:@"ScanReadyforDeliver" bundle:nil];
    [self.navigationController pushViewController:scan animated:NO];
}



#pragma mark - Button Back

-(IBAction)btn_Back:(id)sender
{
    HomeScreen *ln = [[HomeScreen alloc]initWithNibName:@"HomeScreen" bundle:nil];
    [self.navigationController pushViewController:ln animated:NO];
}

#pragma mark - Barcode Button

-(IBAction)btn_BarCodeScanner:(id)sender
{
    str_BarCode=@"Yes";
    
    
    BarCodeScaner *ln = [[BarCodeScaner alloc]initWithNibName:@"BarCodeScaner" bundle:nil];
    ln.str_Type=@"DeliveryLog";
    
    [self.navigationController pushViewController:ln animated:NO];
    
    /*
     if ([str_BarCode isEqualToString:@"No"]) {
     view_BarCode.hidden=NO;
     str_BarCode=@"Yes";
     
     btn_MapListt.enabled=NO;
     
     
     [UIView animateWithDuration:.25
     animations:^{
     
     if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
     {
     
     [view_BarCode2 setFrame:CGRectMake(self.view.frame.size.width-379, 328-184, view_BarCode2.frame.size.width, view_BarCode2.frame.size.height)];
     
     }
     
     else
     {
     
     [view_BarCode2 setFrame:CGRectMake(self.view.frame.size.width-186, 328-184, view_BarCode2.frame.size.width, view_BarCode2.frame.size.height)];
     
     }
     }
     ];
     }
     else
     {
     view_BarCode.hidden=YES;
     str_BarCode=@"No";
     btn_MapListt.enabled=YES;
     
     [UIView animateWithDuration:.25
     animations:^{
     
     [view_BarCode2 setFrame:CGRectMake(self.view.frame.size.width-186, 329, view_BarCode2.frame.size.width, view_BarCode2.frame.size.height)];
     }
     ];
     
     }
     
     
     // BarCodeScaner *ln = [[BarCodeScaner alloc]initWithNibName:@"BarCodeScaner" bundle:nil];
     //  [self.navigationController pushViewController:ln animated:NO];
     
     */
}
-(IBAction)btn_BarCodeScanner_Close:(id)sender
{
    
    
    
        // BarCodeScaner *ln = [[BarCodeScaner alloc]initWithNibName:@"BarCodeScaner" bundle:nil];
        //  [self.navigationController pushViewController:ln animated:NO];
}

-(IBAction)btn_RxCodeScanner:(id)sender
{
        // view_BarCode.hidden=NO;
    
    str_BarCode=@"Yes";
    
    BarCodeScaner *ln = [[BarCodeScaner alloc]initWithNibName:@"BarCodeScaner" bundle:nil];
    ln.str_Type=@"Rx";
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_DeliveryIDCodeScanner:(id)sender
{
        // view_BarCode.hidden=NO;
    
    str_BarCode=@"Yes";
    
    BarCodeScaner *ln = [[BarCodeScaner alloc]initWithNibName:@"BarCodeScaner" bundle:nil];
    ln.str_Type=@"DeliveryLog";
    
    [self.navigationController pushViewController:ln animated:NO];
}
-(IBAction)btn_POSidCodeScanner:(id)sender
{
        //view_BarCode.hidden=NO;
    
    str_BarCode=@"Yes";
    
    BarCodeScaner *ln = [[BarCodeScaner alloc]initWithNibName:@"BarCodeScaner" bundle:nil];
    ln.str_Type=@"POS";
    
    [self.navigationController pushViewController:ln animated:NO];
}




-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField ==alertTextField) {
        
        NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
            // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
        
        if ([string isEqualToString:filtered]) {
            CGFloat borderWidth = 1.0f;
            return [string isEqualToString:filtered];
            
            
                //view_name.layer.borderColor = [UIColor lightGrayColor].CGColor;
                //view_name.layer.borderWidth = borderWidth;
                //view_name.layer.cornerRadius = 3;
        }
        else
        {
            return NO;
        }
        
    }
    else
    {
        
    }
    return YES;
}
#pragma mark - Map List Button

-(IBAction)btn_ListMapScreen:(id)sender
{
        //  if ([str_tableType isEqualToString:@"Current"])
        //  {
    RouteMap *ln = [[RouteMap alloc]initWithNibName:@"RouteMap" bundle:nil];
    manage.arr_OnlineArray=arr_CurrentDelivery_sort;
    ln.str_viewType=@"List";
    [self.navigationController pushViewController:ln animated:NO];
    
    /* }
     else
     {
     RouteMap *ln = [[RouteMap alloc]initWithNibName:@"RouteMap" bundle:nil];
     manage.arr_OnlineArray=arr_DeliveredDelivery;
     ln.str_viewType=@"List";
     [self.navigationController pushViewController:ln animated:NO];
     
     }*/
    
}


#pragma mark - Network Reachability

- (void) reachabilityChanged:(NSNotification *)note
{
    Reachability* curReach = [note object];
    NSParameterAssert([curReach isKindOfClass:[Reachability class]]);
    [self updateInterfaceWithReachability:curReach];
}



- (void)updateInterfaceWithReachability:(Reachability *)reachability
{
    if (reachability == self.hostReachability)
    {
        [self reachability:reachability];
        NetworkStatus netStatus = [reachability currentReachabilityStatus];
        BOOL connectionRequired = [reachability connectionRequired];
        
            //      self.summaryLabel.hidden = (netStatus != ReachableViaWWAN);
        NSString* baseLabelText = @"";
        
        if (connectionRequired)
        {
            baseLabelText = NSLocalizedString(@"Cellular data network is available.\nInternet traffic will be routed through it after a connection is established.", @"Reachability text if a connection is required");
        }
        else
        {
            baseLabelText = NSLocalizedString(@"Cellular data network is active.\nInternet traffic will be routed through it.", @"Reachability text if a connection is not required");
        }
            //   self.summaryLabel.text = baseLabelText;
    }
    
    if (reachability == self.internetReachability)
    {
            //     [self configureTextField:self.internetConnectionStatusField imageView:self.internetConnectionImageView reachability:reachability];
    }
    
}


- (void)reachability:(Reachability *)reachability
{
    NetworkStatus netStatus = [reachability currentReachabilityStatus];
    BOOL connectionRequired = [reachability connectionRequired];
    NSString* statusString = @"";
    
    switch (netStatus)
    {
        case NotReachable:
        {
            statusString = NSLocalizedString(@"Access Not Available", @"Text field text for access is not available");
                //       imageView.image = [UIImage imageNamed:@"stop-32.png"] ;
            /*
             Minor interface detail- connectionRequired may return YES even when the host is unreachable. We cover that up here...
             */
            
            manage.str_InternetFlag=@"No";
            
            connectionRequired = NO;
            
            break;
        }
            
        case ReachableViaWWAN:
        {
            if ([manage.str_InternetFlag isEqualToString:@"Yes"]) {
                
            }
            else
            {
                statusString = NSLocalizedString(@"Reachable WWAN", @"");
                manage.str_InternetFlag=@"Yes";
                
                NSMutableArray *arrSigVal=[[NSMutableArray alloc]init];
                arrSigVal=[[DBManager getSharedInstance]retrive_DeliveredValues];
                
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                    dispatch_async(dispatch_get_main_queue(), ^{
                    });
                    
                    if (arrSigVal.count>0)
                    {
                        for ( int i=0; i<arrSigVal.count; i++)
                        {
                            
                            
                            NSMutableArray *arr_val=[[NSMutableArray alloc]init];
                                // [arr_val addObject:arrSigVal[i][@"StoreID"]];
                                //[arr_val addObject:arrSigVal[i][@"UserName"]];
                                //  [arr_val addObject:arrSigVal[i][@"Password"]];
                            [arr_val addObject:arrSigVal[i][@"Relation"]];
                            [arr_val addObject:arrSigVal[i][@"Name"]];
                            [arr_val addObject:arrSigVal[i][@"XmlTrans"]];
                            [arr_val addObject:arrSigVal[i][@"Signature"]];
                            [arr_val addObject:@"DELIVERY APP - iPhone"];
                            [arr_val addObject:@"P0$P@%m#n79@tew@%"];
                            
                            
                            
                            NSString *str_siggg=arrSigVal[i][@"Signature"];
                            NSString *str_sIDD=arrSigVal[i][@"StoreID"];
                            
                            
                            NSArray *propertyNames =[NSArray arrayWithObjects: @"Relation",@"SignedBy",@"XmlTrans",@"Signature",@"Source",@"TransactionPassword" ,nil];
                            
                            
                            NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
                            
                            NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
                            [newUserObject2 setObject:properties forKey:@"objDelivery"];
                            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
                            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                            NSString *str_service3=[NSString stringWithFormat:@"http://www.dbsuatserver.com/DigitalRxPOSPayment/POSPaymentGateway.svc/PostPOSDelivery2"];
                            
                         //   NSString *str_service3=[NSString stringWithFormat:@"http://146.148.93.102/POSPaymentGateway/POSPaymentGateway.svc/PostPOSDelivery2"];
                            
                                // str_service3=[manage.str_url stringByAppendingString:str_service3];
                            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000000];
                            [request setHTTPMethod:@"POST"];
                           // [request setValue:jsonString forHTTPHeaderField:@"json"];
                            [request setHTTPBody:jsonData];
                            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                            
                            NSError *error = nil;
                            NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                            if(data)
                            {
                                NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                
                                NSString *str_SigID=jsonArray3[@"PostPOSDelivery2Result"];
                                
                                    //NSString *str_SigID=tranID2[@"TransactionId"];
                                
                                if ([str_SigID isEqualToString:@"OK"]) {
                                        //  NSLog(@"%@",jsonArray3);
                                    
                                    
                                    
                                    
                                    NSMutableArray *arr_11=[[NSMutableArray alloc]init];
                                    [arr_11 removeAllObjects];
                                    
                                    
                                    
                                    [arr_11 addObject:arrSigVal[i][@"StoreID"]];
                                    [arr_11 addObject:arrSigVal[i][@"POSID"]];
                                    [arr_11 addObject:arrSigVal[i][@"RxID"]];
                                    [arr_11 addObject:arrSigVal[i][@"UserName"]];
                                    [arr_11 addObject:arrSigVal[i][@"CounsellingType"]];
                                    [arr_11 addObject:arrSigVal[i][@"DeliveryComments"]];
                                    [arr_11 addObject:arrSigVal[i][@"DeletedRxList"]];
                                    [arr_11 addObject:arrSigVal[i][@"UserName"]];

                                    
                                    
                                    
                                    NSArray *property_11 =[NSArray arrayWithObjects:@"StoreID",@"LogID",@"RxID",@"DeliveredBy",@"CounselType",@"DeliveryComments",@"ShippingDetailID",@"LoggedInBy", nil];
                                    
                                    
                                    NSDictionary *properties4 = [NSDictionary dictionaryWithObjects:arr_11 forKeys:property_11];
                                    
                                    NSMutableDictionary *newUserObject4 = [NSMutableDictionary dictionary];
                                    
                                    [newUserObject4 setObject:properties4 forKey:@"ObjShippingLog"];
                                    
                                    NSData *jsonData4 = [NSJSONSerialization dataWithJSONObject:newUserObject4 options:kNilOptions error:nil];
                                    NSString *jsonString4 = [[NSString alloc] initWithData:jsonData4 encoding:NSUTF8StringEncoding];
                                    NSString *str_service4=[NSString stringWithFormat:@"UpdateShippingLogDetailsByID"];
                                    str_service4=[manage.str_url stringByAppendingString:str_service4];
                                    NSMutableURLRequest *request4 = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service4] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
                                    [request4 setHTTPMethod:@"POST"];
                                   // [request4 setValue:jsonString4 forHTTPHeaderField:@"json"];
                                    [request4 setHTTPBody:jsonData4];
                                    [request4 setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                                    
                                    NSError *error4 = nil;
                                    NSURLResponse *theResponse4 = [[NSURLResponse alloc]init];
                                    NSData *data4 = [NSURLConnection sendSynchronousRequest:request4 returningResponse:&theResponse4 error:&error4];
                                    if(data4)
                                        
                                    {
                                        NSDictionary *jsonArray4 =[NSJSONSerialization JSONObjectWithData:data4 options:NSJSONReadingMutableContainers error:&error4];
                                        
                                        NSDictionary *tranID4=jsonArray4[@"UpdateShippingLogDetailsByIDResult"];
                                        
                                        NSString *str_SigID4=tranID4[@"ReturnID"];
                                        
                                        
                                    }
                                    
                                    
                                    BOOL ConditionSig=[[DBManager getSharedInstance]deleteSig:str_siggg StoreID:str_sIDD];
                                    
                                    
                                }
                                
                            }
                        }
                        
                        
                    }
                    else
                    {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                        });
                        
                    }
                });
            }
            
            break;
        }
        case ReachableViaWiFi:
        {
            if ([manage.str_InternetFlag isEqualToString:@"Yes"]) {
                
            }
            else
            {
                statusString= NSLocalizedString(@"Reachable WiFi", @"");
                    //       imageView.image = [UIImage imageNamed:@"Airport.png"];
                manage.str_InternetFlag=@"Yes";
                
                NSMutableArray *arrSigVal=[[NSMutableArray alloc]init];
                arrSigVal=[[DBManager getSharedInstance]retrive_DeliveredValues];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                    dispatch_async(dispatch_get_main_queue(), ^{
                    });
                    
                    if (arrSigVal.count>0)
                    {
                        for ( int i=0; i<arrSigVal.count; i++)
                        {
                            
                            NSMutableArray *arr_val=[[NSMutableArray alloc]init];
                                // [arr_val addObject:arrSigVal[i][@"StoreID"]];
                                //[arr_val addObject:arrSigVal[i][@"UserName"]];
                                //  [arr_val addObject:arrSigVal[i][@"Password"]];
                            [arr_val addObject:arrSigVal[i][@"Relation"]];
                            [arr_val addObject:arrSigVal[i][@"Name"]];
                            [arr_val addObject:arrSigVal[i][@"XmlTrans"]];
                            [arr_val addObject:arrSigVal[i][@"Signature"]];
                            [arr_val addObject:@"DELIVERY APP - iPhone"];
                            [arr_val addObject:@"P0$P@%m#n79@tew@%"];
                            
                            
                            
                            NSString *str_siggg=arrSigVal[i][@"Signature"];
                            NSString *str_sIDD=arrSigVal[i][@"StoreID"];
                            
                            
                            NSArray *propertyNames =[NSArray arrayWithObjects: @"Relation",@"SignedBy",@"XmlTrans",@"Signature",@"Source",@"TransactionPassword" ,nil];
                            
                            
                            NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
                            
                            NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
                            
                            [newUserObject2 setObject:properties forKey:@"objDelivery"];
                            
                            
                            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
                            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                            NSString *str_service3=[NSString stringWithFormat:@"http://www.dbsuatserver.com/DigitalRxPOSPayment/POSPaymentGateway.svc/PostPOSDelivery2"];
                            
                            
                          //  NSString *str_service3=[NSString stringWithFormat:@"http://146.148.93.102/POSPaymentGateway/POSPaymentGateway.svc/PostPOSDelivery2"];
                            
                                //  str_service3=[manage.str_url stringByAppendingString:str_service3];
                            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10000000];
                            [request setHTTPMethod:@"POST"];
                            //[request setValue:jsonString forHTTPHeaderField:@"json"];
                            [request setHTTPBody:jsonData];
                            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                            
                            NSError *error = nil;
                            NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                            if(data)
                            {
                                NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                
                                NSString *str_SigID=jsonArray3[@"PostPOSDelivery2Result"];
                                
                                    // NSString *str_SigID=tranID2[@"TransactionId"];
                                
                                if ([str_SigID isEqualToString:@"OK"]) {
                                        //    NSLog(@"%@",jsonArray3);
                                    
                                    NSMutableArray *arr_11=[[NSMutableArray alloc]init];
                                    [arr_11 removeAllObjects];
                                    
                                    
                                    
                                    [arr_11 addObject:arrSigVal[i][@"StoreID"]];
                                    [arr_11 addObject:arrSigVal[i][@"POSID"]];
                                    [arr_11 addObject:arrSigVal[i][@"RxID"]];
                                        //UserName
                                    [arr_11 addObject:arrSigVal[i][@"UserName"]];
                                    [arr_11 addObject:arrSigVal[i][@"CounsellingType"]];
                                    [arr_11 addObject:arrSigVal[i][@"DeliveryComments"]];
                                    
                                    [arr_11 addObject:arrSigVal[i][@"DeletedRxList"]];
                                    [arr_11 addObject:arrSigVal[i][@"UserName"]];
                                    
                                    
                                    NSArray *property_11 =[NSArray arrayWithObjects:@"StoreID",@"LogID",@"RxID",@"DeliveredBy",@"CounselType",@"DeliveryComments",@"ShippingDetailID",@"LoggedInBy", nil];
                                    
                                    
                                    NSDictionary *properties4 = [NSDictionary dictionaryWithObjects:arr_11 forKeys:property_11];
                                    
                                    NSMutableDictionary *newUserObject4 = [NSMutableDictionary dictionary];
                                    
                                    [newUserObject4 setObject:properties4 forKey:@"ObjShippingLog"];
                                    
                                    NSData *jsonData4 = [NSJSONSerialization dataWithJSONObject:newUserObject4 options:kNilOptions error:nil];
                                    NSString *jsonString4 = [[NSString alloc] initWithData:jsonData4 encoding:NSUTF8StringEncoding];
                                    NSString *str_service4=[NSString stringWithFormat:@"UpdateShippingLogDetailsByID"];
                                    str_service4=[manage.str_url stringByAppendingString:str_service4];
                                    NSMutableURLRequest *request4 = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service4] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
                                    [request4 setHTTPMethod:@"POST"];
                                  //  [request4 setValue:jsonString4 forHTTPHeaderField:@"json"];
                                    [request4 setHTTPBody:jsonData4];
                                    [request4 setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                                    
                                    NSError *error4 = nil;
                                    NSURLResponse *theResponse4 = [[NSURLResponse alloc]init];
                                    NSData *data4 = [NSURLConnection sendSynchronousRequest:request4 returningResponse:&theResponse4 error:&error4];
                                    if(data4)
                                    {
                                        NSDictionary *jsonArray4 =[NSJSONSerialization JSONObjectWithData:data4 options:NSJSONReadingMutableContainers error:&error4];
                                        
                                        NSDictionary *tranID4=jsonArray4[@"UpdateShippingLogDetailsByIDResult"];
                                        
                                        NSString *str_SigID4=tranID4[@"ReturnID"];
                                        
                                        
                                    }
                                    
                                    
                                    BOOL ConditionSig=[[DBManager getSharedInstance]deleteSig:str_siggg StoreID:str_sIDD];
                                    
                                }
                                
                            }
                        }
                        
                        
                    }
                    else
                    {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                            
                        });
                        
                    }
                });
            }
            
            break;
            
        }
    }
    
    if (connectionRequired)
    {
        NSString *connectionRequiredFormatString = NSLocalizedString(@"%@, Connection Required", @"Concatenation of status string with connection requirement");
        statusString= [NSString stringWithFormat:connectionRequiredFormatString, statusString];
    }
        //textField.text= statusString;
}



#pragma mark - Map View Location Update


- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
        // NSLog(@"OldLocation %f %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude);
        //  NSLog(@"NewLocation %f %f", newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    
    f_UserLocation1=newLocation.coordinate.latitude;
    f_UserLocation2=newLocation.coordinate.longitude;
    
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"AdminLogin"]length]==0)
    {
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude"];
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude"];
        
        [[NSUserDefaults standardUserDefaults]setObject:@"0.00" forKey:@"RouteDistance"];
        
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation1] forKey:@"StartLatitude1"];
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%f",f_UserLocation2] forKey:@"StartLongitude1"];
        
        [[NSUserDefaults standardUserDefaults]setObject:@"Yes" forKey:@"AdminLogin"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    else
    {
        
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (IBAction)btnSettings_Click:(id)sender {
    [self hideMenu];
}
@end
