//
//  ListOrderSortScreen.h
//  Delivery
//
//  Created by Barani Elangovan on 5/9/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListOrderSortScreen : UIViewController

@end
