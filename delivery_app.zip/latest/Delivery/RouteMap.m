//
//  RouteMap.m
//  Delivery
//
//  Created by Barani Elangovan on 4/18/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "RouteMap.h"

#import "DGActivityIndicatorView.h"


@interface RouteMap ()
{
    
    
    DGActivityIndicatorView *activityIndicatorView;
    
    
    float f_UserLocation1;
    float f_UserLocation2;
    
    float f_EndLocation1;
    float f_EndLocation2;
    
    NSString *str_TravelMode;
    
    
    NSMutableArray  *arr_Address;
    NSMutableArray *arr_lat;
    NSMutableArray *arr_lon;
    
    NSMutableArray *arr_lat1;
    NSMutableArray *arr_lon1;
    
    NSMutableArray *arr_Duration;
    
    NSMutableArray *arr_Distance;
    NSString *str_distance;
    NSString *str_PolyLine;
    
    NSMutableArray *arr_mutAddress;
    NSMutableArray *arr_mutAddressSorted;
    
    NSInteger S_location;
    
    NSInteger s_Pin;
    
    NSString *str_LocationClick;
    
    
    NSMutableArray *arr_soretedLan;
    NSMutableArray *arr_soretedLon;
    NSMutableArray *arr_soretedAddress;
    NSMutableArray *arr_sortedDistance;
    NSMutableArray *arr_flag_sort;
    NSMutableArray *arr_preference_num;
    NSMutableArray *arr_distance_addr;
    
}
@end

@implementation RouteMap

@synthesize arr_AddressMain,view_Map,view_Walk,view_Driving,mapView,str_viewType,locationManager,view_List,table_List,image_Location,btn_Location,str_ListType,view_NoData;


- (void)viewDidLoad {
    [super viewDidLoad];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        [self restrictRotation:NO];
    }
    else
    {
        
        [self restrictRotation:NO];
        
    }
    manage=[singleton share];
    
    
    arr_flag_sort=[[NSMutableArray alloc] init];
    arr_soretedLan=[[NSMutableArray alloc]init];
    arr_soretedLon=[[NSMutableArray alloc]init];
    arr_soretedAddress=[[NSMutableArray alloc]init];
    arr_sortedDistance=[[NSMutableArray alloc]init];
    
    arr_preference_num=[[NSMutableArray alloc]init];
    
    arr_distance_addr=[[NSMutableArray alloc]init];
    
    if ([str_viewType isEqualToString:@"List"]) {
        image_Location.hidden=NO;
        btn_Location.hidden=NO;
        view_List.hidden=NO;
        
        activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
        
        //CGFloat width = self.view.bounds.size.width / 5.0f;
        // CGFloat height = self.view.bounds.size.height / 5.0f;
        
        BOOL isIPhone = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone;
        BOOL isIPhone_4s = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=481.0);
        BOOL isIPhone_se = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=569.0);
        BOOL isIPhone_6s = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=668.0);
        BOOL isIPhone_6s_plus = isIPhone && ([[UIScreen mainScreen] bounds].size.height <=
                                             737);
        
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        {
            UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
            //  NSLog(@"iphone");
            if(orientation == UIInterfaceOrientationPortrait)
            {
                if (isIPhone_4s) {
                    activityIndicatorView.frame = CGRectMake(320/4,405/4, 320/2, 405/2);
                    
                }
                else if (isIPhone_se) {
                    activityIndicatorView.frame = CGRectMake((320/4),(493/4), (320/2),(493/2));
                    
                }
                
                else if (isIPhone_6s) {
                    activityIndicatorView.frame = CGRectMake((375/4),(592/4), (375/2),(592/2));
                    
                }
                else if (isIPhone_6s_plus) {
                    activityIndicatorView.frame = CGRectMake((414/4),(661/4), (414/2),(661/2));
                    
                }
                else{
                }
                
            }
            
            else if(orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight)
            {
                
            }
        }
        
        
        else
        {
            
            
            
            
        }
        
    }
    else
    {
        image_Location.hidden=YES;
        btn_Location.hidden=YES;
        view_List.hidden=YES;
        
    }
    
    
    
    arr_mutAddressSorted=[[NSMutableArray alloc]init];
    
    str_TravelMode=@"Driving";
    
    view_Driving. layer.cornerRadius =24;
    view_Driving. layer.masksToBounds =YES;
    view_Driving.layer.borderColor=[UIColor lightGrayColor].CGColor;
    view_Driving.layer.borderWidth=1;
    
    view_Walk. layer.cornerRadius =24;
    view_Walk. layer.masksToBounds =YES;
    view_Walk.layer.borderColor=[UIColor lightGrayColor].CGColor;
    view_Walk.layer.borderWidth=1;
    
    
    view_Driving.backgroundColor=[UIColor lightGrayColor];
    view_Walk.backgroundColor=[UIColor groupTableViewBackgroundColor];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
    [self.navigationController setNavigationBarHidden:YES];
    
    
    s_Pin=0;
    
    arr_AddressMain=[[NSMutableArray alloc]init];
    arr_Address=[[NSMutableArray alloc]init];
    
    NSLog(@"%lu" ,(unsigned long)manage.arr_OnlineArray.count);
    
    for (int i=0; i<manage.arr_OnlineArray.count; i++)
    {
        [arr_AddressMain addObject:[NSString stringWithFormat:@"%@, %@, %@ - %@",manage.arr_OnlineArray[i][@"PatientStreet"],manage.arr_OnlineArray[i][@"PatientCity"],manage.arr_OnlineArray[i][@"PatientState"],manage.arr_OnlineArray[i][@"Patientzip"]]];
    }
    
    NSArray *tempArr= [arr_AddressMain copy];
    
    NSInteger idx = [tempArr count] - 1;
    
    for (id object in [tempArr reverseObjectEnumerator]) {
        
        if ([arr_AddressMain indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
            [arr_AddressMain removeObjectAtIndex:idx];
        }
        idx--;
    }
    
    arr_Address=arr_AddressMain;
    
    //  arr_Address=[NSMutableArray arrayWithObjects:@"1111 S 70TH ST, APT # 340, LINCOLN, NE, USA",@"2333 NW 44TH ST, LINCOLN, NE, USA",@"103041 W DENTON RD, DENTON, NE, USA",@"6266 FRANCIS, LINCOLN, NE, USA",@"1419 AVENUE O, SCOTTSBLUFF, NE, USA",@"7200 VAN DORN ST. APT 133, LINCOLN, NE, USA",@"3110 S. 48TH STREET, BETHANY, NE, USA", nil];
    
    
    // NSLog(@"%@",arr_Address);
    
    /* for (int i=0; i<arr_Address.count; i++) {
     if ([arr_Address[i] isEqualToString:@"1116 PHOENIX DRIVE, NEBRASKA CITY, NE, USA"] || [arr_Address[i] isEqualToString:@"1111 SO 70TH STREET APT#224, LINCOLN, NE, USA"])
     {
     [arr_Address removeObjectAtIndex:i];
     
     }
     }
     */
    
    
    
    str_distance=@"no";
    str_PolyLine=@"no";
    arr_lat=[[NSMutableArray alloc]init];
    arr_lon=[[NSMutableArray alloc]init];
    arr_Duration=[[NSMutableArray alloc]init];
    arr_lat1=[[NSMutableArray alloc]init];
    arr_lon1=[[NSMutableArray alloc]init];
    
    
    arr_Distance=[[NSMutableArray alloc]init];
    arr_mutAddress=[[NSMutableArray alloc]init];
    
    self.locationManager = [[CLLocationManager alloc]init];
    self.locationManager.delegate = self;
    if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
        [self.locationManager requestAlwaysAuthorization];
    }
    
    CLAuthorizationStatus authorizationStatus= [CLLocationManager authorizationStatus];
    
    if (authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedAlways ||
        authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        [self.locationManager startUpdatingLocation];
        self.mapView.showsUserLocation = YES;
        
    }
    
    if (self.locationManager == nil)
    {
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
        self.locationManager.delegate = self;
    }
    [self.locationManager startUpdatingLocation];
    
    
    // [self.mapView setUserTrackingMode:MKUserTrackingModeFollow];
    
    if (arr_Address.count==0)
    {
        view_NoData.hidden=NO;
        [activityIndicatorView stopAnimating];
        [activityIndicatorView setHidden:YES];
        
    }
    else
    {
        [self AddressLocation];
        view_NoData.hidden=YES;
        
        
    }
    
    
}


-(void)viewWillAppear:(BOOL)animated
{
    
    CGFloat width = self.view.bounds.size.width ;
    CGFloat height = self.view.bounds.size.height;
    
    activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
    
    
    //  activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
    [self.view addSubview:activityIndicatorView];
    [activityIndicatorView startAnimating];
    
    
}
#pragma mark - Travel Mode Change Button

/*
 -(IBAction)btn_Walk:(id)sender
 {
 
 str_TravelMode=@"Walk";
 [self.mapView removeAnnotations:mapView.annotations];
 
 
 view_Driving.backgroundColor=[UIColor groupTableViewBackgroundColor];
 view_Walk.backgroundColor=[UIColor lightGrayColor];
 [self ModeChange];
 
 }
 -(IBAction)btn_Driving:(id)sender
 {
 str_TravelMode=@"Driving";
 [self.mapView removeAnnotations:mapView.annotations];
 
 view_Driving.backgroundColor=[UIColor lightGrayColor];
 view_Walk.backgroundColor=[UIColor groupTableViewBackgroundColor];
 
 [self ModeChange];
 
 }
 
 -(void)ModeChange
 {
 
 [arr_Distance removeAllObjects];
 [arr_Duration removeAllObjects];
 [arr_mutAddressSorted removeAllObjects];
 
 [self.mapView removeOverlays:self.mapView.overlays];
 
 [arr_lat1 removeAllObjects];
 [arr_lon1 removeAllObjects];
 
 
 for (int ii=0; ii<arr_Address.count; ii++)
 {
 
 MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
 
 MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
 [srcMapItem setName:@""];
 
 MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake([arr_lat[ii]floatValue], [arr_lon[ii]floatValue]) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
 
 MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
 [distMapItem setName:@""];
 
 
 MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
 [request setSource:srcMapItem];
 
 [request setDestination:distMapItem];
 if ([str_TravelMode isEqualToString:@"Walk"]) {
 
 [request setTransportType:MKDirectionsTransportTypeWalking];
 
 }
 else
 {
 [request setTransportType:MKDirectionsTransportTypeAutomobile];
 
 }
 // [request setRequestsAlternateRoutes:YES];
 
 MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
 
 [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
 //  NSLog(@"response = %@",[response destination]);
 //  NSLog(@"response = %f",[[[[response destination]placemark]location]coordinate].latitude);
 // NSLog(@"response = %f",[[[[response destination]placemark]location]coordinate].latitude);
 
 NSArray *arrRoutes = [response routes];
 [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
 
 MKRoute *route = obj;
 // NSLog(@"Rout Name : %@",route.name);
 //  NSLog(@"Total Distance (in Meters) :%f",route.distance);
 
 [arr_Distance addObject:[NSString stringWithFormat:@"%.0f",route.distance]];
 [arr_Duration addObject:[NSString stringWithFormat:@"%.0f",route.expectedTravelTime]];
 
 
 
 [arr_lat1 addObject:[NSString stringWithFormat:@"%f",[[[[response destination]placemark]location]coordinate].latitude]];
 [arr_lon1 addObject:[NSString stringWithFormat:@"%f",[[[[response destination]placemark]location]coordinate].longitude]];
 
 
 if (arr_Distance.count==arr_Address.count)
 {
 //  NSLog(@"%@",arr_Distance);
 
 NSNumber *min=[arr_Distance valueForKeyPath:@"@min.doubleValue"];
 
 for (int j=0; j<arr_Distance.count; j++)
 {
 
 //     NSLog(@"%@",min);
 //    NSLog(@"%@",arr_Distance[j]);
 
 NSString *str_min=[NSString stringWithFormat:@"%@",min];
 NSString *str_val=[NSString stringWithFormat:@"%@",arr_Distance[j]];
 
 if ([str_min isEqualToString:str_val])
 {
 
 for (int k=0; k<arr_lon1.count; k++) {
 
 float f_latt1=[arr_lat1[k]floatValue];
 float f_lon1=[arr_lon1[k]floatValue];
 
 for (int m=0; m<arr_lon1.count; m++)
 {
 if ((f_latt1 == [arr_lat[m]floatValue]) && (f_lon1 == [arr_lon[m]floatValue]) )
 {
 
 CLLocation *newLocation = [[CLLocation alloc] initWithLatitude:[arr_lat1[k]doubleValue] longitude:[arr_lon1[k]doubleValue]];
 MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
 annotation.coordinate = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
 annotation.title = arr_mutAddress[m];
 [self.mapView addAnnotation:annotation];
 
 m=arr_lat1.count;
 }
 }
 
 }
 S_location=j;
 f_EndLocation1=[arr_lat1[S_location]floatValue];
 f_EndLocation2=[arr_lon1[S_location]floatValue];
 
 j=arr_Distance.count;
 
 str_PolyLine=@"Yes";
 dispatch_async(dispatch_get_main_queue(), ^{
 [self viewMapFunction];
 });
 
 }
 
 }
 
 }
 }];
 }];
 }
 
 
 }
 */

#pragma mark - Distance Calculation Function

-(void)AddressLocation
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
        });
        
        for (int i=0; i<arr_AddressMain.count; i++)
        {
            
            NSString *address = [NSString stringWithFormat:@"%@",arr_AddressMain[i]];
            CLGeocoder *geocoder = [[CLGeocoder alloc] init];
            
            [geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error)
             {
                 
                 if(!error)
                 {
                     dispatch_async(dispatch_get_main_queue(), ^{
                         
                         //    NSLog(@"%@",placemarks);
                         //    NSLog(@"%@",address);
                         
                         CLPlacemark *placemark = [placemarks objectAtIndex:0];
                         //  NSLog(@"%f",placemark.location.coordinate.latitude);
                         //  NSLog(@"%f",placemark.location.coordinate.longitude);
                         //   NSLog(@"%@",[NSString stringWithFormat:@"%@",[placemark description]]);
                         
                         float f_lat=placemark.location.coordinate.latitude;
                         float f_lon=placemark.location.coordinate.longitude;
                         
                         arr_soretedLan=[[NSMutableArray alloc]init];
                         arr_soretedLon=[[NSMutableArray alloc]init];
                         arr_soretedAddress=[[NSMutableArray alloc]init];
                         arr_sortedDistance=[[NSMutableArray alloc]init];
                         
                         
                         [arr_lat addObject:[NSString stringWithFormat:@"%f",f_lat]];
                         [arr_lon addObject:[NSString stringWithFormat:@"%f",f_lon]];
                         [arr_mutAddress addObject:address];
                         
                         if (arr_lon.count==arr_Address.count)
                         {
                             for (int ii=0; ii<arr_Address.count; ii++)
                             {
                                 
                                 
                                 
                                 MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
                                 
                                 MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
                                 [srcMapItem setName:@""];
                                 
                                 MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake([arr_lat[ii]floatValue], [arr_lon[ii]floatValue]) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
                                 
                                 MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
                                 [distMapItem setName:@""];
                                 
                                 
                                 MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
                                 [request setSource:srcMapItem];
                                 
                                 [request setDestination:distMapItem];
                                 
                                 if ([str_TravelMode isEqualToString:@"Walk"]) {
                                     
                                     [request setTransportType:MKDirectionsTransportTypeWalking];
                                     
                                 }
                                 else
                                 {
                                     [request setTransportType:MKDirectionsTransportTypeAutomobile];
                                     
                                 }
                                 // [request setRequestsAlternateRoutes:YES];
                                 
                                 MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
                                 
                                 [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                                     //  NSLog(@"response = %@",[response destination]);
                                     //  NSLog(@"response = %f",[[[[response destination]placemark]location]coordinate].latitude);
                                     // NSLog(@"response = %f",[[[[response destination]placemark]location]coordinate].latitude);
                                     
                                     NSArray *arrRoutes = [response routes];
                                     [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                                         
                                         MKRoute *route = obj;
                                         //  NSLog(@"Rout Name : %@",route.name);
                                         //   NSLog(@"Total Distance (in Meters) :%f",route.distance);
                                         
                                         MKPolyline *line = [route polyline];
                                         
                                         [self.mapView setVisibleMapRect:[line boundingMapRect] animated:YES];
                                         
                                         // [self.mapView setVisibleMapRect:[line boundingMapRect]];
                                         
                                         
                                         [arr_Distance addObject:[NSString stringWithFormat:@"%.0f",route.distance]];
                                         [arr_Duration addObject:[NSString stringWithFormat:@"%.0f",route.expectedTravelTime]];
                                         
                                         
                                         
                                         [arr_lat1 addObject:[NSString stringWithFormat:@"%f",[[[[response destination]placemark]location]coordinate].latitude]];
                                         [arr_lon1 addObject:[NSString stringWithFormat:@"%f",[[[[response destination]placemark]location]coordinate].longitude]];
                                         
                                         
                                         if (arr_Distance.count==arr_Address.count)
                                         {
                                             
                                             [activityIndicatorView stopAnimating];
                                             [activityIndicatorView setHidden:YES];
                                             
                                             
                                             //   NSLog(@"%@",arr_Distance);
                                             
                                             NSArray *sorted1 = [arr_Distance sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
                                             
                                             
                                             //  NSLog(@"%@",sorted1);
                                             
                                             
                                             NSNumber *min=[arr_Distance valueForKeyPath:@"@min.doubleValue"];
                                             
                                             
                                             
                                             for (int k=0; k<sorted1.count; k++)
                                             {
                                                 [arr_sortedDistance addObject:sorted1[k]];
                                                 
                                             }
                                             
                                             
                                             for (int b=0; b<arr_Distance.count; b++)
                                             {
                                                 NSString *str_min=[NSString stringWithFormat:@"%@",sorted1[b]];
                                                 
                                                 for (int a=0; a<arr_Distance.count; a++) {
                                                     
                                                     NSString *str_val=[NSString stringWithFormat:@"%@",arr_Distance[a]];
                                                     if ([str_min isEqualToString:str_val])
                                                     {
                                                         [arr_soretedLan addObject:arr_lat1[a]];
                                                         [arr_soretedLon addObject:arr_lon1[a]];
                                                         
                                                     }
                                                 }
                                             }
                                             
                                             
                                             
                                             for (int c=0; c<arr_Address.count; c++)
                                             {
                                                 NSString *str_val=[NSString stringWithFormat:@"%@",arr_soretedLan[c]];
                                                 NSString *str_val1=[NSString stringWithFormat:@"%@",arr_soretedLon[c]];
                                                 
                                                 for (int a=0; a<arr_Distance.count; a++) {
                                                     
                                                     if ([str_val isEqualToString:arr_lat[a]] && [str_val1 isEqualToString:arr_lon[a]])
                                                     {
                                                         [arr_soretedAddress addObject:arr_mutAddress[a]];
                                                         
                                                         
                                                         
                                                         CLLocation *newLocation = [[CLLocation alloc] initWithLatitude:[arr_lat[a]doubleValue] longitude:[arr_lon[a]doubleValue]];
                                                         MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
                                                         annotation.coordinate = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
                                                         
                                                         NSArray *items = [arr_mutAddress[a] componentsSeparatedByString:@","];   //take the one array for split the string
                                                         NSString *str1=[items objectAtIndex:0];
                                                         NSString *str2=[NSString stringWithFormat:@"%@,%@",[items objectAtIndex:1],[items objectAtIndex:2]];
                                                         
                                                         annotation.title = str1;
                                                         annotation.subtitle=str2;
                                                         
                                                         [self.mapView addAnnotation:annotation];
                                                         
                                                         a=arr_Distance.count;
                                                         
                                                         
                                                         
                                                     }
                                                 }
                                             }
                                             
                                             [table_List reloadData];
                                             [self preference];
                                             for (int j=0; j<arr_Distance.count; j++)
                                             {
                                                 
                                                 //    NSLog(@"%@",min);
                                                 //   NSLog(@"%@",arr_Distance[j]);
                                                 
                                                 NSString *str_min=[NSString stringWithFormat:@"%@",sorted1[j]];
                                                 NSString *str_val=[NSString stringWithFormat:@"%@",arr_Distance[j]];
                                                 
                                                 if ([str_min isEqualToString:str_val])
                                                 {
                                                     
                                                     S_location=j;
                                                     
                                                     f_EndLocation1=[arr_lat1[S_location]floatValue];
                                                     f_EndLocation2=[arr_lon1[S_location]floatValue];
                                                     
                                                     j=arr_Distance.count;
                                                     
                                                     str_PolyLine=@"Yes";
                                                     dispatch_async(dispatch_get_main_queue(), ^{
                                                         [self viewMapFunction];
                                                     });
                                                     
                                                 }
                                                 
                                             }
                                             
                                         }
                                     }];
                                 }];
                             }
                             
                             
                         }
                     });
                 }
                 else
                 {
                     //   NSLog(@"%@",address);
                     dispatch_async(dispatch_get_main_queue(), ^{
                         
                         
                         for (int a=0; a<arr_Address.count; a++) {
                             
                             if ([arr_Address[a] isEqualToString:address])
                             {
                                 [arr_Address removeObjectAtIndex:a];
                                 //a=arr_Address.count;
                                 
                             }
                             if (arr_lon.count==arr_Address.count)
                             {
                                 for (int ii=0; ii<arr_Address.count; ii++)
                                 {
                                     
                                     
                                     
                                     MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
                                     
                                     MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
                                     [srcMapItem setName:@""];
                                     
                                     MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake([arr_lat[ii]floatValue], [arr_lon[ii]floatValue]) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
                                     
                                     MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
                                     [distMapItem setName:@""];
                                     
                                     
                                     MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
                                     [request setSource:srcMapItem];
                                     
                                     [request setDestination:distMapItem];
                                     
                                     if ([str_TravelMode isEqualToString:@"Walk"]) {
                                         
                                         [request setTransportType:MKDirectionsTransportTypeWalking];
                                         
                                     }
                                     else
                                     {
                                         [request setTransportType:MKDirectionsTransportTypeAutomobile];
                                         
                                     }
                                     // [request setRequestsAlternateRoutes:YES];
                                     
                                     MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
                                     
                                     [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                                         //  NSLog(@"response = %@",[response destination]);
                                         //  NSLog(@"response = %f",[[[[response destination]placemark]location]coordinate].latitude);
                                         // NSLog(@"response = %f",[[[[response destination]placemark]location]coordinate].latitude);
                                         
                                         NSArray *arrRoutes = [response routes];
                                         [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                                             
                                             MKRoute *route = obj;
                                             //  NSLog(@"Rout Name : %@",route.name);
                                             //   NSLog(@"Total Distance (in Meters) :%f",route.distance);
                                             
                                             MKPolyline *line = [route polyline];
                                             
                                             [self.mapView setVisibleMapRect:[line boundingMapRect] animated:YES];
                                             
                                             // [self.mapView setVisibleMapRect:[line boundingMapRect]];
                                             
                                             
                                             [arr_Distance addObject:[NSString stringWithFormat:@"%.0f",route.distance]];
                                             [arr_Duration addObject:[NSString stringWithFormat:@"%.0f",route.expectedTravelTime]];
                                             
                                             
                                             
                                             [arr_lat1 addObject:[NSString stringWithFormat:@"%f",[[[[response destination]placemark]location]coordinate].latitude]];
                                             [arr_lon1 addObject:[NSString stringWithFormat:@"%f",[[[[response destination]placemark]location]coordinate].longitude]];
                                             
                                             
                                             if (arr_Distance.count==arr_Address.count)
                                             {
                                                 
                                                 [activityIndicatorView stopAnimating];
                                                 [activityIndicatorView setHidden:YES];
                                                 
                                                 
                                                 //   NSLog(@"%@",arr_Distance);
                                                 
                                                 NSArray *sorted1 = [arr_Distance sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
                                                 
                                                 
                                                 //  NSLog(@"%@",sorted1);
                                                 
                                                 
                                                 NSNumber *min=[arr_Distance valueForKeyPath:@"@min.doubleValue"];
                                                 
                                                 
                                                 
                                                 for (int k=0; k<sorted1.count; k++)
                                                 {
                                                     [arr_sortedDistance addObject:sorted1[k]];
                                                     
                                                 }
                                                 
                                                 
                                                 for (int b=0; b<arr_Distance.count; b++)
                                                 {
                                                     NSString *str_min=[NSString stringWithFormat:@"%@",sorted1[b]];
                                                     
                                                     for (int a=0; a<arr_Distance.count; a++) {
                                                         
                                                         NSString *str_val=[NSString stringWithFormat:@"%@",arr_Distance[a]];
                                                         if ([str_min isEqualToString:str_val])
                                                         {
                                                             [arr_soretedLan addObject:arr_lat1[a]];
                                                             [arr_soretedLon addObject:arr_lon1[a]];
                                                             
                                                         }
                                                     }
                                                 }
                                                 
                                                 
                                                 
                                                 for (int c=0; c<arr_Address.count; c++)
                                                 {
                                                     NSString *str_val=[NSString stringWithFormat:@"%@",arr_soretedLan[c]];
                                                     NSString *str_val1=[NSString stringWithFormat:@"%@",arr_soretedLon[c]];
                                                     
                                                     for (int a=0; a<arr_Distance.count; a++) {
                                                         
                                                         if ([str_val isEqualToString:arr_lat[a]] && [str_val1 isEqualToString:arr_lon[a]])
                                                         {
                                                             [arr_soretedAddress addObject:arr_mutAddress[a]];
                                                             
                                                             
                                                             
                                                             CLLocation *newLocation = [[CLLocation alloc] initWithLatitude:[arr_lat[a]doubleValue] longitude:[arr_lon[a]doubleValue]];
                                                             MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
                                                             annotation.coordinate = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
                                                             
                                                             NSArray *items = [arr_mutAddress[a] componentsSeparatedByString:@","];   //take the one array for split the string
                                                             NSString *str1=[items objectAtIndex:0];
                                                             NSString *str2=[NSString stringWithFormat:@"%@,%@",[items objectAtIndex:1],[items objectAtIndex:2]];
                                                             
                                                             annotation.title = str1;
                                                             annotation.subtitle=str2;
                                                             
                                                             [self.mapView addAnnotation:annotation];
                                                             
                                                             a=arr_Distance.count;
                                                             
                                                             
                                                             
                                                         }
                                                     }
                                                 }
                                                 
                                                 [table_List reloadData];
                                                 [self preference];
                                                 
                                                 for (int j=0; j<arr_Distance.count; j++)
                                                 {
                                                     
                                                     //    NSLog(@"%@",min);
                                                     //   NSLog(@"%@",arr_Distance[j]);
                                                     
                                                     NSString *str_min=[NSString stringWithFormat:@"%@",sorted1[j]];
                                                     NSString *str_val=[NSString stringWithFormat:@"%@",arr_Distance[j]];
                                                     
                                                     if ([str_min isEqualToString:str_val])
                                                     {
                                                         
                                                         S_location=j;
                                                         
                                                         f_EndLocation1=[arr_lat1[S_location]floatValue];
                                                         f_EndLocation2=[arr_lon1[S_location]floatValue];
                                                         
                                                         j=arr_Distance.count;
                                                         
                                                         str_PolyLine=@"Yes";
                                                         dispatch_async(dispatch_get_main_queue(), ^{
                                                             [self viewMapFunction];
                                                         });
                                                         
                                                     }
                                                     
                                                 }
                                                 
                                                 
                                             }
                                         }];
                                     }];
                                 }
                                 
                                 
                             }
                             
                             
                         }
                         
                     });
                 }
             }
             ];
        }
    });
}

-(void)viewMapFunction
{
    // [self.mapView removeOverlays:self.mapView.overlays];
    
    
    CLLocationCoordinate2D touchMapCoordinate;
    
    CLLocationCoordinate2D userCoordinate;
    
    userCoordinate.latitude = f_UserLocation1;
    userCoordinate.longitude = f_UserLocation2;
    
    
    touchMapCoordinate.latitude = f_EndLocation1;
    touchMapCoordinate.longitude = f_EndLocation2;
    
    
    
    MKPlacemark *source = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_UserLocation1,f_UserLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
    
    MKMapItem *srcMapItem = [[MKMapItem alloc]initWithPlacemark:source];
    [srcMapItem setName:@""];
    
    MKPlacemark *destination = [[MKPlacemark alloc]initWithCoordinate:CLLocationCoordinate2DMake(f_EndLocation1, f_EndLocation2) addressDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] ];
    
    MKMapItem *distMapItem = [[MKMapItem alloc]initWithPlacemark:destination];
    [distMapItem setName:@""];
    
    
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
    [request setSource:srcMapItem];
    [request setDestination:distMapItem];
    if ([str_TravelMode isEqualToString:@"Walk"])
    {
        
        [request setTransportType:MKDirectionsTransportTypeWalking];
        
    }
    else
    {
        [request setTransportType:MKDirectionsTransportTypeAutomobile];
        
    }
    // [request setRequestsAlternateRoutes:YES];
    
    MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
    
    [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
        
        //  NSLog(@"response = %@",response);
        NSArray *arrRoutes = [response routes];
        [arrRoutes enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            
            MKRoute *route = obj;
            
            
            
            MKPolyline *line = [route polyline];
            
            //  NSLog(@"Rout Name : %@",route.name);
            //  NSLog(@"Total Distance (in Meters) :%f",route.distance);
            
            // [arr_Distance addObject:[NSString stringWithFormat:@"%f",route.distance]];
            
            
            //  [self.mapView addOverlay:line];
            
            
            // NSLog(@"Total Duration (in mins) :%f",route.expectedTravelTime);
            
            
            [arr_Duration addObject:[NSString stringWithFormat:@"%.0f",route.expectedTravelTime]];
            
            
            
            ////// EDITED FROM HERE by Kosuke //////
            NSUInteger pointCount = route.polyline.pointCount;
            
            // allocate a C array to hold this many points/coordinates...
            CLLocationCoordinate2D *routeCoordinates
            = malloc(pointCount * sizeof(CLLocationCoordinate2D));
            
            // get the coordinates (all of them)...
            [route.polyline getCoordinates:routeCoordinates
                                     range:NSMakeRange(0, pointCount)];
            
            // make line between User location and Start point
            CLLocationCoordinate2D coordinates1[2] = {userCoordinate, routeCoordinates[0]};
            MKPolyline *line1 = [MKPolyline polylineWithCoordinates:coordinates1 count:2];
            //[self.mapView addOverlay:line1];
            
            // make line between Finish point and Destination location
            CLLocationCoordinate2D coordinates2[2] = {routeCoordinates[pointCount - 1], touchMapCoordinate};
            MKPolyline *line2 = [MKPolyline polylineWithCoordinates:coordinates2 count:2];
            // [self.mapView addOverlay:line2];
            
            //free the memory used by the C array when done with it...
            free(routeCoordinates);
            
            //////////////////
            
            NSArray *steps = [route steps];
            
            // NSLog(@"Total Steps : %lu",(unsigned long)[steps count]);
            
        }];
    }];
    
}

#pragma mark - Restrict Orientation

-(void)viewDidAppear:(BOOL)animated
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        
    }
    else
    {
        
    }
    
}

-(void) restrictRotation:(BOOL) restriction
{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.restrictRotation = restriction;
}

#pragma mark - Back Button

-(IBAction)btn_Back:(id)sender
{
    if ([str_LocationClick isEqualToString:@"Yes" ])
    {
        view_List.hidden=NO;
        image_Location.hidden=NO;
        btn_Location.hidden=NO;
        str_LocationClick=@"No";
    }
    else
    {
        
        if ([manage.GPSallow isEqualToString:@"Yes"])
        {
            
        }
        else
        {
           // [self.locationManager stopUpdatingLocation];
            
        }
        
        [self.navigationController popViewControllerAnimated:NO];
    }
}


-(IBAction)btn_LocationClose:(id)sender
{
    view_List.hidden=YES;
    image_Location.hidden=YES;
    btn_Location.hidden=YES;
    str_LocationClick=@"Yes";
    
    /* [arr_lat removeAllObjects];
     [arr_lon removeAllObjects];
     
     [arr_lat1 removeAllObjects];
     [arr_lon1 removeAllObjects];
     
     [arr_Duration removeAllObjects];
     
     [arr_Distance removeAllObjects];
     
     [arr_mutAddress removeAllObjects];
     [arr_mutAddressSorted removeAllObjects];
     
     [arr_soretedLan removeAllObjects];
     [arr_soretedLon removeAllObjects];
     [arr_soretedAddress removeAllObjects];
     [arr_sortedDistance removeAllObjects];
     
     if (arr_Address.count==0)
     {
     view_NoData.hidden=NO;
     }
     else
     {
     [self AddressLocation];
     view_NoData.hidden=YES;
     
     
     }
     */
}

#pragma mark - Location update

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    // NSLog(@"OldLocation %f %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude);
    // NSLog(@"NewLocation %f %f", newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    
    f_UserLocation1=newLocation.coordinate.latitude;
    f_UserLocation2=newLocation.coordinate.longitude;
    
    //f_UserLocation1=33.659885;
    // f_UserLocation2=-117.755047;
    
    if ([str_PolyLine isEqualToString:@"Yes" ])
    {
        [self viewMapFunction];
    }
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
    CustomAnnotation *myAnnotation  = (CustomAnnotation *)view.annotation;
    //  NSLog(@"%f",myAnnotation.coordinate.latitude);
    //  NSLog(@"%f",myAnnotation.coordinate.longitude);
    
    
    f_EndLocation1=myAnnotation.coordinate.latitude;
    f_EndLocation2=myAnnotation.coordinate.longitude;
    
    [self viewMapFunction];
    
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    static NSString * const kPinAnnotationIdentifier = @"PinIdentifier";
    if(annotation == self.mapView.userLocation)
    {
        return nil;
    }
    
    
    
    CustomAnnotation *myAnnotation  = (CustomAnnotation *)annotation;
    
    
    
    MKAnnotationView *newAnnotation = (MKAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:kPinAnnotationIdentifier];
    
    if(!newAnnotation){
        newAnnotation = [[MKAnnotationView alloc] initWithAnnotation:myAnnotation reuseIdentifier:@"userloc"];
    }
    
    //NSDictionary *dict=[alertInfoArray objectAtIndex:myAnnotation.ann_tag];
    
    float f_latt=myAnnotation.coordinate.latitude;
    float f_lon=myAnnotation.coordinate.longitude;
    
    for (int i=0; i<arr_Distance.count; i++)
    {
        if ((f_latt == [arr_lat1[i]floatValue]) && (f_lon == [arr_lon1[i]floatValue]) )
        {
            s_Pin=i;
            i=arr_lat1.count;
        }
    }
    
    UIView *anView=[[UIView alloc] init];
    anView.backgroundColor=[UIColor clearColor];
    
    UILabel *lab_Distancee=[[UILabel alloc] init];
    lab_Distancee.font=[UIFont systemFontOfSize:12];
    
    lab_Distancee.textAlignment=NSTextAlignmentCenter;
    lab_Distancee.textColor=[UIColor blackColor];
    lab_Distancee.backgroundColor=[UIColor clearColor];
    float str_distancee=[arr_Distance[s_Pin]floatValue];
    float f_distance=str_distancee/1609.34;
    lab_Distancee.text=[NSString stringWithFormat:@"%.2f",f_distance];
    lab_Distancee.frame=CGRectMake(5,13,40,15);
    
    
    
    
    UILabel *lblduration=[[UILabel alloc] init];
    lblduration.font=[UIFont systemFontOfSize:10];
    lblduration.textAlignment=NSTextAlignmentCenter;
    lblduration.textColor=[UIColor blackColor];
    lblduration.backgroundColor=[UIColor clearColor];
    lblduration.text=[NSString stringWithFormat:@"Miles"];
    lblduration.frame=CGRectMake(5,28,40,15);
    
    
    
    newAnnotation.frame=CGRectMake(0, 0, 50, 140);
    anView.frame=CGRectMake(0, 0, 50, 70);
    UIImageView *bgImg=[[UIImageView alloc] init];
    bgImg.frame=CGRectMake(0, 0, 50, 70);
    bgImg.image=[UIImage imageNamed:@"ClusterAnnotation.png"];
    [anView addSubview:bgImg];
    
    [anView addSubview:lab_Distancee];
    
    [anView addSubview:lblduration];
    
    // [anView addSubview:lblSeparate];
    
    
    [newAnnotation addSubview:anView];
    
    newAnnotation.canShowCallout = YES;
    newAnnotation.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeInfoLight];
    //   newAnnotation.canShowCallout=YES;
    [newAnnotation setEnabled:YES];
    
    return newAnnotation;
    
}

#pragma mark - Polyline

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id)overlay {
    
    if ([overlay isKindOfClass:[MKPolyline class]]) {
        MKPolylineView* aView = [[MKPolylineView alloc]initWithPolyline:(MKPolyline*)overlay] ;
        aView.strokeColor = [UIColor colorWithRed:0.0/255.0 green:169.0/255.0 blue:252.0/255.0 alpha:1.0];
        aView.lineWidth = 8;
        return aView;
    }
    
    return nil;
}

#pragma mark - Apple Map Redirect function

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    
    CustomAnnotation *annotation = (CustomAnnotation *)view.annotation;
    
    //  NSLog(@"%@",annotation.title);
    //   NSLog(@"%@",annotation.subtitle);
    
    // NSLog(@"%@",annotation.coordinate.longitude);
    
    
    NSString* directionsURL = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%f,%f&dirflg=d&t=m", annotation.coordinate.latitude, annotation.coordinate.longitude];
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: directionsURL]];
    
    /*   if ([str_ListType isEqualToString:@"Delivered"])
     {
     DeliveredDetailedScreen *ln = [[DeliveredDetailedScreen alloc]initWithNibName:@"DeliveredDetailedScreen" bundle:nil];
     ln.str_addresss=[NSString stringWithFormat:@"%@,%@",annotation.title,annotation.subtitle];
     ln.str_isMapView=@"Yes";
     [self.navigationController pushViewController:ln animated:NO];
     }
     else
     {
     DetailedScreen *ln = [[DetailedScreen alloc]initWithNibName:@"DetailedScreen" bundle:nil];
     ln.str_addresss=[NSString stringWithFormat:@"%@,%@",annotation.title,annotation.subtitle];
     ln.str_isMapView=@"Yes";
     [self.navigationController pushViewController:ln animated:NO];
     }
     */
    
}



-(void)preference

{
    
    for (NSDictionary *temp1 in manage.arr_OnlineArray)
    {
        if ([temp1[@"flag"] isEqualToString:@""]||temp1[@"flag"] ==nil) {
            
            
        }
        else
        {
            
            NSMutableDictionary   *itemshowdetails1=[[NSMutableDictionary alloc]init];
            [itemshowdetails1 setValue:temp1[@"DeliveredDate"] forKey:@"DeliveredDate"];
            [itemshowdetails1 setValue:temp1[@"Dispatcher"] forKey:@"Dispatcher"];
            [itemshowdetails1 setValue:temp1[@"DrugName"] forKey:@"DrugName"];
            [itemshowdetails1 setValue:temp1[@"IsPOS"] forKey:@"IsPOS"];
            [itemshowdetails1 setValue:temp1[@"PatientCity"] forKey:@"PatientCity"];
            [itemshowdetails1 setValue:temp1[@"PatientMobile"] forKey:@"PatientMobile"];
            [itemshowdetails1 setValue:temp1[@"PatientName"] forKey:@"PatientName"];
            [itemshowdetails1 setValue:temp1[@"PatientState"] forKey:@"PatientState"];
            [itemshowdetails1 setValue:temp1[@"PatientStreet"] forKey:@"PatientStreet"];
            [itemshowdetails1 setValue:temp1[@"RxID"] forKey:@"RxID"];
            [itemshowdetails1 setValue:temp1[@"Qty"] forKey:@"Qty"];
            
            
            [itemshowdetails1 setValue:temp1[@"Patientzip"] forKey:@"Patientzip"];
            [itemshowdetails1 setValue:temp1[@"Patpay"] forKey:@"Patpay"];
            [itemshowdetails1 setValue:temp1[@"PickupDate"] forKey:@"PickupDate"];
            [itemshowdetails1 setValue:temp1[@"RxDate"] forKey:@"RxDate"];
            [itemshowdetails1 setValue:temp1[@"RxNumber"] forKey:@"RxNumber"];
            [itemshowdetails1 setValue:temp1[@"ShipLogID"] forKey:@"ShipLogID"];
            [itemshowdetails1 setValue:temp1[@"ShipNotes"] forKey:@"ShipNotes"];
            [itemshowdetails1 setValue:temp1[@"PatientCreditCardNo"] forKey:@"PatientCreditCardNo"];
            [itemshowdetails1 setValue:temp1[@"PatientCCExpMMYY"] forKey:@"PatientCCExpMMYY"];
            [itemshowdetails1 setValue:temp1[@"PatientCCCode"] forKey:@"PatientCCCode"];
            [itemshowdetails1 setValue:temp1[@"flag"] forKey:@"flag"];
            [arr_flag_sort addObject:itemshowdetails1];
            
            
        }
        
        
    }
    
    NSLog(@"%@",arr_flag_sort);
    
    NSSortDescriptor *valueDescriptor = [[NSSortDescriptor alloc] initWithKey:@"flag" ascending:YES];
    NSArray *descriptors = [NSArray arrayWithObject:valueDescriptor];
    NSArray *sortedArray = [arr_flag_sort sortedArrayUsingDescriptors:descriptors];
    
    NSMutableArray *arr_TestArr=[[NSMutableArray alloc]init];
    
    for (int i=0; i<sortedArray.count; i++)
    {
        [arr_TestArr addObject:[NSString stringWithFormat:@"%@, %@, %@ - %@",sortedArray[i][@"PatientStreet"],sortedArray[i][@"PatientCity"],sortedArray[i][@"PatientState"],sortedArray[i][@"Patientzip"]]];
    }
    
    NSArray *tempArr= [arr_TestArr copy];
    
    NSInteger idx = [tempArr count] - 1;
    
    for (id object in [tempArr reverseObjectEnumerator]) {
        
        if ([arr_TestArr indexOfObject:object inRange:NSMakeRange(0, idx)] != NSNotFound) {
            [arr_TestArr removeObjectAtIndex:idx];
        }
        idx--;
    }

    
    
    NSMutableArray *arr_distance_addr1;
    NSMutableArray *arr_distance_addr_new;
    arr_distance_addr1=[[NSMutableArray alloc] init];
    arr_distance_addr_new=[[NSMutableArray alloc] init];

    
    
    //NSMutablArray
    for (int i=0; i<arr_sortedDistance.count; i++) {
        
            float f_diiss= [arr_sortedDistance[i]floatValue]/1609.34;

    NSMutableDictionary *myDictionary =[[NSMutableDictionary alloc]init];
    
    [myDictionary setValue:arr_soretedAddress[i] forKey:@"address"];
    [myDictionary setObject:[NSString stringWithFormat:@"%f", f_diiss] forKey:@"Distance"];
        [myDictionary setObject:arr_lat[i] forKey:@"latitude"];
        [myDictionary setObject:arr_lon[i] forKey:@"longitude"];
        [arr_distance_addr addObject:myDictionary];
    }
    arr_distance_addr_new=arr_distance_addr;
    
    for (int i=1; i<=arr_soretedAddress.count; i++) {
        [arr_preference_num addObject:@""];
    }
    for (int i=1; i<=arr_TestArr.count; i++) {
        NSString *address_sort;
        
        address_sort  = arr_TestArr[i-1];
        
        
        if ([arr_soretedAddress containsObject:address_sort]) {
            [arr_soretedAddress removeObject:address_sort];
            [arr_soretedAddress insertObject:address_sort atIndex:i-1];
            //[arr_preference_num replaceObjectAtIndex:i-1 withObject:sortedArray[i-1][@"flag"]];
            //[arr_preference_num insertObject:sortedArray[i-1][@"flag"] atIndex:i-1];
            
            
        }
        
        
        
        NSLog(@"%lu",(unsigned long)arr_soretedAddress.count);
        for (int i1=1; i1<=arr_soretedAddress.count; i1++) {
            
            if([arr_distance_addr[i1-1][@"address"] isEqualToString:address_sort])
            {
                NSMutableDictionary *myDictionary1 =[[NSMutableDictionary alloc]init];
                
                [myDictionary1 setObject: arr_distance_addr[i1-1][@"address"] forKey:@"address"];
                [myDictionary1 setObject:arr_distance_addr[i1-1][@"Distance"] forKey:@"Distance"];
                [myDictionary1 setObject:arr_distance_addr[i1-1][@"latitude"] forKey:@"latitude"];
                [myDictionary1 setObject:arr_distance_addr[i1-1][@"longitude"] forKey:@"longitude"];
                [arr_distance_addr1 addObject:myDictionary1];
                [arr_distance_addr removeObjectAtIndex:i1-1];
                [arr_distance_addr insertObject:myDictionary1 atIndex:i-1];
                
                for (int c=0; c<sortedArray.count; c++) {
                    
                    if ([address_sort isEqualToString:[NSString stringWithFormat:@"%@, %@, %@ - %@",sortedArray[c][@"PatientStreet"],sortedArray[c][@"PatientCity"],sortedArray[c][@"PatientState"],sortedArray[c][@"Patientzip"]]])
                    {
                        [arr_preference_num insertObject:sortedArray[c][@"flag"] atIndex:i-1];
                        c=sortedArray.count;
                    }
                    
                    

                }
                

                
            }
            else
            {
                
            }
        }
        
    }

}
#pragma mark - TableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr_soretedAddress.count;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return nil;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *SimpletableIndentifier=@"OnlineListCellDistance";
    OnlineListCellDistance *cell = [table_List dequeueReusableCellWithIdentifier:SimpletableIndentifier];
    if (cell == nil) {
        cell = [[OnlineListCellDistance alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpletableIndentifier];
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OnlineListCellDistance" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        UIView *bgColorView = [[UIView alloc] init];
        bgColorView.backgroundColor = [UIColor colorWithRed:0/255.0f green:128/255.0f blue:255/255.0f alpha:.3f];;
        [cell setSelectedBackgroundView:bgColorView];
        //cell = [nib objectAtIndex:0];
    }
    
    if ([arr_preference_num[indexPath.row]isEqualToString:@""]) {
        cell.view_preference.hidden=YES;
    }
    else
    {
        cell.view_preference.hidden=NO;

    cell.view_preference.layer.cornerRadius=8;
    cell.lab_preference_num.text=arr_preference_num[indexPath.row];
    }/*
    cell.lab_Address.text=[NSString stringWithFormat:@"%@",arr_soretedAddress[indexPath.row]];
    if (arr_preference_num.count<=count&& arr_preference_num.count!=0) {
        
        cell.lab_preference_num.text=[NSString stringWithFormat:@"%@", arr_preference_num[indexPath.row]];

    }
     */
   // float f_diiss= [arr_sortedDistance[indexPath.row]floatValue]/1609.34;
    
    //cell.lab_Distance.text=[NSString stringWithFormat:@"%.2f Miles",f_diiss];
    
    
    cell.lab_Address.text=[NSString stringWithFormat:@"%@",arr_distance_addr[indexPath.row][@"address"]];
    cell.lab_Distance.text=[NSString stringWithFormat:@"%.2f Miles",[arr_distance_addr[indexPath.row][@"Distance"]floatValue]];
    NSString *strAdd=arr_soretedAddress[indexPath.row];
    
    float f_Cost=0.0;
    int i_count=0;
    NSString *str_Dispacher=@"";
    NSString *str_Date=@"";
    NSString *str_LogID=@"";
    
    for (int i=0; i<manage.arr_OnlineArray.count; i++)
    {
        if ([strAdd isEqualToString:[NSString stringWithFormat:@"%@, %@, %@ - %@",manage.arr_OnlineArray[i][@"PatientStreet"],manage.arr_OnlineArray[i][@"PatientCity"],manage.arr_OnlineArray[i][@"PatientState"],manage.arr_OnlineArray[i][@"Patientzip"]]]) {
            f_Cost=f_Cost+[manage.arr_OnlineArray[i][@"Patpay"]floatValue];
            
            if(i_count==0)
            {
                str_LogID=[NSString stringWithFormat:@"%@",manage.arr_OnlineArray[i][@"ShipLogID"]];
            }
            i_count=i_count+1;
        }
    }
    
    cell.lab_Cost.text=[NSString stringWithFormat:@"Total Items: %d;   Cost $: %.2f",i_count,f_Cost];
    cell.lab_ID.text=[NSString stringWithFormat:@"%@;",str_LogID] ;
    
    
    if (indexPath.row ==arr_soretedAddress.count-1)
    {
        [activityIndicatorView stopAnimating];
        activityIndicatorView.hidden=YES;
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString* directionsURL = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%f,%f&dirflg=d&t=m",[arr_soretedLan[indexPath.row]floatValue],[arr_soretedLon[indexPath.row]floatValue]];
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: directionsURL]];
    
    
    /*  if ([str_ListType isEqualToString:@"Delivered"])
     {
     DeliveredDetailedScreen *ln = [[DeliveredDetailedScreen alloc]initWithNibName:@"DeliveredDetailedScreen" bundle:nil];
     
     ln.str_addresss=arr_soretedAddress[indexPath.row];
     ln.str_isMapView=@"Yes";
     
     [self.navigationController pushViewController:ln animated:NO];
     
     }
     else
     {
     DetailedScreen *ln = [[DetailedScreen alloc]initWithNibName:@"DetailedScreen" bundle:nil];
     ln.str_addresss=arr_soretedAddress[indexPath.row];
     ln.str_isMapView=@"Yes";
     [self.navigationController pushViewController:ln animated:NO];
     }
     */
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */



/*
 
 "1111 S 70TH ST, APT # 340, LINCOLN, NE, USA",
 "2333 NW 44TH ST, LINCOLN, NE, USA",
 "103041 W DENTON RD, DENTON, NE, USA",
 "6266 FRANCIS, LINCOLN, NE, USA",
 "1419 AVENUE O, SCOTTSBLUFF, NE, USA",
 "7200 VAN DORN ST. APT 133, LINCOLN, NE, USA",
 "1116 PHOENIX DRIVE, NEBRASKA CITY, NE, USA",
 "3110 S. 48TH STREET, BETHANY, NE, USA"
 
 */



@end
