//
//  OnlineListCellDistance.h
//  Delivery
//
//  Created by Barani Elangovan on 5/9/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OnlineListCellDistance : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lab_ID;
@property(strong,nonatomic)IBOutlet UILabel *lab_Cost;
@property(strong,nonatomic)IBOutlet UILabel *lab_Address;
@property(strong,nonatomic)IBOutlet UILabel *lab_Distance;
@property(strong,nonatomic)IBOutlet UIView *view_preference;
@property(strong,nonatomic)IBOutlet UILabel *lab_preference_num;


@end
