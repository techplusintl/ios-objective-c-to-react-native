//
//  PatientProfile.h
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/3/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "singleton.h"
#import <MapKit/MapKit.h>
#import "Mapannotation.h"
#import <CoreLocation/CoreLocation.h>

@interface PatientProfile : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    singleton *manage;
}
@property(weak,nonatomic)IBOutlet MKMapView *mapView;


@property(strong,nonatomic)IBOutlet UIView *view_Phone;
@property(strong,nonatomic)IBOutlet UIView *view_Mail;
@property(strong,nonatomic)IBOutlet UIView *view_Fax;
@property(strong,nonatomic)IBOutlet UIScrollView *scroll_view;


@property(strong,nonatomic)IBOutlet UILabel *lab_Name;
@property(strong,nonatomic)IBOutlet UILabel *lab_phone;
@property(strong,nonatomic)IBOutlet UILabel *lab_DOB;
@property(strong,nonatomic)IBOutlet UILabel *lab_Sex;
@property(strong,nonatomic)IBOutlet UILabel *lab_Mail;
@property(strong,nonatomic)IBOutlet UILabel *lab_Street;
@property(strong,nonatomic)IBOutlet UILabel *lab_cityState;


@end
