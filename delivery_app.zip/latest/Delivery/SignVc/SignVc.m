//
//  SignVc.m
//  Delivery
//
//  Created by Ghanshyam on 13/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import "SignVc.h"
#import "TESignatureView.h"

@interface SignVc ()

@end

@implementation SignVc

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setUI];
}

//MARK:- CUSTOM METHODS

-(void)setUI{
    self.btnPay.layer.cornerRadius = 5.0;
    self.btnClear.layer.cornerRadius = 5.0;
    self.signtureView.layer.cornerRadius = 8.0;
    self.txtRelation.delegate = self;
    for (UIView* key in self.viewRound) {
        // do stuff
        key.layer.cornerRadius = 5.0;
        key.layer.borderColor = UIColor.lightGrayColor.CGColor;
        key.layer.borderWidth = 1.0;
    }
}

-(void)openMenu{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Select"
            message:@""
            preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *firstAction = [UIAlertAction actionWithTitle:@"Spouse"
            style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                NSLog(@"Spouse");
        self.txtRelation.text = @"Spouse";
            }];
    UIAlertAction *secondAction = [UIAlertAction actionWithTitle:@"Father"
            style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                NSLog(@"Father");
        self.txtRelation.text = @"Father";
            }];
    
    UIAlertAction *third = [UIAlertAction actionWithTitle:@"Mother"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Mother");
        self.txtRelation.text = @"Mother";
    }];
    
    UIAlertAction *fourth = [UIAlertAction actionWithTitle:@"Child"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Child");
        self.txtRelation.text = @"Child";
    }];
    
    UIAlertAction *fifth = [UIAlertAction actionWithTitle:@"Siblings"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Siblings");
        self.txtRelation.text = @"Siblings";
    }];
    
    UIAlertAction *six = [UIAlertAction actionWithTitle:@"Employee"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Employee");
        self.txtRelation.text = @"Employee";
    }];
    
    UIAlertAction *seventh = [UIAlertAction actionWithTitle:@"Life Partner"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Life Partner");
        self.txtRelation.text = @"Life Partner";
    }];
    
    UIAlertAction *eight = [UIAlertAction actionWithTitle:@"Other Relationship"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Other Relationship");
        self.txtRelation.text = @"Other Relationship";
    }];
    
    UIAlertAction *ninth = [UIAlertAction actionWithTitle:@"Self"
    style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        NSLog(@"Self");
        self.txtRelation.text = @"Self";
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel"
    style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
        NSLog(@"Cancel");
    }];
    
    [alert addAction:firstAction];
    [alert addAction:secondAction];
    [alert addAction:third];
    [alert addAction:fourth];
    [alert addAction:fifth];
    [alert addAction:six];
    [alert addAction:seventh];
    [alert addAction:eight];
    [alert addAction:ninth];
    [alert addAction:cancel];
    
   // Remove arrow from action sheet.
    [alert.popoverPresentationController setPermittedArrowDirections:0];

    //For set action sheet to middle of view.
    CGRect rect = self.view.frame;
    rect.origin.x = self.view.frame.size.width / 20;
    rect.origin.y = self.view.frame.size.height / 20;
    alert.popoverPresentationController.sourceView = self.view;
    alert.popoverPresentationController.sourceRect = rect;
    
    [self presentViewController:alert animated:YES completion:nil];
}

-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller
{
    return UIModalPresentationNone;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField == self.txtRelation)
    {
        [self openMenu];
        return false;
    }
    return true;
}

//MARK:- IBACTION METHODS

- (IBAction)btnBack_Click:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)btnClear_Click:(id)sender {
    [self.signtureView clearSignature];
}

- (IBAction)btnPay_Click:(id)sender {
    NSLog(@"%@", self.signtureView.getSignatureImage);
   
}

@end
