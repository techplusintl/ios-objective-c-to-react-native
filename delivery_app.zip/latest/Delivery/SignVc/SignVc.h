//
//  SignVc.h
//  Delivery
//
//  Created by Ghanshyam on 13/07/20.
//  Copyright © 2020 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TESignatureView.h"

NS_ASSUME_NONNULL_BEGIN

@interface SignVc : UIViewController<UITextFieldDelegate,UIPopoverPresentationControllerDelegate>

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *viewRound;
@property (weak, nonatomic) IBOutlet UITextField *txtRelation;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet TESignatureView *signtureView;
@property (weak, nonatomic) IBOutlet UIButton *btnPay;
@property (weak, nonatomic) IBOutlet UIButton *btnClear;

- (IBAction)btnBack_Click:(id)sender;
- (IBAction)btnClear_Click:(id)sender;
- (IBAction)btnPay_Click:(id)sender;


@end

NS_ASSUME_NONNULL_END
