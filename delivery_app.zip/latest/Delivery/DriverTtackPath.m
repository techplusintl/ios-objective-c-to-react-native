//
//  DriverTtackPath.m
//  Delivery
//
//  Created by Barani Elangovan on 9/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "DriverTtackPath.h"
#import "DGActivityIndicatorView.h"

@interface DriverTtackPath ()
{
    DGActivityIndicatorView *activityIndicatorView;
    NSMutableArray *arr_RouteVal;
}
@end

@implementation DriverTtackPath

@synthesize mapView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage =[singleton share];
    
    arr_RouteVal=[[NSMutableArray alloc]init];
    
    [activityIndicatorView removeFromSuperview];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
                //  NSLog(@"%@",manage.activityTypes);
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width ;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake((self.view.frame.size.width/4),(self.view.frame.size.height/4), width/2, height/2);
                // activityIndicatorView.frame = CGRectMake(100,100, 25, 25);
            [self.view addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
        });
        
        NSString *str_urrl=[NSString stringWithFormat:@"http://192.168.1.37:8085/Delivery.svc/GetDriverTrackByDateAndTimeRange/%@/%@/09/02/2017/12.00/11.00",manage.arr_storeInfoList[@"StoreID"],manage.arr_storeInfoList[@"UserID"]];
            // NSString *str_urrl=[NSString stringWithFormat:@"GetLogIn/%@/%@/%@",text_StoreNumber.text,text_UserId.text,text_Password.text];
        
        NSString *myurlString = [manage.str_url stringByAppendingString:str_urrl];
        
        
            // NSString *myurlString = [NSString stringWithFormat:@"http://192.168.0.105:8085/RxCityApp.svc/GetLogIn/%@/%@", text_UserId.text,text_Password.text];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myurlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:240.0];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            //   NSLog(@"%@",responsedata);
        
        
        if (responsedata)
        {
            
            NSDictionary *jsonArray = [NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingMutableContainers error:&err];
                //NSLog(@"%@",jsonArray);
            
            NSArray *arr_Content = jsonArray[@"POSQueueByIDResult"];
            
            
            
            if (arr_Content.count==0)
            {
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [activityIndicatorView stopAnimating];
                    
                    for (NSDictionary *temp in arr_Content)
                    {
                        
                        NSMutableDictionary   *itemshowdetails=[[NSMutableDictionary alloc]init];
                        [itemshowdetails setValue:temp[@"Price"] forKey:@"Price"];
                        [itemshowdetails setValue:temp[@"City"] forKey:@"City"];
                        [itemshowdetails setValue:temp[@"ItemID"] forKey:@"ItemID"];
                        [itemshowdetails setValue:temp[@"ItemName"] forKey:@"ItemName"];
                        
                        
                        [arr_RouteVal addObject:itemshowdetails];
                    }
                });
            }
        }
    });
    
    
    
    
    // Do any additional setup after loading the view.
}

-(IBAction)btn_back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
