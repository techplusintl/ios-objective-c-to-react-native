//
//  PatientProfile.m
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/3/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "PatientProfile.h"

@interface PatientProfile ()
{
    Mapannotation *newAnnotation;
    NSDateFormatter *Formate_DateMonthYear;
    NSDateFormatter *Formate_DateMonthYear_Service;

}
@end

@implementation PatientProfile

@synthesize lab_phone,lab_Street,lab_DOB,lab_Sex,lab_Mail,lab_Name,lab_cityState,mapView,scroll_view;

@synthesize view_Mail,view_Phone,view_Fax;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    Formate_DateMonthYear=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear setDateFormat:@"MMMM dd, yyyy"];
    
    Formate_DateMonthYear_Service=[[NSDateFormatter alloc]init];
    [Formate_DateMonthYear_Service setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];


    manage=[singleton share];
    
    view_Mail. layer.cornerRadius =28;
    view_Mail. layer.masksToBounds =YES;
    view_Mail.layer.borderColor=([UIColor whiteColor]).CGColor;
    view_Mail.layer.borderWidth=1;

    view_Phone. layer.cornerRadius =28;
    view_Phone. layer.masksToBounds =YES;
    view_Phone.layer.borderColor=([UIColor whiteColor]).CGColor;
    view_Phone.layer.borderWidth=1;
    
    view_Fax. layer.cornerRadius =28;
    view_Fax. layer.masksToBounds =YES;
    view_Fax.layer.borderColor=([UIColor whiteColor]).CGColor;
    view_Fax.layer.borderWidth=1;
    
    
    
    
    lab_Name.text=manage.arr_storeInfoList[@"PatientName"];
    
    lab_phone.text=manage.arr_storeInfoList[@"Phone"];
    lab_Mail.text=manage.arr_storeInfoList[@"EmailAddress"];
    
    if ([manage.arr_storeInfoList[@"SEX"] isEqualToString:@"F"])
    {
        lab_Sex.text=@"Female";

    }
    else if ([manage.arr_storeInfoList[@"SEX"] isEqualToString:@"M"])
    {
        lab_Sex.text=@"Male";

    }
    else
    {
        lab_Sex.text=@"Other";

    }
    
    
    
     NSLog(@"%@",manage.arr_storeInfoList[@"DOB"]);
   
    NSDate *date = [Formate_DateMonthYear_Service dateFromString:manage.arr_storeInfoList[@"DOB"]];
    
    
    NSString *str_Date=[Formate_DateMonthYear stringFromDate:date];
    
   
    
    
    
    lab_DOB.text=str_Date;
    lab_Street.text=manage.arr_storeInfoList[@"Street1"];
    
    NSString *str_Add=[manage.arr_storeInfoList[@"City"] stringByAppendingString:@", "];
    str_Add=[str_Add stringByAppendingString:manage.arr_storeInfoList[@"State"]];
    str_Add=[str_Add stringByAppendingString:@" - "];
    str_Add=[str_Add stringByAppendingString:manage.arr_storeInfoList[@"Zip"]];
    lab_cityState.text=str_Add;

    
    
    mapView.mapType = MKMapTypeStandard;
    
    NSString *address=[lab_Street.text stringByAppendingString:[NSString stringWithFormat:@", %@",manage.arr_storeInfoList[@"City"]]];
    address=[address stringByAppendingString:[NSString stringWithFormat:@", %@",manage.arr_storeInfoList[@"State"]]];
    address=[address stringByAppendingString:[NSString stringWithFormat:@" - %@",manage.arr_storeInfoList[@"Zip"]]];
    
    
    //  NSString *address = [NSString stringWithFormat:@"100 Pacifica Suite 470,Irvine,California,United States"];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error)
     {
         if(!error)
         {
             CLPlacemark *placemark = [placemarks objectAtIndex:0];
             // NSLog(@"%f",placemark.location.coordinate.latitude);
             // NSLog(@"%f",placemark.location.coordinate.longitude);
             // NSLog(@"%@",[NSString stringWithFormat:@"%@",[placemark description]]);
             
             CLLocationCoordinate2D location;
             
             location.longitude =placemark.location.coordinate.longitude;
             location.latitude =placemark.location.coordinate.latitude;
             // Add the annotation to our map view
             newAnnotation = [[Mapannotation alloc]
                              initWithTitle:@"Your Address" andCoordinate:location];
             [mapView addAnnotation:newAnnotation];
             
         }
         else
         {
             // NSLog(@"There was a forward geocoding error\n%@",[error localizedDescription]);
         }
     }
     ];
    

    // Do any additional setup after loading the view.
}
-(void)viewDidAppear:(BOOL)animated
{
    scroll_view.scrollEnabled=YES;
    scroll_view.contentSize=CGSizeMake(self.view.frame.size.width,586);
}

- (void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    MKAnnotationView *annotationView = [views objectAtIndex:0];
    id <MKAnnotation> mp = [annotationView annotation];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance
    ([mp coordinate], 500, 500);
    [mv setRegion:region animated:YES];
    [mv selectAnnotation:mp animated:YES];
    
    
}


-(IBAction)btn_Back:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
