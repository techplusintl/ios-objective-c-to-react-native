//
//  MSSCalendarDefine.h
//  Dashboard
//
//  Created by Barani Elangovan on 11/18/16.
//  Copyright © 2016 digitalRx. All rights reserved.
//


#define MSS_SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define MSS_SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
#define MSS_UTILS_COLORRGB(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define MSS_Iphone6Scale(x) ((x) * MSS_SCREEN_WIDTH / 375.0f)
#define MSS_ONE_PIXEL (1.0f / [[UIScreen mainScreen] scale])


#define MSS_titleViewColor MSS_UTILS_COLORRGB(46, 60, 73)


// DateLabel
#define MSS_TextColor MSS_UTILS_COLORRGB(53, 150, 204)
// DateLabel
#define MSS_SelectBackgroundColor MSS_UTILS_COLORRGB(40, 54, 63)
// DateLabel
#define MSS_SelectTextColor [UIColor whiteColor]
// SubLabel
#define MSS_SelectSubLabelTextColor MSS_UTILS_COLORRGB(29, 154, 180);
// SubLabel
#define MSS_SelectBeginText @""
// SubLabel
#define MSS_SelectEndText @""
#define MSS_HolidayTextColor [UIColor purpleColor]
#define MSS_WeekEndTextColor MSS_UTILS_COLORRGB(53, 150, 204)
#define MSS_TouchUnableTextColor MSS_UTILS_COLORRGB(150, 150, 150)
#define MSS_WeekViewHeight 55
#define MSS_HeaderViewLineColor [UIColor lightGrayColor]
#define MSS_HeaderViewTextColor [UIColor whiteColor]
#define MSS_HeaderViewHeight 50
#define MSS_CalendarPopViewTextColor [UIColor whiteColor]
#define MSS_CalendarPopViewBackgroundColor [UIColor blackColor]


