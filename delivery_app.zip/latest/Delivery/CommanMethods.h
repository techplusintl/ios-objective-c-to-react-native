//
//  CommanMethods.h
//  Inventory
//
//  Created by Barani Elangovan on 2/27/18.
//  Copyright © 2018 1mySOFT. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface CommanMethods : NSObject

-(NSString *) dateformate:(NSString*)inputdate ;

-(NSString *) nullHandler:(NSString*)inputVal ;

-(NSData *) serviceVal:(NSString*)inputVal;



@end
