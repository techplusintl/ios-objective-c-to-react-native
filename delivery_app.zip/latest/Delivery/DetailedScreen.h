//
//  DetailedScreen.h
//  Delivery
//
//  Created by Barani Elangovan on 5/4/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailedTableCell.h"
#import "DeliveryLocation.h"
#import "Card_payment.h"
#import "singleton.h"
@interface DetailedScreen : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>
{
    singleton *manage;
}
@property(strong,nonatomic)NSString *str_RxSearch;

@property(strong,nonatomic)IBOutlet UIView *view_Datas;

@property(strong,nonatomic)IBOutlet UITableView *table_Detaill;

@property(strong,nonatomic)NSString *str_LogID;
@property(strong,nonatomic)NSString *str_addresss;

@property(strong,nonatomic)NSString *str_isMapView;


@property(strong,nonatomic)IBOutlet UILabel *lab_Address;
@property(strong,nonatomic)IBOutlet UILabel *lab_TCount;
@property(strong,nonatomic)IBOutlet UILabel *lab_SCount;
@property(strong,nonatomic)IBOutlet UILabel *lab_TCost;
@property(strong,nonatomic)IBOutlet UILabel *lab_SCost;
@property(strong,nonatomic)IBOutlet UILabel *lab_Name;
@property(strong,nonatomic)IBOutlet UILabel *lab_Description;
@property(strong,nonatomic)IBOutlet UILabel *lab_SpetialNotes;


@property (strong,nonatomic) NSString *str_cardNumber;
@property (strong,nonatomic) NSString *str_expDate;
@property (strong,nonatomic) NSString *str_ccCode;
@property (strong,nonatomic) NSString *str_patZip;
@property (strong,nonatomic) IBOutlet UILabel *labl_araccount;

@property (strong,nonatomic) NSArray *arr_pendingRxlist;


@end
