//
//  NSString+test.h
//  uioio
//
//  Created by Barani Elangovan on 3/16/18.
//  Copyright © 2018 1mySOFT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "singleton.h"
static singleton *manage;

@interface NSString (test)

- (BOOL)PhoneNumberFormate:(NSString *)string TextFeildValue:(NSString*)TextFeildValue;
- (BOOL)NumberFormate:(NSString *)string;
- (BOOL)NameFormate:(NSString *)string;

- (NSArray *)WebserviceReturnArray:(NSString *)inputVal;

- (NSString *)ImageConversion:(NSArray *)inputVal;


- (BOOL)ValidEmailAddress:(NSString *)inputVal;

@end
