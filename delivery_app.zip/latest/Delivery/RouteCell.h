//
//  RouteCell.h
//  digitalRx Patient
//
//  Created by Barani Elangovan on 3/8/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lab_Distance;
@property(strong,nonatomic)IBOutlet UILabel *lab_Instruction;

@end
