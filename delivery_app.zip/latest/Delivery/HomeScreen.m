//
//  HomeScreen.m
//  Delivery
//
//  Created by Barani Elangovan on 5/3/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import "HomeScreen.h"

@interface HomeScreen ()

@end

@implementation HomeScreen

@synthesize view_Online,view_Upload,view_Offline,view_Download,lab_Online_icon_color,lab_Upload_icon_color,lab_Offline_icon_color,lab_Download_icon_color,sidepage,scroll_SidePage,view1,lab_DriverName,lab_PharmacyName;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    manage=[singleton share];
    
    view_Online. layer.cornerRadius =5;
    view_Online. layer.masksToBounds =YES;
    
    view_Upload. layer.cornerRadius =5;
    view_Upload. layer.masksToBounds =YES;
    
    view_Offline. layer.cornerRadius =5;
    view_Offline. layer.masksToBounds =YES;
    
    view_Download. layer.cornerRadius =5;
    view_Download. layer.masksToBounds =YES;
    
    lab_Online_icon_color. layer.cornerRadius =26;
    lab_Online_icon_color. layer.masksToBounds =YES;
    
    lab_Upload_icon_color. layer.cornerRadius =26;
    lab_Upload_icon_color. layer.masksToBounds =YES;
    
    lab_Offline_icon_color. layer.cornerRadius =26;
    lab_Offline_icon_color. layer.masksToBounds =YES;
    
    lab_Download_icon_color. layer.cornerRadius =26;
    lab_Download_icon_color. layer.masksToBounds =YES;
    
    lab_PharmacyName.text=manage.arr_storeInfoList[@"PharmacyName"];
    lab_DriverName.text=[NSString stringWithFormat:@"%@ %@",manage.arr_storeInfoList[@"UserFirstName"],manage.arr_storeInfoList[@"UserLastName"]];

    
    
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    scroll_SidePage.scrollEnabled=YES;
    scroll_SidePage.contentSize=CGSizeMake(246,642);
    
    /*  NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:0];
     [side_table selectRowAtIndexPath:indexPath animated:YES  scrollPosition:UITableViewScrollPositionBottom];*/
}


#pragma mark - sidepage view

-(IBAction)menu:(id)sender
{
    if(view1.frame.origin.x== 0) //only show the menu if it is not already shown
    {
        [self showMenu];
    }
    else
    {
        [self hideMenu];
    }
    
}
-(void)showMenu{
    
        //slide the content view to the right to reveal the menu
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [view1 setFrame:CGRectMake(sidepage.frame.size.width, view1.frame.origin.y, view1.frame.size.width, view1.frame.size.height)];
                         }
         ];
    }
    else
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [view1 setFrame:CGRectMake(sidepage.frame.size.width, view1.frame.origin.y, view1.frame.size.width, view1.frame.size.height)];
                         }
         ];
        
    }
    
}

-(void)hideMenu{
    
        //slide the content view to the left to hide the menu
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [view1 setFrame:CGRectMake(0, view1.frame.origin.y, view1.frame.size.width, view1.frame.size.height)];
                         }
         ];
    }
    else
    {
        [UIView animateWithDuration:.25
                         animations:^{
                             
                             [view1 setFrame:CGRectMake(0, view1.frame.origin.y, view1.frame.size.width, view1.frame.size.height)];
                         }
         ];
        
    }
}
-(void)hideMenuspeed{
    
        //slide the content view to the left to hide the menu
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        [UIView animateWithDuration:.0
                         animations:^{
                             
                             [view1 setFrame:CGRectMake(0, 0, view1.frame.size.width, view1.frame.size.height)];
                         }
         ];
    }
    else
    {
        [UIView animateWithDuration:.0
                         animations:^{
                             
                             [view1 setFrame:CGRectMake(0, 0, view1.frame.size.width, view1.frame.size.height)];
                         }
         ];
        
    }
}



-(void)handleSwipeLeft:(UISwipeGestureRecognizer*)recognizer{
    
    if(view1.frame.origin.x !=0)
        [self hideMenu];
}


-(void)handleSwipeRight:(UISwipeGestureRecognizer*)recognizer{
    if(sidepage.frame.origin.x ==0)
        [self hideMenu];
}
-(IBAction)btn_home:(id)sender
{
    [self hideMenu];
    
}


#pragma mark - logout


-(IBAction)sign_out:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sign Out" message:@"Do you want to sign out?"
                                                   delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Confirm", nil];
    alert.tag=999;
    [alert show];
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==999)
    {
        if (buttonIndex==0) {
        }
        else
        {
                // if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
                //  {
            
            ViewController *home = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
            [self.navigationController pushViewController:home animated:YES];
            /* }
             else
             {
             Login_view *home = [[Login_view alloc]initWithNibName:@"Login_view_ipad" bundle:nil];
             [self.navigationController pushViewController:home animated:YES];
             
             }*/
        }
    }
}


-(IBAction)btn_Online:(id)sender
{
    OnlineList *ln = [[OnlineList alloc]initWithNibName:@"OnlineList" bundle:nil];
    [self.navigationController pushViewController:ln animated:NO];
}

-(IBAction)btn_Location:(id)sender
{
    LocationFind *create_account = [[LocationFind alloc] initWithNibName:@"LocationFind" bundle:nil];
    create_account.str_IsPharmacy=@"Yes";
    [self.navigationController pushViewController:create_account animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
