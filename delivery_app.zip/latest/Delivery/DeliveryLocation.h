//
//  DeliveryLocation.h
//  Delivery
//
//  Created by Barani Elangovan on 5/5/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Mapannotation.h"
#import <CoreLocation/CoreLocation.h>
#import "CustomAnnotation.h"
#import "singleton.h"

@interface DeliveryLocation : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    singleton *manage;
}
@property(weak,nonatomic)IBOutlet MKMapView *mapView;
@property (nonatomic,strong) CLLocationManager *locationManager;

@property(strong,nonatomic)NSString *str_Address;
@property(strong,nonatomic)NSString *str_Street;
@property(strong,nonatomic)NSString *str_State;

@property(strong,nonatomic)NSString *str_PatientName;

@property(strong,nonatomic)IBOutlet UILabel *lab_PatientName;

@end
