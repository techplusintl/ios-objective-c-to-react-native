//
//  DeliveryOrderScreen.h
//  Delivery
//
//  Created by Barani Elangovan on 2/20/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Signature_screen.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "CustomAnnotation.h"

#import "DeliveryOrderSearchDownloadCell.h"

#import "Card_payment.h"

#import "AppDelegate.h"

#import "singleton.h"


#import "DeliveryOrderSearchCell.h"
#import "DetailedTableCell.h"

@interface DeliveryOrderScreen : UIViewController<CLLocationManagerDelegate>
{
    singleton *manage;
}

@property(strong,nonatomic)NSString *str_RxSearch;


@property(strong,nonatomic)NSMutableArray *arr_RxList;
@property(strong,nonatomic)NSString *str_DeliveryNumber;
@property(strong,nonatomic)IBOutlet UILabel *lab_date;

@property(strong,nonatomic)IBOutlet UITextField *text_RxNumber;
@property(strong,nonatomic)IBOutlet UITextField *text_RxNumber1;

@property(strong,nonatomic)IBOutlet UIView *view_Search;
@property(strong,nonatomic)IBOutlet UIView *view_Search1;

@property(strong,nonatomic)IBOutlet UITableView *table_RxList;

@property(strong,nonatomic)IBOutlet UILabel *lab_storeNmae;

@property(strong,nonatomic)IBOutlet UIButton *btn_Search;
@property(strong,nonatomic)IBOutlet UIButton *btn_Search1;
@property(strong,nonatomic)IBOutlet UIButton *btn_Clear;

@property(strong,nonatomic)IBOutlet UILabel *lab_RxNumLine;
@property(strong,nonatomic)IBOutlet UILabel *lab_DelNumLine;
@property(strong,nonatomic)IBOutlet UILabel *lab_POSNumLine;

@property(strong,nonatomic)IBOutlet UILabel *lab_TextHint;
@property(strong,nonatomic)IBOutlet UIView *view_activity;



@property(strong,nonatomic)IBOutlet UILabel *lab_PName;
@property(strong,nonatomic)IBOutlet UILabel *lab_Address;
@property(strong,nonatomic)IBOutlet UILabel *lab_Phone;



@end
