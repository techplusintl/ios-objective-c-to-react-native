//
//  Signature_screen.h
//  Delivery_offline
//
//  Created by Barani Elangovan on 16/03/17.
//  Copyright © 2017 digitalRx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PJRSignatureView.h"
#import "OnlineList.h"
#import "singleton.h"

#import <CoreLocation/CoreLocation.h>

@interface Signature_screen : UIViewController<UITextFieldDelegate,CLLocationManagerDelegate,UIAlertViewDelegate,UIActionSheetDelegate >

{
      PJRSignatureView *signatureView;
        CGFloat animatedDistance;
      singleton *manage;
}

@property(strong,nonatomic)NSString *str_PaymentType;

@property (nonatomic,strong) CLLocationManager *locationManager;

@property(strong,nonatomic)NSString *str_RxSearch;

@property(strong,nonatomic)NSMutableArray *arr_RxNumberr;
@property(strong,nonatomic)NSMutableArray *arr_RxPrice;
@property(strong,nonatomic)NSMutableArray *arr_RxID;
@property(strong,nonatomic)NSMutableArray *arr_del_Qty;

@property(strong,nonatomic)NSMutableArray *arr_HipaaSigID;
@property(strong,nonatomic)NSMutableArray *arr_HipaaSig;
@property(strong,nonatomic)NSMutableArray *arr_PatientID;
@property(strong,nonatomic)NSMutableArray *arr_BalanceAmount;
@property(strong,nonatomic)NSMutableArray *arr_RxARItemID;


@property(strong,nonatomic)NSString *str_PatientAddresss;

@property(strong,nonatomic)NSString *str_PatientName;
@property(strong,nonatomic)NSString *str_IsPOS;
@property(strong,nonatomic)NSString *str_POSID;

@property(strong,nonatomic)NSString *str_TotalTender;
@property(strong,nonatomic)NSString *str_PayType;
@property(strong,nonatomic)NSString *str_RefNumber;



@property(strong,nonatomic)NSString *str_CCNumber;
@property(strong,nonatomic)NSString *str_ExpDate;
@property(strong,nonatomic)NSString *str_CVV;
@property(strong,nonatomic)NSString *str_ZipCode;

@property(strong,nonatomic)NSString *str_CCNumber1;
@property(strong,nonatomic)NSString *str_ExpDate1;
@property(strong,nonatomic)NSString *str_CVV1;
@property(strong,nonatomic)NSString *str_ZipCode1;


@property(strong,nonatomic)NSString *str_street;
@property(strong,nonatomic)NSString *str_city;
@property(strong,nonatomic)NSString *str_state;


@property(strong,nonatomic)IBOutlet UIView *view_PaymentConfirm;
@property(strong,nonatomic)IBOutlet UIButton *btn_payConfirmation;
@property(strong,nonatomic)IBOutlet UILabel *lab_deliveredCount;

@property(strong,nonatomic)NSString *str_Cash;
@property(strong,nonatomic)NSString *str_checks;
@property(strong,nonatomic)NSString *str_ccard;
@property(strong,nonatomic)NSString *str_CCAuth;
@property(strong,nonatomic)NSString *str_CCTranID;
@property(strong,nonatomic)NSString *str_CardIssuer;
@property(strong,nonatomic)NSString *str_CCardNumber;
    //@property(strong,nonatomic)NSString *str_DriverName;
@property(strong,nonatomic)NSString *str_Comments;



@property(strong,nonatomic)IBOutlet UITextField *txt_name;
@property(strong,nonatomic)IBOutlet UITextField *txt_relation;
@property(strong,nonatomic)IBOutlet UIButton *btn_sig_clear;
@property(strong,nonatomic)IBOutlet UIButton *btn_sig_download;
@property(strong,nonatomic) NSString *str_internet;
@property(strong,nonatomic)IBOutlet UIButton *btn_pay_online;
@property(strong,nonatomic)NSString *str_logid;
@property(strong,nonatomic)IBOutlet UIView *view_name;
@property(strong,nonatomic)IBOutlet UIView *view_relation;
@property(strong,nonatomic)IBOutlet UIView *view_offline_alert;
@property(strong,nonatomic)IBOutlet UIButton *btn_back;
@property(strong,nonatomic)IBOutlet UIView *view_activityView;

@property(weak,nonatomic)IBOutlet UIView *view_signature;
@property(strong,nonatomic)IBOutlet UIImageView *img_rotate;
@property(strong,nonatomic)IBOutlet UIView *view_sig;
@property(strong,nonatomic)IBOutlet UIView *view_activity;

@property(strong,nonatomic)NSString *str_pat_email;

@end
