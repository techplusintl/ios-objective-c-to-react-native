    //
    //  NSString+test.m
    //  uioio
    //
    //  Created by Barani Elangovan on 3/16/18.
    //  Copyright © 2018 1mySOFT. All rights reserved.
    //

#import "NSString+test.h"
NSDateFormatter *Formate_Date;
NSDateFormatter *Formate_ReturnDate;
@implementation NSString (test)

- (BOOL)NumberFormate:(NSString *)string
{
    NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
    if ([string isEqualToString:filtered]) {
        return YES;
    }
    else
    {
        return NO;
    }
}
- (BOOL)FloatValueFormate:(NSString *)string
{
    NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789."]invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
    if ([string isEqualToString:filtered]) {
        return YES;
    }
    else
    {
        return NO;
    }
}
- (BOOL)ZipCodeFormate:(NSString *)string TextFeildValue:(NSString*)TextFeildValue
{
    NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
    if ([string isEqualToString:filtered]) {
        if(string.length!=0){
            if (TextFeildValue.length < 6)
            {
                return YES;
            }
            else
            {
                return NO;
            }
        }
        else
        {
            return YES;
        }
    }
    else
    {
        return NO;
    }
}
- (BOOL)NameFormate:(NSString *)string
{
    NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"]invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
    if ([string isEqualToString:filtered]) {
        return YES;
    }
    else
    {
        return NO;
    }
}
/*
- (BOOL)PhoneNumberFormate:(NSString *)string TextFeildValue:(NSString*)TextFeildValue
{
    manage=[singleton share];
    NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
    if ([string isEqualToString:filtered]) {
        if(string.length!=0){
            if (TextFeildValue.length == 0)
            {
                TextFeildValue = [NSString stringWithFormat:@"(%@",TextFeildValue];
                manage.str_TextFieldValue=TextFeildValue;
                return YES;
            }
            if (TextFeildValue.length == 4)
            {
                TextFeildValue = [NSString stringWithFormat:@"%@) ",TextFeildValue];
                manage.str_TextFieldValue=TextFeildValue;
                return YES;
            }
            if (TextFeildValue.length == 9)
            {
                TextFeildValue = [NSString stringWithFormat:@"%@-",TextFeildValue];
                manage.str_TextFieldValue=TextFeildValue;
                return YES;
            }
            if (TextFeildValue.length>13){
                manage.str_TextFieldValue=TextFeildValue;
                return NO;
            }
            manage.str_TextFieldValue=TextFeildValue;
        }
        else{
            if (TextFeildValue.length == 2)
                TextFeildValue=[TextFeildValue stringByReplacingOccurrencesOfString:@"(" withString:@""];
            
            if (TextFeildValue.length == 7)
                TextFeildValue=[TextFeildValue stringByReplacingOccurrencesOfString:@") " withString:@""];
            
            if (TextFeildValue.length == 11)
                TextFeildValue=[TextFeildValue stringByReplacingOccurrencesOfString:@"-" withString:@""];
            manage.str_TextFieldValue=TextFeildValue;
            return YES;
        }
        return YES;
    }
    else
    {
        return NO;
    }
}*/
- (NSArray *)WebserviceReturnArray:(NSString *)inputVal
{
    NSArray *dataArr;
    NSMutableArray *arr_val=[[NSMutableArray alloc]init];
    [arr_val removeAllObjects];
    [arr_val addObject:inputVal];
    NSArray *propertyNames =[NSArray arrayWithObjects:@"JsonString",nil];
    NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:properties options:kNilOptions error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *str_service=[NSString stringWithFormat:@"http://192.168.1.21/1myPOS_Mob/api/GenericAPI/CommonServicewithobject"];
        // str_service=[manage.str_url stringByAppendingString:str_service];
    NSMutableURLRequest *request= [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service]];
    [request setHTTPMethod:@"POST"];
    [request setValue:jsonString forHTTPHeaderField:@"json"];
    [request setHTTPBody:jsonData];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSError *error = nil;
    NSURLResponse *theResponse = [[NSURLResponse alloc]init];
    NSData *responsedata = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
    if(responsedata)
    {
        NSMutableDictionary *dict=[NSJSONSerialization JSONObjectWithData:responsedata options:NSJSONReadingAllowFragments error:nil];
        
        NSString *ststr=[NSString stringWithFormat:@"%@",dict];
        
        NSMutableDictionary *dict1=[NSJSONSerialization JSONObjectWithData:[ststr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        
        dataArr = [dict1 valueForKey:@"Table"];
        return dataArr;
    }
    else
    {
        return dataArr;
    }
    
}
- (BOOL)ValidEmailAddress:(NSString *)inputVal
{
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,10}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    
    if ([emailTest evaluateWithObject:inputVal] == NO)
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

- (NSString *)DateFormate:(NSString*)inputdate {
    
    Formate_Date=[[NSDateFormatter alloc]init];
    [Formate_Date setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
    Formate_ReturnDate=[[NSDateFormatter alloc]init];
    [Formate_ReturnDate setDateFormat:@"MMM dd, yyyy"];
    NSDate *date_InputDate=[Formate_Date dateFromString:inputdate];
    NSString *str_InputDate=[Formate_ReturnDate stringFromDate:date_InputDate];
    
    if (str_InputDate.length==0) {
        str_InputDate=@"-";
    }
    
    return str_InputDate;
}
-(NSString *) nullHandler:(NSString*)inputVal
{
    NSString *str_OutData;
    if ([inputVal isEqual:[NSNull null]]) {
        str_OutData=@"";
    }
    else
    {
        str_OutData=inputVal;
    }
    return str_OutData;
}

- (NSString *)ImageConversion:(NSArray *)inputVal
{
    NSInteger c = inputVal.count;
    uint8_t *bytes = malloc(sizeof(*bytes) * c);
    unsigned i;
    for (i = 0; i < c; i++)
    {
        NSString *str = [inputVal objectAtIndex:i];
        int byte = [str intValue];
        bytes[i] = (uint8_t)byte;
    }
    
    NSString *strBase64=[[NSString alloc] initWithBytes:bytes
                                                 length:c
                                               encoding:NSUTF8StringEncoding];
    return strBase64;
}



@end
