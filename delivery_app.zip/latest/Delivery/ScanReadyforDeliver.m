//
//  ScanReadyforDeliver.m
//  Delivery
//
//  Created by Rex on 19/02/19.
//  Copyright © 2019 digitalRx. All rights reserved.
//

#import "ScanReadyforDeliver.h"
#import "DGActivityIndicatorView.h"


static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
@interface ScanReadyforDeliver ()
{
    NSString *str_ScanCount;
    NSString *str_Scan;
    NSString *str_Flash;
    NSString *str_StoreID;
    DGActivityIndicatorView *activityIndicatorView;

}
@property(strong,nonatomic)NSString *str_Code;
@property(strong,nonatomic)NSString *str_Code_Copy;
@end

@implementation ScanReadyforDeliver
@synthesize btn_Scann,image_Flash,scanner,previewView,view_previewOut,str_Code,str_Code_Copy,str_Type,view_activity,txt_searchRx;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    str_Scan=@"No";
    str_Flash=@"No";
    str_Type=@"LogID";
    manage=[singleton share];
    str_StoreID=[NSString stringWithFormat:@"%d",[manage.arr_storeInfoList[@"StoreID"]intValue]];

    view_activity.hidden = YES;
    view_previewOut.hidden = NO;
    [MTBBarcodeScanner requestCameraPermissionWithSuccess:^(BOOL success) {
        if (success) {
            
            btn_Scann.hidden=NO;
            [self startScanning];
            
        } else {
            btn_Scann.hidden=YES;
            [self displayPermissionMissingAlert];
        }
    }];
    
    
    btn_Scann. layer.cornerRadius =3;
    btn_Scann. layer.masksToBounds =YES;
    // Do any additional setup after loading the view from its nib.
}


#pragma mark - Barcode Scanner Functions

- (MTBBarcodeScanner *)scanner {
    if (!scanner) {
        scanner = [[MTBBarcodeScanner alloc] initWithPreviewView:previewView];
    }
    return scanner;
}

#pragma mark - Scanning

- (void)startScanning {
    
    
    /* [self.scanner startScanningWithResultBlock:^(NSArray *codes) {
     
     }];
     */
    [self.scanner startScanningWithResultBlock:^(NSArray *codes) {
        self.uniqueCodes = [[NSMutableArray alloc] init];
        
        if ([str_Scan isEqualToString:@"No"])
        {
            btn_Scann.hidden=NO;
            
        }
        else
        {
            btn_Scann.hidden=YES;
            
            for (AVMetadataMachineReadableCodeObject *code in codes) {
                if (code.stringValue && [self.uniqueCodes indexOfObject:code.stringValue] == NSNotFound) {
                    [self.uniqueCodes addObject:code.stringValue];
                    
                    // NSLog(@"Found unique code: %@", code.stringValue);
                    
                    
                    str_Code= code.stringValue;
                    str_Code_Copy=code.stringValue;
                    
                }
            }
            
            
            
            if (![str_Code isEqualToString:@""])
            {
                if ([str_ScanCount isEqualToString:@"One"])
                {
                    str_ScanCount=@"Two";
                    btn_Scann.hidden=NO;
                    str_Code=@"";
                    str_Scan=@"No";
                 //   lab_Code.text=str_Code_Copy;
                    
                    
                    if ([str_Type isEqualToString:@"Rx"]) {
                    }
                    else
                    {
                        view_activity.hidden=NO;
                        [activityIndicatorView removeFromSuperview];
                        
                        
                        // [self.scanner stopScanning];
                        
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                            dispatch_async(dispatch_get_main_queue(), ^{
                                
                                activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
                                
                                CGFloat width = self.view.bounds.size.width;
                                CGFloat height = self.view.bounds.size.height;
                                
                                activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
                                
                                [self.view_activity addSubview:activityIndicatorView];
                                [activityIndicatorView startAnimating];
                                
                            });
                            NSMutableArray *arr_val=[[NSMutableArray alloc]init];
                            [arr_val addObject:str_StoreID];
                            [arr_val addObject:str_Code_Copy];
                            [arr_val addObject:manage.arr_storeInfoList[@"UserFirstName"]];
                            
                            NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"LoggedInBy" ,nil];
                            
                            NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
                            
                            NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
                            
                            [newUserObject2 setObject:properties forKey:@"ObjDeliveryFlag"];
                            
                            
                            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
                            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                            NSString *str_service3=[NSString stringWithFormat:@"UpdateOutForDeliveryFlag"];
                            str_service3=[manage.str_url stringByAppendingString:str_service3];
                            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
                            [request setHTTPMethod:@"POST"];
                            [request setValue:jsonString forHTTPHeaderField:@"json"];
                            [request setHTTPBody:jsonData];
                            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
                            
                            NSError *error = nil;
                            NSURLResponse *theResponse = [[NSURLResponse alloc]init];
                            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
                            if(data)
                            {
                                NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                
                                NSDictionary *tranID2=jsonArray3[@"UpdateOutForDeliveryFlagResult"];
                                
                                NSString *str_SigID=tranID2[@"ReturnID"];
                                
                                if (str_SigID.intValue>0) {
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        self.view_previewOut.hidden = NO;
                                        self.txt_searchRx.text = @"";
                                        self.view_activity.hidden=YES;
                                        [activityIndicatorView stopAnimating];
                                        activityIndicatorView.hidden=YES;
                                    });
                                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Update Successfully!" preferredStyle:UIAlertControllerStyleAlert];
                                    
                                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                                    [alertController addAction:ok];
                                    
                                    [self presentViewController:alertController animated:YES completion:nil];
                                }
                                else{
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        self.view_previewOut.hidden = NO;
                                        self.txt_searchRx.text = @"";
                                        self.view_activity.hidden=YES;
                                        [activityIndicatorView stopAnimating];
                                        activityIndicatorView.hidden=YES;
                                    });
                                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Update Failed!" preferredStyle:UIAlertControllerStyleAlert];
                                    
                                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                                    [alertController addAction:ok];
                                    
                                    [self presentViewController:alertController animated:YES completion:nil];
                                }
                                
                            }
                            
                        });
                        
                        //cancel clicked ...do your action
                    }
                }
            }
            
            
        }
        
    }];
    
}

-(void)Update_OutforDelivery
{
    
    view_activity.hidden=NO;
    [activityIndicatorView removeFromSuperview];
    NSString *strsearchRx=txt_searchRx.text;

    
    // [self.scanner stopScanning];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            
            activityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:(DGActivityIndicatorAnimationType)[manage.activityTypes[0] integerValue] tintColor:[UIColor colorWithRed:51/255.0f green:153/255.0f blue:204/255.0f alpha:1.0f]];
            
            CGFloat width = self.view.bounds.size.width;
            CGFloat height = self.view.bounds.size.height;
            
            activityIndicatorView.frame = CGRectMake(self.view.frame.size.width/4,self.view.frame.size.height/4, width/2, height/2);
            
            [self.view_activity addSubview:activityIndicatorView];
            [activityIndicatorView startAnimating];
            
        });
        NSMutableArray *arr_val=[[NSMutableArray alloc]init];
        [arr_val addObject:str_StoreID];
        [arr_val addObject:strsearchRx];
        [arr_val addObject:manage.arr_storeInfoList[@"UserFirstName"]];
        
        NSArray *propertyNames =[NSArray arrayWithObjects:@"StoreID",@"LogID", @"LoggedInBy" ,nil];
        
        NSDictionary *properties = [NSDictionary dictionaryWithObjects:arr_val forKeys:propertyNames];
        
        NSMutableDictionary *newUserObject2 = [NSMutableDictionary dictionary];
        
        [newUserObject2 setObject:properties forKey:@"ObjDeliveryFlag"];
        
        
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:newUserObject2 options:kNilOptions error:nil];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *str_service3=[NSString stringWithFormat:@"UpdateOutForDeliveryFlag"];
        str_service3=[manage.str_url stringByAppendingString:str_service3];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str_service3] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100000];
        [request setHTTPMethod:@"POST"];
        [request setValue:jsonString forHTTPHeaderField:@"json"];
        [request setHTTPBody:jsonData];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
        NSError *error = nil;
        NSURLResponse *theResponse = [[NSURLResponse alloc]init];
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&error];
        if(data)
        {
            NSDictionary *jsonArray3 =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
            
            NSDictionary *tranID2=jsonArray3[@"UpdateOutForDeliveryFlagResult"];
            
            NSString *str_SigID=tranID2[@"ReturnID"];
            
            if (str_SigID.intValue>0) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.txt_searchRx.text = @"";
                 //   btn_Scann.hidden=NO;
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    activityIndicatorView.hidden=YES;
                });
              //  self.view_previewOut.hidden = NO;
              //  btn_Scann.hidden=NO;
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Update Successfully!" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
            }
            else{
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    self.txt_searchRx.text = @"";
                    self.view_activity.hidden=YES;
                    [activityIndicatorView stopAnimating];
                    activityIndicatorView.hidden=YES;
                });
            //    self.view_previewOut.hidden = NO;
            //    btn_Scann.hidden=NO;
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Update Failed!" preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:ok];
                
                [self presentViewController:alertController animated:YES completion:nil];
            }
            
        }
        
    });
    
    //cancel clicked ...do your action
}

- (void)displayPermissionMissingAlert {
    NSString *message = nil;
    if ([MTBBarcodeScanner scanningIsProhibited]) {
        message = @"This app does not have permission to use the camera.";
    } else if (![MTBBarcodeScanner cameraIsPresent]) {
        message = @"This device does not have a camera.";
    } else {
        message = @"An unknown error occurred.";
    }
    
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)btn_Scann:(id)sender
{
    str_Scan=@"Yes";
    str_ScanCount=@"One";
    btn_Scann.hidden=YES;
    view_previewOut.hidden = YES;
    [MTBBarcodeScanner requestCameraPermissionWithSuccess:^(BOOL success) {
        if (success) {
            
            btn_Scann.hidden=YES;
            [self startScanning];
            
        } else {
            btn_Scann.hidden=YES;
            [self displayPermissionMissingAlert];
        }
    }];
   // previewView.hidden = NO;
}

- (IBAction)btn_SearchLog:(id)sender
{
    if ([txt_searchRx.text isEqualToString:@""]) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Alert" message:@"LogID is Empty!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else{
        [self.scanner stopScanning];
        self.view_previewOut.hidden = NO;
        self.btn_Scann.hidden = NO;
        [[self view] endEditing:YES];
        [self Update_OutforDelivery];
    }
    
}


-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField ==txt_searchRx) {
        
        NSCharacterSet *acceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"]invertedSet];
        // NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:acceptedInput] componentsJoinedByString:@""];
        
        if ([string isEqualToString:filtered]) {
            if(string.length!=0){
                if ([string isEqualToString:@"."]) {
                    if ([txt_searchRx.text containsString:@"."]) {
                        return NO;
                    }
                    else
                    {
                        return YES;
                    }
                }
                else
                {
                    return YES;
                    
                }
                
            }
            else
            {
                return YES;
            }
        }
        
        return [string isEqualToString:filtered];
        
    }
    else
    {
        return YES;
    }
}

- (IBAction)btn_Flash:(id)sender {
    
    if ([str_Flash isEqualToString:@"No"])
    {
        str_Flash=@"Yes";
        
        image_Flash.image=[UIImage imageNamed:@"Flash Off-64.png"];
        
        self.scanner.torchMode = MTBTorchModeOn;
        
    }
    else
    {
        image_Flash.image=[UIImage imageNamed:@"Flash On-64.png"];
        
        self.scanner.torchMode = MTBTorchModeOff;
        
        str_Flash=@"No";
    }
    
}

#pragma mark - Back Button

-(IBAction)btn_Back:(id)sender
{
    
    self.scanner.torchMode = MTBTorchModeOff;
    
    
    [self.navigationController popViewControllerAnimated:NO];
}


#pragma mark - Textfield

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[self view] endEditing:YES];
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    
    animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
